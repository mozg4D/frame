// Focused CPU qualification only. Deliberately does not invoke the repository
// standard/stress runner (which currently exercises Unite), a browser or a GPU.
import {readFile,readdir,mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {resolve,relative,join} from 'node:path';
const root=resolve(fileURLToPath(new URL('../../../',import.meta.url))),cfd=join(root,'plugins/cfd');
async function files(dir){const out=[];for(const entry of await readdir(dir,{withFileTypes:true})){const path=join(dir,entry.name);if(entry.isDirectory()&&entry.name!=='validation-results')out.push(...await files(path));else if(entry.isFile()&&entry.name.endsWith('.mjs'))out.push(path);}return out.sort();}
const sources=async()=>Object.fromEntries(await Promise.all([join(root,'index.html'),...await files(cfd)].map(async path=>[relative(root,path).replaceAll('\\','/'),createHash('sha256').update(await readFile(path)).digest('hex')])));
const report={started:new Date().toISOString(),node:process.version,backend:'cpu-reference-only',hardwareGPUValidated:false,nativeSpaceTimeCouplingValidated:false,solverReady:false,standardStressExecuted:false,standardStressReason:'Current no-Unite instruction; broad repository runner includes Unite.',sources:await sources(),stages:[]};
const standalone=(await readdir(join(cfd,'tests'))).filter(n=>n.endsWith('.test.mjs')).sort().map(n=>`plugins/cfd/tests/${n}`);
const syntaxFiles=['plugins/cfd/tetra-spacetime.mjs','plugins/cfd/tetra-spacetime-integer.mjs','plugins/cfd/tests/tetra-spacetime.test.mjs','plugins/cfd/tests/tetra-spacetime-integer.test.mjs','plugins/cfd/tests/spacetime-reference-gate.mjs'];
const stages=[['foundation',['plugins/cfd/tests/run.mjs']],['standalone',['--test','--test-reporter=tap',...standalone]],...syntaxFiles.map(path=>['syntax:'+path,['--check',path]])];
for(const [name,args] of stages){
  const started=performance.now(),result=spawnSync(process.execPath,args,{cwd:root,encoding:'utf8',timeout:120000,maxBuffer:32*1024*1024});
  const stage={name,exitCode:result.status,signal:result.signal,error:result.error?.message||null,completedOperationMs:performance.now()-started,stdout:result.stdout||'',stderr:result.stderr||''};
  if(name==='foundation'&&result.status===0){const parsed=JSON.parse(stage.stdout);stage.checks=parsed.checks.length;stage.pass=parsed.pass;}
  else if(name==='standalone'&&result.status===0){stage.checks=Number(stage.stdout.match(/^# tests (\d+)$/m)?.[1]);stage.pass=stage.checks>0&&/^# fail 0$/m.test(stage.stdout);}
  else stage.pass=result.status===0;
  report.stages.push(stage);if(!stage.pass)break;
}
report.sourcesAfter=await sources();report.sourcesUnchanged=JSON.stringify(report.sources)===JSON.stringify(report.sourcesAfter);
report.pass=report.sourcesUnchanged&&report.stages.length===stages.length&&report.stages.every(s=>s.pass);
report.finished=new Date().toISOString();const destination=join(cfd,'validation-results',`spacetime-reference-${report.started.replaceAll(/[:.]/g,'-')}.json`);
await mkdir(resolve(destination,'..'),{recursive:true});await writeFile(destination,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({pass:report.pass,report:relative(root,destination),sourcesUnchanged:report.sourcesUnchanged,stages:report.stages.map(({name,pass,checks,completedOperationMs,error})=>({name,pass,checks,completedOperationMs,error})),hardwareGPUValidated:false},null,2));
process.exitCode=report.pass?0:1;
