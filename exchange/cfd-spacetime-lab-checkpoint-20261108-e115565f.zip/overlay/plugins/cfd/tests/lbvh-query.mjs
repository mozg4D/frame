import {planBVHQuery,queryBVHLinks,bvhCutLinkShader} from '../lbvh-query.mjs';
import {cutLinkShader} from '../cut-link-gpu.mjs';
import {planTopology,buildMortonTopology} from '../lbvh-topology.mjs';
import {sampleCutLinks} from '../cut-links.mjs';
const limits={maxStorageBufferBindingSize:128*1024*1024,maxBufferSize:256*1024*1024,maxComputeWorkgroupsPerDimension:65535,maxComputeInvocationsPerWorkgroup:256,maxComputeWorkgroupSizeX:256,maxUniformBufferBindingSize:65536,minUniformBufferOffsetAlignment:256};
export function queryChecks(){
 const checks=[],timings=[],start=performance.now(),check=(name,pass)=>{checks.push({name:`LBVH query plan: ${name}`,pass:!!pass});if(!pass)throw Error(name);};
 try{
  const narrow=cutLinkShader.slice(cutLinkShader.indexOf('  let t=triangles[j]'),cutLinkShader.lastIndexOf('\n }'));
  check('exact frozen narrow-phase source retained',bvhCutLinkShader.includes(narrow));
  check('saturated ambiguity only exit and visit failure guard present',bvhCutLinkShader.includes('result.hitInfo.x==2u&&result.hitInfo.y==2u')&&bvhCutLinkShader.includes('visits>=arrayLength(&nodes)')&&bvhCutLinkShader.includes('atomicOr(&failure,1u)'));
  check('no known reserved identifiers',!/\b(target|common|meta)\b/.test(bvhCutLinkShader));
  for(const count of [1,3,129]){const p=planBVHQuery(count,17,{limits,maxBytes:1e7,maxNodeVisits:1e8,maxTriangleTests:1e8});check('exact mandatory telemetry/memory/work reservation',p.totalBytes===p.geometry.totalBytes+17*112+16&&p.totalNodeVisits===p.geometry.logicalNodeVisits+17*(2*count-1)&&p.statisticsBytes===136);}
  const plan=planBVHQuery(3,2,{limits,maxBytes:1e7,maxNodeVisits:1e8,maxTriangleTests:1e8});for(const change of [{maxBytes:plan.totalBytes-1},{maxNodeVisits:plan.totalNodeVisits-1},{maxTriangleTests:5}]){let failed=false;try{planBVHQuery(3,2,{limits,maxBytes:1e7,maxNodeVisits:1e8,maxTriangleTests:1e8,...change});}catch{failed=true;}check('work/memory cap rejects',failed);}
  const cpu=sampleCutLinks(()=>({source:'counterexample',positions:[0,0,0,1,0,0,0,1,0],velocities:Array(9).fill(0),indices:[0,1,2]}),{time:0,starts:[-1,.5,0],ends:[.5,2,0]});check('CPU SAT counterexample is clear, not GPU uncertainty baseline',cpu.results[0].status==='clear');
 }catch(error){return {pass:false,checks,timings,error:String(error)};}
 timings.push({name:'BVH query plan/static checks',ms:performance.now()-start});return {pass:true,checks,timings};
}

/** Real shared GPU differential vs frozen all-pairs, not a CPU shader emulation. */
export async function queryGPUChecks(device){
 if(!device?.createBuffer)throw Error('Actual shared GPUDevice required');const owned=[],checks=[];let error;
 const buffer=(size,usage)=>{const b=device.createBuffer({size,usage});owned.push(b);return b;};
 const check=(name,pass)=>{checks.push({name:`GPU BVH differential: ${name}`,pass:!!pass});if(!pass)throw Error(name);};
 try{
  const count=4,segments=[[-1,.5,0,.5,2,0],[.2,.2,-1,.2,.2,1],[4,4,-1,4,4,1],[0,0,-1,0,0,1],[.2,.2,-.1,.2,.2,.3],[.2,.2,0,.2,.2,.55]],linkCount=segments.length,p=planBVHQuery(count,linkCount,{limits:device.limits,maxBytes:64*1024*1024,maxNodeVisits:1e7,maxTriangleTests:1e7});
  const pairBuffer=buffer(count*8,136),nodes=buffer(p.geometry.nodeBytes,136),seen=buffer(p.geometry.seenBytes,136),status=buffer(16,140),readback=buffer(16,9);device.queue.writeBuffer(pairBuffer,0,new Uint32Array(Array.from({length:count},(_,i)=>[i,i]).flat()));
  const top=await buildMortonTopology(device,{count,maxBytes:64*1024*1024,pairs:pairBuffer,nodes,seen,status,readback,uniform:buffer(16,72),assertCurrent(){}});
  const triangles=buffer(count*112,136),links=buffer(p.linkBytes,136),results=buffer(p.resultBytes,140),baseline=buffer(p.resultBytes,140),statistics=buffer(p.statisticsBytes,132),statisticsReadback=buffer(p.statisticsBytes,9),queryUniform=buffer(16,72),geometryUniform=buffer(p.geometry.uniformBytes,72),copy=buffer(2*p.resultBytes,9);
  const linkData=new Float32Array(linkCount*8);segments.forEach((v,i)=>{linkData.set(v.slice(0,3),i*8);linkData.set(v.slice(3),i*8+4);});device.queue.writeBuffer(links,0,linkData);
  const module=device.createShaderModule({code:cutLinkShader}),info=await module.getCompilationInfo();if(info.messages.some(m=>m.type==='error'))throw Error('Baseline compilation failed');const pipeline=await device.createComputePipelineAsync({layout:'auto',compute:{module,entryPoint:'cutLinks'}});
  for(const time of [0,0.25]){
   const data=new Float32Array(count*28);for(let j=0;j<count;j++){const z=time+(j===3?5:[0,.5,.6][j]);data.set([0,0,z,1,1,0,z,1,0,1,z,1,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,1],j*28);}device.queue.writeBuffer(triangles,0,data);
   const report=await queryBVHLinks(device,{count,root:top.root,links,linkCount,results,statistics,statisticsReadback,queryUniform,maxBytes:64*1024*1024,maxNodeVisits:1e7,maxTriangleTests:1e7,triangles,nodes,seen,uniform:geometryUniform,status,readback,assertCurrent(){}});
   const group=device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[[triangles,count*112],[links,p.linkBytes],[baseline,p.resultBytes],[queryUniform,16]].map(([b,size],binding)=>({binding,resource:{buffer:b,offset:0,size}}))}),encoder=device.createCommandEncoder();encoder.clearBuffer(baseline,0,p.resultBytes);const pass=encoder.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,group);pass.dispatchWorkgroups(1);pass.end();encoder.copyBufferToBuffer(results,0,copy,0,p.resultBytes);encoder.copyBufferToBuffer(baseline,0,copy,p.resultBytes,p.resultBytes);device.queue.submit([encoder.finish()]);await copy.mapAsync(1);
   try{const bytes=copy.getMappedRange(),u=new Uint32Array(bytes),f=new Float32Array(bytes),base=p.resultBytes/4;
    for(let i=0;i<linkCount;i++){const at=i*16;check(`status/crossings t=${time} link=${i}`,u[at]===u[base+at]&&u[at+1]===u[base+at+1]);if(u[at]===1)check('resolved identity and geometry match all-pairs',u[at+2]===u[base+at+2]&&u[at+3]===u[base+at+3]&&Array.from(f.slice(at+4,at+16)).every((x,k)=>Math.abs(x-f[base+at+4+k])<2e-6));}
    if(time===0)check('coplanar endpoint-AABB counterexample stays ambiguous',u[0]===2);
   }finally{copy.unmap();}
   check('bounded actual telemetry returned',report.nodeVisits<=linkCount*(2*count-1)&&report.leafTests<=linkCount*count&&report.leafTests<=report.nodeVisits);
  }
  // Direct malformed-escape shader test, deliberately bypassing the wrapper's rebuild.
  const data=new Float32Array(count*28);for(let j=0;j<count;j++){const z=j===3?5:[0,.5,.6][j];data.set([0,0,z,1,1,0,z,1,0,1,z,1,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,1],j*28);}device.queue.writeBuffer(triangles,0,data);
  await queryBVHLinks(device,{count,root:top.root,links,linkCount,results,statistics,statisticsReadback,queryUniform,maxBytes:64*1024*1024,maxNodeVisits:1e7,maxTriangleTests:1e7,triangles,nodes,seen,uniform:geometryUniform,status,readback,assertCurrent(){}});
  device.queue.writeBuffer(nodes,(count-1)*48+36,new Uint32Array([count-1]));device.queue.writeBuffer(status,0,new Uint32Array([0]));
  const brokenPipeline=await device.createComputePipelineAsync({layout:'auto',compute:{module:device.createShaderModule({code:bvhCutLinkShader}),entryPoint:'cutLinks'}}),brokenGroup=device.createBindGroup({layout:brokenPipeline.getBindGroupLayout(0),entries:[[triangles,count*112],[links,p.linkBytes],[results,p.resultBytes],[queryUniform,16],[nodes,p.geometry.nodeBytes],[statistics,p.statisticsBytes],[status,4]].map(([b,size],binding)=>({binding,resource:{buffer:b,offset:0,size}}))}),brokenEncoder=device.createCommandEncoder();brokenEncoder.clearBuffer(results,0,p.resultBytes);const brokenPass=brokenEncoder.beginComputePass();brokenPass.setPipeline(brokenPipeline);brokenPass.setBindGroup(0,brokenGroup);brokenPass.dispatchWorkgroups(1);brokenPass.end();brokenEncoder.copyBufferToBuffer(status,0,readback,0,4);device.queue.submit([brokenEncoder.finish()]);await readback.mapAsync(1,0,4);try{check('cycle exhausts bounded traversal with failure flag',(new Uint32Array(readback.getMappedRange(0,4))[0]&1)!==0);}finally{readback.unmap();}
 }catch(e){error=String(e);}finally{try{await device.queue.onSubmittedWorkDone();}catch(e){error??=String(e);}for(const b of owned)b.destroy();}
 return {pass:!error,checks,error,hardwareGPUExecuted:true};
}

export async function queryHostChecks(){
 const {motionValidityFixture}=await import('./motion-validity.mjs');const checks=[],timings=[],start=performance.now(),check=(name,pass)=>{checks.push({name:`LBVH query host: ${name}`,pass:!!pass});if(!pass)throw Error(name);};
 const fixture=(badStats=false)=>{const base=motionValidityFixture(),device=base.context.device;device.limits=limits;device.createBindGroupLayout=d=>d;device.createPipelineLayout=d=>d;const bindings=[];device.createBindGroup=d=>{bindings.push(d);return {};};const p=planBVHQuery(3,2,{limits,maxBytes:1e6,maxNodeVisits:1e6,maxTriangleTests:100}),b=(size,usage)=>({size,usage});let readSize=0;
 const readback={size:16,usage:9,async mapAsync(mode,offset,size){readSize=size;base.log.push('map:'+size);},getMappedRange(){return new Uint32Array(readSize===4?[0]:[0,1,5,5]).buffer;},unmap(){base.log.push('unmap');}};
 const statisticsReadback={size:16,usage:9,async mapAsync(){base.log.push('stats-map');},getMappedRange(){return new Uint32Array(badStats?[6,1,0,0]:[5,2,1,0]).buffer;},unmap(){base.log.push('stats-unmap');}};
 return {device,log:base.log,bindings,args:{count:3,root:0,links:b(p.linkBytes,128),linkCount:2,results:b(p.resultBytes,136),statistics:b(p.statisticsBytes,132),statisticsReadback,queryUniform:b(16,72),maxBytes:1e6,maxNodeVisits:1e6,maxTriangleTests:100,triangles:b(p.geometry.triangleBytes,128),nodes:b(p.geometry.nodeBytes,128),seen:b(p.geometry.seenBytes,136),uniform:b(p.geometry.uniformBytes,72),status:b(16,140),readback,assertCurrent(){}}};};
 try{const f=fixture(),r=await queryBVHLinks(f.device,f.args);check('actual telemetry aggregate validated',r.nodeVisits===6&&r.leafTests===2&&r.telemetryReadback===true);check('build and query submissions fenced before success',f.log.filter(x=>x==='submit').length===2&&f.log.at(-1)==='stats-unmap');check('query binding ranges exact',f.bindings.at(-1).entries.length===7&&f.bindings.at(-1).entries[4].resource.size===240&&f.bindings.at(-1).entries[5].resource.size===16);
 const bad=fixture(true);let error;try{await queryBVHLinks(bad.device,bad.args);}catch(e){error=e;}check('impossible telemetry rejects and unmaps',String(error).includes('Invalid BVH telemetry')&&bad.log.at(-1)==='stats-unmap');
 const alias=fixture();alias.args.statistics=alias.args.results;let failed=false;try{await queryBVHLinks(alias.device,alias.args);}catch{failed=true;}check('cross-role query alias rejects',failed&&!alias.log.includes('submit'));
 }catch(error){return {pass:false,checks,timings,error:String(error)};}
 timings.push({name:'BVH query lifecycle mocks',ms:performance.now()-start});return {pass:true,checks,timings};
}
