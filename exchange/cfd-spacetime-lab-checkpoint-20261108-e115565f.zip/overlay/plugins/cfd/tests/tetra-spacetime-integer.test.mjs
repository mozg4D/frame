import test from 'node:test';
import assert from 'node:assert/strict';
import {planTetraSpaceTimeFlux as exact} from '../tetra-spacetime.mjs';
import {planTetraSpaceTimeInteger as integer,packTetraSpaceTimeMotion} from '../tetra-spacetime-integer.mjs';
function compare(options){
  const a=exact(options),b=integer(options);
  for(const [field,denominator,reference] of [['volumesBefore48',48,'volumesBefore'],['volumesAfter48',48,'volumesAfter'],['faceFlux23040',23040,'faceFluxes'],['faceAreaTime11520',11520,'faceAreaTime']]){
    for(let i=0;i<b[field].length;i++){
      const [n,d]=a.exact[reference][i].split('/').map(BigInt);
      assert.equal(BigInt(b[field][i])*d,n*BigInt(denominator),`${field}[${i}]`);
    }
  }
  return b;
}
test('integer denominator represents every default endpoint, flux and area exactly',()=>{const p=compare();assert.equal(p.cellCount,512);assert.equal(p.exactGeometricConservation,true);});
test('largest leg and mixed maximal displacement stay in checked i32 range',()=>{
  for(const leg of [.5,1,2.5,4.5,6,7])compare({leg,keyframes:[{time:0,anchor:[.5,.5,.5]},{time:1,anchor:leg===7?[.5,.5,.5]:[1,1,1]},{time:32,anchor:[.5,.5,.5]}]});
});
test('120 deterministic three-segment paths match the independent BigInt primitive exactly',()=>{
  let state=0x1742ac1;const next=()=>{state=(Math.imul(1664525,state)+1013904223)>>>0;return state;};let faces=0;
  const start=performance.now();
  for(let sample=0;sample<120;sample++){
    const leg=[.5,1,1.5,2,2.5][sample%5],keyframes=[{time:0,anchor:[1,1,1]}];
    for(let t=1;t<=3;t++){
      const before=keyframes.at(-1).anchor,anchor=before.map(v=>{const choices=[-1,-.5,0,.5,1].map(d=>v+d).filter(x=>x>0&&x+leg<5);return choices[next()%choices.length];});
      keyframes.push({time:t,anchor});
    }
    const p=compare({dimensions:[5,5,5],leg,keyframes});faces+=p.faceFlux23040.length;
  }
  assert.equal(faces,45000);const elapsed=performance.now()-start;assert.ok(elapsed<10000,`Cross-check exceeded 10s: ${elapsed}`);console.log(JSON.stringify({paths:120,faces,completedMs:elapsed,hardwareGPUValidated:false}));
});
test('path sensitivity, stationary alignment and non-retraced closed circulation remain exact',()=>{
  const o={dimensions:[4,4,4],leg:1,keyframes:[{time:0,anchor:[.5,.5,1.5]},{time:1,anchor:[1.5,.5,1.5]},{time:2,anchor:[1.5,1.5,1.5]}]},a=compare(o);o.keyframes[1].anchor=[.5,1.5,1.5];const b=compare(o),j=3*(4+16);
  assert.equal(a.faceFlux23040[j],47*480);assert.equal(b.faceFlux23040[j],43*480);
  compare({dimensions:[5,5,5],leg:2,keyframes:[{time:0,anchor:[1,1,1]},{time:32,anchor:[1,1,1]}]});
  compare({dimensions:[4,4,4],leg:1,keyframes:[{time:0,anchor:[.5,.5,1.5]},{time:1,anchor:[1.5,.5,1.5]},{time:2,anchor:[1.5,1.5,1.5]},{time:3,anchor:[.5,1.5,1.5]},{time:4,anchor:[.5,.5,1.5]}]});
});
test('packing rejects unsupported motion before integer evaluation and does not mutate input',()=>{
  const source={dimensions:[4,4,4],leg:1,keyframes:[{time:0,anchor:[.5,.5,.5]},{time:1,anchor:[1,1,1]}]},saved=structuredClone(source);packTetraSpaceTimeMotion(source);assert.deepEqual(source,saved);
  for(const bad of [null,{dimensions:[9,8,8]},{leg:.1},{leg:8},{keyframes:[]},{...source,keyframes:[{time:0,anchor:[.5,.5,.5]},{time:1,anchor:[2,1,1]}]},{...source,keyframes:[{time:0,anchor:[.5,.5,.5]},{time:.5,anchor:[1,1,1]}]},{...source,keyframes:[{time:0,anchor:[.5,.5,.5]},{time:1,anchor:[1.1,1,1]}]}])assert.throws(()=>integer(bad));
});
test('CPU integer prototype cannot qualify a GPU or a fluid solver',()=>{const p=integer();for(const key of ['hardwareGPUValidated','nativeSpaceTimeCouplingValidated','streamingCollisionPerformed','solverReady'])assert.equal(p[key],false);});
