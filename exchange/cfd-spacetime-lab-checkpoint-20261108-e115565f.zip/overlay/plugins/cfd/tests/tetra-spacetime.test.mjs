import test from 'node:test';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {planTetraSpaceTimeFlux as plan} from '../tetra-spacetime.mjs';
import {planCoMovingTetra} from '../tetra-remap.mjs';

const close=(a,b,e=2e-13)=>assert.ok(Math.abs(a-b)<=e,`${a} != ${b}, error ${Math.abs(a-b)}`);
const parse=s=>s.split('/').map(BigInt);
const sum=(...ss)=>ss.map(parse).reduce(([a,b],[c,d])=>[a*d+c*b,b*d],[0n,1n]);
const equal=(s,t)=>{const [a,b]=parse(s),[c,d]=parse(t);return a*d===b*c;};
const negative=s=>{const [a,b]=parse(s);return `${-a}/${b}`;};
const add=(s,t)=>{const [a,b]=sum(s,t);return `${a}/${b}`;};
const pnt=(i,d)=>[i%d[0],Math.floor(i/d[0])%d[1],Math.floor(i/(d[0]*d[1]))];
const idx=(v,d)=>v[0]+d[0]*(v[1]+d[1]*v[2]);
const base={dimensions:[4,4,4],leg:1,keyframes:[{time:0,anchor:[.5,.5,1.5]},{time:1,anchor:[1.5,.5,1.5]},{time:2,anchor:[1.5,1.5,1.5]}]};

// Independent geometry: clip a 2D triangular cross-section to the face square,
// then integrate its shoelace area by two-point Gauss on all topology intervals.
// No cubic/squared-positive-part inclusion-exclusion from the runtime is reused.
function polygonArea(cell,axis,a,leg){
  const remaining=leg-(cell[axis]+1-a[axis]);
  if(cell[axis]+1<a[axis]||remaining<=0)return 0;
  const axes=[0,1,2].filter(k=>k!==axis),[u,v]=axes.map(k=>a[k]);
  let polygon=[[u,v],[u+remaining,v],[u,v+remaining]];
  for(let dim=0;dim<2;dim++)for(const upper of [false,true]){
    const boundary=cell[axes[dim]]+(upper?1:0),distance=p=>upper?boundary-p[dim]:p[dim]-boundary,next=[];
    for(let i=0;i<polygon.length;i++){
      const a=polygon[i],b=polygon[(i+1)%polygon.length],da=distance(a),db=distance(b);
      if(da>=0)next.push(a);
      if((da<0&&db>0)||(da>0&&db<0))next.push(a.map((x,k)=>x+da/(da-db)*(b[k]-x)));
    }
    polygon=next;
  }
  // Shift the origin to the cell to avoid large-coordinate cancellation.
  polygon=polygon.map(v=>v.map((x,k)=>x-cell[axes[k]]));
  return Math.abs(polygon.reduce((s,a,i)=>{const b=polygon[(i+1)%polygon.length];return s+a[0]*b[1]-a[1]*b[0];},0))/2;
}
function oracleFace(cell,axis,options){
  let flux=0,areaTime=0;
  const {keyframes,leg}=options;
  for(let s=1;s<keyframes.length;s++){
    const from=keyframes[s-1],to=keyframes[s],delta=to.anchor.map((v,k)=>v-from.anchor[k]),times=[0,1];
    const crossing=(a,b)=>{if(b){const t=-a/b;if(t>0&&t<1)times.push(t);}};
    for(let k=0;k<3;k++)for(const offset of [0,1])crossing(from.anchor[k]-cell[k]-offset,delta[k]);
    const other=[0,1,2].filter(k=>k!==axis);
    // The moving triangle vertices can cross a square edge before its oblique
    // edge crosses a square corner. Both kinds of topology event are needed.
    crossing(leg-cell[axis]-1+from.anchor[axis],delta[axis]);
    for(const k of other)for(const offset of [0,1])crossing(from.anchor[k]+leg-cell[axis]-1+from.anchor[axis]-cell[k]-offset,delta[k]+delta[axis]);
    for(const u of [0,1])for(const v of [0,1])crossing(leg+from.anchor.reduce((a,b)=>a+b,0)-(cell[axis]+1+cell[other[0]]+u+cell[other[1]]+v),delta.reduce((a,b)=>a+b,0));
    times.sort((a,b)=>a-b);let solid=0;
    for(let k=1;k<times.length;k++){
      const half=(times[k]-times[k-1])/2,mid=(times[k]+times[k-1])/2;
      for(const sign of [-1,1]){const t=mid+sign*half/Math.sqrt(3);solid+=half*polygonArea(cell,axis,from.anchor.map((v,k)=>v+delta[k]*t),leg);}
    }
    flux+=delta[axis]*(1-solid);areaTime+=(to.time-from.time)*(1-solid);
  }
  return {flux,areaTime};
}

function assertGCL(p){
  for(let i=0;i<p.cellCount;i++){
    const terms=[p.exact.volumesAfter[i],negative(p.exact.volumesBefore[i])],cell=pnt(i,p.dimensions);
    for(let k=0;k<3;k++){
      const low=cell.slice();low[k]=(low[k]+p.dimensions[k]-1)%p.dimensions[k];
      terms.push(p.exact.faceFluxes[3*i+k],negative(p.exact.faceFluxes[3*idx(low,p.dimensions)+k]));
    }
    assert.equal(sum(...terms)[0],0n,`Independent exact GCL cell ${i}`);
  }
}

test('every default cell satisfies independent exact GCL and analytic total volume',()=>{
  const p=plan();assert.equal(p.cellCount,512);assertGCL(p);
  assert.equal(p.exact.totalFluidVolume,'1015/2');assert.ok(p.volumesBefore.some(v=>v>0&&v<1));
  assert.ok(p.volumesBefore.some((v,i)=>v!==p.volumesAfter[i]));
  const before=sum(...p.exact.volumesBefore),after=sum(...p.exact.volumesAfter);
  assert.equal(before[0]*2n,1015n*before[1]);assert.equal(after[0]*2n,1015n*after[1]);
  assert.equal(p.maximumExactResidual,'0/1');assert.equal(p.exactGeometricConservation,true);
});

test('endpoint volumes agree with the previously qualified geometry reference',()=>{
  const p=plan(),previous=planCoMovingTetra({dimensions:p.dimensions,anchor:p.keyframes[0].anchor,leg:p.leg,displacement:[.5,.5,.5]});
  for(let i=0;i<p.cellCount;i++){close(p.volumesBefore[i],previous.volumesBefore[i],1e-15);close(p.volumesAfter[i],previous.volumesAfter[i],1e-15);}
});

test('same endpoints do not determine the physical path flux: exact 1/12 witness',()=>{
  const alternate=structuredClone(base);alternate.keyframes[1].anchor=[.5,1.5,1.5];
  const p=plan(base),q=plan(alternate),face=3*idx([0,1,1],base.dimensions);
  assert.deepEqual(p.exact.volumesBefore,q.exact.volumesBefore);assert.deepEqual(p.exact.volumesAfter,q.exact.volumesAfter);
  assert.equal(p.exact.faceFluxes[face],'47/48');assert.equal(q.exact.faceFluxes[face],'43/48');
  assert.ok(equal(add(p.exact.faceFluxes[face],negative(q.exact.faceFluxes[face])),'1/12'));
  assert.notDeepEqual(p.exact.faceFluxes,q.exact.faceFluxes);assertGCL(p);assertGCL(q);
});

test('independent clipped-face Gauss oracle agrees for jumps, oblique cuts and reversals',()=>{
  for(const options of [base,{dimensions:[5,5,5],leg:2.5,keyframes:[{time:0,anchor:[.5,.5,.5]},{time:1,anchor:[1.5,1,1]},{time:3,anchor:[1,1.5,.5]},{time:6,anchor:[.5,1,1.5]}]}]){
    const p=plan(options);
    for(let i=0;i<p.cellCount;i++)for(let axis=0;axis<3;axis++){
      const expected=oracleFace(pnt(i,p.dimensions),axis,options),j=3*i+axis;
      close(p.faceFluxes[j],expected.flux);close(p.faceAreaTime[j],expected.areaTime,5e-13);
    }
  }
});

test('stationary geometry has zero transport even on exactly aligned solid faces',()=>{
  const options={dimensions:[5,5,5],leg:2,keyframes:[{time:0,anchor:[1,1,1]},{time:3,anchor:[1,1,1]}]},p=plan(options);
  assert.ok(p.exact.faceFluxes.every(v=>v==='0/1'));assert.deepEqual(p.exact.volumesBefore,p.exact.volumesAfter);
  assert.ok(p.faceAreaTime.some(v=>v===0));assert.ok(p.faceAreaTime.some(v=>v===3));
  assert.ok(p.faceAreaTime.some(v=>v>0&&v<3));assertGCL(p);
});

test('time reversal negates every flux and preserves integrated aperture',()=>{
  const p=plan(base),reversed={...base,keyframes:base.keyframes.slice().reverse().map(k=>({time:2-k.time,anchor:k.anchor}))},q=plan(reversed);
  assert.deepEqual(q.exact.volumesAfter,p.exact.volumesBefore);assert.deepEqual(q.exact.volumesBefore,p.exact.volumesAfter);
  p.exact.faceFluxes.forEach((v,i)=>assert.ok(equal(q.exact.faceFluxes[i],negative(v))));assert.deepEqual(q.exact.faceAreaTime,p.exact.faceAreaTime);
});

test('retiming preserves integrated material flux but changes aperture-time and velocity',()=>{
  const slow=structuredClone(base);slow.keyframes[1].time=5;slow.keyframes[2].time=9;
  const p=plan(base),q=plan(slow);assert.deepEqual(q.exact.faceFluxes,p.exact.faceFluxes);assert.notDeepEqual(q.exact.faceAreaTime,p.exact.faceAreaTime);assert.equal(q.duration,9);
});

test('collinear extra knots and subdivided duration preserve exact integrals',()=>{
  const start=[.5,.5,1.5],end=[1.5,1.5,1.5],p=plan({...base,keyframes:[{time:0,anchor:start},{time:2,anchor:end}]}),q=plan({...base,keyframes:[{time:0,anchor:start},{time:1,anchor:[1,1,1.5]},{time:2,anchor:end}]});
  assert.deepEqual(p.exact,q.exact);
});

test('retraced closed path has zero flux, while a closed rectangular loop has circulation',()=>{
  const start=base.keyframes[0].anchor,mid=base.keyframes[1].anchor,end=base.keyframes[2].anchor;
  const retrace=plan({...base,keyframes:[{time:0,anchor:start},{time:1,anchor:mid},{time:2,anchor:start}]});
  assert.ok(retrace.exact.faceFluxes.every(v=>v==='0/1'));
  const loop=plan({...base,keyframes:[{time:0,anchor:start},{time:1,anchor:mid},{time:2,anchor:end},{time:3,anchor:[.5,1.5,1.5]},{time:4,anchor:start}]});
  assert.deepEqual(loop.exact.volumesAfter,loop.exact.volumesBefore);assert.ok(loop.exact.faceFluxes.some(v=>v!=='0/1'));assert.ok(loop.exact.cellFluxDivergence.every(v=>v==='0/1'));assertGCL(loop);
});

test('segment composition adds exact fluxes without assigning interval length as LBM dt',()=>{
  const whole=plan(base),first=plan({...base,keyframes:base.keyframes.slice(0,2)}),second=plan({...base,keyframes:base.keyframes.slice(1).map(k=>({...k,time:k.time-1}))});
  whole.exact.faceFluxes.forEach((v,i)=>assert.ok(equal(v,add(first.exact.faceFluxes[i],second.exact.faceFluxes[i]))));
  whole.exact.faceAreaTime.forEach((v,i)=>assert.ok(equal(v,add(first.exact.faceAreaTime[i],second.exact.faceAreaTime[i]))));
});

test('deterministic half-grid sweep covers simultaneous contacts and both velocity signs',()=>{
  let count=0;
  for(const dx of [-1,-.5,0,.5,1])for(const dy of [-1,0,1])for(const dz of [-1,0,1]){
    const p=plan({dimensions:[5,5,5],leg:.5,keyframes:[{time:0,anchor:[2,2,2]},{time:1,anchor:[2+dx,2+dy,2+dz]}]});
    assertGCL(p);count++;
  }
  assert.equal(count,45);
});

test('corner/edge grazing with half-cell small tetrahedra retains real nonzero volumes',()=>{
  const p=plan({dimensions:[4,4,4],leg:.5,keyframes:[{time:0,anchor:[.5,.5,.5]},{time:1,anchor:[1,1,1]}]});
  assert.equal(p.exact.totalFluidVolume,'3071/48');assert.ok(p.exact.volumesBefore.some(v=>v==='47/48'));assertGCL(p);
});

test('caller data is unchanged; independent calls do not share mutable output',()=>{
  const input=structuredClone(base),saved=structuredClone(input),a=plan(input);assert.deepEqual(input,saved);
  a.keyframes[0].anchor[0]=999;a.faceFluxes.fill(NaN);a.exact.faceFluxes.fill('broken');
  assert.deepEqual(input,saved);assert.ok(plan(input).faceFluxes.every(Number.isFinite));
});

test('unsupported coordinates, time paths, capacities and escaped solids reject',()=>{
  for(const options of [null,{dimensions:[1,4,4]},{dimensions:[9,4,4]},{dimensions:[4,4,NaN]},{leg:0},{leg:1/3},{keyframes:[]},{keyframes:[{time:0,anchor:[1,1,1]}]},
    {keyframes:[{time:1,anchor:[1,1,1]},{time:2,anchor:[1,1,1]}]},
    {keyframes:[{time:0,anchor:[1,1,1]},{time:0,anchor:[1,1,1]}]},
    {keyframes:[{time:0,anchor:[1,1,1]},{time:.5,anchor:[1,1,1]}]},
    {keyframes:[{time:0,anchor:[1,1,1]},{time:33,anchor:[1,1,1]}]},
    {keyframes:[{time:0,anchor:[1,1,1]},{time:1,anchor:[2.5,1,1]}]},
    {keyframes:[{time:0,anchor:[0,1,1]},{time:1,anchor:[1,1,1]}]},
    {keyframes:[{time:0,anchor:[1,1,1]},{time:1,anchor:[1.1,1,1]}]},
    {...base,leg:3},{...base,keyframes:Array.from({length:10},(_,time)=>({time,anchor:[.5,.5,1.5]}))},
    {...base,keyframes:[{time:0,anchor:[.5,.5,1.5]},{time:1,anchor:[Infinity,1,1]}]}])assert.throws(()=>plan(options));
});

test('all qualification flags explicitly exclude GPU, native coupling and solver readiness',()=>{
  const p=plan(base);
  for(const key of ['continuousNativeTrajectoryValidated','nativeSpaceTimeCouplingValidated','hardwareGPUValidated','streamingCollisionPerformed','wallImpulseValidated','solverReady'])assert.equal(p[key],false,key);
});

test('maximum admitted 512-cell eight-segment operation completes within CPU budget',()=>{
  const keyframes=Array.from({length:9},(_,time)=>({time,anchor:time%2?[1.5,1.5,1.5]:[1,1,1]})),started=performance.now(),p=plan({keyframes}),elapsed=performance.now()-started;
  assertGCL(p);assert.ok(elapsed<2000,`Completed operation ${elapsed}ms exceeds 2000ms reference budget`);
  console.log(JSON.stringify({operation:'exact-tetra-spacetime-plan',cells:p.cellCount,segments:8,completedOperationMs:elapsed,budgetMs:2000,hardwareGPUValidated:false}));
});
