# LAB space-time geometry checkpoint

This remains an uninstalled CFD numerical reference. No fluid step, native
trajectory, force, GPU execution or production readiness is qualified here.

The exact CPU module `tetra-spacetime.mjs` and its focused tests were recovered
byte-for-byte and rerun on LAB. Their SHA-256 identities are respectively
ae13d184cee2190f0adb18c46571b9c41b09a718dbc7b97e9de2289897cdeef2 and
9549d10f861e9c90abd1127aac7dbb7da1e12c33b1ffb2514f4fb14ccbb59a04.

## New bounded integer representation

`planTetraSpaceTimeInteger(options)` mirrors the prescribed affine translation
domain of `planTetraSpaceTimeFlux(options)`. Dimensions are integers 2..8;
anchors and leg are half-cell multiples; the tetrahedron remains strictly inside
the periodic box; segment displacements are at most one cell per axis. There
are 2..9 knots with increasing integer times from zero through 32. Both solid
and fluid move with the same prescribed velocity. There is no relative wall
flux or kinetic population update.

Geometry branches change only at normalized segment times 0, 1/2 and 1.
On each interval a positive-part height is h(t)=(A+B*t)/2. At t=s/2, set
H=2*A+B*s=4*h. The integral of (h_+)^2/2 is:

- B != 0: delta(H_+^3)/(192*B).
- B == 0: H_+^2*delta(s)/64.

Every B is an integer in [-6,6]. Every nonzero |B| divides 60. Therefore the
area integral has an exact denominator of 11520. Multiplying its fluid
complement by twice the displacement produces flux with denominator 23040.
Endpoint volume uses denominator 48, converting to 23040 by multiplying by 480.
Cellwise volume change plus outward face flux must equal exactly zero.

The domain gives leg <= 7 and positive H <= 28. Cube terms are at most 21952;
the coefficient magnitude is at most 60. Four inclusion-exclusion terms on two
intervals remain below 10,536,960. Eight-segment signed flux is at most 184320
in absolute value; area-time is at most 368640. These fit i32. The CPU prototype
also checks intermediate integer range explicitly instead of silently wrapping.
This arithmetic still needs independent review and actual WGSL/GPU tests.

Persistent alignment of a solid coordinate face with a grid face uses a
closed-solid area trace. Adjacent one-sided fluid traces differ there, but the
normal translation velocity is zero. These areas are not certified kinetic
apertures for a later streaming operator.

## Verification and recovery

Run with the supported Node >=22 executable:

    node plugins/cfd/tests/spacetime-reference-gate.mjs

The source-bound CPU runner covers the existing local foundation, all local
standalone CFD host tests, and syntax of the five new/reference files. It does
not start a browser, GPU, Unite or standard/stress suite. The isolated historical
LAB package does not contain the complete repository test tree, so its check
counts must not be equated with an earlier cloud checkout.

The new integer tests include 120 deterministic three-segment paths and 45000
face comparisons against the exact rational reference, with no tolerance. The
reference separately covers polygon-clipping integration, endpoint volume,
reversal, retiming, path subdivision, closed loops and unsupported inputs.

The LAB recovery also corrected one stale static assertion in tests/lbvh-query:
it still searched for reserved WGSL name result.meta while the already-qualified
shader used result.hitInfo. The ambiguity/visit/failure guard checks remain, and
the reserved-name check now explicitly rejects meta. Runtime files from the
59-entry hardware partition manifest were not changed. The initial CPU failure
report was retained.

Next: independently review the integer proof, implement a bounded GPU fixture,
and compare actual i32 GPU results to the rational reference. Direction-dependent
transport, relative moving-wall flux and wall impulse balance remain separate
later requirements. Do not expose Solve/results or call this a ready solver.
