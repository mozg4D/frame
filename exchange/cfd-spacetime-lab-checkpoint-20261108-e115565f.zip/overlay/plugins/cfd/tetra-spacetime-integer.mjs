// Bounded i32 arithmetic prototype for a future WGSL gate. This is still CPU
// geometry only; it does not execute a fluid step or validate native motion.
export const SPACE_TIME_AREA_DENOMINATOR=11520;
export const SPACE_TIME_FLUX_DENOMINATOR=23040;
const xyz=v=>Array.isArray(v)&&v.length===3&&[0,1,2].every(k=>Number.isFinite(v[k]));
const point=(i,d)=>[i%d[0],Math.floor(i/d[0])%d[1],Math.floor(i/(d[0]*d[1]))];
const index=(p,d)=>p[0]+d[0]*(p[1]+d[1]*p[2]);
const i32=v=>{if(!Number.isInteger(v)||v<-(2**31)||v>=2**31)throw new RangeError('Integer geometry intermediate exceeds i32');return v;};
const cubePositive=v=>{const p=Math.max(v,0);return i32(i32(p*p)*p);};

export function packTetraSpaceTimeMotion({dimensions=[8,8,8],leg=3,keyframes=[{time:0,anchor:[1,1,1]},{time:1,anchor:[1.5,1.5,1.5]}]}={}){
  if(!xyz(dimensions)||dimensions.some(v=>!Number.isInteger(v)||v<2||v>8))throw new RangeError('Dimensions must be integers in [2,8]');
  if(!Number.isFinite(leg)||leg<=0||!Number.isSafeInteger(2*leg))throw new RangeError('Positive half-cell leg required');
  if(!Array.isArray(keyframes)||keyframes.length<2||keyframes.length>9)throw new RangeError('Two to nine motion knots required');
  const knots=[];
  for(let k=0;k<keyframes.length;k++){
    const frame=keyframes[k],prior=knots.at(-1);
    if(!frame||!Number.isInteger(frame.time)||frame.time<0||frame.time>32||(!k&&frame.time!==0)||(prior&&frame.time<=prior.time))throw new RangeError('Increasing integer times from zero through 32 required');
    if(!xyz(frame.anchor)||frame.anchor.some((v,a)=>!Number.isSafeInteger(v*2)||v<=0||v+leg>=dimensions[a]))throw new RangeError('Half-cell tetrahedron must remain strictly inside the periodic box');
    const half=frame.anchor.map(v=>v*2);
    if(prior&&half.some((v,a)=>Math.abs(v-prior.half[a])>2))throw new RangeError('Maximum segment displacement is one cell per axis');
    knots.push({half,time:frame.time});
  }
  return {dimensions:dimensions.slice(),legHalf:2*leg,knots,cellCount:dimensions.reduce((a,b)=>a*b,1)};
}

function fluidVolume48(cell,anchor,leg){
  const lo=cell.map((v,k)=>Math.max(2*v,anchor[k])),hi=cell.map(v=>2*v+2);
  if(hi.some((v,k)=>v<=lo[k]))return 48;
  const width=hi.map((v,k)=>v-lo[k]);let height=leg,solid=0;
  for(let k=0;k<3;k++)height-=lo[k]-anchor[k];
  for(let mask=0;mask<8;mask++){
    let h=height,sign=1;
    for(let k=0;k<3;k++)if(mask&(1<<k)){h-=width[k];sign=-sign;}
    solid=i32(solid+sign*cubePositive(h));
  }
  const fluid=48-solid;if(fluid<0||fluid>48)throw new RangeError('Invalid exact cell volume');return fluid;
}

// h(t) = (A+B*t)/2. At t=s/2, H=2*A+B*s=4*h.
// Integral (h_+)^2/2 dt * 11520 = (60/B)*delta(H_+^3).
// For B=0 it is 180*H_+^2*delta(s). All B in [-6,6] divide 60.
function primitiveDifference(A,B,lo,hi){
  if(!Number.isInteger(B)||Math.abs(B)>6)throw new RangeError('Slope exceeds exact denominator domain');
  const h0=i32(2*A+B*lo),h1=i32(2*A+B*hi);
  if(h0>28||h1>28)throw new RangeError('Positive height exceeds integer domain');
  if(B)return i32((60/B)*i32(cubePositive(h1)-cubePositive(h0)));
  const h=Math.max(h0,0);return i32(180*i32(h*h)*(hi-lo));
}

function solidFace11520(cell,axis,start,end,leg){
  const delta=end.map((v,k)=>v-start[k]),face=cell[axis]+1,other=[0,1,2].filter(k=>k!==axis);
  let integral=0;
  // Under this domain every anchor/grid jump is at 0, 1/2 or 1. No sampling:
  // midpoint comparisons only choose an affine branch; the integral is exact.
  for(let part=0;part<2;part++){
    const lo=part,hi=part+1,mid=lo+hi;
    const anchor4=k=>4*start[k]+delta[k]*mid;
    if(anchor4(axis)>8*face)continue;
    const lower=other.map(k=>anchor4(k)>8*cell[k]?[start[k],delta[k]]:[2*cell[k],0]);
    if(other.some((k,j)=>4*lower[j][0]+lower[j][1]*mid>=8*(cell[k]+1)))continue;
    const width=other.map((k,j)=>[2*(cell[k]+1)-lower[j][0],-lower[j][1]]);
    let A=leg-2*face+start[axis],B=delta[axis];
    for(let j=0;j<2;j++){A-=lower[j][0]-start[other[j]];B-=lower[j][1]-delta[other[j]];}
    for(let mask=0;mask<4;mask++){
      let a=A,b=B,sign=1;
      for(let j=0;j<2;j++)if(mask&(1<<j)){a-=width[j][0];b-=width[j][1];sign=-sign;}
      integral=i32(integral+sign*primitiveDifference(a,b,lo,hi));
    }
  }
  if(integral<0||integral>11520)throw new RangeError('Invalid exact face integral');return integral;
}

export function planTetraSpaceTimeInteger(options={}){
  const p=packTetraSpaceTimeMotion(options),d=p.dimensions,n=p.cellCount,last=p.knots.at(-1);
  const volumesBefore48=new Int32Array(n),volumesAfter48=new Int32Array(n),faceFlux23040=new Int32Array(n*3),faceAreaTime11520=new Int32Array(n*3);
  for(let i=0;i<n;i++){
    const cell=point(i,d);volumesBefore48[i]=fluidVolume48(cell,p.knots[0].half,p.legHalf);volumesAfter48[i]=fluidVolume48(cell,last.half,p.legHalf);
    for(let axis=0;axis<3;axis++){
      let flux=0,areaTime=0;
      for(let k=1;k<p.knots.length;k++){
        const a=p.knots[k-1],b=p.knots[k],fluid=11520-solidFace11520(cell,axis,a.half,b.half,p.legHalf);
        flux=i32(flux+i32((b.half[axis]-a.half[axis])*fluid));areaTime=i32(areaTime+i32((b.time-a.time)*fluid));
      }
      faceFlux23040[3*i+axis]=flux;faceAreaTime11520[3*i+axis]=areaTime;
    }
  }
  for(let i=0;i<n;i++){
    const cell=point(i,d);let balance=i32(480*(volumesAfter48[i]-volumesBefore48[i]));
    for(let k=0;k<3;k++){const minus=cell.slice();minus[k]=(minus[k]+d[k]-1)%d[k];balance=i32(balance+faceFlux23040[3*i+k]-faceFlux23040[3*index(minus,d)+k]);}
    if(balance)throw new RangeError('Exact integer GCL failed at cell '+i);
  }
  const total=48*n-p.legHalf**3;
  if(volumesBefore48.reduce((a,b)=>a+b,0)!==total||volumesAfter48.reduce((a,b)=>a+b,0)!==total)throw new RangeError('Exact total volume failed');
  return {...p,volumesBefore48,volumesAfter48,faceFlux23040,faceAreaTime11520,
    stage:'i32-spacetime-geometry-prototype',exactGeometricConservation:true,
    hardwareGPUValidated:false,nativeSpaceTimeCouplingValidated:false,streamingCollisionPerformed:false,solverReady:false};
}
