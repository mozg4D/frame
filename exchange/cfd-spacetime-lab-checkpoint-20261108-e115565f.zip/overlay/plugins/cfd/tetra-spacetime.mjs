// Exact, bounded geometric reference. Prescribed co-moving material transport,
// NOT a fluid kinetic step or a native animation trajectory certificate.
const zero={n:0n,d:1n},one={n:1n,d:1n};
const gcd=(a,b)=>{a=a<0n?-a:a;while(b){const r=a%b;a=b;b=r;}return a;};
function r(n,d=1n){if(!d)throw new RangeError('Zero rational denominator');if(!n)return zero;if(d<0n){n=-n;d=-d;}const g=gcd(n,d);return {n:n/g,d:d/g};}
const integer=n=>r(BigInt(n)),half=n=>r(BigInt(2*n),2n);
const add=(a,b)=>r(a.n*b.d+b.n*a.d,a.d*b.d),neg=a=>r(-a.n,a.d),sub=(a,b)=>add(a,neg(b));
const mul=(a,b)=>r(a.n*b.n,a.d*b.d),div=(a,b)=>r(a.n*b.d,a.d*b.n);
const cmp=(a,b)=>{const x=a.n*b.d-b.n*a.d;return x<0n?-1:x>0n?1:0;};
const max=(a,b)=>cmp(a,b)>0?a:b;
const square=a=>mul(a,a),cube=a=>mul(square(a),a),encode=a=>`${a.n}/${a.d}`,number=a=>Number(a.n)/Number(a.d);
const at=(line,t)=>add(line[0],mul(line[1],t)),constant=v=>[v,zero];
const lineSub=(a,b)=>[sub(a[0],b[0]),sub(a[1],b[1])];
const vector=v=>Array.isArray(v)&&v.length===3&&[0,1,2].every(k=>Number.isFinite(v[k]));
const point=(i,d)=>[i%d[0],Math.floor(i/d[0])%d[1],Math.floor(i/(d[0]*d[1]))];
const index=(p,d)=>p[0]+d[0]*(p[1]+d[1]*p[2]);

function parameters({dimensions=[8,8,8],leg=3,keyframes=[{time:0,anchor:[1,1,1]},{time:1,anchor:[1.5,1.5,1.5]}]}={}){
  if(!vector(dimensions)||dimensions.some(v=>!Number.isInteger(v)||v<2||v>8))throw new RangeError('Dimensions must be integers in [2,8]');
  if(!Number.isFinite(leg)||leg<=0||!Number.isSafeInteger(2*leg))throw new RangeError('A positive half-cell leg is required');
  if(!Array.isArray(keyframes)||keyframes.length<2||keyframes.length>9)throw new RangeError('Two to nine affine motion keyframes required');
  const frames=[];
  for(let i=0;i<keyframes.length;i++){
    const k=keyframes[i],prior=frames.at(-1);
    if(!k||!Number.isInteger(k.time)||k.time<0||k.time>32||(!i&&k.time!==0)||(prior&&k.time<=prior.time))throw new RangeError('Times must increase from zero in integer lattice-time units up to 32');
    if(!vector(k.anchor)||k.anchor.some((v,a)=>!Number.isSafeInteger(2*v)||v<=0||v+leg>=dimensions[a]))throw new RangeError('Half-cell anchors must keep the whole tetrahedron strictly inside the periodic box');
    if(prior&&k.anchor.some((v,a)=>Math.abs(v-prior.anchor[a])>1))throw new RangeError('Each affine segment displacement must be at most one cell per axis');
    frames.push({time:k.time,anchor:k.anchor.slice()});
  }
  return {dimensions:dimensions.slice(),leg,keyframes:frames};
}

// Independent endpoint volume: simplex/box cubic inclusion-exclusion.
function fluidVolume(cell,anchor,leg){
  const lo=cell.map((v,k)=>max(integer(v),half(anchor[k]))),hi=cell.map(v=>integer(v+1));
  if(hi.some((v,k)=>cmp(v,lo[k])<=0))return one;
  const width=hi.map((v,k)=>sub(v,lo[k]));
  let h=half(leg),solid=zero;
  for(let k=0;k<3;k++)h=sub(h,sub(lo[k],half(anchor[k])));
  for(let mask=0;mask<8;mask++){
    let value=h,sign=1;
    for(let k=0;k<3;k++)if(mask&(1<<k)){value=sub(value,width[k]);sign=-sign;}
    if(value.n>0n)solid=add(solid,mul(integer(sign),cube(value)));
  }
  const fluid=sub(one,div(solid,integer(6)));
  if(cmp(fluid,zero)<0||cmp(fluid,one)>0)throw new RangeError('Exact endpoint volume outside [0,1]');
  return fluid;
}

// Integral max(line(t),0)^2 dt, including an exact zero-crossing if needed.
function positiveSquareIntegral(line,lo,hi){
  let a=at(line,lo),b=at(line,hi);
  if(a.n<=0n&&b.n<=0n)return zero;
  if(a.n<0n){lo=div(neg(line[0]),line[1]);a=zero;}
  if(b.n<0n){hi=div(neg(line[0]),line[1]);b=zero;}
  return div(mul(sub(hi,lo),add(add(square(a),mul(a,b)),square(b))),integer(3));
}

// The segment parameter is s in [0,1], NOT physical time. A solid area can
// jump when a coordinate-aligned tetrahedron face crosses this grid face.
// Split those jumps as well as changes to the tangential max(lower,anchor).
function solidAreaIntegral(cell,axis,start,end,leg){
  const face=cell[axis]+1,other=[0,1,2].filter(k=>k!==axis);
  if(face<Math.min(start[axis],end[axis])||face>Math.max(start[axis],end[axis])+leg||
    other.some(k=>cell[k]+1<=Math.min(start[k],end[k])||cell[k]>=Math.max(start[k],end[k])+leg))return zero;
  const anchor=start.map((v,k)=>[half(v),half(end[k]-v)]),breaks=[zero,one];
  for(let k=0;k<3;k++)for(const boundary of k===axis?[face]:[cell[k],cell[k]+1]){
    if(!anchor[k][1].n)continue;
    const crossing=div(sub(integer(boundary),anchor[k][0]),anchor[k][1]);
    if(cmp(crossing,zero)>0&&cmp(crossing,one)<0)breaks.push(crossing);
  }
  breaks.sort(cmp);
  const times=breaks.filter((t,i)=>!i||cmp(t,breaks[i-1])!==0);
  let integral=zero;
  for(let part=1;part<times.length;part++){
    const lo=times[part-1],hi=times[part],mid=div(add(lo,hi),integer(2));
    if(cmp(at(anchor[axis],mid),integer(face))>0)continue;
    const lower=other.map(k=>cmp(at(anchor[k],mid),integer(cell[k]))>0?anchor[k]:constant(integer(cell[k])));
    if(other.some((k,j)=>cmp(at(lower[j],mid),integer(cell[k]+1))>=0))continue;
    const width=other.map((k,j)=>lineSub(constant(integer(cell[k]+1)),lower[j]));
    let height=lineSub(constant(half(leg)),lineSub(constant(integer(face)),anchor[axis]));
    for(let j=0;j<2;j++)height=lineSub(height,lineSub(lower[j],anchor[other[j]]));
    let area=zero;
    for(let mask=0;mask<4;mask++){
      let term=height,sign=1;
      for(let j=0;j<2;j++)if(mask&(1<<j)){term=lineSub(term,width[j]);sign=-sign;}
      area=add(area,mul(integer(sign),positiveSquareIntegral(term,lo,hi)));
    }
    integral=add(integral,div(area,integer(2)));
  }
  if(cmp(integral,zero)<0||cmp(integral,one)>0)throw new RangeError('Exact integrated face area outside [0,1]');
  return integral;
}

/**
 * Integrate continuous, explicitly prescribed co-moving material fluxes.
 * Unit cell length; keyframe times are lattice-time units. The same uniform
 * a_dot moves BOTH solid and fluid. Each cell stores its three positive-face
 * fluxes. Adjacent cells share that exact value, including periodic wrap.
 * faceAreaTime uses the closed-solid trace at persistent solid/grid alignment;
 * it is not a certified kinetic aperture. Normal velocity is zero there.
 * No interpolation of a Frame animation, scalar update or LBM step occurs.
 */
export function planTetraSpaceTimeFlux(options={}){
  const p=parameters(options),d=p.dimensions,n=d.reduce((a,b)=>a*b,1),last=p.keyframes.at(-1);
  const before=[],after=[],flux=[],areaTime=[];
  for(let i=0;i<n;i++){
    const cell=point(i,d);
    before.push(fluidVolume(cell,p.keyframes[0].anchor,p.leg));after.push(fluidVolume(cell,last.anchor,p.leg));
    for(let axis=0;axis<3;axis++){
      let f=zero,a=zero;
      for(let s=1;s<p.keyframes.length;s++){
        const start=p.keyframes[s-1],end=p.keyframes[s];
        const fluidArea=sub(one,solidAreaIntegral(cell,axis,start.anchor,end.anchor,p.leg));
        f=add(f,mul(half(end.anchor[axis]-start.anchor[axis]),fluidArea));
        a=add(a,mul(integer(end.time-start.time),fluidArea));
      }
      flux.push(f);areaTime.push(a);
    }
  }
  let totalBefore=zero,totalAfter=zero;const divergence=[];
  for(let i=0;i<n;i++){
    const cell=point(i,d);let outward=zero;
    for(let axis=0;axis<3;axis++){
      const minus=cell.slice();minus[axis]=(minus[axis]+d[axis]-1)%d[axis];
      outward=add(outward,sub(flux[3*i+axis],flux[3*index(minus,d)+axis]));
    }
    const residual=add(sub(after[i],before[i]),outward);
    if(residual.n)throw new RangeError(`Exact geometric conservation failed in cell ${i}: ${encode(residual)}`);
    divergence.push(outward);totalBefore=add(totalBefore,before[i]);totalAfter=add(totalAfter,after[i]);
  }
  const expected=sub(integer(n),div(cube(half(p.leg)),integer(6)));
  if(cmp(totalBefore,expected)||cmp(totalAfter,expected))throw new RangeError('Endpoint partition differs from analytic tetrahedron volume');
  return {...p,cellCount:n,duration:last.time,stage:'prescribed-affine-tetra-spacetime-geometry-reference',
    volumesBefore:Float64Array.from(before,number),volumesAfter:Float64Array.from(after,number),
    faceFluxes:Float64Array.from(flux,number),faceAreaTime:Float64Array.from(areaTime,number),
    cellFluxDivergence:Float64Array.from(divergence,number),
    exact:{volumesBefore:before.map(encode),volumesAfter:after.map(encode),faceFluxes:flux.map(encode),faceAreaTime:areaTime.map(encode),cellFluxDivergence:divergence.map(encode),totalFluidVolume:encode(expected)},
    exactGeometricConservation:true,maximumExactResidual:'0/1',
    prescribedCoMovingTrajectoryValidated:true,continuousNativeTrajectoryValidated:false,
    nativeSpaceTimeCouplingValidated:false,hardwareGPUValidated:false,
    streamingCollisionPerformed:false,wallImpulseValidated:false,solverReady:false};
}
