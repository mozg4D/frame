// Network-free controls exercise the actual packet functions and bootstrap CLI.
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,cp,symlink,lstat} from 'node:fs/promises';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {packet,args,verifyPacket,newDirectory,save,put,hash,blob,valid,urlFor,fetchPinned,verifyTree,inventory,cleanPath,preserveFailure} from './lib.mjs';
const o=args(['--seal','--evidence']);await verifyPacket(o['--seal']);const out=await newDirectory(o['--evidence'],[packet]);let checks=[];
async function check(name,fn){await fn();checks.push({name,pass:true});}
const bytes=Buffer.from('fixed immutable bytes\n'),d={path:'tests/source.txt',bytes:bytes.length,sha256:hash(bytes),gitBlobSHA1:blob(bytes)};
const mock=(changes={})=>async(url,options)=>{assert.equal(url,urlFor(d));assert.equal(options.redirect,'error');assert.equal(options.headers['Accept-Encoding'],'identity');return {status:200,url,redirected:false,headers:new Headers(),body:(async function*(){yield bytes;})(),...changes};};
try{
 await check('valid immutable byte transport',async()=>assert.deepEqual(await fetchPinned(d,mock()),bytes));
 for(const [name,changes] of [['redirect-status',{status:302}],['partial-status',{status:206}],['missing-status',{status:404}],['changed-url',{url:urlFor(d)+'?alternate=1'}],['redirected-response',{redirected:true}],['absent-body',{body:null}],['content-range',{headers:new Headers({'content-range':'bytes 0-20/21'})}],['wrong-content-length',{headers:new Headers({'content-length':String(bytes.length+1)})}],['compressed-response',{headers:new Headers({'content-encoding':'gzip'})}],['short-response',{body:(async function*(){yield bytes.subarray(1);})()}],['oversize-response',{body:(async function*(){yield Buffer.concat([bytes,Buffer.from('x')]);})()}],['same-size-corrupt-response',{body:(async function*(){yield Buffer.alloc(bytes.length);})()}]])await check(name,()=>assert.rejects(()=>fetchPinned(d,mock(changes))));
 await check('network error no retry',async()=>{let calls=0;await assert.rejects(()=>fetchPinned(d,async()=>{calls++;throw Error('network offline');}));assert.equal(calls,1);});
 await check('wrong Git blob rejected',()=>assert.rejects(()=>fetchPinned({...d,gitBlobSHA1:'0'.repeat(40)},mock())));
 await check('wrong SHA-256 rejected',()=>assert.rejects(()=>fetchPinned({...d,sha256:'0'.repeat(64)},mock())));
 await check('moving commit rejected before fetch',async()=>assert.throws(()=>urlFor(d,'main')));
 await check('path traversal and Windows aliases rejected',async()=>{for(const p of ['../x','/absolute','C:/x','a\\b','a/../b','a//b','a/NUL.txt','a/file.','a/file ','a/b:stream','//server/share','a\0b'])assert.equal(valid(p),false,p);});
 const tiny=join(out,'tiny');await mkdir(tiny);await put(tiny,d.path,bytes);
 await check('exact source verification positive',()=>verifyTree(tiny,[d]));
 await check('missing source rejected',()=>assert.rejects(()=>verifyTree(tiny,[d,{...d,path:'absent.txt'}])));
 await check('extra source rejected',()=>assert.rejects(()=>verifyTree(tiny,[])));
 await check('changed source bytes rejected',()=>assert.rejects(()=>verifyTree(tiny,[{...d,sha256:'0'.repeat(64)}])));
 const linked=join(out,'linked');await symlink(tiny,linked,process.platform==='win32'?'junction':'dir');
 await check('source symlink or junction rejected',()=>assert.rejects(()=>cleanPath(linked)));
 await check('firstFAIL immutable',async()=>{await preserveFailure(tiny,Error('first sentinel'),'sentinel');const b=await readFile(join(tiny,'firstFAIL.json'));await preserveFailure(tiny,Error('second failure'),'retry');assert.deepEqual(await readFile(join(tiny,'firstFAIL.json')),b);});
 const clone=join(out,'packet-copy');await cp(packet,clone,{recursive:true});const marker=join(out,'existing-target');await mkdir(marker);await writeFile(join(marker,'KEEP.txt'),'preserve me');
 const run=(tool,args)=>spawnSync(process.execPath,[tool,...args],{encoding:'utf8',timeout:30000});
 await check('existing target refused without overwrite',async()=>{const r=run(join(packet,'bootstrap.mjs'),['--local-base',tiny,'--out',marker,'--evidence',join(out,'unused-evidence'),'--seal',o['--seal']]);assert.equal(r.status,1);assert.match(r.stderr,/Destination already exists/);assert.equal(await readFile(join(marker,'KEEP.txt'),'utf8'),'preserve me');await assert.rejects(()=>lstat(join(out,'unused-evidence')));});
 await check('corrupt overlay rejected before network or target',async()=>{await writeFile(join(clone,'overlay/plugins/thermal/plugin.js'),'corrupt');const r=run(join(clone,'bootstrap.mjs'),['--fetch','--out',join(out,'never-created'),'--evidence',join(out,'never-created-evidence'),'--seal',o['--seal']]);assert.equal(r.status,1);assert.match(r.stderr,/Packet inventory mismatch/);await assert.rejects(()=>lstat(join(out,'never-created')));});
 await save(out,'RESULT.json',{pass:true,checks:checks.length,networkRequests:0,hardwareRun:false,controls:checks});console.log(JSON.stringify({pass:true,checks:checks.length,networkRequests:0}));
}catch(error){await preserveFailure(out,error,'negative-controls',{completed:checks});throw error;}
