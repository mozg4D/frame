import test from 'node:test';
import assert from 'node:assert/strict';
import {historyFixture} from './native-history-fixture.mjs';

const authoring=()=>[
 {id:'owner-id',nativeHash:'owner',type:'thermal',params:{Initial:26.85,Ambient:20},tags:[]},
 {id:'fan-id',nativeHash:'fan',parent:'owner-id',type:'thermal_fan',params:{Thermal:'owner',Direction:'Forward'},tags:[]}
];
const frame=y=>[.25,0,0,0,.25,0,0,0,.25,-25,y,-12.5];

test('Actual core transform Undo restores Fan matrix while retaining exact owner and Fan JS objects',async()=>{
 const nodes=authoring(),f=historyFixture(nodes);f.setFrame('fan',frame(-12.5));const before=f.frames();f.setFrame('fan',frame(3));f.pushFrame(before,f.frames());
 assert.deepEqual(f.frame('fan'),frame(3));await f.undo();
 assert.strictEqual(f.nodes,nodes);assert.strictEqual(f.nodes[0],nodes[0]);assert.strictEqual(f.nodes[1],nodes[1]);assert.deepEqual(f.frame('fan'),frame(-12.5));
 assert.deepEqual(f.nodes[1].params,{Thermal:'owner',Direction:'Forward'});assert.equal(f.frameRedo,1);assert.equal(f.documentRedo,0);assert.deepEqual(f.events,['frame-engine-parents']);
});
test('Actual core authoring delete Undo replaces JS nodes, preserves durable identities and dispatches restored',async()=>{
 const nodes=authoring();let notified=0;const f=historyFixture(nodes,()=>notified++);f.deleteOwner('owner');assert.equal(f.nodes.length,0);await f.undo();
 assert.notStrictEqual(f.nodes,nodes);assert.notStrictEqual(f.nodes[0],nodes[0]);assert.notStrictEqual(f.nodes[1],nodes[1]);assert.deepEqual(f.nodes,nodes);
 assert.equal(notified,1);assert.equal(f.documentRedo,1);assert.equal(f.frameRedo,0);assert.deepEqual(f.events,['restored']);
});
test('Actual core chronological dispatcher prefers document Undo over older transform metadata',async()=>{
 const nodes=authoring(),f=historyFixture(nodes);f.setFrame('fan',frame(-12.5));const before=f.frames();f.setFrame('fan',frame(3));f.pushFrame(before,f.frames());f.deleteOwner('owner');await f.undo();
 assert.notStrictEqual(f.nodes[0],nodes[0]);assert.equal(f.documentRedo,1);assert.equal(f.frameRedo,0);assert.deepEqual(f.events,['restored']);
});
