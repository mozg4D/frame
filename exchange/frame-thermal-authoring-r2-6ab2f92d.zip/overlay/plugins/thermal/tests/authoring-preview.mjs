import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {activate} from '../plugin.js';
import {nativeCreationFixture,math,manifest,core} from './native-creation-fixture.mjs';

export async function fixture(){
 const native=nativeCreationFixture();let operations,attributes,viewport,editor,deviceReads=0;
 const context={version:1,document:native.context.document,math,
  get device(){deviceReads++;throw Error('Authoring must not acquire a numerical device.');},
  scene:{capture(){throw Error('Authoring must not capture numerical geometry.');}},
  operations:{register:v=>operations=v},attributes:{register:v=>attributes=v},
  editor:{...native.context.editor,register:v=>{editor=v;native.context.editor.register(v);}},
  viewport:{register:async v=>{viewport=v;native.entry.viewport=v;}},
  requestAttributes(){throw Error('No numerical status refresh.');},requestDraw(){throw Error('No numerical drawing.');}};
 await activate(context);const owner=native.create('thermal');native.sync();await native.context.editor.selectOwner(owner.nativeHash);
 const command=(id,args={},hash=owner.nativeHash)=>operations.find(o=>o.id===id).run(hash,args);
 return {native,owner,context,command,operations,attributes,viewport,editor,get deviceReads(){return deviceReads;}};
}
const snapshot=f=>JSON.stringify({nodes:f.native.nodes,frames:f.native.nodes.map(n=>[n.nativeHash,Array.from(f.native.local(n.nativeHash))]),transactions:f.native.transactions,selected:f.native.selected});
const shape=(f,hash)=>Array.from(f.native.local(hash));

test('manifest is a lazy authoring-only closure with genuine 32 px native icon',async()=>{
 assert.deepEqual(manifest.assets,['native-fan.js','native-frame.js']);assert.equal(manifest.tags,undefined);
 assert.deepEqual(manifest.objects.map(o=>o.type),['thermal','thermal_probe','thermal_fan']);
 const source=await readFile(new URL('../plugin.js',import.meta.url),'utf8'),icon=await readFile(new URL('../icon.svg',import.meta.url),'utf8');
 assert.match(icon,/width="32" height="32" viewBox="0 0 32 32"/);assert.doesNotMatch(icon,/transform=/);
 assert.doesNotMatch(source,/createBuffer|createTexture|createComputePipeline|requestAdapter|solveConduction|scene-conjugate|navigator\.gpu/);
 assert.match(core,/button\.disabled=!!action\.disabled/);
 const catalogue=JSON.parse(await readFile(new URL('../../index.json',import.meta.url),'utf8'));assert.equal(catalogue.filter(x=>x==='thermal/plugin.json').length,1);
});

test('every authoring type has a disabled explicit status and no Solve or Measure action',async()=>{
 const f=await fixture(),fan=await f.command('create-fan'),probe=await f.command('create-probe');
 for(const hash of [f.owner.nativeHash,fan.hash,probe.hash]){
  const a=f.attributes(hash),s=f.command('status',{},hash);
  assert.deepEqual(a.actions[0],{id:'status',label:'Under construction',disabled:true});
  assert.ok(a.actions.every(a=>!['measure','solve-grid','solve-scene','clear','cancel'].includes(a.id)));
  assert.equal(s.authoringOnly,true);assert.equal(s.numericalAvailable,false);assert.equal(s.measurementAvailable,false);assert.equal(s.state,'under-construction');
 }
 assert.deepEqual(f.attributes(f.owner.nativeHash).actions.slice(1).map(a=>a.id),['create-fan','create-probe']);
 assert.equal(f.deviceReads,0);assert.equal(f.viewport.render,undefined);assert.equal(f.editor.flush,undefined);
});

test('every numerical endpoint rejects arbitrary input before mutation, device access or capture',async()=>{
 const f=await fixture(),probe=await f.command('create-probe');
 const before=snapshot(f),started=performance.now();
 for(const id of ['solve-grid','solve-scene','measure','inspect','inspect-velocity'])for(const hash of [f.owner.nativeHash,probe.hash])for(const args of [{},{dimensions:[1,1,1],conductivity:[1],cellSize:[.1,.1,.1]},{untrusted:'not a physical request'}]){
  const op=f.operations.find(o=>o.id===id);assert.equal(op.readOnly,true);assert.equal(op.interrupt,undefined);
  assert.throws(()=>f.command(id,args,hash),e=>e.code==='THERMAL_AUTHORING_ONLY');assert.equal(snapshot(f),before);
 }
 const wallMs=performance.now()-started;assert.ok(wallMs<100);assert.equal(f.deviceReads,0);
 console.log(JSON.stringify({operation:'30 rejection-only numerical calls',wallMs,budgetMs:100,hardwareVerified:false}));
});

test('Fan has exact 25 mm native frame and local-X direction independent of native hierarchy',async()=>{
 const f=await fixture(),{hash}=await f.command('create-fan');let fan=f.native.nodes.find(n=>n.nativeHash===hash),r=f.command('fan-inputs');
 assert.deepEqual(shape(f,hash),[.25,0,0,0,0,.25,0,0,0,0,.25,0,-25,-12.5,-12.5,1]);
 assert.deepEqual(r.fan.mapping.sizeMM,[25,25,25]);assert.deepEqual(r.fan.directionLocal,[1,0,0]);assert.equal(r.solverEligible,false);
 f.editor.parameters(fan,{Direction:'Reverse'});fan.params.Direction='Reverse';r=f.command('fan-inputs');assert.deepEqual(r.fan.directionLocal,[-1,0,0]);
 const matrix=math.rotation([0,0,1],Math.PI/2);matrix[0]*=.25;matrix[1]*=.25;matrix[4]*=.25;matrix[5]*=.25;matrix[10]=.25;
 f.native.setLocal(hash,matrix);r=f.command('fan-inputs');assert.ok(Math.abs(r.fan.normalizedWorldAxis[1]+1)<1e-12);assert.equal(r.fan.mapping.status,'unsupported-frame');
 const other=f.native.create('thermal');f.native.sync();fan.parent=other.id;assert.equal(f.command('fan-inputs',{},hash).ownerHash,f.owner.nativeHash);
 assert.equal(f.deviceReads,0);
});

test('Fan and Probe parameter validation rejects invalid references before native mutation',async()=>{
 const f=await fixture();for(const type of ['thermal_fan','thermal_probe']){
  const {hash}=await f.command(type==='thermal_fan'?'create-fan':'create-probe'),n=f.native.nodes.find(n=>n.nativeHash===hash),before=snapshot(f);
  for(const Thermal of ['missing',hash,42]){assert.throws(()=>f.editor.parameters(n,{Thermal}),e=>e.code==='INVALID_ARGUMENT');assert.equal(snapshot(f),before);}
  assert.deepEqual(f.editor.parameters(n,{Thermal:''}),{});assert.deepEqual(f.editor.parameters(n,{Thermal:f.owner.nativeHash}),{});
  if(type==='thermal_fan')for(const patch of [{'Shutoff pressure':-1},{'Free flow':0},{Direction:'Up'}])assert.throws(()=>f.editor.parameters(n,patch),e=>e.code==='INVALID_ARGUMENT');
 }
 assert.throws(()=>f.editor.parameters(f.owner,{Ambient:-274}),e=>e.code==='INVALID_ARGUMENT');
});

test('repeated completed authoring creation and metadata inspection stay bounded with zero numerical allocations',async()=>{
 const f=await fixture(),started=performance.now();
 for(let i=0;i<32;i++){const {hash}=await f.command(i%2?'create-fan':'create-probe');if(i%2){const r=f.command('fan-inputs',{},hash);assert.deepEqual(r.fan.mapping.sizeMM,[25,25,25]);}assert.equal(f.command('status',{},hash).numericalAvailable,false);}
 const wallMs=performance.now()-started;assert.ok(wallMs<1500);assert.equal(f.native.transactions,32);assert.equal(f.deviceReads,0);
 console.log(JSON.stringify({operation:'32 native preview creations plus status/Fan metadata',wallMs,budgetMs:1500,hardwareVerified:false}));
});
