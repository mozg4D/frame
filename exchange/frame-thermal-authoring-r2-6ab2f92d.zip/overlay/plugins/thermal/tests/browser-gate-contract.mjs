import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {isHardwareAdapter,isDecodedNativeIcon,hasBoundedFrameTimings,restoresAuthoringRows} from './browser-gates.mjs';

// These are CPU negative controls for real hardware-harness acceptance logic,
// not a substitute for decoding an image, running a browser or hardware WebGPU.
const harness=await readFile(new URL('./authoring-browser.mjs',import.meta.url),'utf8');
const probeHarness=await readFile(new URL('./native-probe-browser.mjs',import.meta.url),'utf8');
const hardware={vendor:'nvidia',architecture:'test identity',isFallbackAdapter:false};
const icon={decoded:true,complete:true,width:32,height:32,naturalWidth:32,naturalHeight:32,rect:{width:32,height:32}};
const sample=()=>({timestampQueries:true,frames:Array.from({length:12},()=>({cpuMs:1,gpuMs:2}))});
const owner='a'.repeat(32),fan='b'.repeat(32),probe='c'.repeat(32),hashes=[owner,fan,probe];
const rows=()=>[
 {hash:owner,type:'thermal',parent:null,matrix:[1,0,0,0,1,0,0,0,1,0,0,0],worldMatrix:[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],params:{Ambient:20,Initial:20}},
 {hash:fan,type:'thermal_fan',parent:owner,matrix:[.25,0,0,0,.25,0,0,0,.25,-25,-12.5,-12.5],worldMatrix:[.25,0,0,0,0,.25,0,0,0,0,.25,0,-25,-12.5,-12.5,1],params:{Thermal:owner,Direction:'Forward','Shutoff pressure':0,'Free flow':.1}},
 {hash:probe,type:'thermal_probe',parent:owner,matrix:[.02,0,0,0,.02,0,0,0,.02,0,0,0],worldMatrix:[.02,0,0,0,0,.02,0,0,0,0,.02,0,0,0,0,1],params:{Thermal:owner}}
];

test('hardware gate requires explicit false fallback flag, identifiable device and no software identity',()=>{
 assert.equal(isHardwareAdapter(hardware),true);
 for(const isFallbackAdapter of [undefined,null,true,0,'false'])assert.equal(isHardwareAdapter({...hardware,isFallbackAdapter}),false);
 for(const bad of [null,{}, {isFallbackAdapter:false},{vendor:'SwiftShader',isFallbackAdapter:false},{architecture:'llvmpipe',isFallbackAdapter:false}])assert.equal(isHardwareAdapter(bad),false);
 const absent={...hardware};delete absent.isFallbackAdapter;assert.equal(isHardwareAdapter(absent),false);
});

test('icon gate rejects broken, undecoded, natural-size mismatched and layout-scaled images despite 32 px attributes',()=>{
 assert.equal(isDecodedNativeIcon(icon),true);
 for(const key of ['decoded','complete'])assert.equal(isDecodedNativeIcon({...icon,[key]:false}),false);
 for(const key of ['naturalWidth','naturalHeight','width','height'])for(const value of [undefined,0,16,64])assert.equal(isDecodedNativeIcon({...icon,[key]:value}),false);
 for(const key of ['width','height'])for(const value of [0,16,31.999,64])assert.equal(isDecodedNativeIcon({...icon,rect:{...icon.rect,[key]:value}}),false);
 assert.equal(isDecodedNativeIcon({...icon,rect:undefined}),false);assert.equal(isDecodedNativeIcon(null),false);
});

test('Fan frame gate requires exactly twelve timestamp-query samples before every()',()=>{
 assert.equal(hasBoundedFrameTimings(sample()),true);
 for(const count of [0,1,11,13])assert.equal(hasBoundedFrameTimings({...sample(),frames:Array.from({length:count},()=>({cpuMs:1,gpuMs:2}))}),false);
 for(const timestampQueries of [false,undefined,0])assert.equal(hasBoundedFrameTimings({...sample(),timestampQueries}),false);
 for(const key of ['cpuMs','gpuMs'])for(const value of [undefined,NaN,Infinity,50,51]){const bad=sample();bad.frames[11][key]=value;assert.equal(hasBoundedFrameTimings(bad),false);}
 assert.equal(hasBoundedFrameTimings({...sample(),frames:undefined}),false);
});

test('delete Undo cannot pass on empty, wrong-count, missing or duplicated expected hashes',()=>{
 const expected=rows();assert.equal(restoresAuthoringRows(rows(),expected,hashes),true);
 assert.equal(restoresAuthoringRows([],expected,hashes),false);assert.equal(restoresAuthoringRows([],[],hashes),false);
 for(let i=0;i<3;i++){
  const missing=rows();missing.splice(i,1);assert.equal(restoresAuthoringRows(missing,expected,hashes),false);
  const wrong=rows();wrong[i].hash='d'.repeat(32);assert.equal(restoresAuthoringRows(wrong,expected,hashes),false);
  const duplicate=rows();duplicate[i].hash=duplicate[(i+1)%3].hash;assert.equal(restoresAuthoringRows(duplicate,expected,hashes),false);
 }
 assert.equal(restoresAuthoringRows([...rows(),{...rows()[0],hash:'d'.repeat(32)}],expected,hashes),false);
 assert.equal(restoresAuthoringRows(rows(),expected,[owner,fan,fan]),false);
 assert.equal(restoresAuthoringRows(rows(),expected,[owner,fan]),false);
});

test('delete Undo requires every owner/Fan/Probe local/world frame, parent, reference and parameters',()=>{
 const expected=rows();for(let i=0;i<3;i++)for(const field of ['matrix','worldMatrix','parent','type','params']){
  const actual=rows();if(field==='matrix'||field==='worldMatrix')actual[i][field][0]+=1;else if(field==='params')actual[i].params={...actual[i].params,unexpected:true};else actual[i][field]='wrong';
  assert.equal(restoresAuthoringRows(actual,expected,hashes),false,`must reject ${i} ${field}`);
 }
 for(const i of [1,2]){const actual=rows();actual[i].params.Thermal='d'.repeat(32);assert.equal(restoresAuthoringRows(actual,expected,hashes),false);}
 assert.equal(restoresAuthoringRows([...rows()].reverse(),expected,hashes),true,'row order does not replace durable native identity');
});

function sourceBindings(main,probe){
 assert.match(main,/import \{isHardwareAdapter,isDecodedNativeIcon,hasBoundedFrameTimings,restoresAuthoringRows\} from '\.\/browser-gates\.mjs';/);
 assert.match(probe,/import \{isHardwareAdapter\} from '\.\/browser-gates\.mjs';/);
 assert.match(main,/check\('preview uses identifiable hardware WebGPU',isHardwareAdapter\(hardware\),hardware\)/);
 assert.match(probe,/check\('Probe harness uses identifiable hardware WebGPU',isHardwareAdapter\(hardware\),hardware\)/);
 assert.match(main,/await page\.locator\('#tabPlugins'\)\.click\(\)/);
 assert.match(main,/evaluate\(async img=>\{await img\.decode\(\);const rect=img\.getBoundingClientRect\(\);return \{decoded:true,complete:img\.complete,width:img\.width,height:img\.height,naturalWidth:img\.naturalWidth,naturalHeight:img\.naturalHeight,rect:\{width:rect\.width,height:rect\.height\}\}/);
 assert.match(main,/check\('native Thermal icon decodes at its genuine displayed dimensions',isDecodedNativeIcon\(icon\),icon\)/);
 assert.match(main,/const afterFrames=await call\('diagnostics\.frame',\{frames:12\}\)/);
 assert.match(main,/check\('native authoring helper CPU\/GPU frame budget',hasBoundedFrameTimings\(afterFrames\),\{beforeFrames,afterFrames\}\)/);
 assert.match(main,/const restoredRows=await inspect\(\);check\('delete Undo restores native helper identities and references',restoresAuthoringRows\(restoredRows,savedRows,\[owner\.hash,fanHash,probe\.hash\]\)/);
 assert.match(main,/'plugins\/thermal\/tests\/browser-gates\.mjs'/);assert.match(probe,/'plugins\/thermal\/tests\/browser-gates\.mjs'/);
}
test('actual browser harness observation and acceptance call sites are bound to the tested guard module',()=>sourceBindings(harness,probeHarness));

test('source-binding controls reject removed or misbound hardware, decode, frame and Undo guards',()=>{
 for(const [needle,replacement]of [
  ['isHardwareAdapter(hardware),hardware','true,hardware'],
  ['await img.decode();',''],
  ['const rect=img.getBoundingClientRect();','const rect={width:32,height:32};'],
  ['isDecodedNativeIcon(icon),icon','true,icon'],
  ['hasBoundedFrameTimings(afterFrames)','true'],
  ['restoresAuthoringRows(restoredRows,savedRows,[owner.hash,fanHash,probe.hash])','true'],
  ["await page.locator('#tabPlugins').click();",'']
 ]){assert.ok(harness.includes(needle),needle);assert.throws(()=>sourceBindings(harness.replace(needle,replacement),probeHarness),needle);}
 assert.throws(()=>sourceBindings(harness,probeHarness.replace('isHardwareAdapter(hardware),hardware','true,hardware')));
});
