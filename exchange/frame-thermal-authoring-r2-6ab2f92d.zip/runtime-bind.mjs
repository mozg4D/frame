// Read-only qualification around the unchanged source launch call; no source assertions change.
import {chromium} from 'playwright';
import {writeFile,appendFile,mkdir} from 'node:fs/promises';
import {join,resolve,sep} from 'node:path';
import {tmpdir} from 'node:os';
import {processInventory,descendants,identity,ownedProfiles} from './owned-processes.mjs';
const report=process.env.FRAME_PACKET_RUNTIME_REPORT,folder=process.env.FRAME_PACKET_EVIDENCE;
const ownership={nodePID:process.pid,parentPID:process.ppid,freshProfileTempRoot:tmpdir(),cleanup:'Only descendants of this Node PID, with matching creation identities and this fresh profile root, belong to the test. Never kill unrelated chrome/node processes.'};
await writeFile(join(folder,'runtime-ownership.json'),JSON.stringify(ownership,null,2)+'\n',{flag:'wx'});
const original=chromium.launch.bind(chromium),seen=new Map();
async function snapshot(){const rows=await processInventory(),owned=descendants(rows,process.pid);for(const r of owned)seen.set(identity(r),r);await appendFile(join(folder,'runtime-owned-processes.jsonl'),JSON.stringify({at:new Date().toISOString(),owned})+'\n');return rows;}
await snapshot();
chromium.launch=async options=>{
 const browser=await original(options),originalClose=browser.close.bind(browser);let timer,closing,tracking=null,trackingError=null,stopping=false;
 function scheduleTracking(){if(stopping)return;timer=setTimeout(()=>{if(stopping)return;tracking=snapshot().catch(async error=>{trackingError??=error;await writeFile(join(folder,'runtime-ownership-error.json'),JSON.stringify({error:error.message})+'\n',{flag:'wx'}).catch(()=>{});}).finally(()=>{tracking=null;if(!stopping&&!trackingError)scheduleTracking();});},2000);timer.unref();}
 browser.close=()=>closing??=(async()=>{
  stopping=true;clearTimeout(timer);if(tracking)await tracking;
  let closeCompleted=false,remaining=[],inspectionError=trackingError;
  try{await snapshot();}catch(e){inspectionError??=e;}
  // Tracking failure must never prevent closing the browser we own.
  try{await originalClose();closeCompleted=true;}catch(e){inspectionError??=e;}
  try{
   let rows;
   for(let i=0;i<3;i++){rows=await processInventory();if(!rows.some(r=>r.pid!==process.pid&&seen.has(identity(r))))break;await new Promise(r=>setTimeout(r,500));}
   remaining=rows.filter(r=>r.pid!==process.pid&&seen.has(identity(r)));
  }catch(e){inspectionError??=e;}
  const pass=closeCompleted&&!inspectionError&&remaining.length===0;
  await writeFile(join(folder,'runtime-cleanup.json'),JSON.stringify({pass,normalCloseCompleted:closeCompleted,remaining,inspectionError:inspectionError?.message||null,knownOwnedProcesses:[...seen.values()]},null,2)+'\n',{flag:'wx'});
  if(!pass)throw Error('Owned browser cleanup or tracking not confirmed; inspect runtime-cleanup.json and confirm manual cleanup before any further hardware run');
 })();
 try{
  const version=browser.version();if(!/^156\./.test(version))throw Error('Existing Chromium major must be 156; got '+version);
  const launchedRows=await snapshot(),profiles=await ownedProfiles(descendants(launchedRows,process.pid)),temp=resolve(tmpdir()).toLowerCase();if(!profiles.length||profiles.some(p=>!resolve(p.path).toLowerCase().startsWith(temp+sep)))throw Error('Actual owned Chromium profile is absent or outside fresh test TEMP root');await writeFile(join(folder,'runtime-profiles.json'),JSON.stringify({pass:true,profiles,freshTempRoot:tmpdir()},null,2)+'\n',{flag:'wx'});scheduleTracking();
  await writeFile(report,JSON.stringify({playwright:'1.64.1',chromium:version,existingInstallOnly:true,headless:options.headless===true},null,2)+'\n',{flag:'wx'});return browser;
 }catch(e){await browser.close();throw e;}
};
