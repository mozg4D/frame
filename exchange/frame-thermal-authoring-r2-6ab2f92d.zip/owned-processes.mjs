// Read only PID, parent PID, executable name and creation identity. No command lines.
import {readdir,readFile} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const execute=promisify(execFile);
export async function processInventory(){
 if(process.platform==='win32'){
  const script="$ErrorActionPreference='Stop'; @(Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CreationDate) | ConvertTo-Json -Compress";
  const {stdout}=await execute('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{encoding:'utf8',timeout:15000,maxBuffer:4*1024*1024,windowsHide:true});
  const values=JSON.parse(stdout);return (Array.isArray(values)?values:[values]).map(r=>({pid:r.ProcessId,parent:r.ParentProcessId,name:r.Name,created:r.CreationDate}));
 }
 if(process.platform==='linux'){
  const rows=[];for(const name of await readdir('/proc'))if(/^\d+$/.test(name)){try{const text=await readFile('/proc/'+name+'/stat','utf8'),right=text.lastIndexOf(')'),fields=text.slice(right+2).split(' ');rows.push({pid:Number(name),parent:Number(fields[1]),name:text.slice(text.indexOf('(')+1,right),created:fields[19]});}catch(e){if(e.code!=='ENOENT'&&e.code!=='ESRCH')throw e;}}return rows;
 }
 throw Error('Ownership verification supports existing Windows LAB and Linux review only');
}
export function descendants(rows,rootPID){const ids=new Set([rootPID]);let changed=true;while(changed){changed=false;for(const r of rows)if(ids.has(r.parent)&&!ids.has(r.pid)){ids.add(r.pid);changed=true;}}return rows.filter(r=>ids.has(r.pid)).sort((a,b)=>a.pid-b.pid);}
export const identity=r=>r.pid+':'+r.created;
export async function ownedProfiles(owned){
 const profiles=[];
 for(const r of owned){if(r.pid===process.pid)continue;let args=[];
  try{
   if(process.platform==='linux'){const text=await readFile('/proc/'+r.pid+'/cmdline','utf8');args=text.split('\0');}
   else{const script=`$ErrorActionPreference='Stop'; Get-CimInstance Win32_Process -Filter "ProcessId=${r.pid}" | Select-Object ProcessId,CreationDate,CommandLine | ConvertTo-Json -Compress`;const {stdout}=await execute('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{encoding:'utf8',timeout:15000,maxBuffer:65536,windowsHide:true});if(!stdout.trim())continue;const q=JSON.parse(stdout);if(identity({pid:q.ProcessId,created:q.CreationDate})!==identity(r))continue;const re=/(?:"--user-data-dir=([^"]+)"|--user-data-dir="([^"]+)"|--user-data-dir=([^\s]+))/g;for(const m of (q.CommandLine||'').matchAll(re))args.push('--user-data-dir='+(m[1]||m[2]||m[3]));}
   for(const a of args)if(a.startsWith('--user-data-dir='))profiles.push({pid:r.pid,created:r.created,path:a.slice('--user-data-dir='.length)});
  }catch(e){if(!['ENOENT','ESRCH'].includes(e.code))throw e;}
 }
 return profiles;
}
