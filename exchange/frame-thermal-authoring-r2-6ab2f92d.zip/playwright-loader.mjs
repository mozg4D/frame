// Select only the explicitly preflighted existing LAB installation. Never install or download.
import {pathToFileURL} from 'node:url';
export async function resolve(specifier,context,nextResolve){if(specifier==='playwright'){if(!process.env.FRAME_PACKET_PLAYWRIGHT_ENTRY)throw Error('Missing preflighted Playwright entry');return {url:pathToFileURL(process.env.FRAME_PACKET_PLAYWRIGHT_ENTRY).href,shortCircuit:true};}return nextResolve(specifier,context);}
