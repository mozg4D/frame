import {readFile,writeFile,lstat} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {packet,args,fail,verifyPacket,cleanPath,newDirectory,verifyTree,inventory,regular,put,save,verifiedBytes,fetchPinned,preserveFailure,overlap,equal} from './lib.mjs';
let evidence,target,stage='preflight',source,packetBefore,m;
try{
 const o=args(['--seal','--local-base','--out','--evidence'],['--fetch','--verify-package']);
 const verified=await verifyPacket(o['--seal']);({m,packetBefore}=verified);
 if(o['--verify-package']){if(Object.keys(o).some(k=>!['--seal','--verify-package'].includes(k)))fail('Verification-only takes --seal only');console.log(JSON.stringify({pass:true,packetVerified:true,baseFiles:525,finalFiles:545,networkUsed:false}));}
 else{
  if(!!o['--fetch']===!!o['--local-base']||!o['--out']||!o['--evidence'])fail('Choose exactly --fetch or --local-base BASE, plus --out NEW --evidence NEW --seal HASH');
  source=o['--local-base']?await cleanPath(o['--local-base']):null;
  target=await cleanPath(o['--out'],{missing:true});const ev=await cleanPath(o['--evidence'],{missing:true});
  if([packet,...source?[source]:[]].some(p=>overlap(p,target)||overlap(p,ev))||overlap(target,ev))fail('Input, new destination and evidence must be disjoint');
  for(const p of [target,ev]){try{await lstat(p);fail('Destination already exists; nothing overwritten: '+p);}catch(e){if(e.code!=='ENOENT')throw e;}}
  evidence=await newDirectory(ev,[packet,target,...source?[source]:[]]);await save(evidence,'packet-before.json',packetBefore);
  stage='network-free source preflight';
  const before=source?await verifyTree(source,m.baseFiles):m.baseFiles;
  await save(evidence,'source-before.json',{mode:source?'offline-exact-base':'immutable-public-base-manifest',files:before});
  // All package/schema/path/source checks complete before target creation or first request.
  target=await newDirectory(target,[packet,evidence,...source?[source]:[]]);
  stage='materialize complete original base';let total=0;
  for(let i=0;i<m.baseFiles.length;i+=3){const batch=m.baseFiles.slice(i,i+3),results=await Promise.allSettled(batch.map(async d=>verifiedBytes(source?await regular(source,d.path):await fetchPinned(d),d)));const failed=results.find(r=>r.status==='rejected');if(failed)throw failed.reason;for(let k=0;k<batch.length;k++){await put(target,batch[k].path,results[k].value);total+=batch[k].bytes;}}
  if(total!==204029885)fail('Materialized base byte total mismatch');await save(evidence,'base-before-overlay.json',await verifyTree(target,m.baseFiles));
  stage='apply frozen overlay';
  for(const d of m.overlayFiles){const b=await regular(packet,'overlay/'+d.path),final=m.finalFiles.find(x=>x.path===d.path);verifiedBytes(b,final);if(d.baseBlob){const base=m.baseFiles.find(x=>x.path===d.path);verifiedBytes(await regular(target,d.path),base);await writeFile(join(target,d.path),b,{flag:'r+'});const h=await import('node:fs/promises');await h.truncate(join(target,d.path),b.length);}else await put(target,d.path,b);}
  stage='final exact inventory';await save(evidence,'final-after.json',await verifyTree(target,m.finalFiles));
  if(source)await save(evidence,'source-after.json',{mode:'offline-exact-base',files:await verifyTree(source,m.baseFiles)});
  else await save(evidence,'source-after.json',{mode:'immutable-public-base-manifest',files:m.baseFiles});
  if(!equal(await inventory(packet),packetBefore))fail('Packet changed during materialization');await save(evidence,'packet-after.json',packetBefore);
  await save(evidence,'result.json',{pass:true,baseCommit:m.baseCommit,freeze:m.frozenOverlayManifestSHA256,baseFiles:525,finalFiles:545,overlayFiles:23,sourceUnchanged:true,networkBytes:source?0:total,hardwareRun:false,standardStressRun:false});console.log(JSON.stringify({pass:true,baseFiles:525,finalFiles:545,networkBytes:source?0:total,sourceUnchanged:true}));
 }
}catch(error){await preserveFailure(evidence,error,stage);if(evidence){for(const [label,root] of [['source',source],['target',target],['packet',packet]])if(root){try{await save(evidence,label+'-after-failure.json',await inventory(root));}catch(e){await save(evidence,label+'-after-failure-error.json',{error:e.message}).catch(()=>{});}}}console.error(error.stack);process.exitCode=1;}
