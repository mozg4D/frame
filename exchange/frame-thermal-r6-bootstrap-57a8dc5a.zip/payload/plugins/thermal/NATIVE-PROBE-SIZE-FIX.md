# Native Probe helper-size correction

## Scope and diagnosis

This isolated candidate corrects only new Probe initialization. The documented
2 mm helper convention is retained, with zero parent-local sample origin. No
sampling algorithm, numerical solver, shared helper geometry, core runtime,
catalogue or interface changes. Existing authored Probe frames are not migrated.
No main, live-site, user-scene or OBS operation was performed.

Pinned input sources:

- Core `index.html`: `a8e82c4e8986a57b5b4b0d72539c5bbe60dbbfb8c6671e588492bedb4a77eba0`.
- Old Thermal `plugin.js`: `1822c7abd9959f46971b789fc8e3364b8d70a92caffbfd12e21c72a616957087`.
- Unchanged Fan browser fixture: `c957655f1975aa7ea6f88d0a0f783e01dae8dbbd27be48728bcb5a35fea2d610`.

Core `create()` calls `editor.created` before the initial native synchronization.
The old Probe hook assigned scale in `n.transform`. Actual
`frameSyncEngineVisibility()` consumes only packed `creationFrame`, so native
record installation received no matrix and `objectLocal()` returned identity.
The actual helper therefore remained a 100 mm cube despite fallback scale .02.

## Exact runtime replacement

Replace this unique block in `plugins/thermal/plugin.js`:

```js
if(n.type==='thermal_probe'){n.transform[2]=n.transform[5]=n.transform[8]=.02;}
```

with:

```js
if(n.type==='thermal_probe'){const frame=context.math.I();frame[0]=frame[5]=frame[10]=.02;n.creationFrame=Array.from(context.math.pack(frame));}
```

New `plugin.js` SHA-256:
`f9d1d14dc6e02785d9d12d4e44a3565c61c933ee47a41f100fabb885583f0153`.

The packed native local matrix is
`[.02,0,0,0,.02,0,0,0,.02,0,0,0]`. Applied to the existing `[-50,50]³`
geometry, all twelve edges are 2 mm and bounds are `[-1,1]³` in parent
coordinates. Ordinary parent rotation/reflection/nonuniform scale compose with
this frame. Its translation is zero, so the Probe world origin remains exactly
the owner's world origin. Standalone creation has the same matrix and an empty
Thermal reference. Core removes `creationFrame` after consumption; later native
edits, synchronization and restoration do not reset the helper.

## Regression coverage

`native-probe.mjs` reuses `native-creation-fixture.mjs`, which extracts the actual
current core create, document bridge, visibility/native sync, native record
installation, frame readers and affine math. It does not synthesize a conversion
from obsolete transform values. Unrelated UI/GPU/animation endpoints and record
addressing remain CPU fixture adapters, not browser proof.

Seven tests cover actual helper edge lengths and bounds, explicit reference,
single transaction and selection, the old 100 mm defect, standalone creation,
parent-local composition, one-shot consumption, repeated sync, later authored
edits and unchanged Thermal/Fan defaults. The 32 completed create/sync budget is
1500 ms. The older creation test in `numerics.mjs` now uses that actual-core
fixture rather than inspecting fallback transform values; all its transaction,
reference, validation, Measure label and no-result expectations remain.

`native-probe-browser.mjs` is a focused real-hardware gate using the supported
`tools/browser.mjs` runner and a fresh browser context. Only the catalogue response
is extended locally. No runtime replacement, mock physics or live scene is used.
It checks actual `scene.inspect` matrix/worldMatrix/bounds, native Probe button,
selectable helper edges, standalone and transformed-parent creation, repeated
sync, transform Undo/Redo, and HASH persistence of an edited Probe frame. It also
checks 32 completed creations below 10000 ms and real timestamp-query CPU/GPU
frames each below 50 ms. Individual native edits retain 1500 ms budgets.

The full Thermal browser suite includes the new focused gate and adds actual
2 mm/native-frame/bounds assertions to its existing explicit-grid Probe creation
and HASH restoration checks. Existing centre-temperature, bounded-read, repeated
measurement, invalid-replacement, clear/stale and physical-field checks are
preserved without relaxed tolerances. `run.mjs` records the new fixture hashes.

## Verification and remaining gates

- Full Thermal CPU suite: **361/361 PASS**, 40 test modules, zero skips.
- New Probe creation tests plus numerical tests: **27/27 PASS**.
- The same updated tests against the old runtime: **21/27 PASS, 6 FAIL**. This is
  the intentional negative control, demonstrating rejection of old native size.
- Core syntax: two executable and five lazy scripts checked. Changed modules
  pass `node --check`.
- `npm test -- --headless` and `npm run test:stress -- --headless` each pass
  64 pre-browser assertions, then fail at launch because pinned Playwright
  Chromium 1248 is absent. Neither application gate passed.
- Focused Probe and full Thermal browser commands also stop at launch with
  **zero browser checks executed**. No alternate browser or software adapter
  substitutes for actual hardware.

CPU emulators/source contracts are not WGSL, browser, renderer or GPU timing
qualification. Previous hardware results on the input runtime do not certify
these changed bytes. Run both commands on an isolated hardware context before
considering this correction hardware-qualified:

```sh
node plugins/thermal/tests/native-probe-browser.mjs --headless
node plugins/thermal/tests/run.mjs --headless
```

Full application/stress and relevant large-scene qualification remain separate
release gates. This is not a general Thermal release or saved-Fan solver coupling.
The delivery manifest supplies exact before/after hashes, unique replacements,
complete overlay files and verification logs for review and controlled transfer.
