# Native Fan default-frame correction

## Scope and exact diagnosis

This isolated correction preserves the candidate's existing 25 mm default-size
convention and owner-local centre `[-25,-12.5,-12.5]` mm. It does not establish
these numbers as a separately requested physical model. No solver, mapper,
catalogue, interface, Probe initialization or core runtime code changes.

Pinned input sources:

- Core `index.html`: `a8e82c4e8986a57b5b4b0d72539c5bbe60dbbfb8c6671e588492bedb4a77eba0`.
- Old `plugin.js`: `48b9a35998f0305feaacf8152f1ead1d4f32a2e36431e0f37b0b55b42ac9f3ef`.
- Unchanged `native-fan.js`: `bb68e89f37fad4abbcabce6d42ddccc4fa64c61d8f01a49be027a43e0fc1fd67`.
- Unchanged browser harness: `ce6a3e26bb86f508b99a372952c505e3b92d1c1c9a08716f538518c41b41ff47`.

Actual core `create()` calls the plugin `created` hook. The old hook assigned
`n.transform`, but `frameSyncEngineVisibility()` forwards only
`n.creationFrame` as the initial native matrix. `syncNativeObjects()` calls
`installNativeRecords()`, which preserves existing matrices or installs the
supplied packed matrix; without one, `objectLocal()` returns identity. The old
Fan therefore became a native 100 mm cube at the origin. The former CPU fixture
incorrectly converted `n.transform` into a matrix, a conversion the real core
never performs, so it masked the failure.

`box.localSizeMM` remains `[100,100,100]`: it describes unscaled shared helper
geometry, not authored dimensions. The corrected default has
`box.worldEdgeLengthsMM` and owner-relative `mapping.sizeMM` equal to
`[25,25,25]` under an identity owner. With a scaled owner, world edge lengths
follow that native owner frame; owner-relative size remains 25 mm.

## Exact runtime replacement

Replace this unique block in `plugin.js`:

```js
if(n.type==='thermal_fan'){n.transform=[-25,0,.25,-12.5,0,.25,-12.5,0,.25];}
```

with:

```js
if(n.type==='thermal_fan'){const frame=context.math.I();frame[0]=frame[5]=frame[10]=.25;frame.set([-25,-12.5,-12.5],12);n.creationFrame=Array.from(context.math.pack(frame));}
```

Resulting `plugin.js` SHA-256:
`1822c7abd9959f46971b789fc8e3364b8d70a92caffbfd12e21c72a616957087`.

The core consumes and removes `creationFrame` during synchronization. Later
native edits and repeated sync retain installed matrix records; the initializer
is not a parallel saved pose or a recurring transform override.

## Regression and verification

`node --test plugins/thermal/tests/native-fan.mjs` runs 15 focused tests. Its new
`native-creation-fixture.mjs` executes the actual extracted current-core create,
plugin document bridge, visibility sync, native sync, native-record installation,
frame readers and affine math. Unrelated UI/GPU/animation endpoints and record-key
addressing are CPU adapters. This is not real browser, renderer, Undo or HASH IO.

The tests preserve the 25 mm expectation and cover:

- The exact old transform-only defect, with 100 mm native dimensions and origin.
- Default native matrix, explicit owner/transaction/selection, standalone Fan.
- Parent-local default under translated/rotated/anisotropically scaled owner.
- Consumption of the initializer, repeated sync and later edited native matrices.
- Existing validation, strict mapping, finite metadata and detached solver scope.
- 32 complete source-extracted creation/sync operations under 1500 ms, plus
  1000 inspections of a 10000-node document under 1500 ms.

The strengthened regression on the old plugin failed 7 of 15 tests. The corrected
plugin passes 15 of 15. The complete Thermal CPU suite passes 350 of 350 with no
skips. All emulator tests remain CPU-only numerical/lifecycle evidence.

`npm test -- --headless` and `npm run test:stress -- --headless` each complete
64 pre-browser assertions (including syntax), then fail at launch because the
pinned Playwright Chromium executable is absent. The unchanged focused Fan
browser harness also stops before any checks for the same reason. No alternate
browser, software GPU, live scene or OBS route was attempted. Actual native
Fan interaction/rendering/timing and full application/stress/large-scene checks
remain pending hardware gates, not passing checks.

Independent source-contract review also executes the pinned core pipeline and
verifies the corrected default, translated/rotated/reflected/nonuniform owner,
standalone state, initializer consumption and preservation of later edits.

## Separate follow-up risk

The unchanged browser harness reuses an explicit request's numeric
`fluidOccurrence` after native Undo, even though document reconstruction may
reorder captured occurrences. A later failure there requires separate identity
analysis; it does not justify weakening this default-frame assertion or changing
the solver. No occurrence-order harness modification is included here.
