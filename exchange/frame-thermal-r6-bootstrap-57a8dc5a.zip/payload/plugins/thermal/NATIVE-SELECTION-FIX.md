# Native Probe and Fan creation selection

## Proven failure and limited correction

The R5 isolated Probe hardware check confirmed the 2 mm native helper, then found
that an immediate numeric edit moved the Thermal owner instead of its selected
child. The full Windows diagnostic had only Probe selected in the UI, but owner
local/world X changed 0 to 3, while Probe local X stayed 0 and world X became 3.
Diagnostic snapshot SHA-256:
`686122f64d1c6c0315a1df83494a48968d285c71f07ba702d3a4d7c1f3415234`.

Core `document.select` (`index.html:11048`) updates the UI selection and Attributes
but does not call `frameSelectEngineObjects`. `editor.selectOwner` (11053) does.
`scene.inspect.matrix` (18752) is the real packed native local matrix, not a legacy
pose. The transform engine reads `objectSelection` through `selectedRoots`
(14413), which still held the owner. Parent composition explains the moved child
world frame exactly. A world-only assertion would hide a wrong-target edit and
leave the sample at the same owner-local point.

This candidate fixes the two Thermal creation operations only. It does not change
core, public operation schemas/results, helper sizes, sampling, physics, Fan
mapping, runtime field ownership or the catalogue. Other plugins' selection use is
outside this correction. The frozen R5 candidate is unchanged. No main, live site,
working scene, OBS or Windows operation is part of this source task.

## Exact runtime contract

Base core SHA-256:
`a8e82c4e8986a57b5b4b0d72539c5bbe60dbbfb8c6671e588492bedb4a77eba0`.

Old Thermal runtime SHA-256:
`f9d1d14dc6e02785d9d12d4e44a3565c61c933ee47a41f100fabb885583f0153`.

New Thermal runtime SHA-256:
`b32ce100b8d3936683eace4bb4cdae45a87e88757eadda7e095c03c6c36df7fa`.

Each `create-probe` / `create-fan` handler becomes `async run(hash)`. The existing
single `D.transaction` still creates the native child, writes its explicit Thermal
reference and calls `D.select(childHash, 'objects')`. After that transaction has
synchronized its native records, the operation executes:

```js
await context.editor.selectOwner(n.nativeHash);
```

It then returns the same result object as before. Probe returns `{hash,type}`;
Fan additionally returns `authoringOnly:true`.

The existing helper calls `frameSelectEngineObjects` (11956), then `selectObjects`
and its native `selectionQueue` (17674). It creates no authoring transaction or
extra Undo checkpoint. The synchronous transaction is not made asynchronous.
Attributes remains selected normally; there is no fallback, alternate pose,
manual selection repair or second selection implementation in runtime.

The actual `frameAI.call` task tail awaits `tool.run` before completing and
starting the next command (18885). An immediately queued transform therefore waits
for selection completion. The operation does not recursively call the serialized
API, avoiding a self-wait. Later user/editor selection must remain authoritative;
finishing an older creation must not reselect its child over that newer selection.

If `selectOwner` rejects, the operation rejects and does not report successful
completion, retry or create a duplicate. The child and its one checkpoint already
exist and remain undoable. This is not atomic rollback. The core's own
`selectObjects().catch(editError)` behavior for contained drawing errors is
unchanged; explicit endpoint rejection tests do not misrepresent that handling.

## Regression requirements

`native-creation-fixture.mjs` now executes the actual extracted native bridge,
commit, selection synchronizer, `selectObjects` / `applyObjectSelection` queue,
serialized API call queue, pivots, native transforms, snapshots and restoration,
in addition to prior creation/synchronization/record/math paths. GPU, DOM,
record-key addressing and unrelated API validation/settling are labelled test
adapters. This does not claim full native browser Undo/HASH or renderer coverage.

`native-selection.mjs` covers both child types: matching UI/engine selection,
exactly one creation checkpoint, delayed completion, rejection and subsequent
queue recovery, repeated creation, preservation of earlier children, actual
parent-local/world edits, frame restoration and source reproduction of the old
wrong-target defect. Additional cases preserve a newer editor selection after a
delayed creation, exercise vertex/edge/polygon display modes, and bound API-tail
completion to detect self-wait. Its budget is 32 complete creation/selection/API-queue/
transform operations within 1500 ms. Existing Probe/Fan/numerics fixtures now
await the operations and retain the actual native editor bridge rather than a
register-only mock. No production compatibility shim is introduced.

Both focused browser gates require an immediate transform after the Attributes
creation action to change the child's native local/world frame and helper bounds
while the owner's local/world frame stays unchanged. No `scene.select` occurs
between the action and this check. The original Probe packed X=3 expectation is
retained. Fan also checks exact translated bounds. Queued API creation+transform
paths exercise the real serial command boundary without awaiting creation before
submitting the edit. Probe repetitions verify earlier records stay unchanged.

Undo of the transform restores defaults; the next Undo must remove the creation,
proving selection added no checkpoint. Redo restores the native authoring and
subsequent edited frame where applicable. Existing field/measurement/stale/copy/
HASH tests and acceptance tolerances are retained.

Existing wall-time limits remain: Probe creation 2000 ms, Fan creation 10000 ms,
native edits 1500 ms, 32 native creations 10000 ms, measured CPU/GPU frames each
below 50 ms. Queued combined limits sum the individual limits and still assert
individual creation/edit times. Focused and full reports include source hashes.

## Hardware and release gates

Run all three on a fresh isolated hardware context using the supported runner:

```sh
node plugins/thermal/tests/native-probe-browser.mjs --headless
node plugins/thermal/tests/native-fan-browser.mjs --headless
node plugins/thermal/tests/run.mjs --headless
```

The cloud has no pinned Chromium 1248 executable. Launch-blocked runs execute zero
browser checks and are not passing hardware results. No alternate browser,
software adapter or CPU emulator may replace that evidence. Standard/stress
application suites and relevant large-scene performance remain separate release
gates. Previous runtime CPU/GPU passes do not qualify changed source bytes.

Final CPU counts, source hashes, negative-control results, independent review and
preserved launch-failure reports are recorded in the delivery verification summary.
