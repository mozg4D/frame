# Native Fan history fixture correction

## Scope

Only test code and this verification note change. Core, Thermal runtime,
manifest/catalogue, default 25 mm Fan frame, solver physics and numerical
acceptance budgets remain unchanged. This is an isolated source candidate, not a
live release or a completed hardware qualification.

Pinned sources:

- Core `index.html`: `a8e82c4e8986a57b5b4b0d72539c5bbe60dbbfb8c6671e588492bedb4a77eba0`.
- Thermal `plugin.js`: `1822c7abd9959f46971b789fc8e3364b8d70a92caffbfd12e21c72a616957087`.
- Old browser fixture: `ce6a3e26bb86f508b99a372952c505e3b92d1c1c9a08716f538518c41b41ff47`.
- Corrected browser fixture: `c957655f1975aa7ea6f88d0a0f783e01dae8dbbd27be48728bcb5a35fea2d610`.
- Unchanged stable-hash resolver: `aa05c16d5b5def99531ec8f4bf3d11ccc5ff9f8b72b99ca13945afe7c8c0e299`.

## The incorrect expectation

The earlier fixture assumed that every Undo replaces native JS owner objects.
The observed native transform Undo restored the Fan translation from
`[-25,3,-12.5]` to `[-25,-12.5,-12.5]`, kept scale 0.25, retained the exact owner
object/session ID/native hash and retained the ready explicit-request job and
its temperature. This is correct: saved Fan authoring is not consumed by the
explicit numerical request.

The current core has two distinct history routes. Transform metadata Undo calls
`restoreFrames(metadata.before, true, metadata.after)` without reconstructing
nodes. Authoring document Undo reaches `frameUndoUI()` and `restore()`, which
assigns parsed `s.nodes` and dispatches the plugin `restored` notification.
Owner deletion followed by this document Undo therefore provides a genuine
same-hash/different-JS-owner case. A frame-only Undo must not be used to stand in
for it.

## Browser gates

The focused harness still creates a fresh isolated browser context and requires
identifiable non-software WebGPU. A uniquely guarded module-route insertion
captures the real activation context for read-only document identity comparison.
It does not replace GPU results, pause stages, modify editor hooks or write
runtime source files.

The corrected sequence requires:

1. The actual explicit one-step field contains all 24 finite temperatures and 30
   finite local-X face velocities. It meets the existing independent one-step
   reference budgets of 0.0005 K and 0.00002 m/s, and has exactly one 0.01 s step
   with 0.75 J source energy within the existing numerical comparison tolerance.
2. Actual authored Fan parameter and position changes retain the same JS owner
   and Fan objects, native IDs, job and bit-for-bit identical complete 24T/30u
   samples. Transform Undo restores the exact prior Fan mapping and preserves
   the edited parameters, while retaining that same job and those samples.
3. Native owner deletion removes both owner and child Fan. Native delete Undo
   restores the same durable owner/Fan hashes but different JS objects. Status
   is idle with a null job, and temperature and velocity inspection both reject
   with `NO_RESULT`. No old result is resurrected.
4. A fresh complete two-occurrence capture resolves the fluid's stable mesh hash
   through the existing strict resolver. Missing, ambiguous or incomplete
   captures reject; no retained array index or inferred material role is used.
   A fresh solve has a new job, agrees with the prior physical field within the
   existing budgets, and independently agrees with the one-step oracle. This
   fresh GPU solve is not required to be bitwise repeatable.
5. Changing the actual solid Heater to 76 W makes the fresh job stale and both
   temperature and velocity reads reject with `NO_RESULT`.

The 25 mm default, strict mappings, invalid-parameter checks, enabled semantics,
completed-operation budgets, 32-Fan and 100-inspection performance checks,
CPU/GPU frame budgets, HASH Open/Merge, native reference drop, wrong-type
rejection, duplicate and clipboard reference checks remain strict. The original
prefix before the explicit-scene segment and suffix from the 100-inspection
performance block are preserved verbatim apart from imports/observation and
report source entries.

## CPU evidence and limits

`native-history-fixture.mjs` extracts the actual current-core `undoEdit`,
`restoreFrames`, `frameUndoUI` and authoring `restore` functions. Narrow CPU
adapters supply record addressing/storage, snapshot capture, DOM and rendering
endpoints. The three history contract tests prove the frame-versus-document
identity distinction and chronological route selection. They are not browser,
HASH serialization or GPU tests.

The added `native-fan.mjs` regression combines those source-extracted history
routes with the shipped Thermal controller and test-only GPU command emulator.
It proves exact 24T/30u retention for detached Fan edits and frame Undo,
retirement on document owner replacement, stable-hash restart after a reversed
occurrence capture, and Heater stale rejection. It does not fabricate successful
production GPU work or establish hardware qualification.

The full source-bound CPU results and exact unique replacement blocks are stored
in the delivery evidence. Real browser/GPU checks, full application/stress and
large-scene qualification remain separately required. Missing Chromium is a
blocked gate, never a pass. No alternate browser, working scene or OBS route is
used.

Final source-bound CPU verification: 354/354 tests pass serially with zero skips
in 23.24 s. The first complete serial run passed 353/354: the unchanged 8³
implicit-heat latency check took 6155 ms against its existing 5000 ms budget.
That failure is retained. An unchanged isolated retry passed 11/11 with the same
operation at 209 ms; the unchanged complete retry then passed all 354 tests.
No numerical or latency tolerance was relaxed. The focused history/Fan/job/Probe
and exact-identity set passes 50/50.

The final focused browser attempt executes zero browser checks because the
pinned Playwright Chromium executable is absent. Standard and stress each pass
64 pre-browser assertions, then fail at the same missing executable. They are
not passing application or hardware runs. All logs retain the exact tested
source hashes, with no source changes between the final CPU run and packaging.
