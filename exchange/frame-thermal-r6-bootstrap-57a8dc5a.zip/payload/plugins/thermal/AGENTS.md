# Thermal numerical foundation

Follow ../../AGENTS.md and ../AGENTS.md. Read README.md before changing the model.

- Keep runtime in plugin.js and keep Thermal independent of other solvers.
- This is an explicit-grid conduction foundation, not a geometry-driven Thermal release. Do not add a scene Solve action or advertise convection, radiation, or animation physics until implemented and validated. Material/Heater authoring remains separate from grid solving.
- Use SI internally. Frame's millimetres must be converted by a future scene adapter, not guessed from grid numbers.
- Preserve reciprocal face conductances, half-cell Dirichlet distances, source-volume and boundary-flux-area normalization, and backward-Euler energy accounting. Prescribed flux is inward-positive; boundary diagnostics remain outward-positive. Reject overlapping temperature/flux conditions.
- Production iteration uses the borrowed WebGPU device. The independent Float64 direct solver belongs only in tests.
- Run node plugins/thermal/tests/numerics.mjs and the hardware browser checks in tests/run.mjs. Standard/stress integration discovers tests/index.mjs once the integrator registers the manifest. No software-adapter substitution or skipped GPU checks counted as success.
- Keep numerical fields runtime-only. Native authoring/Undo/HASH own Thermal objects and parameters. Publish only converged, current, uncancelled results and release every owned resource on failure or retirement.

- Probe reads at most eight explicit-grid cell values. Centre the grid in owner coordinates, convert millimetres to metres exactly once, reject exterior points, and revalidate source and Probe after every asynchronous read. It must not imply scene geometry has been solved. Keep readings runtime-only and use native transactions for Probe creation. Run tests/probe.mjs with the numerical suite.

- Initialize new Probe helpers with native packed creationFrame, never fallback n.transform. Preserve the 2 mm parent-local helper and zero sample origin; core consumes the initializer once and later native frames remain authoritative. Run tests/native-probe.mjs against the actual extracted core and tests/native-probe-browser.mjs on real hardware. Helper-size checks must not replace or weaken measurement/stale-field tests.

- Probe/Fan creation must retain one native authoring transaction and await context.editor.selectOwner afterward, before returning. document.select only updates UI selection. Reuse the native selection queue, never call the serialized frameAI API recursively, add selection fallbacks or hide wrong-target edits with world-only tests. Immediate Attributes/API transforms must change the child local/world frame while leaving its owner unchanged. Run tests/native-selection.mjs and the strict native Probe/Fan browser gates; test delayed completion and rejection without inventing rollback semantics.

- scene-grid.js is an internal adapter, not occupancy validation. Never register it as a scene solver without a validated classifier, complete Heater coverage, boundary model and scale-aware field sampling. Keep source provenance and physical-volume accounting explicit.

- box-classifier.js recognizes actual twelve-triangle axis-aligned cuboid boundaries only. Preserve strict triangle validation, partial/void rejection and resource-free metadata outputs. It is internal and hardware-unverified; do not register Solve or extrapolate it to general material volumes or fluid domains.

- scene-pipeline.js is internal only and supports a complete single-cuboid domain. Keep production solve GPU-only. Test-injected solvers belong solely in tests; never expose a mock Solve or claim hardware completion from CPU lifecycle tests. Returned handles require explicit disposal and enforce stale/cancel checks.

- touching-classifier.js must preserve two independently captured interfaces. Never substitute aggregate union or bounds-only filling. Its first scope is exact buffer-backed full-face cuboids with perfect contact and exact restricted relative transforms. Keep reciprocal conductance and resistance-aware Probe metadata; reject gaps/overlaps/uncertain contact rather than snapping.

- layered-heat-gpu.js is an internal explicit-grid conduction/source adapter, not a fluid solver or native scene command. Preserve explicit Kelvin/Celsius conversion, shared-device ownership, Float32 source gates, abort/stale cleanup and bounded reads. No CPU fallback. Read GPU-INTEGRATION-PLAN.md before extending GPU/native scope.

- mac-projection-gpu.js is a bounded internal qualification stage only. Preserve all-fluid/closed-wall limits, local actual-field checks, GPU-only iteration, synchronous shared-device error scopes and unconditional cleanup. Do not advertise hardware validation from the test-only command emulator.

- mac-viscosity-gpu.js remains a bounded all-fluid closed-box qualification stage. Preserve normal/tangential no-slip coefficients, per-component normalization and actual dimensional residual/energy checks. No CPU fallback, implicit projection claim or hardware claim from emulator tests.

- mac-fan-gpu.js is a partial-sheet qualification, not a general fan/scene solver. Keep operating-pressure-relative actual-flow acceptance, finite midpoint work/energy gates and nested GPU lifecycle. Do not replace full-span rejection with an unlabelled CPU analytic fallback or call mechanical work heat.

- temperature-advection-gpu.js must preserve shared single face fluxes, both pre/post-upload CFL/divergence checks, normal physical energy/transfer gates and actual Kelvin reconstruction. Do not relax incompressibility to connect GPU flow without a separately validated composition contract.

- project-temperature-gpu.js requires an explicit local per-step divergence drift budget. Never replace per-cell original/uploaded checks with global projection diagnostics, enlarge energy allowance for divergence, or advertise the per-step bound as long-time accuracy. Strict standalone transport remains the default.

- forced-temperature-gpu.js must keep fan last mechanically and use that exact returned velocity for passive transport. Preserve per-cell drift/CFL checks, separate mechanical/thermal accounting, source snapshots and late-failure cleanup. No fan/viscous heat conversion or full CFD/scene claim.

- fluid-heat-gpu.js/forced-heat-gpu.js must reuse the existing GPU conduction solver, keep explicit Kelvin conversion and adiabatic-only scope, and validate actual source-cell residual relative to source power. Apply source once after advection, keep mechanical/thermal energy separate, dispose retained conduction fields even on late failures.

- conjugate-heat-gpu.js must confine flow/advection to the left fluid chamber, keep interface/solid velocities zero, preserve reciprocal layered heat conductance and apply solid source only in the shared heat solve. Check actual per-cell/source/global/regional energy and retained-field cleanup. No arbitrary-geometry or native scene extrapolation.

- scene-conjugate.js is an internal one-step-from-rest qualification bridge, not a public scene operation. Require an explicit left fluid role and SI densities/viscosity, preserve native volumetric capacities and solid-only Heater provenance. Local-X fan box centre/footprint must be exactly grid-aligned; box thickness has no force-volume semantics. Reuse the existing GPU chain and physical-frame Probe. No native job/UI registration until real browser/GPU qualification; never call the test-only CPU oracle a production fallback.

- scene-conjugate-duration.js reuses the existing GPU timestep, preserving actual T/u/v/w over at most ten steps and 0.1 s. Require explicit cumulative local divergence allowance, actual endpoint/source/regional/mechanical accounting and task-queue yields. Never publish partial duration state, retry a failed step, convert fan work into heat, expose continuation via native handles, or present per-step tolerances as duration accuracy. Keep current/candidate states only, snapshot caller inputs and preserve cancellation/source/owner/device-loss guards. Hardware fixture gates and larger-grid duration qualification remain separate from CPU emulator/lifecycle tests.

- The unregistered candidate's solve-scene operation owns the existing restricted duration handle in the same native job map as solve-grid. It accepts an explicit request, not saved domain/Fan authoring. Keep the public catalogue unregistered and expose no Solve attribute button. Validate request schema and cross-field limits before interrupting a predecessor. Keep a per-owner work tail through deletion/restore, drain it before replacement GPU allocation, and retain only scalar source stamps, never captured GPU wrappers. Generic flush must stay nonblocking; author/output/render barriers drain active and retired work. Simulation flush does not advance Thermal. Keep the stable native Clear action with cancel:'cancel' present from idle so the existing core can show Stop while running without rebuilding Attributes. Clear must immediately refresh a selected Probe label. Run native-job.mjs and the actual hardware native-job-browser.mjs; emulation is not hardware evidence.

- native-fan.js is detached authoring metadata only. thermal_fan uses native parameters/reference/transforms and the shared box, with no custom renderer or numerical state. Keep arbitrary native authoring editable; supported-frame mapping requires exact direct-child local/world composition and positive relative diagonal scale, and never implies containment, grid alignment or solver eligibility. Do not connect it silently to explicit-request solve-scene or infer Material/fluid roles. Report direct enabled flags separately from unqualified ancestor semantics. Preserve the hard native copy/reference-drop browser tests and known core blockers; do not repair references from hierarchy or accept session IDs as durable references. Run native-fan.mjs and the real native-fan-browser.mjs hardware harness when supported; missing Chromium is not a pass.
