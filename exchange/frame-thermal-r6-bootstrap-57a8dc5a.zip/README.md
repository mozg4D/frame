# Construct a clean exact Thermal R6 baseline

This bootstrap preserves the existing source and outputs. It constructs a NEW clean source tree accepted by the unchanged strict R6-to-R9+masked patcher. It does not repair in place, install anything, run a browser or change any numerical/runtime source.

The observed partial source has 373 expected files: 369 exact matches and four older documentation revisions. The complete original base needs 461 files. This bootstrap supplies 88 absent files and the exact four expected documentation revisions only in a new directory. Historical output files and dependency/result directories remain untouched in the old tree and are never copied or uploaded.

To keep this packet small, it contains 72 exact source/documentation payloads. Twenty larger bundled public assets (15 models and five texture-source PNGs) are downloaded from the fixed public GitHub commit 961f85eed4334599d886735879fa0df845e09ebb. Every asset is bound to its original required SHA-256, exact byte count and verified Git blob SHA-1. There are no moving branch URLs, mirror substitutions, redirects or skipped files. The constructor stops on any download mismatch. These are already public bundled assets, not private user scenes.

Verify the independently supplied bootstrap archive SHA-256 before extraction. ORIGINAL_PACKET is the previously verified extracted source packet whose PATCH-MANIFEST.json SHA-256 is c502d92a935f47f0a4fc85c01dfa63c81fdf720e90038124a1c55bfe007ab073 and apply.mjs SHA-256 is bcfc2fa319bd5ebeb335fa30dff4001da57587e5e71d756b7df15f8087fa1494. OLD_SOURCE is the original partial Thermal R6 tree. CLEAN_BASE and NEW_TARGET must be separate nonexistent directories, outside all inputs.

    node bootstrap.mjs --check ORIGINAL_PACKET OLD_SOURCE
    node bootstrap.mjs --apply ORIGINAL_PACKET OLD_SOURCE CLEAN_BASE
    node ORIGINAL_PACKET/apply.mjs --check CLEAN_BASE
    node ORIGINAL_PACKET/apply.mjs --apply CLEAN_BASE NEW_TARGET
    node ORIGINAL_PACKET/apply.mjs --verify-target NEW_TARGET

Stop immediately after any nonzero exit. Preserve incomplete output and all earlier failures. Never edit either manifest, the original patcher, the source expected hashes or its ignore roots. Do not reuse or delete a failed target. A network failure is a blocker, not permission to omit an asset or substitute another source.

The bootstrap validates every observed expected input source, including the four exact old-document hashes and the exact 88-path absent set. It copies only the 369 matching source files, writes reviewed payloads and verified public assets into the new baseline, verifies its exact 461-file inventory and hashes, then rechecks the original observed input and original patcher. Source symlinks, unexpected expected-path contents, overlapping or existing output paths, packet extras and corrupt payloads are rejected. Outside-manifest historical outputs are not read or modified.

The original strict patcher then independently verifies the clean baseline and reconstructs the exact frozen 483-file R9+masked candidate. The original patcher and manifests are byte-identical. No numerical acceptance checks, source inventory or ignore rules are weakened.

This bootstrap does not transfer old hardware PASS results to any rebuilt source. The first separately authorized qualification remains the focused CPU tests followed by the standalone masked/all-fluid projection hardware fixture. R7/R8/R9/full and application/stress gates remain pending decisions. No laboratory or GPU execution is authorized by possession of this packet.
