// Build a new clean R6 source baseline. Never writes to the observed old source.
import {readFile,readdir,lstat,realpath,mkdir,writeFile} from 'node:fs/promises';
import {resolve,dirname,basename,join,sep,isAbsolute} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const packet=dirname(fileURLToPath(import.meta.url)),sha=b=>createHash('sha256').update(b).digest('hex'),fail=m=>{throw new Error(m);};
const MANIFEST='c502d92a935f47f0a4fc85c01dfa63c81fdf720e90038124a1c55bfe007ab073',APPLIER='bcfc2fa319bd5ebeb335fa30dff4001da57587e5e71d756b7df15f8087fa1494',PUBLIC_COMMIT='961f85eed4334599d886735879fa0df845e09ebb';
const valid=p=>typeof p==='string'&&p.length>0&&!p.includes('\\')&&!p.includes(':')&&!isAbsolute(p)&&p.split('/').every(x=>x&&x!=='.'&&x!=='..');
const overlap=(a,b)=>a===b||a.startsWith(b+sep)||b.startsWith(a+sep);
const hashPattern=/^[a-f0-9]{64}$/,gitPattern=/^[a-f0-9]{40}$/;
const m=JSON.parse(await readFile(join(packet,'BOOTSTRAP-MANIFEST.json'),'utf8'));
const [mode,originalArg,oldArg,targetArg,...extra]=process.argv.slice(2);
if(extra.length||!['--check','--apply'].includes(mode)||!originalArg||!oldArg||(mode==='--apply'?!targetArg:targetArg!==undefined))fail('Usage: node bootstrap.mjs --check ORIGINAL_PACKET OLD_SOURCE | --apply ORIGINAL_PACKET OLD_SOURCE NEW_CLEAN_BASE');
const original=await realpath(resolve(originalArg)),old=await realpath(resolve(oldArg)),packetReal=await realpath(packet);
if(overlap(old,original)||overlap(old,packetReal)||overlap(original,packetReal))fail('Old source, bootstrap and original packet must be separate trees.');
async function regular(root,rel,{missing=false}={}){
 if(!valid(rel))fail('Unsafe relative source path.');
 let p=root;const parts=rel.split('/');
 for(let i=0;i<parts.length;i++){
  p=join(p,parts[i]);let s;try{s=await lstat(p);}catch(e){if(e.code==='ENOENT'&&missing)return null;throw e;}
  if(s.isSymbolicLink())fail('Symlink in source or packet path: '+rel);
  if(i<parts.length-1?!s.isDirectory():!s.isFile())fail('Nonregular source path: '+rel);
 }
 return readFile(p);
}
async function walk(root){const names=[];async function at(dir,prefix=''){for(const e of await readdir(dir,{withFileTypes:true})){const p=prefix+e.name,s=await lstat(join(dir,e.name));if(s.isSymbolicLink())fail('Symlink in constructed tree or packet: '+p);if(s.isDirectory())await at(join(dir,e.name),p+'/');else if(s.isFile())names.push(p);else fail('Nonregular entry: '+p);}}await at(root);return names.sort();}
const originalBytes=await regular(original,'PATCH-MANIFEST.json'),originalTool=await regular(original,'apply.mjs');
if(sha(originalBytes)!==MANIFEST||sha(originalTool)!==APPLIER||m.originalManifestSHA256!==MANIFEST||m.originalApplierSHA256!==APPLIER)fail('Original strict patcher identity mismatch; do not edit it.');
const originalManifest=JSON.parse(originalBytes),base=originalManifest.baseFiles;
if(m.format!==1||m.publicAssetCommit!==PUBLIC_COMMIT||Object.keys(base).length!==461||Object.keys(originalManifest.targetFiles).length!==483)fail('Unexpected bootstrap/original source contract.');
for(const [p,h] of Object.entries(base))if(!valid(p)||!hashPattern.test(h))fail('Invalid original source inventory.');
if(new Set(Object.keys(base).map(x=>x.toLowerCase())).size!==461)fail('Case-colliding original paths.');
const missing=m.missingPaths,mismatch=m.observedMismatchSHA256,payload=m.payloadFiles,remote=m.remoteFiles;
if(!Array.isArray(missing)||missing.length!==88||new Set(missing).size!==88||Object.keys(mismatch).length!==4||Object.keys(payload).length!==72||Object.keys(remote).length!==20)fail('Unexpected repair cardinality.');
const repairs=[...missing,...Object.keys(mismatch)].sort(),supplied=[...Object.keys(payload),...Object.keys(remote)].sort();
if(new Set(repairs).size!==92||JSON.stringify(repairs)!==JSON.stringify(supplied)||repairs.some(p=>!Object.hasOwn(base,p)))fail('Repair coverage must be exactly 88 absent plus four changed documentation files.');
const allowedMismatch=['app.md','plugins.md','plugins/thermal/AGENTS.md','plugins/thermal/README.md'];
if(JSON.stringify(Object.keys(mismatch).sort())!==JSON.stringify(allowedMismatch)||Object.values(mismatch).some(h=>!hashPattern.test(h)))fail('Unexpected observed documentation preconditions.');
for(const [p,d] of Object.entries({...payload,...remote}))if(!valid(p)||d.sha256!==base[p]||!Number.isSafeInteger(d.bytes)||d.bytes<0)fail('Repair bytes do not match the original full base: '+p);
for(const [p,d] of Object.entries(remote)){
 if(!(p.startsWith('models/')&&p.endsWith('.hash')||p.startsWith('textures/src/')&&p.endsWith('.png'))||!gitPattern.test(d.gitBlobSHA1)||d.url!==`https://raw.githubusercontent.com/mozg4D/frame/${PUBLIC_COMMIT}/${p}`)fail('Unexpected remote asset destination: '+p);
}
const packetNames=['BOOTSTRAP-MANIFEST.json','README.md','bootstrap.mjs',...Object.keys(payload).map(p=>'payload/'+p)].sort();
if(JSON.stringify(await walk(packet))!==JSON.stringify(packetNames))fail('Unexpected or missing bootstrap packet entry.');
if(sha(await regular(packet,'bootstrap.mjs'))!==m.toolSHA256||sha(await regular(packet,'README.md'))!==m.readmeSHA256)fail('Bootstrap tool or README identity mismatch.');
for(const [p,d] of Object.entries(payload)){const b=await regular(packet,'payload/'+p);if(b.length!==d.bytes||sha(b)!==d.sha256)fail('Bootstrap payload mismatch: '+p);}
const absent=new Set(missing),copy=Object.keys(base).filter(p=>!repairs.includes(p));
if(copy.length!==369)fail('Unexpected copy set.');
async function verifyObserved(){
 let count=0;
 for(const [p,h] of Object.entries(base)){
  const b=await regular(old,p,{missing:true});
  if(absent.has(p)){if(b!==null)fail('Previously absent source unexpectedly exists: '+p);continue;}
  if(b===null||sha(b)!==(mismatch[p]??h))fail('Observed input SHA-256 mismatch: '+p);count++;
 }
 if(count!==373)fail('Unexpected observed present-source count.');
}
async function verifyClean(target){
 if(JSON.stringify(await walk(target))!==JSON.stringify(Object.keys(base).sort()))fail('Clean baseline inventory mismatch.');
 for(const [p,h] of Object.entries(base))if(sha(await regular(target,p))!==h)fail('Clean baseline SHA-256 mismatch: '+p);
}
async function fetchAsset(path,d){
 const response=await fetch(d.url,{redirect:'error',signal:AbortSignal.timeout(60000),headers:{'Accept':'application/octet-stream'}});
 if(response.status!==200||response.url!==d.url)fail('Pinned GitHub asset HTTP mismatch: '+path);
 const chunks=[];let size=0;
 for await(const chunk of response.body){size+=chunk.length;if(size>d.bytes)fail('Pinned GitHub asset exceeds expected size: '+path);chunks.push(Buffer.from(chunk));}
 const b=Buffer.concat(chunks);if(size!==d.bytes||sha(b)!==d.sha256||createHash('sha1').update(Buffer.concat([Buffer.from(`blob ${size}\0`),b])).digest('hex')!==d.gitBlobSHA1)fail('Pinned GitHub asset digest mismatch: '+path);
 return b;
}
await verifyObserved();
if(mode==='--check')console.log(JSON.stringify({pass:true,mode,expectedBaseFiles:461,presentSourceFiles:373,exactCopiedSources:369,missingSources:88,changedDocumentationSources:4,payloadFiles:72,pinnedPublicAssets:20,originalPatcherUnchanged:true}));
else{
 const requested=resolve(targetArg),parent=await realpath(dirname(requested)),target=join(parent,basename(requested));
 if([old,original,packetReal].some(p=>overlap(p,target)))fail('New clean baseline overlaps an input tree.');
 let exists=true;try{await lstat(target);}catch(e){if(e.code==='ENOENT')exists=false;else throw e;}
 if(exists)fail('Clean baseline must not exist; preserve all prior sources and failures.');
 await mkdir(target);
 const write=async(p,b)=>{if(sha(b)!==base[p])fail('Input changed before write: '+p);const f=join(target,p);await mkdir(dirname(f),{recursive:true});await writeFile(f,b,{flag:'wx'});};
 for(const p of copy)await write(p,await regular(old,p));
 for(const p of Object.keys(payload))await write(p,await regular(packet,'payload/'+p));
 for(const [p,d] of Object.entries(remote)){await write(p,await fetchAsset(p,d));console.log(JSON.stringify({downloaded:p,bytes:d.bytes,sha256:d.sha256}));}
 await verifyClean(target);await verifyObserved();
 if(sha(await regular(original,'PATCH-MANIFEST.json'))!==MANIFEST||sha(await regular(original,'apply.mjs'))!==APPLIER)fail('Original strict patcher changed during bootstrap.');
 console.log(JSON.stringify({pass:true,mode,cleanBaseFiles:461,observedInputUnchanged:true,originalPatcherUnchanged:true,target,qualification:'Source reconstruction only. CPU and hardware gates must run separately.'}));
}
