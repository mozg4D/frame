import {readFile,writeFile,mkdir,access} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,dirname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
const source=dirname(fileURLToPath(import.meta.url)),target=process.argv[2]&&resolve(process.argv[2]);
if(!target||process.argv.length!==3||target===source)throw Error('Pass exactly one existing target Frame checkout directory, separate from this package');
const manifest=JSON.parse(await readFile(resolve(source,'NATIVE-PARTITION-MANIFEST.json'),'utf8'));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const inside=(root,path)=>{if(typeof path!=='string'||path.includes('\\')||path.split('/').some(p=>!p||p==='.'||p==='..'))throw Error('Invalid manifest path');const full=resolve(root,path);if(!full.startsWith(root+sep))throw Error('Manifest path leaves checkout');return full;};
for(const [path,digest]of Object.entries(manifest.required)){
  const bytes=await readFile(inside(target,path));if(sha(bytes)!==digest)throw Error('Required target source SHA mismatch: '+path);
}
const writes=[];
for(const [path,digest]of Object.entries(manifest.files)){
  if(!path.startsWith('plugins/cfd/'))throw Error('Only add-only CFD files are allowed');
  const bytes=await readFile(inside(source,path));if(sha(bytes)!==digest)throw Error('Package source SHA mismatch: '+path);
  const destination=inside(target,path);let exists=true;
  try{await access(destination);}catch(error){if(error.code==='ENOENT')exists=false;else throw error;}
  if(exists){if(sha(await readFile(destination))!==digest)throw Error('Refusing to overwrite differing target file: '+path);}
  else writes.push({path,destination,bytes,digest});
}
// Every dependency/payload/destination was checked before the first write.
for(const file of writes){await mkdir(dirname(file.destination),{recursive:true});await writeFile(file.destination,file.bytes,{flag:'wx'});}
for(const [path,digest]of Object.entries(manifest.files))if(sha(await readFile(inside(target,path)))!==digest)throw Error('Post-copy SHA mismatch: '+path);
console.log(JSON.stringify({prepared:true,copied:writes.length,verified:Object.keys(manifest.files).length,coreSHA256:manifest.required['index.html'],command:'node plugins/cfd/tests/native-partition-browser.mjs --headless',hardwareGPUValidated:false,solverReady:false},null,2));
