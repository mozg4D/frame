# Native exact endpoint material partition trial

Technical, add-only candidate. Do not merge into main or install in the plugin catalogue.
No personal scene data is included. This archive is not a qualified solver release.

1. Extract this package into a NEW directory, separate from the existing test checkout.
2. Run `node prepare-native-partition.mjs "PATH_TO_EXISTING_FRAME_TEST_CHECKOUT"`.
   It checks all dependency and payload hashes before writing, adds only nine new CFD
   files, permits an identical repeat, and refuses to overwrite any differing file.
3. From the existing test checkout run:
   `node plugins/cfd/tests/native-partition-browser.mjs --headless`
4. Preserve the complete report `plugins/cfd/validation-results/native-partition-latest.json`
   with its SHA256. A full pass expects 107 assertions and 11 successful result cases.

The existing checkout must have the already-qualified native volume package and the
pinned core identified by NATIVE-PARTITION-MANIFEST.json. No core files are included.
The runner defaults to Chromium channel, with optional FRAME_BROWSER_CHANNEL and
FRAME_BROWSER executable. FRAME_CFD_CORE_ROOT may select the existing pinned core.

A hardware pass may qualify only exact endpoint prescribed material transport.
Continuous-native geometry, physical space-time coupling, kinetic streaming/collision,
wall-induced flow and solver readiness remain false. See the included detailed gate
scope and all limitations in plugins/cfd/NATIVE-PARTITION-GATE.md.

Host suites: 452 new checks plus 1878 existing CFD checks passed. Those do not compile
or execute WGSL. Repository standard/stress browser checks were blocked by a missing
installed Chromium executable in the cloud; no fallback or skipped GPU pass is claimed.
