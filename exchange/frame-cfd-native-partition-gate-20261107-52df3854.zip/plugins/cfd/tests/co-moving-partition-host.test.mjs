import assert from 'node:assert/strict';
import test from 'node:test';
import {planCoMovingPartition,dispatchCoMovingPartition,coMovingPartitionShader} from '../co-moving-partition-gpu.mjs';

// Host orchestration mocks and source-shape assertions ONLY. These tests never
// compile WGSL, execute GPU arithmetic, validate native geometry or certify CFD.
const started=performance.now();
const grid=()=>({origin:[0,0,0],pitch:2**-5,dimensions:[8,8,8]});
const limits=()=>({maxStorageBufferBindingSize:2**20,maxBufferSize:2**20,
  maxComputeWorkgroupsPerDimension:65535,maxComputeInvocationsPerWorkgroup:256,
  maxComputeWorkgroupSizeX:256,maxUniformBufferBindingSize:65536,maxStorageBuffersPerShaderStage:8,
  maxBindingsPerBindGroup:1000,minStorageBufferOffsetAlignment:256});
const budgets={maxBytes:2**21,maxCells:4096};
const usage={triangles:128,state:140,uniform:72,cells:128,weights:128,input:128,output:128,readback:9};
const entries=['extractCoMovingTetra','initializeCoMovingCells','partitionCoMovingCells','auditCoMovingPartition','remapCoMovingPopulations'];
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
const plan=(g=grid(),options={})=>planCoMovingPartition(g,{limits:limits(),...budgets,...options});
const status=()=>{const s=new Uint32Array(32);s.set([0,1,512,512,512,512,3876,3399,2,2,2,12,3,3,3,12,1,1,1]);return s;};

function fixture(){
  const events=[],writes=[],groups=[],layouts=[],pipelines=[],submissions=[],copies=[],hooks={};let current=true,depth=0,guardCount=0;
  const buffers={};
  for(const [role,size]of Object.entries(plan().sizes))buffers[role]={role,size,usage:usage[role],mapState:'unmapped',mapCount:0,unmapCount:0,
    destroy(){assert.fail('Caller-owned '+role+' must not be destroyed');},
    async mapAsync(mode,offset,length){assert.equal(role,'readback');assert.deepEqual([mode,offset,length],[1,0,128]);assert.equal(this.mapState,'unmapped');this.mapCount++;events.push('map');await hooks.map?.();this.mapState='mapped';},
    getMappedRange(offset,length){assert.equal(role,'readback');assert.deepEqual([offset,length],[0,128]);assert.equal(this.mapState,'mapped');events.push('read');hooks.read?.();return (hooks.status??status()).buffer;},
    unmap(){assert.equal(this.mapState,'mapped');this.mapState='unmapped';this.unmapCount++;events.push('unmap');}};
  const device={limits:limits(),
    createBuffer(){assert.fail('Runtime must not allocate caller-owned buffers');},
    createShaderModule({code}){assert.equal(code,coMovingPartitionShader);events.push('compile');hooks.module?.();return {async getCompilationInfo(){assert.equal(depth,0);await hooks.compile?.();return {messages:hooks.messages??[]};}};},
    async createComputePipelineAsync(d){assert.equal(depth,0);events.push('pipeline:'+d.compute.entryPoint);await hooks.pipeline?.(d.compute.entryPoint);pipelines.push(d);return {entryPoint:d.compute.entryPoint};},
    createBindGroupLayout(d){hooks.layout?.();layouts.push(d);return d;},createPipelineLayout(d){return d;},
    createBindGroup(d){hooks.bind?.();groups.push(d);return d;},
    pushErrorScope(type){assert.equal(type,'validation');assert.equal(depth,0);depth++;events.push('scope:push');},
    popErrorScope(){assert.equal(depth,1);depth--;events.push('scope:pop');return (async()=>{await hooks.scope?.();return hooks.validationError??null;})();},
    createCommandEncoder(){hooks.encoder?.();const commands=[];return {
      beginComputePass(){let entry;return {setPipeline(p){entry=p.entryPoint;},setBindGroup(i,g){assert.equal(i,0);assert.equal(g,groups.at(-1));},dispatchWorkgroups(count){commands.push({entry,count});hooks.pass?.(entry);},end(){}};},
      copyBufferToBuffer(from,fromOffset,to,toOffset,size){const c={from,fromOffset,to,toOffset,size};copies.push(c);commands.push(c);hooks.copy?.();},
      finish(){hooks.finish?.();return commands;}};},
    queue:{writeBuffer(buffer,offset,data){assert.ok(!['triangles','input'].includes(buffer.role),'Native endpoints and source populations are read-only');writes.push({buffer,offset,bytes:new Uint8Array(data.buffer??data,data.byteOffset??0,data.byteLength).slice()});events.push('write:'+buffer.role);hooks.write?.(buffer.role);},
      submit(commands){assert.equal(depth,1);submissions.push(commands.flat());events.push('submit');hooks.submit?.();},
      async onSubmittedWorkDone(){assert.equal(depth,0,'A shared device error scope must not span await');events.push('fence');await hooks.fence?.();events.push('retired');}}
  };
  const options={grid:grid(),timeStart:0,timeEnd:.5,...budgets,...buffers,assertCurrent(){guardCount++;if(!current)throw Error('Injected stale/cancelled partition');hooks.guard?.(guardCount);}};
  return {device,buffers,options,hooks,events,writes,groups,layouts,pipelines,submissions,copies,stale(){current=false;},restore(){current=true;},run(overrides={}){return dispatchCoMovingPartition(device,{...options,...overrides});}};
}
async function reusableAfterFailure(f,pattern,options={}){
  await assert.rejects(f.run(options),pattern);assert.equal(f.buffers.readback.mapState,'unmapped');
  for(const k of Object.keys(f.hooks))delete f.hooks[k];f.restore();assert.equal((await f.run()).cellCount,512);
}

test('exact bounded plan is deterministic, immutable and explicitly unqualified',()=>{
  const g=grid(),original=structuredClone(g);Object.freeze(g.origin);Object.freeze(g.dimensions);Object.freeze(g);
  const p=plan(g);assert.deepEqual(g,original);assert.deepEqual(plan(g),p);assert.equal(p.gridKey,JSON.stringify(g));
  assert.deepEqual(p.sizes,{triangles:1024,state:128,uniform:64,cells:8192,weights:16384,input:55296,output:55296,readback:128});
  assert.equal(p.cellCount,512);assert.equal(p.totalBytes,136512);assert.equal(p.dispatches,5);assert.deepEqual(p.stages,entries);
  assert.equal(p.exactVolumeDenominator,48);assert.equal(p.maximumOverlapsPerSource,8);
  for(const key of ['hardwareValidated','sourceGeometryCertified','nativeSpaceTimeCouplingValidated','nativeFrameSceneValidated','nativeTransportValidated','generalMovingBody','solverReady','forceValidated','kineticStreamingPerformed','streamingCollisionPerformed'])assert.equal(p[key],false);
  assert.equal(plan({...grid(),dimensions:[2,3,4]}).cellCount,24);assert.equal(plan({...grid(),dimensions:[16,16,16]}).cellCount,4096);
  assert.equal(plan({...grid(),pitch:2**-20}).cellCount,512);assert.equal(plan({...grid(),pitch:2**10}).cellCount,512);
});
const badGrids=[undefined,null,{}, {...grid(),origin:[0,,0]}, {...grid(),origin:new Float32Array(3)},
  {...grid(),origin:[0,0]}, {...grid(),origin:[0,0,1]}, {...grid(),origin:[NaN,0,0]},
  {...grid(),dimensions:[8,,8]}, {...grid(),dimensions:new Uint32Array([8,8,8])},
  ...[0,1,17,2.5,NaN,Infinity].map(v=>({...grid(),dimensions:[v,8,8]})),
  ...[undefined,0,-1,NaN,Infinity,Number.MIN_VALUE,.025,.001,2**-21,2**11,1+Number.EPSILON].map(pitch=>({...grid(),pitch}))];
for(const [i,g]of badGrids.entries())test('invalid dense/exact grid '+i+' rejects',()=>assert.throws(()=>planCoMovingPartition(g,{limits:limits(),...budgets}),/partition grid required/));
for(const key of ['maxBytes','maxCells'])for(const value of [undefined,0,-1,1.5,Infinity,2**53])test('invalid explicit budget '+key+' '+value+' rejects',()=>assert.throws(()=>plan(grid(),{[key]:value}),/budgets required/));
for(const key of Object.keys(limits()))for(const value of [undefined,0,-1,1.5,Infinity])test('invalid limit '+key+' '+value+' rejects',()=>assert.throws(()=>plan(grid(),{limits:{...limits(),[key]:value}}),/device limits required/));
for(const [key,value]of Object.entries({maxStorageBufferBindingSize:55295,maxBufferSize:55295,maxComputeWorkgroupsPerDimension:7,maxComputeInvocationsPerWorkgroup:63,maxComputeWorkgroupSizeX:63,maxUniformBufferBindingSize:63,maxStorageBuffersPerShaderStage:5,maxBindingsPerBindGroup:6}))test('device budget '+key+' rejects',()=>assert.throws(()=>plan(grid(),{limits:{...limits(),[key]:value}}),/budget exceeded/));
for(const alignment of [3,192,1024])test('native endpoint offset rejects alignment '+alignment,()=>assert.throws(()=>plan(grid(),{limits:{...limits(),minStorageBufferOffsetAlignment:alignment}}),/offset 512/));
test('exact byte, dispatch, binding, alignment and cell thresholds are accepted',()=>{
  const limitsAt={...limits(),maxStorageBufferBindingSize:55296,maxBufferSize:55296,maxComputeWorkgroupsPerDimension:8,maxComputeInvocationsPerWorkgroup:64,maxComputeWorkgroupSizeX:64,maxUniformBufferBindingSize:64,maxStorageBuffersPerShaderStage:6,maxBindingsPerBindGroup:7,minStorageBufferOffsetAlignment:512};
  assert.equal(plan(grid(),{limits:limitsAt,maxBytes:136512,maxCells:512}).totalBytes,136512);
  assert.throws(()=>plan(grid(),{maxBytes:136511}),/budget exceeded/);assert.throws(()=>plan(grid(),{maxCells:511}),/budget exceeded/);
});
test('dispatch preserves native endpoints/source populations, orders five separate passes and reads status only',async()=>{
  const f=fixture(),original=structuredClone(f.options.grid);const result=await f.run();assert.deepEqual(f.options.grid,original);
  assert.deepEqual(f.submissions.map(cs=>cs.filter(c=>c.entry).map(({entry,count})=>[entry,count])),[entries.map((entry,i)=>[entry,i===0?1:8])]);
  assert.deepEqual(f.writes.map(w=>w.buffer.role),['uniform','state']);assert.deepEqual(Array.from(f.writes[1].bytes),Array(128).fill(0));
  assert.deepEqual(Array.from(new Float32Array(f.writes[0].bytes.buffer,0,8)),[0,0,0,0,2**-5,64,0,0]);
  assert.deepEqual(Array.from(new Uint32Array(f.writes[0].bytes.buffer,32,8)),[8,8,8,0,0,0,0,0]);
  assert.deepEqual(f.layouts[0].entries.map(e=>e.buffer.type),['read-only-storage','storage','uniform','storage','storage','read-only-storage','storage']);
  assert.deepEqual(f.groups[0].entries.map(e=>[e.binding,e.resource.buffer.role,e.resource.offset,e.resource.size]),[
    [0,'triangles',0,1024],[1,'state',0,128],[2,'uniform',0,64],[3,'cells',0,8192],[4,'weights',0,16384],[5,'input',0,55296],[6,'output',0,55296]]);
  assert.deepEqual(f.copies.map(c=>[c.from.role,c.fromOffset,c.to.role,c.toOffset,c.size]),[['state',0,'readback',0,128]]);
  assert.ok(f.events.indexOf('scope:pop')<f.events.indexOf('fence'));assert.ok(f.events.indexOf('retired')<f.events.indexOf('map'));
  assert.equal(f.buffers.readback.mapCount,1);assert.equal(f.buffers.readback.unmapCount,1);
  assert.equal(result.stage,'native-endpoint-prescribed-material-partition-unverified');assert.equal(result.path,'endpoint-defined-linear-prescribed-material-interpolation');
  assert.deepEqual(result.anchor2Before,[2,2,2]);assert.deepEqual(result.anchor2After,[3,3,3]);assert.deepEqual(result.displacement2,[1,1,1]);
  assert.equal(result.leg2,12);assert.equal(result.overlapCount,3876);assert.equal(result.transferCount,3399);
  assert.equal(result.timeStart,0);assert.equal(result.timeEnd,.5);assert.equal(result.cellCount,512);assert.equal(result.bytes,136512);
  assert.equal(result.exactGeometricClosure,true);assert.equal(result.sourceShellValidationRequired,true);
  assert.equal(result.cellVolumeAvailable,true);assert.equal(result.transportPlanAvailable,true);assert.equal(result.materialRemapAvailable,true);
  for(const key of ['hardwareValidated','sourceGeometryCertified','nativeSpaceTimeCouplingValidated','nativeFrameSceneValidated','nativeTransportValidated','generalMovingBody','solverReady','forceValidated','kineticStreamingPerformed','streamingCollisionPerformed','refillAvailable'])assert.equal(result[key],false);
});
test('all admitted pitches encode an exact reciprocal half-pitch and preserve half-cell round trips',async()=>{
  // Host f32 arithmetic validates the uniform encoding over the entire allowed
  // power-of-two range. This is not shader execution or GPU compilation proof.
  for(let exponent=-20;exponent<=10;exponent++){
    const pitch=2**exponent,f=fixture();await f.run({grid:{...grid(),pitch}});
    const uniform=new Float32Array(f.writes[0].bytes.buffer,0,8);
    const halfPitch=Math.fround(pitch*.5),inverseHalfPitch=uniform[5];
    assert.equal(uniform[4],pitch);assert.equal(inverseHalfPitch,2/pitch);
    assert.equal(inverseHalfPitch,Math.fround(2/pitch));
    assert.equal(Math.fround(halfPitch*inverseHalfPitch),1);
    for(let coordinate2=1;coordinate2<=32;coordinate2++){
      const raw=Math.fround(coordinate2*halfPitch),q=Math.fround(raw*inverseHalfPitch);
      assert.equal(q,coordinate2);assert.equal(Math.fround(q*halfPitch),raw);
    }
  }
  const admission=coMovingPartitionShader.slice(coMovingPartitionShader.indexOf('fn halfVertex('),coMovingPartitionShader.indexOf('@compute'));
  assert.match(admission,/let q=p\*cfg\.spacing\.y/);
  assert.doesNotMatch(admission,/\bp\s*\/\s*halfPitch/);
});
test('metadata decodes negative displacement as signed integers',async()=>{
  const f=fixture();f.hooks.status=status();f.hooks.status[16]=0xffffffff;f.hooks.status[18]=0xfffffffe;
  assert.deepEqual((await f.run()).displacement2,[-1,1,-2]);
});
test('status diagnostics retain all32 immutable copied words without another readback',async()=>{
  const f=fixture(),source=status();source[16]=0xffffffff;source[31]=0xabcdef01;
  f.hooks.status=source;
  const result=await f.run();assert.equal(result.stateWords.length,32);
  assert.equal(Object.isFrozen(result.stateWords),true);assert.deepEqual(result.stateWords,Array.from(source));
  assert.equal(result.stateWords[16],0xffffffff,'Raw status preserves signed fields as their original u32 words');
  assert.equal(result.stateWords[31],0xabcdef01,'All reserved words remain visible for the independent full-ABI oracle');
  assert.throws(()=>{result.stateWords[0]=1;},TypeError);assert.throws(()=>result.stateWords.push(0),TypeError);
  source.fill(0);assert.equal(result.stateWords[31],0xabcdef01,'The diagnostic snapshot must not alias mapped storage');
  assert.equal(f.buffers.readback.mapCount,1);assert.equal(f.buffers.readback.unmapCount,1);
  assert.deepEqual(f.copies.map(c=>[c.from.role,c.fromOffset,c.to.role,c.toOffset,c.size]),[['state',0,'readback',0,128]]);
});
test('caller grid mutation during compilation cannot change planned capacities or uniforms',async()=>{
  const f=fixture(),original=structuredClone(f.options.grid);
  f.hooks.compile=()=>{f.options.grid.origin[0]=17;f.options.grid.pitch=.025;f.options.grid.dimensions[0]=16;};
  const result=await f.run();assert.equal(result.gridKey,JSON.stringify(original));
  assert.deepEqual(Array.from(new Float32Array(f.writes[0].bytes.buffer,0,8)),[0,0,0,0,2**-5,64,0,0]);
  assert.deepEqual(Array.from(new Uint32Array(f.writes[0].bytes.buffer,32,4)),[8,8,8,0]);
  assert.deepEqual(f.submissions[0].filter(c=>c.entry).map(c=>c.count),[1,8,8,8,8]);
});
for(const [name,options]of [['missing guard',{assertCurrent:undefined}],['negative start',{timeStart:-1}],['missing start',{timeStart:undefined}],['NaN start',{timeStart:NaN}],['missing end',{timeEnd:undefined}],['nonfinite end',{timeEnd:Infinity}],['equal times',{timeEnd:0}],['reversed times',{timeStart:1,timeEnd:.5}]])test(name+' rejects before work',async()=>{
  const f=fixture();await assert.rejects(f.run(options),/endpoint times and lifetime guard/);assert.equal(f.events.length,0);
});
for(const role of Object.keys(usage))for(const defect of ['missing','undersized','wrong usage','noninteger size','mapped','pending'])test(role+' '+defect+' rejects before work',async()=>{
  const f=fixture(),buffer=f.buffers[role];const value=defect==='missing'?undefined:{...buffer,...({'undersized':{size:buffer.size-1},'wrong usage':{usage:0},'noninteger size':{size:buffer.size+.5},'mapped':{mapState:'mapped'},'pending':{mapState:'pending'}}[defect])};
  await assert.rejects(f.run({[role]:value}),new RegExp('Invalid partition buffer '+role));assert.equal(f.events.length,0);
});
test('all cross-role aliases including input/output reject before shader work',async()=>{
  for(const [i,one]of Object.keys(usage).entries())for(const two of Object.keys(usage).slice(i+1)){
    const f=fixture(),alias={size:65536,usage:255};await assert.rejects(f.run({[one]:alias,[two]:alias}),/Distinct scratch buffer objects required/);assert.equal(f.events.length,0);
  }
});
test('compilation diagnostics fail closed without claiming native geometry validity',async()=>{
  const f=fixture();f.hooks.messages=[{type:'warning',message:'harmless'},{type:'error',message:'injected WGSL diagnostic'}];
  await assert.rejects(f.run(),/WGSL compilation failed: injected WGSL diagnostic/);assert.equal(f.pipelines.length,0);assert.equal(f.writes.length,0);
  f.hooks.messages=[{type:'warning',message:'harmless'}];await f.run();
});
for(const entry of entries)test(entry+' pipeline rejection releases scratch',async()=>{
  const f=fixture();f.hooks.pipeline=at=>{if(at===entry)throw Error('Injected pipeline failure');};await reusableAfterFailure(f,/pipeline failure/);
});
for(const flag of [1,2,4,8,16,32,64,128])test('unsupported GPU status flag '+flag+' rejects and unmaps',async()=>{
  const f=fixture();f.hooks.status=status();f.hooks.status[0]=flag;await reusableAfterFailure(f,/Unsupported or unresolved native co-moving partition/);
});
for(const [word,value]of [[1,0],[1,2],[2,511],[3,513],[4,511],[5,511],[6,4097],[7,3877]])test('incomplete/invalid status word '+word+' rejects',async()=>{
  const f=fixture();f.hooks.status=status();f.hooks.status[word]=value;await reusableAfterFailure(f,/Unsupported or unresolved native co-moving partition/);
});
test('short status rejects after unmapping',async()=>{
  const f=fixture();f.hooks.status=new Uint32Array([0,1,512,512,512,512,3876,3399]);await reusableAfterFailure(f,/Unsupported or unresolved/);
});
for(const stage of ['compile','pipeline','write','submit','fence','map','read'])test('staleness at '+stage+' prevents publication and releases lease',async()=>{
  const f=fixture();f.hooks[stage]=()=>f.stale();await assert.rejects(f.run(),/stale\/cancelled/);
  if(stage==='compile'||stage==='pipeline'||stage==='write')assert.equal(f.submissions.length,0);
  assert.equal(f.buffers.readback.mapState,'unmapped');assert.equal(f.buffers.readback.mapCount,f.buffers.readback.unmapCount);
  delete f.hooks[stage];f.restore();await f.run();
});
test('initial guard fails before any GPU API',async()=>{
  const f=fixture();f.stale();await assert.rejects(f.run(),/stale\/cancelled/);assert.equal(f.events.length,0);f.restore();await f.run();
});
for(const stage of ['module','compile','layout','bind','encoder','pass','copy','finish','submit','map','read','scope','fence'])test(stage+' failure cleans up lease/mapping',async()=>{
  const f=fixture();f.hooks[stage]=()=>{throw Error('Injected '+stage+' failure');};await reusableAfterFailure(f,new RegExp('Injected '+stage+' failure'));
});
test('primary encoding error survives secondary validation and retains lease until queue retirement',async()=>{
  const f=fixture(),reached=deferred(),resume=deferred();f.hooks.write=()=>{throw Error('Primary write failure');};f.hooks.validationError={message:'Secondary validation failure'};
  f.hooks.fence=async()=>{reached.resolve();await resume.promise;};const pending=assert.rejects(f.run(),/Primary write failure/);await reached.promise;
  try{await assert.rejects(f.run(),/already in use/);assert.equal(f.submissions.length,0);assert.equal(f.buffers.readback.mapCount,0);}finally{resume.resolve();}
  await pending;for(const k of Object.keys(f.hooks))delete f.hooks[k];await f.run();
});
test('validation failure settles submitted work before scratch reuse',async()=>{
  const f=fixture(),reached=deferred(),resume=deferred();f.hooks.validationError={message:'Injected GPU validation failure'};
  f.hooks.fence=async()=>{reached.resolve();await resume.promise;};const pending=assert.rejects(f.run(),/GPU validation failure/);await reached.promise;
  try{await assert.rejects(f.run(),/already in use/);assert.equal(f.buffers.readback.mapCount,0);}finally{resume.resolve();}
  await pending;delete f.hooks.fence;delete f.hooks.validationError;await f.run();
});
for(const stage of ['compile','pipeline','fence','map'])test('exclusive scratch remains leased while '+stage+' is pending',async()=>{
  const f=fixture(),reached=deferred(),resume=deferred();f.hooks[stage]=async()=>{reached.resolve();await resume.promise;};const pending=f.run();await reached.promise;
  try{await assert.rejects(f.run(),/already in use|Invalid partition buffer readback/);}finally{resume.resolve();}
  await pending;delete f.hooks[stage];await f.run();
});
test('WGSL static contract retains exact integer geometry, read-only endpoints and uniform material weights',()=>{
  assert.match(coMovingPartitionShader,/struct Cell\{before:u32,after:u32,row:u32,column:atomic<u32>\}/);
  assert.match(coMovingPartitionShader,/@binding\(0\) var<storage,read> triangles:array<u32>/);
  assert.match(coMovingPartitionShader,/@binding\(5\) var<storage,read> populationsIn/);
  assert.match(coMovingPartitionShader,/endpoint\*128u\+triangle\*28u\+corner\*4u/);
  assert.match(coMovingPartitionShader,/vec3f\(integer\)!=q/);assert.match(coMovingPartitionShader,/bitcast<vec3u>\(vec3f\(integer\)\*halfPitch\)!=bits/);
  assert.match(coMovingPartitionShader,/solid\+=sign\*h\*h\*h/);assert.match(coMovingPartitionShader,/cells\[i\]\.row!=cells\[i\]\.before/);
  assert.match(coMovingPartitionShader,/atomicLoad\(&cells\[i\]\.column\)!=cells\[i\]\.after/);
  assert.match(coMovingPartitionShader,/bits<0x0d800000u\|\|bits>0x41800000u/);assert.match(coMovingPartitionShader,/cells\[i\]\.before==0u&&!zero/);
  assert.match(coMovingPartitionShader,/weights\[i\*8u\+slot\]=\(to<<6u\)\|weight/);
  assert.match(coMovingPartitionShader,/sum\/f32\(after\)/);assert.match(coMovingPartitionShader,/q<27u/);
  assert.doesNotMatch(coMovingPartitionShader,/atomic<f32>|\bclamp\s*\(|\bround\s*\(/);
  assert.doesNotMatch(coMovingPartitionShader,/\b(?:let|var|fn|struct)\s+(?:input|output|packed|meta|active|asm|typedef|using|volatile|class|namespace)\b/);
  assert.equal((coMovingPartitionShader.match(/@compute @workgroup_size\(64\)/g)??[]).length,5);
});
test('zero remap components bypass division instead of admitting zero-division noise',()=>{
  // Under the admitted nonnegative input domain, sum==0 means every weighted
  // contribution is exactly zero. Wet and dry zero outputs use the literal0.
  // This source regression does not execute or validate WGSL on hardware.
  const remap=coMovingPartitionShader.slice(coMovingPartitionShader.indexOf('fn remapCoMovingPopulations('));
  assert.match(remap,/var value=0\.;if\(after!=0u&&sum>0\.\)\{value=sum\/f32\(after\);\}/);
  assert.equal((remap.match(/sum\/f32\(after\)/g)??[]).length,1);
  assert.doesNotMatch(remap,/\bclamp\s*\(/);
});
test('all WGSL tokens avoid the current W3C reserved-word inventory (not compiler validation)',()=>{
  // https://www.w3.org/TR/2026/CRD-WGSL-20261106/#reserved-words
  const reserved=new Set(`NULL Self abstract active alignas alignof as asm asm_fragment async attribute auto await become cast catch class co_await co_return co_yield coherent column_major common compile compile_fragment concept const_cast consteval constexpr constinit crate debugger decltype delete demote demote_to_helper do dynamic_cast enum explicit export extends extern external fallthrough filter final finally friend from fxgroup get goto groupshared highp impl implements import inline instanceof interface layout lowp macro macro_rules match mediump meta mod module move mut mutable namespace new nil noexcept noinline nointerpolation non_coherent noncoherent noperspective null nullptr of operator package packoffset partition pass patch pixelfragment precise precision premerge priv protected pub public readonly ref regardless register reinterpret_cast require resource restrict self set shared sizeof smooth snorm static static_assert static_cast std subroutine super target template this thread_local throw trait try type typedef typeid typename typeof union unless unorm unsafe unsized use using varying virtual volatile wgsl where with writeonly yield`.split(/\s+/));
  const source=coMovingPartitionShader.replace(/\/\/[^\n]*/g,'').replace(/\/\*[\s\S]*?\*\//g,'');
  assert.deepEqual([...new Set(source.match(/[A-Za-z_][A-Za-z0-9_]*/g))].filter(token=>reserved.has(token)),[]);
});
test('host-only suite meets its completed-operation latency budget',t=>{
  const milliseconds=performance.now()-started;assert.ok(milliseconds<3000,`Host-only checks took ${milliseconds} ms; budget3000 ms`);
  t.diagnostic(`Host-only completed-operation wall time ${milliseconds.toFixed(2)} ms; budget3000 ms. WGSL compilation and hardware execution NOT performed.`);
});
