import {planCoMovingTetra,auditCoMovingTetra} from '../tetra-remap.mjs';
import {DIRECTIONS,equilibrium} from '../lattice.mjs';

// A manufactured endpoint-defined material map: BOTH solid and fluid translate.
// No native intermediate trajectory, streaming, collision or wall-driven flow
// is inferred. The existing Float64 polyhedron clip supplies the independent
// geometry; its separately audited integer evidence supplies exact numerators.
export const fixtureOBJ='o CFD native partition tetra\nv 0 0 0\nv 218.75 0 0\nv 0 218.75 0\nv 0 0 218.75\nf 1 3 2\nf 1 2 4\nf 1 4 3\nf 2 3 4\n';
export const nativePartitionVerticesMM=Object.freeze([[0,0,0],[218.75,0,0],[0,218.75,0],[0,0,218.75]].map(Object.freeze));
export const nativePartitionIndices=Object.freeze([0,2,1,0,1,3,0,3,2,1,2,3]);
export const nativePartitionTimes=Object.freeze([0,1]);
export const nativePartitionGrid=Object.freeze({origin:Object.freeze([0,0,0]),pitch:.0625,
  dimensions:Object.freeze([8,8,8]),units:'m',frame:'fixed-world',sampleLocation:'cell-volume'});
export const nativePartitionCellCount=512;
export const nativePartitionDenominator=48;
export const nativePartitionPopulationScale=Object.freeze({velocityUnitMPerSecond:1,
  materialIntervalSeconds:1,materialVelocityMPerSecond:Object.freeze([.03125,.03125,.03125]),
  latticeVelocity:Object.freeze([.03125,.03125,.03125]),streamingCollisionPerformed:false});
export const nativePartitionReadiness=Object.freeze({solverReady:false,forceValidated:false,
  arbitraryMeshVolumeValidated:false,nativeSpaceTimeCouplingValidated:false,
  streamingCollisionPerformed:false,hardwareValidated:false});
export const nativePartitionArithmeticContract=Object.freeze({
  specification:'https://www.w3.org/TR/2026/CRD-WGSL-20261106/',
  accuracy:'https://www.w3.org/TR/2026/CRD-WGSL-20261106/#floating-point-accuracy',
  reassociation:'https://www.w3.org/TR/2026/CRD-WGSL-20261106/#reassociation-and-fusion',
  additionMultiplicationRelativeError:2**-23,divisionULP:2.5,normalDivisionRelativeError:2.5*2**-23,
  rounding:'either-adjacent-f32',zeroSumRequiresExplicitZeroBranch:true,
  hardwareValidated:false
});
const EPS64=Number.EPSILON,U64=EPS64/2,EPS32=2**-23,DIVISION_RELATIVE=2.5*EPS32;
const gamma=(n,u)=>n*u/(1-n*u);
const inflate=x=>x*(1+16*EPS64);
const same=(a,b)=>a.length===b.length&&Array.from(a).every((v,i)=>Object.is(v,b[i]));
const xyz=(i,d)=>[i%d[0],Math.floor(i/d[0])%d[1],Math.floor(i/(d[0]*d[1]))];
const index=(p,d)=>p[0]+d[0]*(p[1]+d[1]*p[2]);
const wrap=(v,n)=>(v%n+n)%n;
const count=n=>({fluid:n.filter(v=>v===48).length,solid:n.filter(v=>v===0).length,
  cut:n.filter(v=>v>0&&v<48).length,total:n.length,sumNumerator:n.reduce((s,v)=>s+v,0)});

/** Only native endpoints are admitted; midpoint mm-to-SI is not exact. */
export function nativePartitionPose(timeSeconds) {
  if(!nativePartitionTimes.includes(timeSeconds))throw new RangeError('Native partition fixture requires endpoint time 0 or 1 seconds');
  const translationMM=Array(3).fill(31.25+31.25*timeSeconds);
  return {timeSeconds,frame:60*timeSeconds,translationMM,translationM:translationMM.map(v=>v*.001),
    anchorGrid:Array(3).fill(.5+.5*timeSeconds),legGrid:3.5,rotationDegrees:[0,0,0]};
}

export function nativePartitionPlan(options={}) {
  const plan=planCoMovingTetra({anchor:[.5,.5,.5],leg:3.5,displacement:[.5,.5,.5],...options});
  if(plan.leg<2||plan.leg>15)throw new RangeError('Native partition oracle requires half-cell equal leg in [2,15]');
  return plan;
}

/** Fixed eight-slot source ABI; integer-displacement extra slots are absent. */
export function nativePartitionSlot(source,slot,plan) {
  if(!Number.isInteger(source)||source<0||source>=plan.cellCount||!Number.isInteger(slot)||slot<0||slot>7)
    throw new RangeError('Native partition source/slot outside domain');
  const moved=xyz(source,plan.dimensions).map((v,k)=>v+plan.displacement[k]);
  for(let k=0;k<3;k++)if(Number.isInteger(moved[k])&&(slot&(1<<k)))return null;
  const image=moved.map((v,k)=>Math.floor(v)+((slot>>k)&1));
  return {image,destination:index(image.map((v,k)=>wrap(v,plan.dimensions[k])),plan.dimensions)};
}

/** No GPU formula is copied here: retain the independently clipped plan. */
export function createNativePartitionOracle(options={}) {
  const plan=nativePartitionPlan(options),audit=auditCoMovingTetra(plan),n=plan.cellCount;
  const before=new Uint32Array(n),after=new Uint32Array(n),rows=new Uint32Array(n),columns=new Uint32Array(n);
  const weights=new Uint32Array(8*n),weightNumerators=new Uint32Array(8*n),destinations=new Uint32Array(8*n);
  destinations.fill(0xffffffff);
  const slots=new Map();
  for(let source=0;source<n;source++)for(let slot=0;slot<8;slot++) {
    const target=nativePartitionSlot(source,slot,plan);
    if(target){slots.set(source*n+target.destination,8*source+slot);destinations[8*source+slot]=target.destination;}
  }
  for(const overlap of plan.overlaps) {
    const at=slots.get(overlap.from*n+overlap.to);
    if(at===undefined||weights[at]||!Number.isInteger(overlap.numerator)||overlap.numerator<1||overlap.numerator>48)
      throw Error('Independent overlap does not fit eight-slot ABI');
    weightNumerators[at]=overlap.numerator;weights[at]=(overlap.to<<6)|overlap.numerator;
    rows[overlap.from]+=overlap.numerator;columns[overlap.to]+=overlap.numerator;
  }
  // auditCoMovingTetra already independently proves each row/column equals the
  // exact whole-cell numerator. Rounding here only decodes those certified
  // integer rationals from the retained clip, never repairs source geometry.
  for(let i=0;i<n;i++) {
    before[i]=Math.round(plan.volumesBefore[i]*48);after[i]=Math.round(plan.volumesAfter[i]*48);
    if(before[i]!==rows[i]||after[i]!==columns[i])throw Error('Independent exact row/column closure failed');
  }
  const expectedCells=Uint32Array.from({length:4*n},(_,j)=>[before,after,rows,columns][j%4][Math.floor(j/4)]);
  const transitions={dryToWet:0,wetToDry:0,changedPartial:0,stableDry:0,stableWet:0,dryToWetIndices:[],wetToDryIndices:[]};
  for(let i=0;i<n;i++) {
    if(before[i]===0&&after[i]>0){transitions.dryToWet++;transitions.dryToWetIndices.push(i);}
    else if(before[i]>0&&after[i]===0){transitions.wetToDry++;transitions.wetToDryIndices.push(i);}
    else if(before[i]!==after[i])transitions.changedPartial++;
    else transitions[before[i]===0?'stableDry':'stableWet']++;
  }
  return {plan,audit,cellCount:n,denominator:48,before,after,rows,columns,expectedCells,weights,weightNumerators,destinations,
    counts:{before:count(before),after:count(after)},transitions,overlapCount:plan.overlapCount,transferCount:plan.transferCount,
    byteLayout:{cells:16*n,weights:32*n,populations:108*n,state:128},
    geometry:'endpoint-defined-prescribed-co-translation',fluidTransport:'same-prescribed-translation-as-solid',...nativePartitionReadiness};
}

/** The expectation always consumes actual Float32 inputs, not ideal doubles. */
export function createNativePartitionPopulations(oracle=createNativePartitionOracle(),kind='uniform') {
  if(!['uniform','mixed'].includes(kind))throw new RangeError('Native partition population fixture must be uniform or mixed');
  const velocity=oracle.plan.displacement.map(v=>v*nativePartitionGrid.pitch/nativePartitionPopulationScale.materialIntervalSeconds);
  const eq=Float32Array.from(equilibrium(1,velocity));
  return Float32Array.from({length:27*oracle.cellCount},(_,j)=>oracle.before[Math.floor(j/27)]===0?0:
    kind==='uniform'?eq[j%27]:(1+(Math.floor(j/27)*13+(j%27)*17)%97)/1024);
}

function validateInput(oracle,populations) {
  if(!(populations instanceof Float32Array)||populations.length!==27*oracle.cellCount)
    throw new RangeError('Native partition input requires 27 Float32 populations per cell');
  for(let j=0;j<populations.length;j++) {
    const value=populations[j];
    // The numerical proof excludes subnormal/overflow arithmetic. These wide
    // bounds keep up to eight positive products by numerators <=48 normal and
    // finite, including the final division by an integer in [1,48].
    if(!Number.isFinite(value)||value<0||(value>0&&(value<2**-100||value>16)))
      throw new RangeError('Native partition positive inputs require bounded normal Float32 values in [2^-100,16]');
    if(oracle.before[Math.floor(j/27)]===0&&value!==0)throw new RangeError('Native partition dry input cells must be zero');
  }
}

/** WGSL 15.7.4 permits either adjacent f32 for + and *, not only nearest;
 * hence their normal relative error is bounded by epsilon=2^-23. Division
 * permits 2.5 ULP for this denominator domain. A normal positive quotient x
 * has ULP(x)<=epsilon*x, so its division error is <=d*x, d=2.5*epsilon.
 *
 * Independent derivation: let T=sum(w*f)/N be the exact positive answer and
 * E its binary64 reference. For m positive terms, any association of the m
 * products and m-1 additions has relative error <=g=gamma(2m-1,epsilon).
 * Each contribution encounters at most one division, regardless of whether
 * it is performed before/after multiplication or summation. Positivity gives
 * |GPU-T| <= [g+d*(1+g)]*T. Fusion cannot worsen the allowed accuracy.
 * The input bounds keep positive terms/results normal even if division is
 * reassociated before multiplication; integer weights/denominators are exact.
 *
 * With r=gamma(2m,2^-53), |E-T|<=r*T and T<=E/(1-r). Thus the absolute bound
 * is E*[g+d*(1+g)+r]/(1-r). Keep its three contributions separately below.
 * The final inflation covers fewer than 16 binary64 positive arithmetic
 * steps used to evaluate the budget; it is not a free fixture tolerance.
 * An exact zero sum uses the shader's explicit zero branch, never division.
 * See nativePartitionArithmeticContract for versioned normative sources. */
export function nativePartitionPopulationErrorBudget(expected,positiveTerms=8) {
  if(!Number.isFinite(expected)||expected<0||!Number.isInteger(positiveTerms)||positiveTerms<0||positiveTerms>8)
    throw new RangeError('Invalid positive-sum error-bound arguments');
  if(positiveTerms===0) {
    if(expected!==0)throw new RangeError('A sum without positive terms must be zero');
    return {bound:0,productSumBound:0,divisionBound:0,referenceBound:0,
      productSumRelativeBound:0,divisionRelativeBound:0,gpuRelativeBound:0,referenceRelativeBound:0,positiveTerms};
  }
  const g=gamma(2*positiveTerms-1,EPS32),r=gamma(2*positiveTerms,U64),exactUpper=expected/(1-r);
  const productSumBound=exactUpper*g,divisionBound=exactUpper*DIVISION_RELATIVE*(1+g),referenceBound=exactUpper*r;
  return {bound:inflate(productSumBound+divisionBound+referenceBound),productSumBound,divisionBound,referenceBound,
    productSumRelativeBound:g,divisionRelativeBound:DIVISION_RELATIVE,gpuRelativeBound:g+DIVISION_RELATIVE*(1+g),
    referenceRelativeBound:r,positiveTerms};
}

export function nativePartitionPopulationBound(expected,positiveTerms=8) {
  return nativePartitionPopulationErrorBudget(expected,positiveTerms).bound;
}

export function expectedNativePartitionPopulations(oracle,populations) {
  auditCoMovingTetra(oracle.plan);
  validateInput(oracle,populations);
  const numerator=new Float64Array(populations.length),terms=new Uint8Array(populations.length);
  // Visit the original independently clipped donor list, NOT a decoded GPU
  // slot list, so wrong donor identity cannot contaminate the expectation.
  for(const {from,to,numerator:weight} of oracle.plan.overlaps)for(let q=0;q<27;q++) {
    const value=populations[27*from+q];numerator[27*to+q]+=weight*value;if(value>0)terms[27*to+q]++;
  }
  const expected=Float64Array.from(numerator,(v,j)=>oracle.after[Math.floor(j/27)]?v/oracle.after[Math.floor(j/27)]:0);
  const bounds=Float64Array.from(expected,(v,j)=>nativePartitionPopulationBound(v,terms[j]));
  return {expected,bounds,numerator,positiveTerms:terms,maxRelativeBound:nativePartitionPopulationErrorBudget(1,8).gpuRelativeBound,
    arithmeticContract:nativePartitionArithmeticContract,referenceUsesActualFloat32Inputs:true};
}

function view(bytes,size,label) {
  if(!(bytes instanceof ArrayBuffer)||bytes.byteLength!==size)throw new RangeError(`Native partition ${label} readback requires exactly ${size} bytes`);
  return new DataView(bytes);
}

/** cells: four u32 per cell; weights: packed destination<<6 | numerator;
 * populations: 27 f32 per cell. All fields are little-endian and length-exact. */
export function decodeNativePartitionReadback(readback,oracle=createNativePartitionOracle()) {
  const n=oracle.cellCount,cv=view(readback?.cells,16*n,'cells'),wv=view(readback?.weights,32*n,'weights');
  const pv=view(readback?.populations,108*n,'populations');
  const before=new Uint32Array(n),after=new Uint32Array(n),rows=new Uint32Array(n),columns=new Uint32Array(n);
  for(let i=0;i<n;i++)[before,after,rows,columns].forEach((values,k)=>{values[i]=cv.getUint32(16*i+4*k,true);});
  const weights=Uint32Array.from({length:8*n},(_,i)=>wv.getUint32(4*i,true));
  const populations=Float32Array.from({length:27*n},(_,i)=>pv.getFloat32(4*i,true));
  let state=null,inputPopulations=null;
  if(readback.state!==undefined){const sv=view(readback.state,128,'state');state=Uint32Array.from({length:32},(_,i)=>sv.getUint32(4*i,true));}
  if(readback.inputPopulations!==undefined){const iv=view(readback.inputPopulations,108*n,'inputPopulations');inputPopulations=Float32Array.from({length:27*n},(_,i)=>iv.getFloat32(4*i,true));}
  return {before,after,rows,columns,weights,populations,state,inputPopulations};
}

function assertState(state,oracle) {
  if(!state)return;
  const p=oracle.plan,n=oracle.cellCount,expected=new Int32Array(32);
  expected.set([0,1,n,n,n,n,oracle.overlapCount,oracle.transferCount]);
  expected.set([...p.anchor.map(v=>2*v),2*p.leg],8);
  expected.set([...p.anchorAfter.map(v=>2*v),2*p.leg],12);
  expected.set(p.displacement.map(v=>2*v),16);
  for(let i=0;i<32;i++)if(state[i]!==expected[i]>>>0)throw Error(`Native partition state word ${i} differs from exact fixture/counter/reserved ABI`);
}

function conservation(oracle,input,output,bounds) {
  const before=new Float64Array(27),after=new Float64Array(27),allowance=new Float64Array(27),absBefore=new Float64Array(27),absAfter=new Float64Array(27);
  for(let i=0;i<oracle.cellCount;i++)for(let q=0;q<27;q++) {
    const j=27*i+q,a=oracle.before[i]*input[j],b=oracle.after[i]*output[j];
    before[q]+=a;after[q]+=b;absBefore[q]+=Math.abs(a);absAfter[q]+=Math.abs(b);allowance[q]+=oracle.after[i]*bounds[j];
  }
  const sumGamma=gamma(oracle.cellCount+1,U64);
  for(let q=0;q<27;q++) {
    allowance[q]=inflate(allowance[q]*(1+sumGamma)+sumGamma*(absBefore[q]+absAfter[q]));
    if(Math.abs(after[q]-before[q])>allowance[q])throw Error(`Native partition extensive component ${q} exceeds accumulated cell roundoff bound`);
  }
  const reduce=direction=>{
    let a=0,b=0,bound=0,magnitude=0;
    for(let q=0;q<27;q++) {
      const d=direction===null?1:DIRECTIONS[q][direction];a+=d*before[q];b+=d*after[q];
      bound+=Math.abs(d)*allowance[q];magnitude+=Math.abs(d)*(Math.abs(before[q])+Math.abs(after[q]));
    }
    bound=inflate(bound*(1+gamma(27,U64))+gamma(27,U64)*magnitude);
    if(Math.abs(b-a)>bound)throw Error(`Native partition ${direction===null?'mass':'raw momentum'} exceeds accumulated cell roundoff bound`);
    return {before:a/48,after:b/48,error:Math.abs(b-a)/48,bound:bound/48};
  };
  return {components:Array.from(before,(v,q)=>({before:v/48,after:after[q]/48,error:Math.abs(after[q]-v)/48,bound:allowance[q]/48})),
    mass:reduce(null),rawMomentum:[0,1,2].map(reduce),units:'cell-volume-weighted-populations',physicalForceValidated:false};
}

/** Strict geometry/source identity first, derived floating-point bounds second. */
export function assertNativePartitionReadback(readback,{oracle=createNativePartitionOracle(),inputPopulations,inputSnapshot,report}={}) {
  validateInput(oracle,inputPopulations);
  if(inputSnapshot!==undefined&&(!(inputSnapshot instanceof Float32Array)||!same(inputPopulations,inputSnapshot)))
    throw Error('Native partition input mutation detected');
  const decoded=decodeNativePartitionReadback(readback,oracle),n=oracle.cellCount;
  for(const key of ['before','after','rows','columns'])for(let i=0;i<n;i++)
    if(decoded[key][i]!==oracle[key][i])throw Error(`Native partition ${key} cell ${i} differs from independent exact geometry`);
  const rows=new Uint32Array(n),columns=new Uint32Array(n);
  for(let at=0;at<8*n;at++) {
    const word=decoded.weights[at];
    if(word!==oracle.weights[at])throw Error(`Native partition weight/source slot ${at} differs from independent clipped donor`);
    if(word){const numerator=word&63,destination=word>>>6;rows[Math.floor(at/8)]+=numerator;columns[destination]+=numerator;}
  }
  if(!same(rows,decoded.before)||!same(columns,decoded.after))throw Error('Native partition exact row/column closure failed');
  assertState(decoded.state,oracle);
  if(decoded.inputPopulations&&!same(decoded.inputPopulations,inputPopulations))throw Error('Native partition GPU input mutation detected');
  const expected=expectedNativePartitionPopulations(oracle,inputPopulations);
  let maxPopulationError=0,maxBoundRatio=0,dryPopulationCount=0;
  for(let j=0;j<decoded.populations.length;j++) {
    const actual=decoded.populations[j];
    if(!Number.isFinite(actual)||actual<0)throw Error(`Native partition population ${j} must be finite and nonnegative`);
    if(oracle.after[Math.floor(j/27)]===0){dryPopulationCount++;if(actual!==0)throw Error(`Native partition dry population ${j} must be exactly zero`);}
    const error=Math.abs(actual-expected.expected[j]),bound=expected.bounds[j];
    if(error>bound)throw Error(`Native partition population ${j} exceeds derived Float32 positive-sum roundoff bound: ${error} > ${bound}`);
    maxPopulationError=Math.max(maxPopulationError,error);maxBoundRatio=Math.max(maxBoundRatio,bound?error/bound:0);
  }
  const totals=conservation(oracle,inputPopulations,decoded.populations,expected.bounds);
  if(report!==undefined) {
    if(!report||report.solverReady!==false)throw Error('Native partition report must retain unavailable solver');
    for(const key of Object.keys(nativePartitionReadiness))if(report[key]!==undefined&&report[key]!==false)throw Error(`Native partition report cannot claim ${key}`);
    for(const [key,value] of Object.entries({cellCount:n,overlapCount:oracle.overlapCount,transferCount:oracle.transferCount,denominator:48,exactVolumeDenominator:48}))
      if(report[key]!==undefined&&report[key]!==value)throw Error(`Native partition ${key} report/readback mismatch`);
  }
  return {cellCount:n,populationCount:27*n,dryPopulationCount,counts:oracle.counts,transitions:oracle.transitions,
    overlapCount:oracle.overlapCount,transferCount:oracle.transferCount,denominator:48,exactRowColumnClosure:true,
    maxPopulationError,maxBoundRatio,maxRelativeBound:expected.maxRelativeBound,conservation:totals,
    materialMapValidated:true,geometry:oracle.geometry,...nativePartitionReadiness};
}
