import {fixtureOBJ,nativePartitionGrid,createNativePartitionOracle,createNativePartitionPopulations,assertNativePartitionReadback} from './native-partition-oracle.mjs';
import {createNativePartitionProbe} from './native-partition-probe.mjs';
import {nativeSceneStateUnchanged} from './native-scene-cases.mjs';
import {observeNativeQueue} from './native-scene-probe.mjs';

/** Exact native endpoints -> one prescribed material partition, not fluid flow. */
export async function nativePartitionCFDChecks() {
  const checks=[],cases=[],timings=[];let error,probe,context,device,owner,mesh,oracle,populations,velocityMM;
  const call=(name,args={})=>frameAI.call(name,args);
  const check=(name,pass)=>{checks.push({name,pass:!!pass});if(!pass)throw Error(name);};
  const setup=async({anchor=[.5,.5,.5],displacement=[.5,.5,.5],label='forward',obj=fixtureOBJ}={})=>{
    if(probe){await probe.dispose();probe=null;}
    const opened=await call('scene.open',{name:`cfd-partition-${label}.obj`,base64:btoa(obj)});
    check(`${label}: actual native tetra imported`,opened.objects.filter(n=>n.mesh).length===1&&opened.objects.find(n=>n.mesh)?.mesh.triangles===4);
    mesh=opened.objects.find(n=>n.mesh);owner=await call('plugins.create',{plugin:'cfd-native-test'});context=globalThis.__cfdNativeContext;device=context?.device;
    if(device!==frameEngine.renderer.device)throw Error('Native partition must use shared Frame device');
    const start=anchor.map(v=>v*62.5),end=anchor.map((v,k)=>(v+displacement[k])*62.5);velocityMM=displacement.map(v=>v*62.5);
    for(const [id,a,b]of [[mesh.hash,start,end],[owner.hash,[0,0,0],velocityMM]]){
      await call('animation.key',{id,path:'position',frame:0,value:a,interpolation:'hard'});
      await call('animation.key',{id,path:'position',frame:60,value:b,interpolation:'hard'});
    }
    await call('animation.seek',{frame:0});await call('render.stop');
    oracle=createNativePartitionOracle({anchor,displacement});probe=createNativePartitionProbe(context,owner.hash,{grid:nativePartitionGrid});
    populations=createNativePartitionPopulations(oracle,'uniform');
  };
  const args=()=>({timeStart:0,timeEnd:1,expectedId:'mesh:'+mesh.hash,populations});
  const drain=async()=>{await frameEngine.draw(false);await device.queue.onSubmittedWorkDone();};
  const run=async(label,mode='uniform',provided)=>{
    populations=provided??createNativePartitionPopulations(oracle,mode);const snapshot=populations.slice();
    const before=await call('scene.inspect'),timeline=await call('animation.inspect',{id:mesh.hash});
    const result=await probe.run(args());
    if(!Array.isArray(result.report.stateWords)||result.report.stateWords.length!==32)throw Error('Full native partition state ABI missing');
    const numerical=assertNativePartitionReadback({cells:result.cellBytes,weights:result.weightBytes,populations:result.populationBytes,state:new Uint32Array(result.report.stateWords).buffer},{oracle,inputPopulations:populations,inputSnapshot:snapshot,report:result.report});
    check(`${label}: all integer overlaps and 27 components agree with independent oracle`,numerical.exactRowColumnClosure&&numerical.materialMapValidated);
    check(`${label}: scene and visible timeline unchanged`,nativeSceneStateUnchanged(before,await call('scene.inspect'),timeline,await call('animation.inspect',{id:mesh.hash})));
    check(`${label}: one native session holds two shared endpoint samples`,result.audit.created===1&&result.audit.disposed===1&&result.audit.samples.length===2&&result.audit.samples.every(s=>s.meshes.length===1&&s.meshes[0].shared));
    check(`${label}: source and topology identity retained`,result.audit.samples.every(s=>s.sourceSignature===result.sourceSignature&&s.meshes[0].id===result.occurrence&&s.meshes[0].topologyRevision===result.audit.samples[0].meshes[0].topologyRevision));
    const velocityScale=Math.max(1,...velocityMM.map(Math.abs)),tolerance=16*Number.EPSILON*velocityScale;
    check(`${label}: instantaneous endpoint velocity witnesses agree with prescribed fixture`,result.audit.samples.every(s=>s.meshes[0].worldDerivative.every((v,i)=>Math.abs(v-(i>=12&&i<=14?velocityMM[i-12]:0))<=tolerance)));
    check(`${label}: co-moving owner does not erase fixed world geometry`,result.audit.samples.every((s,index)=>s.ownerWorld.every((v,i)=>Math.abs(v-(i>=12&&i<=14?index*velocityMM[i-12]:i%5===0?1:0))<=tolerance)&&s.ownerWorldDerivative.every((v,i)=>Math.abs(v-(i>=12&&i<=14?velocityMM[i-12]:0))<=tolerance)));
    check(`${label}: material map cannot claim kinetic or continuous-native fluid solution`,result.report.materialRemapAvailable===true&&result.report.exactGeometricClosure===true&&result.continuousNativeTrajectoryValidated===false&&result.kineticStreamingPerformed===false&&result.nativeSpaceTimeCouplingValidated===false&&result.solverReady===false);
    const {cellBytes,weightBytes,populationBytes,...summary}=result;cases.push({...summary,numerical,label,mode});timings.push({name:label,ms:result.milliseconds,budgetMs:result.budgetMs});return numerical;
  };
  try {
    check('Native partition owns an empty test scene',(await call('scene.inspect')).objects.length===0);
    await setup();
    const forward=await run('forward uniform material translation');await run('forward mixed populations','mixed');
    check('Forward exact cell volume is not a center label',forward.counts.before.cut===32&&forward.counts.after.cut===19&&forward.counts.before.sumNumerator===24233&&forward.counts.after.sumNumerator===24233);
    await setup({anchor:[1,1,1],displacement:[-.5,-.5,-.5],label:'reverse'});
    const reverse=await run('reverse uniform material translation');await run('reverse mixed populations','mixed');
    check('Reverse material partition fills exactly one newly wet cell',reverse.transitions.dryToWet===1&&reverse.transitions.wetToDry===0);
    await setup({displacement:[0,0,0],label:'stationary'});await run('zero displacement mixed populations','mixed');
    await setup({label:'lifecycle'});
    const phases=[['before-session',0],['after-session',0],['after-sample-0',0],['after-motion-0',1],['after-shell-0',2],['after-sample-1',2],['after-motion-1',3],['after-shell-1',4],['after-partition',5],['after-readback',6]];
    for(const [phase,submissions]of phases){
      await drain();const abort=new AbortController();if(phase==='before-session')abort.abort();
      const hooks={afterCreate:()=>{if(phase==='after-session')abort.abort();},afterSample:i=>{if(phase===`after-sample-${i}`)abort.abort();},afterMotion:i=>{if(phase===`after-motion-${i}`)abort.abort();},afterShell:i=>{if(phase===`after-shell-${i}`)abort.abort();},afterPartition:()=>{if(phase==='after-partition')abort.abort();},afterReadback:()=>{if(phase==='after-readback')abort.abort();}};
      const observed=await observeNativeQueue(device,()=>probe.run({...args(),signal:abort.signal,...hooks}));
      check(`Partition cancellation ${phase} stops at exact stage and retires`,/cancelled/.test(String(observed.error))&&!observed.value&&observed.stats.submissions===submissions&&observed.error.nativePartitionAudit.created===observed.error.nativePartitionAudit.disposed);
    }
    await run('same partition scratch reused after cancellations');
    let stale;
    try{await probe.run({...args(),afterReadback:()=>call('animation.key',{id:mesh.hash,path:'position',frame:60,value:[70,70,70],interpolation:'hard'})});}catch(e){stale=e;}
    check('Future native key edit invalidates both endpoint result after readback',/source changed/.test(String(stale))&&stale.nativePartitionAudit.created===stale.nativePartitionAudit.disposed);
    await call('animation.key',{id:mesh.hash,path:'position',frame:60,value:[62.5,62.5,62.5],interpolation:'hard'});await call('render.stop');
    await run('same partition scratch reused after stale source');
    await call('animation.key',{id:mesh.hash,path:'position',frame:60,value:[63,62.5,62.5],interpolation:'hard'});await call('render.stop');await drain();
    const offGrid=await observeNativeQueue(device,()=>probe.run(args()));
    check('Nonrepresentable native endpoint rejects instead of snapping',/Unsupported or unresolved native co-moving partition/.test(String(offGrid.error))&&!offGrid.value&&offGrid.error.nativePartitionAudit.created===offGrid.error.nativePartitionAudit.disposed);
    await call('animation.key',{id:mesh.hash,path:'position',frame:60,value:[62.5,62.5,62.5],interpolation:'hard'});
    await call('animation.key',{id:mesh.hash,path:'rotation',frame:0,value:[0,0,0],interpolation:'hard'});
    await call('animation.key',{id:mesh.hash,path:'rotation',frame:60,value:[0,0,30],interpolation:'hard'});await call('render.stop');await drain();
    const rotation=await observeNativeQueue(device,()=>probe.run(args()));
    check('Rotating endpoint pair cannot masquerade as translation',/Unsupported or unresolved native co-moving partition/.test(String(rotation.error))&&!rotation.value&&rotation.error.nativePartitionAudit.created===rotation.error.nativePartitionAudit.disposed);
    await call('animation.key',{id:mesh.hash,path:'rotation',frame:60,value:[0,0,0],interpolation:'hard'});await call('render.stop');
    await run('same partition scratch reused after admission failures','mixed');
    const instance=await call('scene.create',{type:'instance',params:{object:mesh.hash}});await call('render.stop');await drain();
    const multiple=await observeNativeQueue(device,()=>probe.run(args()));
    check('Multiple native occurrences reject before geometry submissions',/exactly one whole tetrahedron/.test(String(multiple.error))&&!multiple.value&&multiple.stats.submissions===0);
    await call('scene.delete',{ids:[instance.hash]});
    const reversed=fixtureOBJ.split('\n').map(line=>line.startsWith('f ')?'f '+line.slice(2).split(' ').reverse().join(' '):line).join('\n');
    await setup({obj:reversed,label:'reversed winding'});await run('reversed winding exact material partition');
    await setup({anchor:[1,1,1],displacement:[-.5,-.5,-.5],label:'population admission'});
    const dry=oracle.before.findIndex(v=>v===0),wet=oracle.before.findIndex(v=>v>0);
    for(const [label,index,value]of [['NaN',wet,NaN],['negative',wet,-.01],['subnormal',wet,2**-149],['dry donor',dry,.01]]){
      if(index<0)throw Error('Required native population admission cell missing');
      populations=createNativePartitionPopulations(oracle,'uniform');populations[27*index]=value;await drain();
      const invalid=await observeNativeQueue(device,()=>probe.run(args()));
      check(`${label} population rejects before result publication`,/Unsupported or unresolved native co-moving partition/.test(String(invalid.error))&&!invalid.value&&invalid.error.nativePartitionAudit.created===invalid.error.nativePartitionAudit.disposed);
    }
    await run('same partition scratch reused after population admission failures','mixed');
    const zeros=createNativePartitionPopulations(oracle,'uniform');for(let i=0;i<oracle.cellCount;i++)zeros[27*i]=0;
    await run('zero component remains exactly zero','uniform',zeros);
    await setup({obj:fixtureOBJ.replaceAll('218.75','150'),label:'old nonrepresentable endpoint coordinates'});
    for(const [frame,value]of [[0,[25,25,25]],[60,[50,50,50]]])await call('animation.key',{id:mesh.hash,path:'position',frame,value,interpolation:'hard'});
    await call('render.stop');await drain();
    const oldCoordinates=await observeNativeQueue(device,()=>probe.run(args()));
    check('Earlier native volume geometry cannot be silently snapped into exact partition',/Unsupported or unresolved native co-moving partition/.test(String(oldCoordinates.error))&&!oldCoordinates.value&&oldCoordinates.error.nativePartitionAudit.created===oldCoordinates.error.nativePartitionAudit.disposed);
    check('Shared device remains current',context.device===device&&frameEngine.renderer.device===device);
  }catch(failure){error=failure.stack||String(failure);}
  finally{if(probe)try{await probe.dispose();}catch(failure){error??=String(failure);}}
  return {pass:!error,checks,cases,timings,error,nativeExactEndpointMaterialPartitionValidated:!error,
    continuousNativeTrajectoryValidated:false,nativeSpaceTimeCouplingValidated:false,nativeFrameSceneValidated:false,solverReady:false,
    scope:'Exact admitted native endpoints and conservative prescribed co-moving material interpolation; not direction-dependent kinetic fluid evolution',
    remaining:['general native source-coordinate error admission','continuous native trajectory geometry','arbitrary oriented/deforming solids','direction-dependent kinetic face fluxes','moving-wall mass/impulse ledger','production collision/turbulence/AMR/force/UI']};
}
