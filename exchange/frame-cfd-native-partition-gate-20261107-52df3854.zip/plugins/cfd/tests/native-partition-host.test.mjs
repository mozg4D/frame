import assert from 'node:assert/strict';
import test from 'node:test';
import {motionValidityFixture} from './motion-validity.mjs';
import {createNativePartitionProbe} from './native-partition-probe.mjs';
import {planCoMovingPartition} from '../co-moving-partition-gpu.mjs';

// Host-only lifecycle/ownership regression. No shader, adapter, browser, native
// geometry, numerical material partition or physical CFD update executes here.
// All status counters and derived result bytes are injected control-flow data.
// Passing this suite is NOT numerical accuracy, GPU, or native scene proof.
const started=performance.now();
const grid=()=>({origin:[0,0,0],pitch:1/1024,dimensions:[8,8,8]});
const bounds={maxBytes:1024*1024,maxCells:512,maxWork:1e6};
const request=()=>({timeStart:0,timeEnd:1,expectedId:'tetra',populations:new Float32Array(27*512).fill(.125)});
const identity=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
const roles=['shellTriangles','faces','reachA','reachB','shellUniform','shellStatus','shellReadback','points','shellResults',
  'pairTriangles','partitionState','partitionUniform','cells','weights','input','output','partitionReadback','copy'];
const successCounters=[0,1,512,512,512,512,4061,3550];
const partitionEntries=['extractCoMovingTetra','initializeCoMovingCells','partitionCoMovingCells','auditCoMovingPartition','remapCoMovingPopulations'];
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};

function fixture({failAllocationAt=-1}={}) {
  const {context}=motionValidityFixture(),device=context.device;
  const allocated=[],events=[],groups=[],writes=[],submissions=[],copies=[],sessions=[],samples=[];
  const hooks={},counts=new Map();
  let revision=0,fences=0,submitAttempts=0;
  const state={created:0,disposed:0,sampled:0,sourceReads:0,sourceDestroys:0};
  device.limits={...device.limits,maxStorageBufferBindingSize:1024*1024,maxBufferSize:1024*1024,
    maxComputeWorkgroupsPerDimension:65535,maxComputeInvocationsPerWorkgroup:256,
    maxComputeWorkgroupSizeX:256,maxUniformBufferBindingSize:65536,
    maxStorageBuffersPerShaderStage:8,maxBindGroups:4,maxBindingsPerBindGroup:1000};
  const count=key=>{const n=(counts.get(key)??0)+1;counts.set(key,n);return n;};
  const source=(role,size)=>({role,size,usage:128,
    mapAsync(){state.sourceReads++;throw Error('Borrowed source must not be mapped');},
    getMappedRange(){state.sourceReads++;throw Error('Borrowed source must not be read');},
    destroy(){state.sourceDestroys++;throw Error('Borrowed source must not be destroyed');}});
  const positions=source('nativePositions',48),indices=source('nativeIndices',48);
  const mesh={occurrenceId:'tetra',storage:'buffer',positions,indices,vertexCount:4,triangleCount:4,topologyRevision:1,
    worldMatrix:[...identity],worldDerivative:Array(16).fill(0),deformationVelocity:null};
  const meshes=[mesh];let captureMeshes=meshes;
  const live=()=>assert.equal(state.created-state.disposed,1,'Exactly one native sampler must be retained during GPU work');
  device.createBuffer=({size,usage})=>{
    if(allocated.length===failAllocationAt)throw Error('Injected scratch allocation failure');
    const role=roles[allocated.length];assert.ok(role,'Unexpected scratch allocation or private source copy');
    const buffer={role,size,usage,destroyCount:0,mapCount:0,unmapCount:0,mapped:false,
      destroy(){assert.equal(this.destroyCount++,0,`${role} destroyed twice`);assert.equal(this.mapped,false);events.push('destroy:'+role);},
      async mapAsync(mode,offset,length){
        live();assert.equal(mode,1);assert.equal(offset,0);assert.ok(length<=size);assert.equal(this.mapped,false);
        events.push('map:'+role);this.mapCount++;await hooks.map?.(role,this.mapCount);this.mapped=true;
      },
      getMappedRange(offset,length){
        live();assert.equal(this.mapped,true);assert.equal(offset,0);events.push('read:'+role);hooks.read?.(role,this.mapCount);
        if(role==='shellReadback')return new Uint32Array(hooks.shellStatus??[0,2,0,1,0,0,0,0]).buffer;
        if(role==='partitionReadback'){
          const bytes=new ArrayBuffer(128);new Uint32Array(bytes).set(hooks.partitionStatus??successCounters);
          // Remaining anchor/map bytes are intentionally synthetic placeholders.
          return bytes;
        }
        assert.equal(role,'copy','Only derived result/status buffers may be CPU-read');
        const bytes=new ArrayBuffer(length);new Uint8Array(bytes).fill(0x5a);return bytes;
      },
      unmap(){assert.equal(this.mapped,true);this.mapped=false;this.unmapCount++;events.push('unmap:'+role);}};
    allocated.push(buffer);return buffer;
  };
  device.createShaderModule=({label,code})=>{
    const stage=label?.includes('motion')?'motion':code.includes('validateShell')?'shell':'partition';
    return {async getCompilationInfo(){
      live();const n=count('compile:'+stage);events.push('compile:'+stage);await hooks.compile?.(stage,n);
      return {messages:hooks.compileError===stage?[{type:'error',message:'Injected compile failure'}]:[]};
    }};
  };
  device.createComputePipelineAsync=async({compute})=>{
    live();const entry=compute.entryPoint;events.push('pipeline:'+entry);await hooks.pipeline?.(entry,count('pipeline:'+entry));
    if(hooks.pipelineError===entry)throw Error('Injected pipeline failure');
    return {entryPoint:entry,getBindGroupLayout(){return {};}};
  };
  device.createBindGroupLayout=d=>d;
  device.createPipelineLayout=d=>d;
  device.createBindGroup=d=>{live();groups.push(d);return d;};
  device.pushErrorScope=()=>events.push('scope:push');
  device.popErrorScope=async()=>{events.push('scope:pop');return hooks.validationError?{message:'Injected GPU validation failure'}:null;};
  device.createCommandEncoder=()=>{
    const commands=[];
    return {
      beginComputePass(){let entry;return {setPipeline(p){entry=p.entryPoint;},setBindGroup(){},
        dispatchWorkgroups(n){commands.push({entry,workgroups:n});},end(){}};},
      clearBuffer(buffer,offset=0,size=buffer.size){assert.ok(allocated.includes(buffer));commands.push({clear:buffer,offset,size});},
      copyBufferToBuffer(from,fromOffset,to,toOffset,size){
        assert.ok(from!==positions&&from!==indices&&to!==positions&&to!==indices,'Native source buffers must never be copied');
        const copy={from,fromOffset,to,toOffset,size};copies.push(copy);commands.push(copy);
      },finish(){return commands;}
    };
  };
  device.queue.writeBuffer=(buffer,offset,data)=>{
    live();assert.ok(buffer!==positions&&buffer!==indices,'Borrowed source must never be uploaded/replaced');
    const bytes=ArrayBuffer.isView(data)?new Uint8Array(data.buffer,data.byteOffset,data.byteLength).slice():new Uint8Array(data).slice();
    writes.push({buffer,offset,data,bytes});events.push('write:'+buffer.role);hooks.write?.(buffer.role);
  };
  device.queue.submit=commands=>{
    live();submitAttempts++;hooks.submit?.(submitAttempts);submissions.push(commands.flat());events.push('submit:'+submissions.length);
  };
  device.queue.onSubmittedWorkDone=async()=>{events.push('fence:'+ ++fences);await hooks.fence?.(fences);};
  context.scene.createSampler=async(owner,keys,options)=>{
    assert.equal(owner,'owner');assert.deepEqual(keys,[]);assert.deepEqual(options,[]);state.created++;events.push('create');
    const sourceRevision=revision;
    const session={mode:'transform-only',disposed:false,
      assertCurrent(){if(session.disposed)throw Error('Sampler was disposed');if(revision!==sourceRevision)throw Error('Time sampler source changed');},
      sample({timeSeconds}){
        session.assertCurrent();const index=samples.length;state.sampled++;events.push('sample:'+index);
        const sample={device,timeSeconds,lengthUnit:'mm',velocityUnit:'mm/s',sourceSignature:'source:'+sourceRevision,
          ownerWorld:[...identity],ownerWorldDerivative:Array(16).fill(0),meshes:meshes.map(m=>({...m,worldMatrix:[...m.worldMatrix],worldDerivative:[...m.worldDerivative]})),
          stale:false,assertions:0,assertCurrent(){this.assertions++;session.assertCurrent();if(this.stale)throw Error('Endpoint sample '+index+' became stale');}};
        samples.push(sample);hooks.sample?.(sample,index);return sample;
      },
      dispose(){assert.equal(session.disposed,false,'Sampler disposed twice');session.disposed=true;state.disposed++;events.push('dispose');hooks.dispose?.();}
    };
    sessions.push(session);await hooks.create?.(session);return session;
  };
  context.scene.capture=owner=>{assert.equal(owner,'owner');live();events.push('capture');return {meshes:captureMeshes};};
  return {context,device,mesh,meshes,positions,indices,allocated,events,groups,writes,submissions,copies,sessions,samples,state,hooks,
    stale(){revision++;},captureAs(value){captureMeshes=value;},get fences(){return fences;},get submitAttempts(){return submitAttempts;}};
}
function setup(t,options={},fixtureOptions={}) {
  const f=fixture(fixtureOptions),probe=createNativePartitionProbe(f.context,'owner',{...bounds,grid:grid(),...options});
  t.after(()=>probe.dispose());return {f,probe};
}
async function retire(f,probe) {
  const before=f.fences;await probe.dispose();await probe.dispose();
  assert.equal(f.fences,before+1,'Owned scratch has one fenced retirement');assert.equal(f.allocated.length,roles.length);
  assert.ok(f.allocated.every(b=>b.destroyCount===1&&!b.mapped));assert.equal(f.state.created,f.state.disposed);
  assert.equal(f.state.sourceReads,0);assert.equal(f.state.sourceDestroys,0);
  assert.ok(f.events.indexOf('destroy:shellTriangles')>f.events.lastIndexOf('dispose'));
}
async function rejectsRun(f,probe,options,pattern,{created=1,samples=2,submissions}={}) {
  let failure,published=false;
  await assert.rejects(probe.run({...request(),...options}).then(value=>{published=true;return value;}),error=>{failure=error;assert.match(error.message,pattern);return true;});
  assert.equal(published,false,'Failed operation must not publish a completed result');
  assert.deepEqual({created:failure.nativePartitionAudit.created,disposed:failure.nativePartitionAudit.disposed,samples:failure.nativePartitionAudit.samples.length},{created,disposed:created,samples});
  assert.equal(f.state.created,f.state.disposed);if(submissions!==undefined)assert.equal(f.submissions.length,submissions);
  assert.ok(f.allocated.every(b=>b.destroyCount===0&&!b.mapped),'Failed work retains reusable, unmapped owned scratch');return failure;
}
const stages=[['afterCreate',undefined,0,0],['afterSample',0,0,1],['afterMotion',0,1,1],['afterShell',0,2,1],
  ['afterSample',1,2,2],['afterMotion',1,3,2],['afterShell',1,4,2],['afterPartition',undefined,5,2],['afterReadback',undefined,6,2]];
const at=(index,action)=>i=>{if(index===undefined||i===index)return action();};

test('one retained sampler spans both native endpoints and six ordered mock submissions',async t=>{
  const {f,probe}=setup(t),observed=[];
  const observe=phase=>index=>{assert.equal(f.state.created,1);assert.equal(f.state.disposed,0);observed.push([phase,index]);};
  const result=await probe.run({...request(),...Object.fromEntries([...new Set(stages.map(s=>s[0]))].map(phase=>[phase,observe(phase)]))});
  assert.deepEqual(observed,stages.map(([phase,index])=>[phase,index]));
  assert.equal(result.cellBytes.byteLength,8192);assert.equal(result.weightBytes.byteLength,16384);assert.equal(result.populationBytes.byteLength,55296);
  for(const bytes of [result.cellBytes,result.weightBytes,result.populationBytes])assert.ok(new Uint8Array(bytes).every(v=>v===0x5a));
  assert.deepEqual([result.timeStart,result.timeEnd,result.sourceSignature,result.occurrence],[0,1,'source:0','tetra']);
  assert.deepEqual([result.audit.created,result.audit.disposed,result.audit.samples.length],[1,1,2]);
  assert.deepEqual(result.audit.samples.map(s=>s.timeSeconds),[0,1]);
  for(const sample of result.audit.samples)assert.deepEqual(sample.meshes,[{id:'tetra',vertices:4,triangles:4,topologyRevision:1,worldMatrix:identity,worldDerivative:Array(16).fill(0),shared:true}]);
  assert.equal(result.report.cellCount,512);assert.equal(result.report.gridKey,JSON.stringify(grid()));assert.equal(result.report.hardwareValidated,false);
  for(const shell of result.shellReports){assert.equal(shell.hardwareValidated,false);assert.deepEqual([shell.fluid,shell.solid,shell.unresolved],[1,0,0]);}
  for(const key of ['continuousNativeTrajectoryValidated','kineticStreamingPerformed','nativeSpaceTimeCouplingValidated','nativeFrameSceneValidated','solverReady'])assert.equal(result[key],false);
  assert.equal(result.path,'endpoint-defined-linear-prescribed-material-interpolation');
  assert.equal(result.allocatedBufferBytes,217248);assert.equal(probe.allocatedBufferBytes,217248);
  assert.ok(Number.isFinite(result.milliseconds)&&result.milliseconds>=0&&result.milliseconds<2000);assert.equal(result.budgetMs,30000);
  assert.equal(f.submissions.length,6);
  const entries=f.submissions.map(commands=>commands.filter(c=>c.entry).map(c=>[c.entry,c.workgroups]));
  const shell=[['validateShell',1],['propagate',1],['propagate',1],['propagate',1],['validateConnected',1],['classifyPoints',1]];
  assert.deepEqual(entries.slice(0,4),[[['transformMotion',1]],shell,[['transformMotion',1]],shell]);assert.deepEqual(entries[5],[]);
  assert.deepEqual(entries[4],partitionEntries.map((entry,index)=>[entry,index===0?1:8]));
  const buffer=role=>f.allocated.find(b=>b.role===role);
  const motionGroups=f.groups.filter(g=>g.entries[0]?.resource.buffer===f.positions);
  assert.equal(motionGroups.length,2);for(const g of motionGroups){assert.equal(g.entries[1].resource.buffer,f.indices);assert.equal(g.entries[1].resource.size,48);assert.equal(g.entries[3].resource.buffer,buffer('shellTriangles'));}
  const shellGroups=f.groups.filter(g=>g.entries[0]?.resource.buffer===buffer('shellTriangles'));
  assert.equal(shellGroups.length,4);for(const g of shellGroups)assert.equal(g.entries[1].resource.buffer,f.indices);
  assert.deepEqual(f.copies.map(c=>[c.from.role,c.fromOffset,c.to.role,c.toOffset,c.size]),[
    ['shellTriangles',0,'pairTriangles',0,448],['shellStatus',0,'shellReadback',0,32],
    ['shellTriangles',0,'pairTriangles',512,448],['shellStatus',0,'shellReadback',0,32],
    ['partitionState',0,'partitionReadback',0,128],['cells',0,'copy',0,8192],['weights',0,'copy',8192,16384],['output',0,'copy',24576,55296]]);
  assert.equal(buffer('pairTriangles').size,1024);
  assert.deepEqual(f.allocated.filter(b=>b.mapCount).map(b=>[b.role,b.mapCount,b.unmapCount]),[['shellReadback',2,2],['partitionReadback',1,1],['copy',1,1]]);
  assert.ok(f.events.indexOf('fence:1')<f.events.indexOf('compile:shell'));assert.ok(f.events.lastIndexOf('unmap:shellReadback')<f.events.indexOf('compile:partition'));
  assert.ok(f.events.indexOf('unmap:copy')<f.events.indexOf('fence:6'));assert.equal(f.fences,7);assert.equal(f.events.at(-1),'dispose');
  assert.ok(f.samples.every(s=>s.assertions>1),'Both endpoint samples must remain guarded');await retire(f,probe);
  await assert.rejects(probe.run(request()),/unavailable/);
});

test('caller grid and population mutations across awaited creation cannot change operation snapshots',async t=>{
  const supplied=grid(),{f,probe}=setup(t,{grid:supplied}),options=request(),expected=options.populations.slice();
  const reached=deferred(),resume=deferred();f.hooks.create=async()=>{reached.resolve();await resume.promise;};
  const pending=probe.run(options);await reached.promise;
  supplied.origin[0]=99;supplied.pitch=42;supplied.dimensions[0]=2;options.populations.fill(999);resume.resolve();
  const result=await pending;assert.equal(result.report.gridKey,JSON.stringify(grid()));
  const input=f.writes.find(w=>w.buffer.role==='input');assert.deepEqual(new Float32Array(input.bytes.buffer),expected);assert.notEqual(input.data,options.populations);await retire(f,probe);
});
const invalidSources=[
  ['multiple surfaces',f=>f.meshes.push({...f.mesh,occurrenceId:'other'}),/exactly one whole tetrahedron/],
  ['wrong triangles',f=>{f.mesh.triangleCount=5;f.indices.size=60;},/shared indexed tetrahedron/],
  ['wrong vertices',f=>{f.mesh.vertexCount=5;f.positions.size=60;},/shared indexed tetrahedron/],
  ['texture indices',f=>{f.indices.view={};},/shared indexed tetrahedron/],
  ['non-STORAGE indices',f=>{f.indices.usage=24;},/shared indexed tetrahedron/],
  ['short indices',f=>{f.indices.size=44;},/shared indexed tetrahedron/],
  ['wrong occurrence',f=>{f.mesh.occurrenceId='other';},/shared indexed tetrahedron/],
  ['private positions',f=>f.captureAs([{...f.mesh,positions:{size:48,usage:128}}]),/shared indexed tetrahedron/],
  ['private indices',f=>f.captureAs([{...f.mesh,indices:{size:48,usage:128}}]),/shared indexed tetrahedron/],
  ['nonfinite world matrix',f=>{f.mesh.worldMatrix[3]=NaN;},/motion contract/],
  ['nonfinite world derivative',f=>{f.mesh.worldDerivative[4]=Infinity;},/motion contract/],
  ['missing velocity',f=>{f.mesh.deformationVelocity=undefined;},/motion contract/]
];
for(const [name,change,pattern]of invalidSources)test(name+' rejects before GPU submission',async t=>{
  const {f,probe}=setup(t);change(f);await rejectsRun(f,probe,{},pattern,{samples:1,submissions:0});assert.equal(f.writes.length,0);assert.equal(f.copies.length,0);await retire(f,probe);
});
for(const topologyRevision of [undefined,0,-1,1.5,NaN,'1'])test('invalid topology revision '+topologyRevision+' rejects before GPU work',async t=>{
  const {f,probe}=setup(t);f.mesh.topologyRevision=topologyRevision;
  await rejectsRun(f,probe,{},/topology|indexed tetrahedron/,{samples:1,submissions:0});await retire(f,probe);
});
for(const [name,mutate]of [
  ['source signature',s=>{s.sourceSignature='source:replacement';}],['topology revision',s=>{s.meshes[0].topologyRevision=2;}],
  ['occurrence',s=>{s.meshes[0].occurrenceId='other';}],['positions',s=>{s.meshes[0].positions={size:48,usage:128};}],
  ['indices',s=>{s.meshes[0].indices={size:48,usage:128};}],['mesh count',s=>s.meshes.push({...s.meshes[0]})]
])test('endpoint continuity rejects changed '+name+' before second motion',async t=>{
  const {f,probe}=setup(t);f.hooks.sample=(sample,index)=>{if(index===1)mutate(sample);};
  await rejectsRun(f,probe,{},/source\/topology identity changed/,{submissions:2});await retire(f,probe);
});
for(const [name,mutate]of [
  ['device',s=>{s.device={};}],['time',s=>{s.timeSeconds=99;}],['position units',s=>{s.lengthUnit='m';}],['velocity units',s=>{s.velocityUnit='m/s';}],
  ['signature type',s=>{s.sourceSignature=1;}],['owner matrix',s=>{s.ownerWorld[0]=NaN;}],['owner derivative',s=>{s.ownerWorldDerivative[0]=Infinity;}]
])for(const endpoint of [0,1])test('unsupported '+name+' at endpoint '+endpoint+' never publishes',async t=>{
  const {f,probe}=setup(t);f.hooks.sample=(sample,index)=>{if(index===endpoint)mutate(sample);};
  await rejectsRun(f,probe,{},/sample contract|owner frame\/derivative/,{samples:endpoint+1,submissions:endpoint*2});await retire(f,probe);
});
for(const expectedId of [undefined,'',7])test('invalid expected occurrence '+expectedId+' does not acquire native sampler',async t=>{
  const {f,probe}=setup(t);await assert.rejects(probe.run({...request(),expectedId}),/occurrence/);assert.equal(f.state.created,0);await retire(f,probe);
});
for(const [timeStart,timeEnd]of [[NaN,1],[-1,1],[0,NaN],[0,Infinity],[1,1],[2,1]])test('unsupported endpoint times '+timeStart+','+timeEnd+' fail before native work',async t=>{
  const {f,probe}=setup(t);await assert.rejects(probe.run({...request(),timeStart,timeEnd}),/Increasing physical endpoint times/);assert.equal(f.state.created,0);assert.equal(f.submissions.length,0);await retire(f,probe);
});
for(const populations of [undefined,[],new Float64Array(27*512),new Float32Array(27*512-1),new Float32Array(27*512+1)])test('unsupported population storage '+populations?.constructor.name+':'+populations?.length+' rejects before native work',async t=>{
  const {f,probe}=setup(t);await assert.rejects(probe.run({...request(),populations}),/Float32 populations/);assert.equal(f.state.created,0);await retire(f,probe);
});

test('pre-cancelled run performs no native acquisition or submission',async t=>{
  const {f,probe}=setup(t),controller=new AbortController();controller.abort();
  await rejectsRun(f,probe,{signal:controller.signal},/cancelled/,{created:0,samples:0,submissions:0});assert.equal(f.fences,0);await retire(f,probe);
});
test('cancellation while native sampler creation awaits retires its eventual session',async t=>{
  const {f,probe}=setup(t),controller=new AbortController(),reached=deferred(),resume=deferred();
  f.hooks.create=async()=>{reached.resolve();await resume.promise;};
  const pending=rejectsRun(f,probe,{signal:controller.signal},/cancelled/,{samples:0,submissions:0});await reached.promise;controller.abort();assert.equal(f.state.disposed,0);resume.resolve();await pending;await retire(f,probe);
});
for(const [phase,index,submissions,samples]of stages)for(const kind of ['cancel','throw','stale','device'])test(kind+' at '+phase+(index??'')+' stops later stages and retires once',async t=>{
  const {f,probe}=setup(t),controller=new AbortController();
  const actions={cancel:()=>controller.abort(),throw:()=>{throw Error('Injected callback failure');},stale:()=>f.stale(),device:()=>{f.context.device={queue:{}};}};
  const pattern={cancel:/cancelled/,throw:/Injected callback failure/,stale:/source changed/,device:/shared GPU device changed/}[kind];
  await rejectsRun(f,probe,{signal:controller.signal,[phase]:at(index,actions[kind])},pattern,{samples,submissions});
  if(submissions<5)assert.ok(!f.events.includes('compile:partition'));if(submissions<6)assert.equal(f.copies.filter(c=>c.to.role==='copy').length,0);
  if(kind==='throw')assert.equal((await probe.run(request())).audit.disposed,1);await retire(f,probe);
});
for(const endpoint of [0,1])test('asynchronous sample callback '+endpoint+' rejects before its motion dispatch',async t=>{
  const {f,probe}=setup(t);await rejectsRun(f,probe,{afterSample:index=>{if(index===endpoint)return Promise.resolve();}},/afterSample must be synchronous/,{samples:endpoint+1,submissions:endpoint*2});await retire(f,probe);
});
for(const [role,occurrence,submissions,samples]of [['shellReadback',1,2,1],['shellReadback',2,4,2],['partitionReadback',1,5,2],['copy',1,6,2]])for(const kind of ['cancel','stale','reject'])test(kind+' during '+role+' map '+occurrence+' cannot publish or leak mapped scratch',async t=>{
  const {f,probe}=setup(t),controller=new AbortController();
  f.hooks.map=(at,n)=>{if(at!==role||n!==occurrence)return;if(kind==='cancel')controller.abort();if(kind==='stale')f.stale();if(kind==='reject')throw Error('Injected map failure');};
  await rejectsRun(f,probe,{signal:controller.signal},kind==='cancel'?/cancelled/:kind==='stale'?/source changed/:/Injected map failure/,{samples,submissions});
  const b=f.allocated.find(b=>b.role===role);assert.equal(b.mapCount,occurrence);assert.equal(b.unmapCount,occurrence-(kind==='reject'?1:0));
  if(kind==='reject'){delete f.hooks.map;assert.equal((await probe.run(request())).audit.disposed,1);}await retire(f,probe);
});
for(const role of ['shellReadback','partitionReadback','copy'])test('throwing '+role+' mapped-range access still unmaps and retires',async t=>{
  const {f,probe}=setup(t);f.hooks.read=at=>{if(at===role)throw Error('Injected range failure');};
  await rejectsRun(f,probe,{},/Injected range failure/,{samples:role==='shellReadback'?1:2,submissions:role==='shellReadback'?2:role==='partitionReadback'?5:6});
  const b=f.allocated.find(b=>b.role===role);assert.equal(b.mapCount,1);assert.equal(b.unmapCount,1);await retire(f,probe);
});
for(const endpoint of [0,1])for(const phase of ['afterMotion','afterShell','afterPartition','afterReadback','inner retirement','outer retirement'])test('independent endpoint '+endpoint+' invalidation at '+phase+' prevents result publication',async t=>{
  const {f,probe}=setup(t),options={};const stale=()=>{f.samples[endpoint].stale=true;};
  if(phase.endsWith('retirement'))f.hooks.fence=n=>{if(n===(phase==='inner retirement'?6:7))stale();};
  else options[phase]=phase==='afterMotion'||phase==='afterShell'?at(1,stale):stale;
  const n=phase==='afterMotion'?3:phase==='afterShell'?4:phase==='afterPartition'?5:6;
  await rejectsRun(f,probe,options,/became stale/,{submissions:n});await retire(f,probe);
});
for(const fence of [6,7])for(const kind of ['cancel','stale','device','reject'])test(kind+' during retirement fence '+fence+' cannot publish completed result',async t=>{
  const {f,probe}=setup(t),controller=new AbortController();f.hooks.fence=n=>{if(n!==fence)return;
    if(kind==='cancel')controller.abort();if(kind==='stale')f.stale();if(kind==='device')f.context.device={queue:{}};if(kind==='reject')throw Error('Injected retirement fence failure');};
  await rejectsRun(f,probe,{signal:controller.signal},kind==='cancel'?/cancelled/:kind==='stale'?/source changed/:kind==='device'?/shared GPU device changed/:/Injected retirement fence failure/,{submissions:6});await retire(f,probe);
});

for(const [phase,index]of stages.filter(([phase])=>phase!=='afterSample'))test('busy and disposal guards remain active at '+phase+(index??'')+'; scratch can be reused',async t=>{
  const {f,probe}=setup(t),reached=deferred(),resume=deferred();
  const active=probe.run({...request(),[phase]:at(index,async()=>{reached.resolve();await resume.promise;})});await reached.promise;
  try{const before=f.submissions.length;await assert.rejects(probe.run(request()),/already has active work/);await assert.rejects(probe.dispose(),/still has active work/);
    assert.equal(f.submissions.length,before);assert.equal(f.state.created,1);assert.equal(f.state.disposed,0);assert.ok(f.allocated.every(b=>b.destroyCount===0));
  }finally{resume.resolve();}
  assert.equal((await active).audit.disposed,1);assert.equal((await probe.run(request())).audit.disposed,1);
  assert.equal(f.state.created,2);assert.equal(f.state.disposed,2);assert.equal(f.allocated.length,roles.length);await retire(f,probe);
});
for(const role of ['partitionReadback','copy'])test('pending '+role+' map retains sampler and rejects concurrent retirement',async t=>{
  const {f,probe}=setup(t),reached=deferred(),resume=deferred();f.hooks.map=async at=>{if(at===role){reached.resolve();await resume.promise;}};
  const active=probe.run(request());await reached.promise;try{assert.equal(f.state.disposed,0);await assert.rejects(probe.dispose(),/still has active work/);}finally{resume.resolve();}
  await active;assert.ok(f.events.indexOf('unmap:'+role)<f.events.indexOf('dispose'));await retire(f,probe);
});
for(const [stage,submissions,samples]of [['motion',0,1],['shell',1,1],['partition',4,2]])test(stage+' compilation failure retires without publishing',async t=>{
  const {f,probe}=setup(t);f.hooks.compileError=stage;await rejectsRun(f,probe,{},/compilation failed/,{samples,submissions});await retire(f,probe);
});
for(const [stage,occurrence,submissions,samples]of [['motion',1,0,1],['shell',1,1,1],['motion',2,2,2],['shell',2,3,2],['partition',1,4,2]])for(const kind of ['cancel','stale'])test(kind+' while '+stage+' '+occurrence+' compilation awaits stops submission',async t=>{
  const {f,probe}=setup(t),controller=new AbortController();f.hooks.compile=(at,n)=>{if(at===stage&&n===occurrence){if(kind==='cancel')controller.abort();else f.stale();}};
  await rejectsRun(f,probe,{signal:controller.signal},kind==='cancel'?/cancelled/:/source changed/,{samples,submissions});await retire(f,probe);
});
for(const entry of ['transformMotion','validateShell','propagate','validateConnected','classifyPoints',...partitionEntries])test(entry+' pipeline failure fences and retires borrowed ownership',async t=>{
  const {f,probe}=setup(t);f.hooks.pipelineError=entry;await rejectsRun(f,probe,{},/Injected pipeline failure/,{samples:partitionEntries.includes(entry)?2:1,submissions:entry==='transformMotion'?0:partitionEntries.includes(entry)?4:1});await retire(f,probe);
});
for(let submit=1;submit<=6;submit++)test('queue submission '+submit+' failure retires once and never publishes',async t=>{
  const {f,probe}=setup(t);f.hooks.submit=n=>{if(n===submit)throw Error('Injected submit failure');};
  await rejectsRun(f,probe,{},/Injected submit failure/,{samples:submit<=2?1:2,submissions:submit-1});assert.equal(f.submitAttempts,submit);await retire(f,probe);
});
for(let fence=1;fence<=5;fence++)test('stage fence '+fence+' failure retires without publishing',async t=>{
  const {f,probe}=setup(t);f.hooks.fence=n=>{if(n===fence)throw Error('Injected queue failure');};
  await rejectsRun(f,probe,{},/Injected queue failure/,{samples:fence<=2?1:2,submissions:fence});await retire(f,probe);
});
for(const [name,configure,pattern,submissions,samples]of [
  ['validation scope',f=>{f.hooks.validationError=true;},/Injected GPU validation failure/,1,1],
  ['uncertain shell',f=>{f.hooks.shellStatus=[16,2,0,1,0,0,0,0];},/Unsupported\/uncertain shell/,2,1],
  ['partition error flag',f=>{f.hooks.partitionStatus=[1,...successCounters.slice(1)];},/partition|unresolved/i,5,2],
  ...[1,2,3,4,5].map(index=>['incomplete partition counter '+index,f=>{f.hooks.partitionStatus=[...successCounters];f.hooks.partitionStatus[index]--;},/partition|incomplete|unresolved/i,5,2])
])test(name+' rejects synthetic unsuccessful status rather than publishing',async t=>{
  const {f,probe}=setup(t);configure(f);await rejectsRun(f,probe,{},pattern,{samples,submissions});await retire(f,probe);
});

for(const fence of [6,7])test('pending native retirement fence '+fence+' keeps ownership and busy guard until settled',async t=>{
  const {f,probe}=setup(t),reached=deferred(),resume=deferred();
  f.hooks.fence=async n=>{if(n===fence){reached.resolve();await resume.promise;}};
  const active=probe.run(request());await reached.promise;
  try{assert.equal(f.state.disposed,0);assert.equal(f.submissions.length,6);await assert.rejects(probe.run(request()),/already has active work/);
    await assert.rejects(probe.dispose(),/still has active work/);assert.ok(f.allocated.every(b=>b.destroyCount===0&&!b.mapped));
  }finally{resume.resolve();}
  const result=await active;assert.equal(result.audit.disposed,1);await retire(f,probe);
});
test('source shape rejection leaves scratch reusable by a corrected later native sample',async t=>{
  const {f,probe}=setup(t);f.mesh.topologyRevision=0;
  await rejectsRun(f,probe,{},/indexed tetrahedron/,{samples:1,submissions:0});f.mesh.topologyRevision=1;
  const result=await probe.run(request());assert.equal(result.audit.created,1);assert.equal(result.audit.disposed,1);assert.equal(f.state.created,2);await retire(f,probe);
});
for(const [phase,action]of [['cancel',f=>controller=>controller.abort()],['device',f=>()=>{f.context.device={queue:{}};}]])test(phase+' inside native disposer cannot publish result',async t=>{
  const {f,probe}=setup(t),controller=new AbortController();f.hooks.dispose=()=>action(f)(controller);
  await rejectsRun(f,probe,{signal:controller.signal},/retirement mismatch/,{submissions:6});await retire(f,probe);
});

test('missing sampler, plan capacity and incompatible triangle alignment fail before allocation',()=>{
  const f=fixture(),options={...bounds,grid:grid()};const p=planCoMovingPartition(grid(),{limits:f.device.limits,...bounds});assert.equal(p.totalBytes,136512);
  delete f.context.scene.createSampler;assert.throws(()=>createNativePartitionProbe(f.context,'owner',options),/sampler unavailable/);assert.equal(f.allocated.length,0);
  const g=fixture();assert.throws(()=>createNativePartitionProbe(g.context,'owner',{...options,maxBytes:p.totalBytes-1}),/budget|memory/i);assert.equal(g.allocated.length,0);
  assert.throws(()=>createNativePartitionProbe(g.context,'owner',{...options,maxCells:511}),/budget|capacity/i);assert.equal(g.allocated.length,0);
  g.device.limits.minStorageBufferOffsetAlignment=1024;assert.throws(()=>createNativePartitionProbe(g.context,'owner',options),/alignment/);assert.equal(g.allocated.length,0);
});
for(const [name,mutate]of [
  ['sparse origin',g=>{delete g.origin[1];}],['sparse dimensions',g=>{delete g.dimensions[1];}],
  ['nonfinite origin',g=>{g.origin[0]=Infinity;}],['nonfinite pitch',g=>{g.pitch=NaN;}],['zero pitch',g=>{g.pitch=0;}],
  ['fractional count',g=>{g.dimensions[0]=7.5;}],['too many cells',g=>{g.dimensions=[9,8,8];}]
])test(name+' grid rejects before scratch allocation',()=>{
  const f=fixture(),supplied=grid();mutate(supplied);assert.throws(()=>createNativePartitionProbe(f.context,'owner',{...bounds,grid:supplied}),/grid|budget|capacity/i);assert.equal(f.allocated.length,0);assert.equal(f.state.created,0);
});
test('actual scratch budget counts both endpoint storage, populations and derived copies',async t=>{
  const f=fixture();assert.throws(()=>createNativePartitionProbe(f.context,'owner',{...bounds,grid:grid(),maxBytes:217247}),/Actual native partition scratch exceeds budget/);
  assert.equal(f.allocated.reduce((sum,b)=>sum+b.size,0),217248);assert.ok(f.allocated.every(b=>b.destroyCount===1));assert.equal(f.state.created,0);
  const exact=setup(t,{maxBytes:217248});assert.equal((await exact.probe.run(request())).allocatedBufferBytes,217248);await retire(exact.f,exact.probe);
});
test('default capacity is 512 cells; larger grid needs an explicit supported budget',async t=>{
  const {f,probe}=setup(t,{maxCells:undefined});assert.equal((await probe.run(request())).report.cellCount,512);await retire(f,probe);
  const g=fixture();assert.throws(()=>createNativePartitionProbe(g.context,'owner',{grid:{...grid(),dimensions:[9,8,8]}}),/budget|capacity/i);assert.equal(g.allocated.length,0);
});
for(let failAllocationAt=0;failAllocationAt<roles.length;failAllocationAt++)test('scratch allocation failure at '+roles[failAllocationAt]+' destroys prior buffers once',()=>{
  const f=fixture({failAllocationAt});assert.throws(()=>createNativePartitionProbe(f.context,'owner',{...bounds,grid:grid()}),/Injected scratch allocation failure/);
  assert.equal(f.allocated.length,failAllocationAt);assert.ok(f.allocated.every(b=>b.destroyCount===1));assert.equal(f.state.created,0);assert.equal(f.submissions.length,0);assert.equal(f.state.sourceDestroys,0);
});
test('failed scratch disposal fence still destroys every owned buffer exactly once',async()=>{
  const f=fixture(),probe=createNativePartitionProbe(f.context,'owner',{...bounds,grid:grid()});f.hooks.fence=()=>{throw Error('Injected scratch retirement failure');};
  await assert.rejects(probe.dispose(),/Injected scratch retirement failure/);await probe.dispose();assert.equal(f.fences,1);assert.ok(f.allocated.every(b=>b.destroyCount===1&&!b.mapped));assert.equal(f.state.sourceDestroys,0);
});
test('native partition host lifecycle suite completes within a 2 second budget without hardware proof',t=>{
  const milliseconds=performance.now()-started;assert.ok(milliseconds<2000,`Host lifecycle checks took ${milliseconds} ms`);
  t.diagnostic(`Host-only completed-operation wall time: ${milliseconds.toFixed(2)} ms; budget 2000 ms. Synthetic bytes/counters are not GPU, numerical or native scene proof.`);
});
