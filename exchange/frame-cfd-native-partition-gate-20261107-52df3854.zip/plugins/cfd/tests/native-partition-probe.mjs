import {withSceneMotionSample} from '../scene-geometry.mjs';
import {dispatchMotionSample} from '../motion-dispatch.mjs';
import {planPointOccupancy,classifyConvexPoints} from '../point-occupancy-gpu.mjs';
import {planCoMovingPartition,dispatchCoMovingPartition} from '../co-moving-partition-gpu.mjs';

/** Test-only native endpoint material-map ownership. Not a physical CFD step. */
export function createNativePartitionProbe(nativeContext,owner,{grid,maxBytes=2**20,maxCells=512,maxWork=1e6}={}) {
  if(typeof nativeContext?.scene?.createSampler!=='function')throw Error('Native partition sampler unavailable');
  const device=nativeContext.device,partitionPlan=planCoMovingPartition(grid,{limits:device?.limits,maxBytes,maxCells});
  const fixedGrid=JSON.parse(partitionPlan.gridKey),shellPlan=planPointOccupancy(4,4,1,{limits:device.limits,maxBytes,maxWork});
  if(!Number.isSafeInteger(device.limits.minStorageBufferOffsetAlignment)||512%device.limits.minStorageBufferOffsetAlignment)throw Error('Native endpoint triangle alignment unsupported');
  const owned=[],shell={},partition={},usage={triangles:132,faces:128,reachA:128,reachB:128,uniform:72,status:140,readback:9,points:136,results:132};
  const allocate=(size,flags)=>{const b=device.createBuffer({size,usage:flags});owned.push(b);return b;};
  const offsets={cells:0,weights:partitionPlan.sizes.cells,output:partitionPlan.sizes.cells+partitionPlan.sizes.weights};
  const copyBytes=partitionPlan.sizes.cells+partitionPlan.sizes.weights+partitionPlan.sizes.output;
  let copy,dead=false,busy=false;
  try {
    for(const [key,size]of Object.entries(shellPlan.sizes))if(key!=='indices')shell[key]=allocate(key==='uniform'?160:size,usage[key]);
    const flags={triangles:136,state:140,uniform:72,cells:132,weights:132,input:136,output:132,readback:9};
    for(const [key,size]of Object.entries(partitionPlan.sizes))partition[key]=allocate(size,flags[key]);
    copy=allocate(copyBytes,9);
    if(owned.reduce((s,b)=>s+b.size,0)>maxBytes)throw Error('Actual native partition scratch exceeds budget');
  }catch(error){for(const b of owned)b.destroy();throw error;}
  return {
    allocatedBufferBytes:owned.reduce((s,b)=>s+b.size,0),
    async run({timeStart=0,timeEnd=1,expectedId,populations,signal,afterCreate,afterSample,afterMotion,afterShell,afterPartition,afterReadback}={}) {
      if(dead||nativeContext.device!==device)throw Error('Native partition probe unavailable');
      if(busy)throw Error('Native partition probe already has active work');
      if(typeof expectedId!=='string'||!expectedId||!(populations instanceof Float32Array)||populations.length!==27*partitionPlan.cellCount)throw Error('Native partition occurrence and Float32 populations required');
      if(!Number.isFinite(timeStart)||timeStart<0||!Number.isFinite(timeEnd)||timeEnd<=timeStart)throw Error('Increasing physical endpoint times required');
      const input=populations.slice();busy=true;
      const started=performance.now(),audit={created:0,disposed:0,samples:[]};let session;
      const context={get device(){return nativeContext.device;},scene:{async createSampler(...args){
        const native=await nativeContext.scene.createSampler(...args);audit.created++;
        try{await afterCreate?.();}catch(error){native.dispose();audit.disposed++;throw error;}
        let disposed=false;const sampled=[];
        session={mode:native.mode,assertCurrent:()=>{native.assertCurrent();for(const sample of sampled)sample.assertCurrent();},
          sample(options){
            const sample=native.sample(options),capture=nativeContext.scene.capture(owner);
            sampled.push(sample);
            const index=audit.samples.length;
            audit.samples.push({timeSeconds:sample.timeSeconds,sourceSignature:sample.sourceSignature,ownerWorld:Array.from(sample.ownerWorld),ownerWorldDerivative:Array.from(sample.ownerWorldDerivative),meshes:sample.meshes.map(m=>({id:m.occurrenceId,vertices:m.vertexCount,triangles:m.triangleCount,topologyRevision:m.topologyRevision,worldMatrix:Array.from(m.worldMatrix),worldDerivative:Array.from(m.worldDerivative),shared:capture.meshes.some(c=>c.positions===m.positions&&c.indices===m.indices)}))});
            const hook=afterSample?.(index,sample);if(hook&&typeof hook.then==='function'){Promise.resolve(hook).catch(()=>{});throw Error('afterSample must be synchronous');}
            return sample;
          },dispose(){if(!disposed){disposed=true;native.dispose();audit.disposed++;}}};
        return session;
      }}};
      const prepare=async(input,index)=>{
        input.assertCurrent();const sample=input.sample;
        if(sample.meshes.length!==1)throw Error('Native partition requires exactly one whole tetrahedron');
        const mesh=sample.meshes[0];
        if(mesh.occurrenceId!==expectedId||mesh.triangleCount!==4||mesh.vertexCount!==4||!Number.isSafeInteger(mesh.topologyRevision)||mesh.topologyRevision<1||!audit.samples[index].meshes[0].shared||mesh.indices?.view||!(mesh.indices?.usage&128)||mesh.indices.size<48)throw Error('Native partition requires one shared indexed tetrahedron');
        device.queue.writeBuffer(shell.points,0,new Float32Array([0,0,0,0]));
        const transformed=await dispatchMotionSample(input,{uniform:shell.uniform,output:shell.triangles,maxOutputBytes:448,
          encodeBatch(encoder,descriptor){if(descriptor.first!==0||descriptor.count!==4)throw Error('Incomplete native endpoint triangle batch');encoder.copyBufferToBuffer(shell.triangles,0,partition.triangles,index*512,448);}});
        if(transformed.batches!==1||transformed.triangles!==4)throw Error('Incomplete native endpoint motion');
        await afterMotion?.(index);input.assertCurrent();
        const result=await classifyConvexPoints(device,{...shell,indices:mesh.indices,triangleCount:4,vertexCount:4,pointCount:1,timeSeconds:sample.timeSeconds,maxBytes,maxWork,assertCurrent:input.assertCurrent});
        await afterShell?.(index);input.assertCurrent();return result;
      };
      try {
        const result=await withSceneMotionSample(context,owner,{timeSeconds:timeStart,signal},async first=>{
          const firstShell=await prepare(first,0);
          // Reuse the existing strict sample adapter without creating another
          // native session or duplicating its contract checks. This borrowed
          // view cannot dispose the owning outer session. Samples are the exact
          // native objects; no geometry descriptor is manufactured here.
          const borrowed={get device(){return nativeContext.device;},scene:{async createSampler(){return {mode:session.mode,assertCurrent:session.assertCurrent,sample:options=>session.sample(options),dispose(){}};}}};
          return withSceneMotionSample(borrowed,owner,{timeSeconds:timeEnd,signal},async second=>{
            const a=first.sample,b=second.sample,ma=a.meshes[0],mb=b.meshes[0];
            if(a.sourceSignature!==b.sourceSignature||b.meshes.length!==1||ma.occurrenceId!==mb.occurrenceId||ma.positions!==mb.positions||ma.indices!==mb.indices||ma.topologyRevision!==mb.topologyRevision)throw Error('Native endpoint source/topology identity changed');
            const secondShell=await prepare(second,1),assertCurrent=()=>{first.assertCurrent();second.assertCurrent();};
            assertCurrent();device.queue.writeBuffer(partition.input,0,input);
            const report=await dispatchCoMovingPartition(device,{...partition,grid:fixedGrid,timeStart,timeEnd,maxBytes,maxCells,assertCurrent});
            await afterPartition?.();assertCurrent();
            const encoder=device.createCommandEncoder();
            for(const key of ['cells','weights','output'])encoder.copyBufferToBuffer(partition[key],0,copy,offsets[key],partitionPlan.sizes[key]);
            assertCurrent();device.queue.submit([encoder.finish()]);await copy.mapAsync(1,0,copyBytes);let bytes;
            try{assertCurrent();bytes=copy.getMappedRange(0,copyBytes).slice(0);}finally{copy.unmap();}
            await afterReadback?.();assertCurrent();
            return {cellBytes:bytes.slice(0,offsets.weights),weightBytes:bytes.slice(offsets.weights,offsets.output),populationBytes:bytes.slice(offsets.output),report,shellReports:[firstShell,secondShell],sourceSignature:a.sourceSignature,occurrence:ma.occurrenceId,timeStart,timeEnd};
          });
        });
        if(signal?.aborted||nativeContext.device!==device||audit.created!==1||audit.disposed!==1||audit.samples.length!==2)throw Error('Native paired sample retirement mismatch');
        const milliseconds=performance.now()-started;if(milliseconds>30000)throw Error('Native partition exceeded 30 second completed budget');
        return {...result,audit,milliseconds,budgetMs:30000,allocatedBufferBytes:owned.reduce((s,b)=>s+b.size,0),
          path:'endpoint-defined-linear-prescribed-material-interpolation',continuousNativeTrajectoryValidated:false,kineticStreamingPerformed:false,nativeSpaceTimeCouplingValidated:false,nativeFrameSceneValidated:false,solverReady:false};
      }catch(error){error.nativePartitionAudit=audit;throw error;}
      finally{busy=false;}
    },
    async dispose(){if(dead)return;if(busy)throw Error('Native partition probe still has active work');dead=true;try{await device.queue.onSubmittedWorkDone();}finally{for(const b of owned)b.destroy();}}
  };
}
