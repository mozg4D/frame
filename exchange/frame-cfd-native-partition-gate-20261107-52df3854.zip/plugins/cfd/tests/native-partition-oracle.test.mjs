import assert from 'node:assert/strict';
import test from 'node:test';
import {equilibrium} from '../lattice.mjs';
import {
  fixtureOBJ,nativePartitionVerticesMM,nativePartitionIndices,nativePartitionTimes,nativePartitionGrid,nativePartitionCellCount,
  nativePartitionPose,nativePartitionPopulationScale,nativePartitionPlan,nativePartitionSlot,
  createNativePartitionOracle,createNativePartitionPopulations,expectedNativePartitionPopulations,
  nativePartitionPopulationBound,nativePartitionPopulationErrorBudget,nativePartitionArithmeticContract,
  decodeNativePartitionReadback,assertNativePartitionReadback
} from './native-partition-oracle.mjs';

const forward=createNativePartitionOracle();
const reverse=createNativePartitionOracle({anchor:[1,1,1],displacement:[-.5,-.5,-.5]});
const still=createNativePartitionOracle({displacement:[0,0,0]});
const copy=readback=>Object.fromEntries(Object.entries(readback).map(([key,value])=>[key,value.slice(0)]));

// Synthetic ABI bytes exercise the checker only. This is not shader execution.
function mock(oracle,input,{roundedOperations=false,state=true}={}) {
  const reference=expectedNativePartitionPopulations(oracle,input),output=Float32Array.from(reference.expected);
  if(roundedOperations) {
    output.fill(0);
    for(const {from,to,numerator} of oracle.plan.overlaps)for(let q=0;q<27;q++)
      output[27*to+q]=Math.fround(output[27*to+q]+Math.fround(input[27*from+q]*numerator));
    for(let j=0;j<output.length;j++)output[j]=oracle.after[Math.floor(j/27)]?Math.fround(output[j]/oracle.after[Math.floor(j/27)]):0;
  }
  const result={cells:oracle.expectedCells.slice().buffer,weights:oracle.weights.slice().buffer,populations:output.buffer,inputPopulations:input.slice().buffer};
  if(state) {
    const words=new Int32Array(32),p=oracle.plan,n=oracle.cellCount;
    words.set([0,1,n,n,n,n,oracle.overlapCount,oracle.transferCount]);
    words.set([...p.anchor.map(v=>2*v),2*p.leg],8);words.set([...p.anchorAfter.map(v=>2*v),2*p.leg],12);
    words.set(p.displacement.map(v=>2*v),16);result.state=words.buffer;
  }
  return result;
}

// Test-only WGSL-permitted arithmetic variants. They exercise the bound, not
// native hardware. All tested product/add operands are exactly representable
// in binary64 before choosing either adjacent f32 result.
const floatBits=new DataView(new ArrayBuffer(4));
function adjacentF32(value,direction) {
  floatBits.setFloat32(0,value,true);floatBits.setUint32(0,floatBits.getUint32(0,true)+direction,true);
  return floatBits.getFloat32(0,true);
}
function directedF32(value,up) {
  const nearest=Math.fround(value);
  return up&&nearest<value?adjacentF32(nearest,1):!up&&nearest>value?adjacentF32(nearest,-1):nearest;
}
function wgslULP(value) {
  if(value===0)return 2**-149;
  let e=Math.floor(Math.log2(value));
  while(value<2**e)e--;while(value>=2**(e+1))e++;
  return Math.max(2**-149,2**(e-23-(value===2**e?1:0)));
}
function permittedDivision(numerator,denominator,up) {
  if(numerator===0)return 0; // The explicit shader zero-state branch.
  const exact=numerator/denominator,allowance=2.5*wgslULP(exact);
  const candidate=directedF32(exact+(up?allowance:-allowance),!up);
  assert.ok(Math.abs(candidate-exact)<=allowance,'synthetic division must remain inside 2.5 ULP');
  return candidate;
}
function permittedWGSLMock(oracle,input,association,up) {
  const bytes=mock(oracle,input),output=new Float32Array(bytes.populations),donors=Array.from({length:oracle.cellCount},()=>[]);
  for(const w of oracle.plan.overlaps)donors[w.to].push(w);
  const add=(a,b)=>directedF32(a+b,up),multiply=(a,b)=>directedF32(a*b,up);
  const balanced=values=>values.length<=1?(values[0]??0):add(balanced(values.slice(0,Math.floor(values.length/2))),balanced(values.slice(Math.floor(values.length/2))));
  for(let i=0;i<oracle.cellCount;i++)for(let q=0;q<27;q++) {
    const denominator=oracle.after[i];if(!denominator){output[27*i+q]=0;continue;}
    const values=donors[i].map(w=>association==='divide-before-multiply'?
      multiply(w.numerator,permittedDivision(input[27*w.from+q],denominator,up)):
      multiply(w.numerator,input[27*w.from+q]));
    if(association==='reverse')values.reverse();
    const sum=association==='balanced'?balanced(values):values.reduce(add,0);
    output[27*i+q]=association==='divide-before-multiply'?sum:permittedDivision(sum,denominator,up);
  }
  return bytes;
}

test('218.75-mm tetra fixture retains four shared vertices, outward faces and reverse-paired edges',()=>{
  const lines=fixtureOBJ.split('\n'),vertices=lines.filter(v=>v.startsWith('v ')).map(v=>v.split(' ').slice(1).map(Number));
  const faces=lines.filter(v=>v.startsWith('f ')).map(v=>v.split(' ').slice(1).map(n=>Number(n)-1));
  assert.deepEqual(vertices,nativePartitionVerticesMM);assert.deepEqual(faces.flat(),nativePartitionIndices);
  const edges=new Set();
  for(const face of faces) {
    const [a,b,c]=face.map(i=>vertices[i]),u=b.map((v,k)=>v-a[k]),v=c.map((n,k)=>n-a[k]);
    const normal=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]],opposite=vertices.find((_,i)=>!face.includes(i));
    assert.ok(normal.reduce((s,n,k)=>s+n*(opposite[k]-a[k]),0)<0);
    for(let i=0;i<3;i++)edges.add(face[i]+','+face[(i+1)%3]);
  }
  assert.equal(edges.size,12);for(const edge of edges)assert.ok(edges.has(edge.split(',').reverse().join(',')));
  assert.ok(Object.isFrozen(nativePartitionVerticesMM));assert.ok(nativePartitionVerticesMM.every(Object.isFrozen));
});

test('native endpoint mm-to-SI f32 conversion roundtrips exact half-cell coordinates but midpoint does not',()=>{
  assert.deepEqual(nativePartitionTimes,[0,1]);assert.equal(nativePartitionCellCount,512);
  assert.deepEqual(nativePartitionGrid,{origin:[0,0,0],pitch:.0625,dimensions:[8,8,8],units:'m',frame:'fixed-world',sampleLocation:'cell-volume'});
  assert.ok(Object.isFrozen(nativePartitionGrid));assert.ok(Object.isFrozen(nativePartitionGrid.dimensions));
  const f=Math.fround,convert=(local,translation)=>f(f(f(local)+f(translation))*f(.001));
  for(const [time,lower,upper] of [[0,.03125,.25],[1,.0625,.28125]]) {
    const pose=nativePartitionPose(time);assert.equal(pose.frame,60*time);
    assert.equal(convert(0,pose.translationMM[0]),lower);assert.equal(convert(218.75,pose.translationMM[0]),upper);
    for(const p of [lower,upper]){const half=f(f(p/.0625)*2);assert.ok(Number.isInteger(half));assert.equal(f(f(half*.5)*.0625),p);}
  }
  assert.notEqual(convert(0,46.875),.046875,'do not claim continuous native trajectory follows exact endpoint map');
  for(const time of [.5,-1,2,NaN,'0'])assert.throws(()=>nativePartitionPose(time),/endpoint time/);
  assert.deepEqual(nativePartitionPopulationScale.materialVelocityMPerSecond,[.03125,.03125,.03125]);
  assert.equal(nativePartitionPopulationScale.velocityUnitMPerSecond,1);
  assert.notEqual(nativePartitionPopulationScale.materialIntervalSeconds,nativePartitionGrid.pitch/nativePartitionPopulationScale.velocityUnitMPerSecond);
});

test('independent clipped endpoint geometry proves exact integer row and column continuity',()=>{
  assert.deepEqual(forward.counts.before,{fluid:480,solid:0,cut:32,total:512,sumNumerator:24233});
  assert.deepEqual(forward.counts.after,{fluid:492,solid:1,cut:19,total:512,sumNumerator:24233});
  assert.equal(48*512-24233,343);assert.equal((3.5**3/6)*48,343);
  assert.equal(forward.overlapCount,4061);assert.equal(forward.transferCount,3550);
  assert.equal(forward.transitions.dryToWet,0);assert.equal(forward.transitions.wetToDry,1);
  assert.deepEqual(forward.transitions.wetToDryIndices,[73]);assert.equal(forward.transitions.changedPartial,47);
  assert.equal(forward.transitions.stableWet,464);assert.equal(forward.transitions.stableDry,0);
  assert.deepEqual(forward.before,forward.rows);assert.deepEqual(forward.after,forward.columns);
  assert.deepEqual([...new Set(forward.weightNumerators)].sort((a,b)=>a-b),[0,1,5,6]);
  assert.equal(forward.audit.exactGeometricClosure,true);assert.ok(forward.audit.maxPartitionResidual<=forward.audit.maxClosureBound);
  assert.ok(forward.plan.overlaps.some(w=>w.volume!==w.numerator/48),'retain independently rounded polyhedral clipping evidence');
  for(const key of ['solverReady','forceValidated','nativeSpaceTimeCouplingValidated','hardwareValidated','streamingCollisionPerformed'])assert.equal(forward[key],false);
});

test('packed source slots retain donor identity, diagonal transfer and periodic wrapping on all axes',()=>{
  const rows=new Uint32Array(512),columns=new Uint32Array(512);let positive=0,self=0;
  const wrapped=[false,false,false];
  for(let from=0;from<512;from++)for(let slot=0;slot<8;slot++) {
    const at=8*from+slot,word=forward.weights[at],target=nativePartitionSlot(from,slot,forward.plan);
    if(!word)continue;positive++;const to=word>>>6,numerator=word&63;
    assert.equal(to,target.destination);assert.equal(numerator,forward.weightNumerators[at]);
    rows[from]+=numerator;columns[to]+=numerator;if(from===to)self++;
    for(let axis=0;axis<3;axis++)if(target.image[axis]===8)wrapped[axis]=true;
  }
  assert.equal(positive,4061);assert.equal(self,511);assert.deepEqual(rows,forward.before);assert.deepEqual(columns,forward.after);
  assert.deepEqual(wrapped,[true,true,true]);
  for(const [source,slot] of [[-1,0],[512,0],[0,8],[0,-1],[.1,0]])assert.throws(()=>nativePartitionSlot(source,slot,forward.plan),/domain/);
});

test('reversing endpoint map transposes all material donors and exposes exactly one dry-to-wet cell',()=>{
  assert.deepEqual(reverse.before,forward.after);assert.deepEqual(reverse.after,forward.before);
  assert.equal(reverse.transitions.dryToWet,1);assert.equal(reverse.transitions.wetToDry,0);
  assert.deepEqual(reverse.transitions.dryToWetIndices,[73]);assert.equal(reverse.overlapCount,4061);
  const transposed=new Map(reverse.plan.overlaps.map(w=>[w.to*512+w.from,w.numerator]));
  for(const w of forward.plan.overlaps)assert.equal(transposed.get(w.from*512+w.to),w.numerator);
  assert.equal(reverse.solverReady,false,'geometric reversal is not invertible kinetic evolution');
});

test('zero and integer displacements zero unused slots rather than creating duplicate donors',()=>{
  for(const oracle of [still,createNativePartitionOracle({displacement:[1,0,0]}),createNativePartitionOracle({displacement:[.5,0,.5]})]) {
    for(let from=0;from<oracle.cellCount;from++)for(let slot=0;slot<8;slot++) {
      const target=nativePartitionSlot(from,slot,oracle.plan);
      if(target===null){assert.equal(oracle.weights[8*from+slot],0);assert.equal(oracle.destinations[8*from+slot],0xffffffff);}
    }
    const input=createNativePartitionPopulations(oracle,'mixed'),r=assertNativePartitionReadback(mock(oracle,input),{oracle,inputPopulations:input});
    assert.equal(r.exactRowColumnClosure,true);
  }
  assert.equal(still.overlapCount,512);assert.equal(still.transferCount,0);assert.deepEqual(still.before,still.after);
  for(let i=0;i<512;i++){assert.equal(still.weights[i*8],(i<<6)|still.before[i]);assert.ok(still.weights.slice(i*8+1,i*8+8).every(v=>v===0));}
});

test('uniform fixture uses actual f32 equilibrium at signed physical velocity with no streaming/collision claim',()=>{
  for(const [oracle,speed] of [[forward,.03125],[reverse,-.03125],[still,0]]) {
    const p=createNativePartitionPopulations(oracle,'uniform'),eq=Float32Array.from(equilibrium(1,[speed,speed,speed]));
    let differsFromIdeal=false;const ideal=equilibrium(1,[speed,speed,speed]);
    for(let q=0;q<27;q++)differsFromIdeal||=eq[q]!==ideal[q];assert.ok(differsFromIdeal);
    for(let i=0;i<512;i++)for(let q=0;q<27;q++)assert.equal(p[27*i+q],oracle.before[i]?eq[q]:0);
    const r=assertNativePartitionReadback(mock(oracle,p,{roundedOperations:true}),{oracle,inputPopulations:p});
    assert.equal(r.conservation.components.length,27);assert.equal(r.conservation.rawMomentum.length,3);
    for(const measure of [...r.conservation.components,r.conservation.mass,...r.conservation.rawMomentum])assert.ok(measure.error<=measure.bound);
    assert.equal(r.streamingCollisionPerformed,false);assert.equal(r.hardwareValidated,false);
    const mass=eq.reduce((s,v)=>s+v,0)*24233/48;
    assert.ok(Math.abs(r.conservation.mass.before-mass)<=128*Number.EPSILON*mass,'mass derives from quantized inputs, not ideal density one');
  }
});

test('mixed dyadic populations preserve all 27 components, mass and raw momentum within accumulated cell bounds',()=>{
  for(const oracle of [forward,reverse,still]) {
    const input=createNativePartitionPopulations(oracle,'mixed'),snapshot=input.slice(),readback=mock(oracle,input,{roundedOperations:true});
    const r=assertNativePartitionReadback(readback,{oracle,inputPopulations:input,inputSnapshot:snapshot});
    assert.deepEqual(input,snapshot);assert.equal(r.populationCount,13824);assert.equal(r.dryPopulationCount,oracle.counts.after.solid*27);
    for(const measure of [...r.conservation.components,r.conservation.mass,...r.conservation.rawMomentum])assert.ok(measure.error<=measure.bound);
    const decoded=decodeNativePartitionReadback(readback,oracle);
    for(let i=0;i<512;i++)if(oracle.after[i]===0)assert.ok(decoded.populations.slice(27*i,27*i+27).every(v=>v===0));
    if(oracle===reverse)assert.ok(decoded.populations.slice(73*27,74*27).every(v=>v>0));
  }
});

test('length-exact little-endian decoder rejects short, long and incorrectly typed ABI buffers',()=>{
  const input=createNativePartitionPopulations(forward),bytes=mock(forward,input),decoded=decodeNativePartitionReadback(bytes,forward);
  assert.deepEqual(forward.byteLayout,{cells:8192,weights:16384,populations:55296,state:128});
  assert.deepEqual(decoded.before,forward.before);assert.deepEqual(decoded.after,forward.after);assert.deepEqual(decoded.weights,forward.weights);
  for(const [key,value] of Object.entries(bytes)) {
    for(const invalid of [value.slice(0,-4),new ArrayBuffer(value.byteLength+4),new Uint32Array(value)])
      assert.throws(()=>decodeNativePartitionReadback({...bytes,[key]:invalid},forward),/requires exactly/);
  }
});

test('each endpoint, row and column integer must exactly match independent geometry',()=>{
  const input=createNativePartitionPopulations(forward),bytes=mock(forward,input);
  for(const k of [0,1,2,3]) {
    const broken=copy(bytes),v=new DataView(broken.cells);v.setUint32(4*k,v.getUint32(4*k,true)+1,true);
    assert.throws(()=>assertNativePartitionReadback(broken,{oracle:forward,inputPopulations:input}),/independent exact geometry/);
  }
  // A forged matching endpoint/row pair still cannot manufacture continuity.
  const broken=copy(bytes),v=new DataView(broken.cells);v.setUint32(0,47,true);v.setUint32(8,47,true);
  assert.throws(()=>assertNativePartitionReadback(broken,{oracle:forward,inputPopulations:input}),/independent exact geometry/);
});

test('wrong weight, wrong destination, wrong source, absent and duplicate donors are rejected independently',()=>{
  const input=createNativePartitionPopulations(forward,'mixed'),bytes=mock(forward,input);
  for(const edit of [w=>w[0]++,w=>w[0]^=64,w=>w[0]=0,w=>{const i=w.findIndex(v=>v!==0&&v!==w[0]);[w[0],w[i]]=[w[i],w[0]];},
    w=>{const empty=w.findIndex(v=>v===0);w[empty]=w[0];},w=>w[0]=0xffffffff]) {
    const broken=copy(bytes);edit(new Uint32Array(broken.weights));
    assert.throws(()=>assertNativePartitionReadback(broken,{oracle:forward,inputPopulations:input}),/weight\/source slot/);
  }
  const p=createNativePartitionPopulations(still,'mixed'),unused=mock(still,p);new Uint32Array(unused.weights)[1]=still.weights[0];
  assert.throws(()=>assertNativePartitionReadback(unused,{oracle:still,inputPopulations:p}),/weight\/source slot/);
});

test('state flags, counters, half-cell endpoint coordinates, displacement and reserved words are exact',()=>{
  const input=createNativePartitionPopulations(reverse,'mixed'),bytes=mock(reverse,input);
  for(const at of [0,1,2,3,4,5,6,7,8,11,12,15,16,18,19,20,31]) {
    const broken=copy(bytes);new Uint32Array(broken.state)[at]++;
    assert.throws(()=>assertNativePartitionReadback(broken,{oracle:reverse,inputPopulations:input}),/state word/);
  }
});

test('wrong-source population gathering fails even when exact geometry buffers are unchanged',()=>{
  const input=createNativePartitionPopulations(forward,'mixed'),shifted=input.slice();
  for(let i=0;i<512;i++)for(let q=0;q<27;q++)shifted[27*i+q]=input[27*((i+1)%512)+q];
  const bytes=mock(forward,shifted,{roundedOperations:true});bytes.inputPopulations=input.slice().buffer;
  assert.deepEqual(new Uint32Array(bytes.cells),forward.expectedCells);assert.deepEqual(new Uint32Array(bytes.weights),forward.weights);
  assert.throws(()=>assertNativePartitionReadback(bytes,{oracle:forward,inputPopulations:input}),/derived Float32/);
});

test('NaN, infinities, negative outputs and positive dry-cell output never fit a numerical allowance',()=>{
  const input=createNativePartitionPopulations(forward),bytes=mock(forward,input);
  for(const value of [NaN,Infinity,-Infinity,-Number.MIN_VALUE,-1]) {
    const broken=copy(bytes);new Float32Array(broken.populations)[0]=value===-Number.MIN_VALUE?-(2**-149):value;
    assert.throws(()=>assertNativePartitionReadback(broken,{oracle:forward,inputPopulations:input}),/finite and nonnegative/);
  }
  const broken=copy(bytes);new Float32Array(broken.populations)[73*27]=2**-149;
  assert.throws(()=>assertNativePartitionReadback(broken,{oracle:forward,inputPopulations:input}),/dry population/);
});

test('derived WGSL bound rejects over-tolerance output but accepts genuine nonzero rounding error',()=>{
  const input=createNativePartitionPopulations(forward,'uniform'),bytes=mock(forward,input,{roundedOperations:true});
  const result=assertNativePartitionReadback(bytes,{oracle:forward,inputPopulations:input});
  assert.ok(result.maxPopulationError>0,'a zero allowance would incorrectly reject a valid rounded positive gather');
  assert.ok(result.maxBoundRatio<1);
  const e=expectedNativePartitionPopulations(forward,input),j=e.positiveTerms.findIndex(n=>n===8);
  const epsilon=2**-23,g=15*epsilon/(1-15*epsilon),d=2.5*epsilon;
  assert.ok(j>=0);assert.equal(e.maxRelativeBound,g+d*(1+g));
  const below=copy(bytes),above=copy(bytes);
  new Float32Array(below.populations)[j]=Math.fround(e.expected[j]+e.bounds[j]/2);
  const belowError=Math.abs(new Float32Array(below.populations)[j]-e.expected[j]);
  assert.ok(belowError>0&&belowError<e.bounds[j]);assertNativePartitionReadback(below,{oracle:forward,inputPopulations:input});
  new Float32Array(above.populations)[j]=Math.fround(e.expected[j]+2*e.bounds[j]);
  assert.ok(Math.abs(new Float32Array(above.populations)[j]-e.expected[j])>e.bounds[j]);
  assert.throws(()=>assertNativePartitionReadback(above,{oracle:forward,inputPopulations:input}),/derived Float32/);
  assert.equal(nativePartitionPopulationBound(0,0),0);assert.ok(nativePartitionPopulationBound(1,1)<nativePartitionPopulationBound(1,8));
  for(const args of [[-1,8],[Infinity,8],[1,9],[1,-1],[1,.5],[1,0]])assert.throws(()=>nativePartitionPopulationBound(...args),RangeError);
});

test('WGSL error budget separates either-adjacent add/multiply, 2.5-ULP division and binary64 reference error',()=>{
  assert.equal(nativePartitionArithmeticContract.additionMultiplicationRelativeError,2**-23);
  assert.equal(nativePartitionArithmeticContract.divisionULP,2.5);
  assert.equal(nativePartitionArithmeticContract.normalDivisionRelativeError,2.5*2**-23);
  assert.equal(nativePartitionArithmeticContract.rounding,'either-adjacent-f32');
  assert.ok(nativePartitionArithmeticContract.specification.includes('20261106'));
  for(const m of [1,2,8])for(const expected of [1.25*2**-100,1.25*2**-20,1.25]) {
    const budget=nativePartitionPopulationErrorBudget(expected,m),epsilon=2**-23;
    const g=(2*m-1)*epsilon/(1-(2*m-1)*epsilon),r=2*m*2**-53/(1-2*m*2**-53),upper=expected/(1-r);
    assert.equal(budget.productSumRelativeBound,g);assert.equal(budget.referenceRelativeBound,r);
    assert.equal(budget.productSumBound,upper*g);assert.equal(budget.divisionBound,upper*(2.5*epsilon)*(1+g));
    assert.equal(budget.referenceBound,upper*r);
    assert.equal(budget.bound,(budget.productSumBound+budget.divisionBound+budget.referenceBound)*(1+16*Number.EPSILON));
    assert.equal(nativePartitionPopulationBound(2*expected,m),2*budget.bound,'budget scales with the state, never a fixed absolute fudge');
  }
  // At a binade boundary, the specification uses the smaller adjacent spacing.
  assert.equal(wgslULP(1),2**-24);assert.equal(wgslULP(1+2**-24),2**-23);
  const exact=1+2**-24,allowed=1+3*2**-23;
  assert.equal(allowed-exact,2.5*wgslULP(exact));assert.ok(allowed-exact<nativePartitionPopulationBound(exact,1));
});

test('a permitted two-ULP division result passes where the superseded nearest-rounding bound rejects',()=>{
  const input=createNativePartitionPopulations(still,'mixed'),bytes=mock(still,input),e=expectedNativePartitionPopulations(still,input);
  const j=input.findIndex((v,i)=>e.positiveTerms[i]===1&&v>0&&Math.log2(v)%1!==0),exact=e.expected[j];
  assert.ok(j>=0);const allowed=adjacentF32(adjacentF32(exact,1),1),error=allowed-exact;
  assert.equal(error,2*wgslULP(exact));assert.ok(error<=2.5*wgslULP(exact));
  const oldU=2**-24,oldGamma=2*oldU/(1-2*oldU);assert.ok(error>exact*oldGamma);
  new Float32Array(bytes.populations)[j]=allowed;
  assertNativePartitionReadback(bytes,{oracle:still,inputPopulations:input});
  const excessive=copy(bytes),outside=directedF32(exact+e.bounds[j],true);
  new Float32Array(excessive.populations)[j]=outside===exact+e.bounds[j]?adjacentF32(outside,1):outside;
  assert.ok(new Float32Array(excessive.populations)[j]-exact>e.bounds[j]);
  assert.throws(()=>assertNativePartitionReadback(excessive,{oracle:still,inputPopulations:input}),/derived Float32/);
});

test('directed rounding, alternate sum associations and division placement fit the independently derived bound',()=>{
  const input=createNativePartitionPopulations(forward,'uniform');
  // Every component is positive: distributing division across these terms is
  // also exercised, beyond merely reversing the positive reduction tree.
  let maxRatio=0;
  for(const association of ['left','reverse','balanced','divide-before-multiply'])for(const up of [false,true]) {
    const result=assertNativePartitionReadback(permittedWGSLMock(forward,input,association,up),{oracle:forward,inputPopulations:input});
    assert.ok(result.maxPopulationError>0);assert.ok(result.maxBoundRatio<=1);maxRatio=Math.max(maxRatio,result.maxBoundRatio);
    for(const m of [result.conservation.mass,...result.conservation.rawMomentum])assert.ok(m.error<=m.bound);
  }
  assert.ok(maxRatio>0,'test must actually spend part of the permitted arithmetic error budget');
});

test('the explicit zero-sum branch preserves zero wet populations without a division allowance',()=>{
  const input=new Float32Array(27*forward.cellCount),bytes=mock(forward,input);
  const e=expectedNativePartitionPopulations(forward,input);assert.ok(e.bounds.every(v=>v===0));
  const result=assertNativePartitionReadback(bytes,{oracle:forward,inputPopulations:input});
  assert.equal(result.conservation.mass.before,0);assert.equal(result.conservation.mass.after,0);assert.equal(result.conservation.mass.bound,0);
  new Float32Array(bytes.populations)[0]=2**-149;
  assert.throws(()=>assertNativePartitionReadback(bytes,{oracle:forward,inputPopulations:input}),/derived Float32/);
});

test('population proof covers bounded-normal extremes, zero components and heterogeneous exponents',()=>{
  const input=createNativePartitionPopulations(forward,'mixed');
  for(let j=0;j<input.length;j++)input[j]=j%27===0?0:j%5===0?2**-100:j%7===0?16:2**(-90+j%90);
  const result=assertNativePartitionReadback(mock(forward,input,{roundedOperations:true}),{oracle:forward,inputPopulations:input});
  assert.ok(result.maxBoundRatio<=1);assert.equal(result.conservation.components[0].before,0);assert.equal(result.conservation.components[0].after,0);
  for(const m of [result.conservation.mass,...result.conservation.rawMomentum])assert.ok(m.error<=m.bound);
});

test('population input domain and source snapshots reject unsupported values, dry input and mutation',()=>{
  const input=createNativePartitionPopulations(reverse,'mixed');
  assert.throws(()=>expectedNativePartitionPopulations(reverse,Float64Array.from(input)),/27 Float32/);
  assert.throws(()=>expectedNativePartitionPopulations(reverse,input.slice(1)),/27 Float32/);
  for(const value of [-1,NaN,Infinity,32,2**-101,2**-149]) {
    const broken=input.slice();broken[0]=value;assert.throws(()=>expectedNativePartitionPopulations(reverse,broken),/bounded normal/);
  }
  const dry=input.slice();dry[73*27]=.1;assert.throws(()=>expectedNativePartitionPopulations(reverse,dry),/dry input/);
  const bytes=mock(reverse,input),snapshot=input.slice();snapshot[0]*=2;
  assert.throws(()=>assertNativePartitionReadback(bytes,{oracle:reverse,inputPopulations:input,inputSnapshot:snapshot}),/input mutation/);
  new Float32Array(bytes.inputPopulations)[0]*=2;
  assert.throws(()=>assertNativePartitionReadback(bytes,{oracle:reverse,inputPopulations:input}),/GPU input mutation/);
  assert.throws(()=>createNativePartitionPopulations(reverse,'random'),/uniform or mixed/);
});

test('unsupported geometry and mutated clipped donor plans are not repaired or renormalized',()=>{
  for(const options of [{anchor:[.1,.5,.5]},{displacement:[.25,0,0]},{anchor:[0,.5,.5]},{leg:1.5},
    {leg:NaN},{dimensions:[8,8,17]},{displacement:[1.5,0,0]},{anchor:[7,.5,.5]}])
    assert.throws(()=>nativePartitionPlan(options),RangeError);
  for(const key of ['anchor','displacement','dimensions']){const value=[.5,.5,.5];delete value[1];assert.throws(()=>nativePartitionPlan({[key]:value}),RangeError);}
  const broken=structuredClone(forward);broken.plan.overlaps[0].from=1;
  assert.throws(()=>expectedNativePartitionPopulations(broken,createNativePartitionPopulations(forward)),/Overlap does not match/);
});

test('reports retain unavailable capabilities and agree with exact readback counts',()=>{
  const input=createNativePartitionPopulations(forward),bytes=mock(forward,input),options={oracle:forward,inputPopulations:input};
  const report={solverReady:false,hardwareValidated:false,cellCount:512,overlapCount:4061,transferCount:3550,denominator:48};
  assertNativePartitionReadback(bytes,{...options,report});
  for(const edit of [{solverReady:true},{hardwareValidated:true},{forceValidated:true},{nativeSpaceTimeCouplingValidated:true},
    {streamingCollisionPerformed:true},{arbitraryMeshVolumeValidated:true},{cellCount:1},{overlapCount:1},{transferCount:1},{denominator:47},{exactVolumeDenominator:47}])
    assert.throws(()=>assertNativePartitionReadback(bytes,{...options,report:{...report,...edit}}),/report/);
});

test('complete 512-cell clipping, expectation, readback and 27-component audit has a measured CPU latency budget',t=>{
  const start=performance.now(),oracle=createNativePartitionOracle(),planned=performance.now(),input=createNativePartitionPopulations(oracle,'mixed');
  const inputBefore=input.slice(),oracleBefore=structuredClone(oracle),bytes=mock(oracle,input,{roundedOperations:true}),bytesBefore=copy(bytes);
  assertNativePartitionReadback(bytes,{oracle,inputPopulations:input,inputSnapshot:inputBefore});const done=performance.now();
  assert.deepEqual(input,inputBefore);assert.deepEqual(oracle,oracleBefore);assert.deepEqual(bytes,bytesBefore);
  const budgetMs=2500;assert.ok(done-start<budgetMs,`complete independent oracle ${done-start} ms >= ${budgetMs} ms`);
  t.diagnostic(JSON.stringify({operation:'native-partition-independent-oracle',cells:512,populations:13824,planMs:planned-start,fullMs:done-start,budgetMs,hardwareValidated:false}));
});
