import {chromium} from 'playwright';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {readFile, readdir, mkdir, writeFile, stat} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve, relative, sep, extname} from 'node:path';
import {adapterQualification, watchGPUOperation} from './gpu-harness.mjs';

const CORE_SHA256='adef621e4db7cbaa16057ab69fdd3a930fd19ff4fda53d75342ad310f4a67a54';
const cfdRoot=resolve(fileURLToPath(new URL('../',import.meta.url))),defaultRoot=resolve(cfdRoot,'../..');
const coreRoot=resolve(process.env.FRAME_CFD_CORE_ROOT||defaultRoot),args=process.argv.slice(2);
if(args.some(a=>a!=='--headless')||new Set(args).size!==args.length)throw Error('Usage: node plugins/cfd/tests/native-partition-browser.mjs [--headless]');
const sha=b=>createHash('sha256').update(b).digest('hex'),output=resolve(cfdRoot,'validation-results/native-partition-latest.json');
const manifest={id:'cfd-native-test',name:'CFD native acceptance',module:'plugin.js',icon:'../mill/icon.svg',objects:[{type:'cfd_native_test',name:'CFD native acceptance',fields:{}}]};
const moduleSource='export function activate(context){window.__cfdNativeContext=context;}';
const report={kind:'native-scene-partition-fixture',started:new Date().toISOString(),pass:false,stage:'preflight',expectedCoreSHA256:CORE_SHA256,browserChannel:process.env.FRAME_BROWSER_CHANNEL||'chromium',nativeFrameSceneValidated:false,nativeExactEndpointMaterialPartitionValidated:false,solverReady:false,nativeSpaceTimeCouplingValidated:false,hardwareGPUValidated:false};
await mkdir(resolve(cfdRoot,'validation-results'),{recursive:true});
const save=()=>writeFile(output,JSON.stringify(report,null,2));
async function hashes(){
  const result={'index.html':sha(await readFile(resolve(coreRoot,'index.html'))),'plugins/index.json':sha(await readFile(resolve(coreRoot,'plugins/index.json'))),'test-plugin-module':sha(moduleSource),'test-plugin-manifest':sha(JSON.stringify(manifest))};
  async function walk(dir){for(const entry of await readdir(dir,{withFileTypes:true})){
    const path=resolve(dir,entry.name);
    if(entry.isDirectory()&&entry.name!=='validation-results')await walk(path);
    else if(entry.isFile()&&entry.name.endsWith('.mjs'))result['plugins/cfd/'+relative(cfdRoot,path).split(sep).join('/')]=sha(await readFile(path));
  }}
  await walk(cfdRoot);return Object.fromEntries(Object.entries(result).sort(([a],[b])=>a.localeCompare(b)));
}
// This server reads the pinned core and current test modules. No worktree is
// copied or changed, and no registered catalogue or live page is modified.
async function serveFixture(){
  const server=createServer(async(req,res)=>{try{
    const url=new URL(req.url,'http://127.0.0.1');
    if(req.method!=='GET'){res.writeHead(405).end();return;}
    if(url.pathname==='/favicon.ico'){res.writeHead(204).end();return;}
    if(url.pathname==='/__frame/gpu-memory'){res.writeHead(200,{'Content-Type':'application/json'}).end('{"gpus":null}');return;}
    const pathname=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname),isCFD=pathname.startsWith('/plugins/cfd/');
    const root=isCFD?cfdRoot:coreRoot,path=resolve(root,isCFD?pathname.slice('/plugins/cfd/'.length):'.'+pathname);
    if(!path.startsWith(root+sep)||!(await stat(path)).isFile()){res.writeHead(404).end();return;}
    const type={'.html':'text/html; charset=utf-8','.mjs':'text/javascript','.js':'text/javascript','.json':'application/json','.wasm':'application/wasm','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.md':'text/plain; charset=utf-8'}[extname(path)]||'application/octet-stream';
    res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store'}).end(await readFile(path));
  }catch{res.writeHead(404).end();}});
  await new Promise((ok,no)=>{server.once('error',no);server.listen(0,'127.0.0.1',ok);});
  return {url:`http://127.0.0.1:${server.address().port}`,close:()=>new Promise((ok,no)=>server.close(e=>e?no(e):ok()))};
}
let server,browser;
try{
  report.sources=await hashes();await save();
  if(report.sources['index.html']!==CORE_SHA256)throw Error('Native CFD fixture requires the exact qualified core SHA; FRAME_CFD_CORE_ROOT may point to that existing read-only checkout');
  const catalogue=JSON.parse(await readFile(resolve(coreRoot,'plugins/index.json'),'utf8'));
  if(!Array.isArray(catalogue)||catalogue.some(v=>String(v).includes('cfd-native-test')))throw Error('Invalid or conflicting native fixture catalogue');
  server=await serveFixture();report.stage='browser-startup';await save();
  browser=await chromium.launch({channel:report.browserChannel,headless:args.includes('--headless'),executablePath:process.env.FRAME_BROWSER||undefined,ignoreDefaultArgs:['--enable-unsafe-swiftshader'],args:['--enable-unsafe-webgpu','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
  report.browser=browser.version();
  const context=await browser.newContext({viewport:{width:1280,height:900},serviceWorkers:'block'});
  await context.addInitScript(()=>{
    window.__cfdNativeAdapters=new WeakMap();if(!globalThis.GPUAdapter)return;
    const request=GPUAdapter.prototype.requestDevice;
    GPUAdapter.prototype.requestDevice=async function(...args){const device=await request.apply(this,args),info=this.info||{};
      __cfdNativeAdapters.set(device,Object.fromEntries(['vendor','architecture','device','description'].map(k=>[k,info[k]||'']).concat([['isFallbackAdapter',info.isFallbackAdapter??this.isFallbackAdapter??null]])));return device;};
  });
  await context.route('**/plugins/index.json',r=>r.fulfill({json:[...catalogue,'cfd-native-test/plugin.json']}));
  await context.route('**/plugins/cfd-native-test/plugin.json',r=>r.fulfill({json:manifest}));
  await context.route('**/plugins/cfd-native-test/plugin.js',r=>r.fulfill({contentType:'text/javascript',body:moduleSource}));
  const page=await context.newPage();report.pageErrors=[];report.consoleErrors=[];
  page.on('pageerror',e=>report.pageErrors.push(e.message));page.on('console',m=>{if(m.type()==='error')report.consoleErrors.push(m.text());});
  report.stage='frame-startup';await save();await page.goto(server.url+'/index.html');
  await page.waitForFunction(()=>window.frameAI&&['true','error'].includes(document.querySelector('#frame-engine-canvas')?.dataset.ready),{},{timeout:60000});
  report.adapter=await watchGPUOperation(page.evaluate(()=>{
    const canvas=document.querySelector('#frame-engine-canvas');if(canvas.dataset.ready!=='true')throw Error('Native Frame WebGPU startup failed: '+canvas.dataset.operationError);
    const device=frameEngine.renderer.device;if(!(device instanceof GPUDevice))throw Error('Native shared GPUDevice unavailable');
    window.__cfdNativeDevice=device;window.__cfdNativeGPU=[];window.__cfdNativeLost=null;
    device.addEventListener('uncapturederror',e=>__cfdNativeGPU.push(e.error.message));device.lost.then(info=>__cfdNativeLost={reason:info.reason,message:info.message});
    return {identity:__cfdNativeAdapters.get(device)||{},features:[...device.features],limits:Object.fromEntries(Object.keys(Object.getPrototypeOf(device.limits)).map(k=>[k,device.limits[k]]))};
  }),'Native adapter admission');
  report.qualification=adapterQualification(report.adapter.identity);if(!report.qualification.qualified)throw Error(report.qualification.reason);
  report.stage='native-partition-cases';await save();
  report.result=await watchGPUOperation(page.evaluate(async()=>{
    const {nativePartitionCFDChecks}=await import('/plugins/cfd/tests/native-partition-cases.mjs');return nativePartitionCFDChecks();
  }),'Native partition acceptance',240000);
  report.gpu=await watchGPUOperation(page.evaluate(async()=>{await __cfdNativeDevice.queue.onSubmittedWorkDone();await new Promise(r=>setTimeout(r,0));return {errors:__cfdNativeGPU,lost:__cfdNativeLost,deviceChanged:frameEngine.renderer.device!==__cfdNativeDevice};}),'Native scene final queue');
  if(!report.result.pass)throw Error(report.result.error||'Native partition acceptance failed');
  if(report.gpu.errors.length||report.gpu.lost||report.gpu.deviceChanged||report.pageErrors.length||report.consoleErrors.length)throw Error('Native scene browser/GPU error');
  report.pass=true;report.stage='complete';
}catch(error){report.error=error.stack||String(error);}
finally{
  report.cleanup=(await Promise.allSettled([browser?.close(),server?.close()])).map((r,i)=>({target:i?'server':'browser',status:r.status,error:r.status==='rejected'?String(r.reason):null}));
  if(report.cleanup.some(r=>r.status==='rejected')){report.pass=false;report.error??='Native fixture cleanup failed';}
  try{report.sourcesAfter=await hashes();if(JSON.stringify(report.sources)!==JSON.stringify(report.sourcesAfter)){report.pass=false;report.error??='Native fixture sources changed';}}
  catch(error){report.pass=false;report.hashVerificationError=String(error);}
  report.hardwareGPUValidated=report.pass&&report.qualification?.qualified===true;
  report.nativeExactEndpointMaterialPartitionValidated=report.hardwareGPUValidated&&report.result?.nativeExactEndpointMaterialPartitionValidated===true;
  report.finished=new Date().toISOString();await save();
}
console.log(JSON.stringify({pass:report.pass,stage:report.stage,checks:report.result?.checks.length||0,error:report.error,hardwareGPUValidated:report.hardwareGPUValidated,nativeExactEndpointMaterialPartitionValidated:report.nativeExactEndpointMaterialPartitionValidated,solverReady:false,report:output},null,2));
process.exitCode=report.pass?0:1;
