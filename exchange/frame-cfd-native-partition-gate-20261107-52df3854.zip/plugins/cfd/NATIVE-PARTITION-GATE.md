# Native exact endpoint material partition gate

This separate, add-only candidate connects native GPU endpoint geometry to a
common conservative material-overlap representation and 27 transported scalar
components. It is NOT a coupled CFD solver, direction-dependent kinetic
streaming, collision, or fluid motion inferred from a moving wall.

The preceding native endpoint-volume gate passed 52 assertions / seven cases
on a nonfallback NVIDIA/Ampere adapter. Its report SHA256 is
0558c6949a70a228d50e74c24e977625e4bbc6e17185e571907503831cefdce4.
That report does not qualify the new shader in this candidate.

Run the new independent hardware trial with:

    node plugins/cfd/tests/native-partition-browser.mjs --headless

The complete fixture expects 107 assertions and 11 successful result cases.
The pinned core SHA256 remains
adef621e4db7cbaa16057ab69fdd3a930fd19ff4fda53d75342ad310f4a67a54.
The runner uses its existing shared native GPU device in a separate browser
context, records all source hashes before/after, and rejects software/unknown
adapters. Its report is validation-results/native-partition-latest.json.

## Exact endpoint admission, not an implicit geometry repair

The native source is one indexed right tetrahedron, local leg 218.75 mm, with
position keys (31.25,31.25,31.25) -> (62.5,62.5,62.5) mm at frames 0 -> 60.
The world grid has zero origin, .0625 m pitch and 8 cubed cells. These endpoints
produce exactly representable Float32 SI coordinates: lower .03125 -> .0625 m,
upper .25 -> .28125 m. The owner translates independently by the same vector;
the gate checks its frame and derivative, rather than losing world coordinates.

One real native sampler remains alive across both samples, GPU transformations,
strict closed-shell checks of the SAME triangles/borrowed indices, partition
construction, readback and retirement. A non-owning view reuses the existing
sample-contract validator for the second sample. The aggregate guard rechecks
the session and every sampled object's guard at every stage and retirement.
Private transformed triangles are copied GPU-to-GPU into endpoint scratch.
Borrowed native positions/indices are never read to the CPU or replaced.

The shader admits only origin zero, exact power-of-two pitch in [2^-20,2^10],
2..16 cells per axis, positive half-cell vertex coordinates, equal-leg
positive-orthant tetrahedra with legs 2..15 cells strictly inside the domain,
and a common endpoint translation of at most one cell per axis. Raw IEEE words
must round-trip exactly through integer half-cell coordinates. A host-encoded
exact power-of-two reciprocal avoids the looser WGSL division accuracy during
coordinate admission. Every corresponding endpoint vertex must share one delta.
There is no source-coordinate snapping, proxy geometry or fraction clamping.

Exact endpoints DO NOT prove the native intermediate trajectory is exact.
For example, the midpoint's 46.875 mm converts to .0468750037252903 m, whereas
265.625 mm converts to .265625 m. The map is explicitly the prescribed linear
material interpolation between admitted endpoints, with BOTH solid and fluid
material translating together. The older approximate native-volume coordinates
are rejected by this admission, rather than silently fed into the new ledger.

## One geometric ledger

Each source cell has at most eight material overlaps, including its self-overlap.
The material is periodic; the solid stays strictly inside the box. Simplex/box
integration uses signed integer inclusion-exclusion. Half-cell coordinates give
an exact common denominator 48. All admitted cubic heights are at most 30;
eight signed cubes have absolute sum at most 216000, safely within i32.

Five separate compute passes extract, initialize, partition, audit and remap.
Row and column sums must exactly equal independently calculated integer endpoint
volumes. There are no floating atomics, marginal rescaling, residual repair or
nearest-neighbor refill. Each source slot packs destination<<6 | numerator.
The native fixture checks every slot against an independently polyhedrally
clipped Float64 oracle with separate exact-rational evidence.

Both endpoints have solid numerator 343 and fluid numerator 24233 over 48.
Forward geometry has 32 -> 19 partial cells and 0 -> 1 dry cells, with 4061
nonzero overlaps and 3550 off-diagonal transfers. Reversing the map exposes
exactly one newly wet cell. These are real volume fractions, not center labels.

## Population arithmetic and physical limits

Each destination gathers its at-most-eight donors using that SAME ledger for
all 27 components. The denominator is its integer fluid volume. Admitted inputs
are zero or normal Float32 values in [2^-100,16]; dry donors must be zero.
Raw bits reject NaN, infinities, negatives and subnormals before arithmetic.
An exact-zero sum bypasses division, preserving absent components exactly.

Integer geometry closure is exact; population arithmetic is not. The oracle
uses actual uploaded Float32 inputs, a positive-sum error bound for permitted
WGSL arithmetic, a separate 2.5-ULP division allowance, and Float64 reference
summation error. It checks each component and accumulates its bounds into all
27 extensive totals, mass and raw momentum. No global mass correction is used.
See the derivation and directed-rounding regressions in native-partition-oracle.
The relevant arithmetic contract is the W3C WGSL floating-point accuracy section:
https://www.w3.org/TR/2026/CRD-WGSL-20261106/#floating-point-accuracy

The uniform benchmark velocity is .03125 m/s per axis, obtained from .5 cells
times .0625 m over one second. A separate population velocity scale of 1 m/s
gives the same dimensionless velocity. The material interval is NOT an LBM dt.
A common transfer matrix for all q is material advection, not kinetic streaming;
adding a collision step would not remove that distinction.

## Ownership, tests and readiness

The probe owns 217248 bytes at this fixture size, retains six staged submissions
through successful readback, refuses concurrent reuse/disposal, and checks a
30-second completed-operation budget. Host tests separately cover exact
cancellation stages, independent stale guards on both samples, device changes,
failed allocation/compilation/submission/mapping/retirement, and reuse afterward.
Those mocks are not shader or native-geometry evidence.

Native cases include forward/reverse uniform and mixed fields, zero motion,
reversed winding, full 32-word status ABI, exact-zero components, newly wet/dry
cells, stale edits, cancellation, off-grid/rotating/multiple sources and raw
population admission failures. The source hashes and original qualified files
must remain unchanged during the trial.

Only a successful actual trial may set
nativeExactEndpointMaterialPartitionValidated=true. Keep
continuousNativeTrajectoryValidated=false, nativeSpaceTimeCouplingValidated=false,
nativeFrameSceneValidated=false and solverReady=false. Remaining work includes
general source-coordinate error admission, arbitrary/deforming geometry,
common physical space-time face/wall fluxes, direction-dependent kinetic
transport, wall impulse balance, production collision/turbulence/AMR and UI.

This technical gate may be transferred through the separate exchange branch.
It does not authorize changing main, the live site or the installed catalogue.
