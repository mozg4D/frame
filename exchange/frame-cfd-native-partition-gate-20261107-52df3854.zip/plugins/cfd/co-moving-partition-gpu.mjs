import {acquireScratch} from './scratch-lease.mjs';

/**
 * Experimental, bounded native endpoint geometry -> common material partition.
 * This is NOT direction-dependent LBM streaming, collision, moving-wall physics,
 * or a proof of the native animation between its two samples. The manufactured
 * map prescribes the SAME uniform translation for solid and fluid material.
 *
 * Caller prerequisites: strict closed-shell validation of these SAME four
 * triangles at each endpoint, plus retained occurrence/signature continuity.
 * Neither a CPU proxy nor a snapped native mesh is accepted. Positions must
 * round-trip EXACTLY through integer half-cell coordinates in the GPU shader.
 *
 * ABI: triangles at bytes 0 and 512, four native 112-byte records per endpoint.
 * cells: u32[before/48,after/48,row/48,column/48] (stored as numerators).
 * weights[source*8 + xBit + 2*yBit + 4*zBit]: (destination<<6)|numerator,
 * with zero for unused slots. Self-overlaps are retained. input/output: f32
 * populations[cell*27+q]. All 27 components use the same geometric weights.
 * State words 0..7: flags,extracted,initialized,partitioned,audited,remapped,
 * overlaps,offDiagonal. i32 words 8..11/12..15: endpoint anchor2.xyz,leg2;
 * words 16..19: delta2.xyz,0; words 20..31: reserved zero.
 * Uniform f32 words4/5: pitch and exact reciprocal half-pitch (2/pitch).
 */
export const coMovingPartitionShader=`
struct Config{origin:vec4f,spacing:vec4f,dims:vec4u,padding:vec4u};
struct State{
 flags:atomic<u32>,extracted:atomic<u32>,initialized:atomic<u32>,partitioned:atomic<u32>,
 audited:atomic<u32>,remapped:atomic<u32>,overlaps:atomic<u32>,offDiagonal:atomic<u32>,
 before:vec4i,after:vec4i,delta:vec4i,padding0:vec4u,padding1:vec4u,padding2:vec4u
};
struct Cell{before:u32,after:u32,row:u32,column:atomic<u32>};
@group(0) @binding(0) var<storage,read> triangles:array<u32>;
@group(0) @binding(1) var<storage,read_write> state:State;
@group(0) @binding(2) var<uniform> cfg:Config;
@group(0) @binding(3) var<storage,read_write> cells:array<Cell>;
@group(0) @binding(4) var<storage,read_write> weights:array<u32>;
@group(0) @binding(5) var<storage,read> populationsIn:array<u32>;
@group(0) @binding(6) var<storage,read_write> populationsOut:array<f32>;
fn countCells()->u32{return cfg.dims.x*cfg.dims.y*cfg.dims.z;}
fn rawVertex(endpoint:u32,triangle:u32,corner:u32)->vec3u{
 let at=endpoint*128u+triangle*28u+corner*4u;
 return vec3u(triangles[at],triangles[at+1u],triangles[at+2u]);
}
fn halfVertex(endpoint:u32,triangle:u32,corner:u32)->vec3i{
 let bits=rawVertex(endpoint,triangle,corner);let halfPitch=cfg.spacing.x*.5;
 // Positive IEEE words are ordered. Inspect raw storage before any float
 // arithmetic: NaN/Inf/negative/subnormal data cannot be silently flushed.
 if(any(bits<vec3u(bitcast<u32>(halfPitch)))||any(bits>vec3u(bitcast<u32>(32.*halfPitch)))){atomicOr(&state.flags,1u);return vec3i(0);}
 // The host supplies the exact power-of-two reciprocal half-pitch.
 // Every admitted scaling product is exactly representable and normal;
 // WGSL division permits 2.5 ULP error, even for a power-of-two divisor.
 let p=bitcast<vec3f>(bits);let q=p*cfg.spacing.y;
 if(!all(q>=vec3f(1.))||!all(q<=vec3f(32.))){atomicOr(&state.flags,2u);return vec3i(0);}
 let integer=vec3i(q);
 // Conversion alone would snap. BOTH round trips must be exact.
 if(any(vec3f(integer)!=q)||any(bitcast<vec3u>(vec3f(integer)*halfPitch)!=bits)){atomicOr(&state.flags,2u);return vec3i(0);}
 return integer;
}
@compute @workgroup_size(64) fn extractCoMovingTetra(@builtin(global_invocation_id) id:vec3u){
 if(id.x!=0u){return;}
 var lower:array<vec3i,2>;var upper:array<vec3i,2>;
 for(var e=0u;e<2u;e++){
  lower[e]=vec3i(32);upper[e]=vec3i(0);
  for(var t=0u;t<4u;t++){
   if(triangles[e*128u+t*28u+27u]!=0x3f800000u){atomicOr(&state.flags,1u);return;}
   for(var k=0u;k<3u;k++){let p=halfVertex(e,t,k);lower[e]=min(lower[e],p);upper[e]=max(upper[e],p);}
  }
 }
 if(atomicLoad(&state.flags)!=0u){return;}
 for(var e=0u;e<2u;e++){
  let legs=upper[e]-lower[e];
  if(any(legs!=vec3i(legs.x))||legs.x<4||legs.x>30||any(lower[e]<=vec3i(0))||any(upper[e]>=vec3i(cfg.dims.xyz)*2)){atomicOr(&state.flags,4u);return;}
  var corners=0u;
  for(var t=0u;t<4u;t++){for(var k=0u;k<3u;k++){
   let p=halfVertex(e,t,k);var corner=0u;
   for(var axis=0u;axis<3u;axis++){if(p[axis]==upper[e][axis]){corner|=1u<<axis;}else if(p[axis]!=lower[e][axis]){atomicOr(&state.flags,4u);return;}}
   if(corner!=0u&&corner!=1u&&corner!=2u&&corner!=4u){atomicOr(&state.flags,4u);return;}corners|=1u<<corner;
  }}
  if(corners!=23u){atomicOr(&state.flags,4u);return;}
 }
 let delta=lower[1]-lower[0];
 if(any(abs(delta)>vec3i(2))||any(upper[1]-lower[1]!=upper[0]-lower[0])){atomicOr(&state.flags,8u);return;}
 for(var t=0u;t<4u;t++){for(var k=0u;k<3u;k++){
  if(any(halfVertex(1u,t,k)-halfVertex(0u,t,k)!=delta)){atomicOr(&state.flags,8u);return;}
 }}
 if(atomicLoad(&state.flags)!=0u){return;}
 state.before=vec4i(lower[0],upper[0].x-lower[0].x);
 state.after=vec4i(lower[1],upper[1].x-lower[1].x);state.delta=vec4i(delta,0);
 atomicStore(&state.extracted,1u);
}
fn point(i:u32)->vec3i{return vec3i(i32(i%cfg.dims.x),i32((i/cfg.dims.x)%cfg.dims.y),i32(i/(cfg.dims.x*cfg.dims.y)));}
fn index(p:vec3i)->u32{return u32((p.z*i32(cfg.dims.y)+p.y)*i32(cfg.dims.x)+p.x);}
fn wrap(p:vec3i)->vec3i{let dims=vec3i(cfg.dims.xyz);return ((p%dims)+dims)%dims;}
// All coordinates are half-cell integers. Every numerator is exact in i32:
// h<=30, h^3<=27000, eight signed terms <=216000 in absolute sum.
// Denominator=6*2^3=48, including cut boxes. No float tolerance or clamp.
fn fluidNumerator(primitive:vec4i,boxMin:vec3i,boxMax:vec3i)->i32{
 let widths=boxMax-boxMin;let box=6*widths.x*widths.y*widths.z;
 let lo=max(boxMin,primitive.xyz);if(any(boxMax<=lo)){return box;}
 let cutWidth=boxMax-lo;let relative=lo-primitive.xyz;
 let height=primitive.w-relative.x-relative.y-relative.z;var solid=0;
 for(var mask=0u;mask<8u;mask++){
  var h=height;var sign=1;
  for(var axis=0u;axis<3u;axis++){if((mask&(1u<<axis))!=0u){h-=cutWidth[axis];sign=-sign;}}
  if(h>0){solid+=sign*h*h*h;}
 }
 let fluid=box-solid;
 if(fluid<0||fluid>box||box<0||box>48){atomicOr(&state.flags,16u);return -1;}
 return fluid;
}
@compute @workgroup_size(64) fn initializeCoMovingCells(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=countCells()||atomicLoad(&state.flags)!=0u){return;}
 let lo=2*point(i);let hi=lo+vec3i(2);
 let before=fluidNumerator(state.before,lo,hi);let after=fluidNumerator(state.after,lo,hi);
 if(before<0||after<0){return;}
 cells[i].before=u32(before);cells[i].after=u32(after);cells[i].row=0u;atomicStore(&cells[i].column,0u);
 for(var slot=0u;slot<8u;slot++){weights[8u*i+slot]=0u;}
 atomicAdd(&state.initialized,1u);
}
fn offsetBase()->vec3i{return vec3i(floor(vec3f(state.delta.xyz)*.5));}
fn slotBits(slot:u32)->vec3i{return vec3i(i32(slot&1u),i32((slot>>1u)&1u),i32((slot>>2u)&1u));}
fn validSlot(bits:vec3i)->bool{
 let split=abs(state.delta.xyz)%vec3i(2);return all(bits<=split);
}
@compute @workgroup_size(64) fn partitionCoMovingCells(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=countCells()||atomicLoad(&state.flags)!=0u){return;}
 let source=point(i);let moved=2*source+state.delta.xyz;let base=offsetBase();var row=0u;
 for(var slot=0u;slot<8u;slot++){
  let bits=slotBits(slot);if(!validSlot(bits)){continue;}
  let image=source+base+bits;let destination=wrap(image);let shift=2*(destination-image);
  let lo=max(2*image,moved)+shift;let hi=min(2*image+vec3i(2),moved+vec3i(2))+shift;
  let numerator=fluidNumerator(state.after,lo,hi);if(numerator<0){return;}if(numerator==0){continue;}
  let to=index(destination);let weight=u32(numerator);weights[i*8u+slot]=(to<<6u)|weight;
  row+=weight;atomicAdd(&cells[to].column,weight);atomicAdd(&state.overlaps,1u);
  if(to!=i){atomicAdd(&state.offDiagonal,1u);}
 }
 cells[i].row=row;atomicAdd(&state.partitioned,1u);
}
@compute @workgroup_size(64) fn auditCoMovingPartition(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=countCells()||atomicLoad(&state.flags)!=0u){return;}
 if(cells[i].before>48u||cells[i].after>48u||cells[i].row!=cells[i].before||atomicLoad(&cells[i].column)!=cells[i].after){atomicOr(&state.flags,32u);return;}
 for(var q=0u;q<27u;q++){
  let bits=populationsIn[i*27u+q];let zero=(bits&0x7fffffffu)==0u;
  // +/-0 or a positive normal IEEE f32 in [2^-100,16]. Check raw words,
  // not a float predicate that could flush a tiny positive value to zero.
  if((!zero&&(bits<0x0d800000u||bits>0x41800000u))||(cells[i].before==0u&&!zero)){atomicOr(&state.flags,64u);return;}
 }
 atomicAdd(&state.audited,1u);
}
@compute @workgroup_size(64) fn remapCoMovingPopulations(@builtin(global_invocation_id) id:vec3u){
 let i=id.x;if(i>=countCells()||atomicLoad(&state.flags)!=0u){return;}
 let destination=point(i);let base=offsetBase();let after=cells[i].after;
 for(var q=0u;q<27u;q++){
  var sum=0.;
  if(after!=0u){for(var slot=0u;slot<8u;slot++){
   let bits=slotBits(slot);if(!validSlot(bits)){continue;}
   let donor=index(wrap(destination-base-bits));let encodedWeight=weights[donor*8u+slot];
   if(encodedWeight!=0u){if((encodedWeight>>6u)!=i){atomicOr(&state.flags,32u);return;}sum+=f32(encodedWeight&63u)*bitcast<f32>(populationsIn[donor*27u+q]);}
  }}
  // A zero nonnegative sum means every contribution is zero. Preserve it
  // exactly: WGSL division permits subnormal error even for an exact zero.
  var value=0.;if(after!=0u&&sum>0.){value=sum/f32(after);}
  if(!(value>=0.&&value<=16.)){atomicOr(&state.flags,128u);return;}
  populationsOut[i*27u+q]=value;
 }
 atomicAdd(&state.remapped,1u);
}`;

const readyFlags=Object.freeze({hardwareValidated:false,sourceGeometryCertified:false,
  nativeSpaceTimeCouplingValidated:false,nativeFrameSceneValidated:false,nativeTransportValidated:false,
  generalMovingBody:false,solverReady:false,forceValidated:false,kineticStreamingPerformed:false,
  streamingCollisionPerformed:false});
const stages=Object.freeze(['extractCoMovingTetra','initializeCoMovingCells','partitionCoMovingCells','auditCoMovingPartition','remapCoMovingPopulations']);

function snapshotGrid(grid){
  const dense=value=>Array.isArray(value)&&value.length===3&&[0,1,2].every(i=>Object.hasOwn(value,i)&&Number.isFinite(value[i]));
  const origin=grid?.origin,dimensions=grid?.dimensions,pitch=grid?.pitch;
  if(!dense(origin)||!dense(dimensions))throw new RangeError('Bounded exact half-cell Cartesian partition grid required');
  const copy={origin:Array.from(origin),pitch,dimensions:Array.from(dimensions)},exponent=Math.log2(pitch);
  if(copy.origin.some(v=>v!==0)||!Number.isFinite(pitch)||!Number.isInteger(exponent)||exponent < -20||exponent>10||2**exponent!==pitch||copy.dimensions.some(v=>!Number.isInteger(v)||v<2||v>16))throw new RangeError('Bounded exact half-cell Cartesian partition grid required');
  Object.freeze(copy.origin);Object.freeze(copy.dimensions);return Object.freeze(copy);
}

export function planCoMovingPartition(grid,{limits,maxBytes,maxCells}={}){
  const fixed=snapshotGrid(grid);
  if(!Number.isSafeInteger(maxBytes)||maxBytes<1||!Number.isSafeInteger(maxCells)||maxCells<1)throw new RangeError('Finite explicit partition budgets required');
  const cellCount=fixed.dimensions.reduce((a,b)=>a*b,1);
  const sizes={triangles:1024,state:128,uniform:64,cells:16*cellCount,weights:32*cellCount,input:108*cellCount,output:108*cellCount,readback:128};
  const totalBytes=Object.values(sizes).reduce((a,b)=>a+b,0);
  const required=['maxStorageBufferBindingSize','maxBufferSize','maxComputeWorkgroupsPerDimension','maxComputeInvocationsPerWorkgroup','maxComputeWorkgroupSizeX','maxUniformBufferBindingSize','maxStorageBuffersPerShaderStage','maxBindingsPerBindGroup','minStorageBufferOffsetAlignment'];
  if(required.some(key=>!Number.isSafeInteger(limits?.[key])||limits[key]<1))throw new RangeError('Partition device limits required');
  if(512%limits.minStorageBufferOffsetAlignment!==0)throw new RangeError('Native endpoint offset 512 is incompatible with device storage alignment');
  if(cellCount>maxCells||totalBytes>maxBytes||Math.ceil(cellCount/64)>limits.maxComputeWorkgroupsPerDimension||limits.maxComputeInvocationsPerWorkgroup<64||limits.maxComputeWorkgroupSizeX<64||limits.maxUniformBufferBindingSize<64||limits.maxStorageBuffersPerShaderStage<6||limits.maxBindingsPerBindGroup<7||Object.entries(sizes).some(([key,size])=>size>limits.maxBufferSize||!['uniform','readback'].includes(key)&&size>limits.maxStorageBufferBindingSize))throw new RangeError('Partition work/memory/device budget exceeded');
  return {gridKey:JSON.stringify(fixed),cellCount,sizes,totalBytes,dispatches:5,stages:[...stages],exactVolumeDenominator:48,maximumOverlapsPerSource:8,...readyFlags};
}

/** Caller-owned buffers are never allocated/destroyed; invalid output never publishes. */
export async function dispatchCoMovingPartition(device,{grid,timeStart,timeEnd,maxBytes,maxCells,assertCurrent,...buffers}={}){
  if(typeof assertCurrent!=='function'||!Number.isFinite(timeStart)||timeStart<0||!Number.isFinite(timeEnd)||timeEnd<=timeStart)throw new RangeError('Increasing physical endpoint times and lifetime guard required');
  const plan=planCoMovingPartition(grid,{limits:device?.limits,maxBytes,maxCells});
  const fixedGrid=snapshotGrid(JSON.parse(plan.gridKey));
  const usage={triangles:128,state:140,uniform:72,cells:128,weights:128,input:128,output:128,readback:9};
  for(const [key,size]of Object.entries(plan.sizes)){
    const buffer=buffers[key];
    if(!buffer||!Number.isSafeInteger(buffer.size)||buffer.size<size||!Number.isSafeInteger(buffer.usage)||(buffer.usage&usage[key])!==usage[key]||buffer.mapState!==undefined&&buffer.mapState!=='unmapped')throw new RangeError('Invalid partition buffer '+key);
  }
  const lease=acquireScratch(Object.keys(plan.sizes).map(key=>buffers[key]));
  try{
    assertCurrent();const module=device.createShaderModule({code:coMovingPartitionShader,label:'CFD prescribed common material partition (unverified)'});
    const info=await module.getCompilationInfo();assertCurrent();
    if(info.messages.some(m=>m.type==='error'))throw Error('Co-moving partition WGSL compilation failed: '+info.messages.filter(m=>m.type==='error').map(m=>m.message).join('; '));
    const roles=['triangles','state','uniform','cells','weights','input','output'];
    const layout=device.createBindGroupLayout({entries:roles.map((key,binding)=>({binding,visibility:4,buffer:{type:key==='uniform'?'uniform':key==='triangles'||key==='input'?'read-only-storage':'storage'}}))});
    const pipelineLayout=device.createPipelineLayout({bindGroupLayouts:[layout]}),pipelines=[];
    for(const entryPoint of stages){assertCurrent();pipelines.push(await device.createComputePipelineAsync({layout:pipelineLayout,compute:{module,entryPoint}}));assertCurrent();}
    assertCurrent();device.pushErrorScope('validation');let problem,scope;
    try{
      const uniform=new ArrayBuffer(64);new Float32Array(uniform).set([...fixedGrid.origin,0,fixedGrid.pitch,2/fixedGrid.pitch,0,0]);new Uint32Array(uniform).set([...fixedGrid.dimensions,0],8);
      device.queue.writeBuffer(buffers.uniform,0,uniform);device.queue.writeBuffer(buffers.state,0,new Uint32Array(32));
      const group=device.createBindGroup({layout,entries:roles.map((key,binding)=>({binding,resource:{buffer:buffers[key],offset:0,size:plan.sizes[key]}}))});
      const encoder=device.createCommandEncoder();
      for(let i=0;i<pipelines.length;i++){const pass=encoder.beginComputePass();pass.setPipeline(pipelines[i]);pass.setBindGroup(0,group);pass.dispatchWorkgroups(i===0?1:Math.ceil(plan.cellCount/64));pass.end();}
      encoder.copyBufferToBuffer(buffers.state,0,buffers.readback,0,128);assertCurrent();device.queue.submit([encoder.finish()]);
    }catch(error){problem=error instanceof Error?error:new Error(String(error));}
    finally{try{scope=device.popErrorScope();}catch(error){problem??=error;}}
    // Pop synchronously, then settle BOTH scope and submitted queue on every
    // encoding/submit/validation failure before the scratch lease can release.
    let retirement;try{retirement=device.queue.onSubmittedWorkDone();}catch(error){retirement=Promise.reject(error);}
    const settled=await Promise.allSettled([scope,retirement]);
    for(const result of settled)if(result.status==='rejected')problem??=new Error(String(result.reason));else if(result.value)problem??=new Error(result.value.message);
    if(problem)throw problem;
    assertCurrent();await buffers.readback.mapAsync(1,0,128);let state;
    try{assertCurrent();state=Array.from(new Uint32Array(buffers.readback.getMappedRange(0,128)));}finally{buffers.readback.unmap();}
    assertCurrent();
    if(state.length!==32||state[0]!==0||state[1]!==1||[2,3,4,5].some(i=>state[i]!==plan.cellCount)||state[6]>8*plan.cellCount||state[7]>state[6])throw Error('Unsupported or unresolved native co-moving partition: '+state.slice(0,8).join(','));
    return {stage:'native-endpoint-prescribed-material-partition-unverified',stages:[...stages],timeStart,timeEnd,gridKey:plan.gridKey,
      cellCount:plan.cellCount,bytes:plan.totalBytes,stateWords:Object.freeze(state.slice()),exactVolumeDenominator:48,overlapCount:state[6],transferCount:state[7],
      anchor2Before:state.slice(8,11),anchor2After:state.slice(12,15),leg2:state[11],displacement2:state.slice(16,19).map(v=>v|0),
      path:'endpoint-defined-linear-prescribed-material-interpolation',fluidTransport:'same-prescribed-translation-as-solid',
      cellVolumeAvailable:true,transportPlanAvailable:true,materialRemapAvailable:true,refillAvailable:false,
      exactGeometricClosure:true,sourceShellValidationRequired:true,...readyFlags};
  }finally{lease.release();}
}
