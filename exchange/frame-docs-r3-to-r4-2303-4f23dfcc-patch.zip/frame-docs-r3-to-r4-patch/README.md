# Exact R3 to R4 Docs correction

This small patch reconstructs a NEW focused R4 directory from the known 173-source R3 inventory. It never edits R3, copies node_modules, runs project code, installs software or launches a browser. It refuses an existing output. Full source hash verification runs before and after; source deletion is not permitted. If ad hoc diagnostics were saved in inventoried R3 paths, the checker will correctly reject that tree. Preserve it unchanged and use a fresh extraction of the verified original R3 ZIP. Do not delete failed reports, relax the checker or regenerate R3 inventory. The index receives only two exact version replacements. No runtime assets are re-transferred.

Verify the ZIP SHA-256 supplied separately, then extract to a separate directory. Keep the original Windows R3 PASS/FAIL and diagnostic reports unchanged. All R4 browser qualification is UNRUN. Parent-reported R3: CPU15 and first six browser stages PASS, PWA FAIL, final two stages NOT RUN. The original failing worker is preserved in the target qualification evidence.

PowerShell, from this patch folder. Replace these two paths with the verified R3 folder and a NEW sibling destination:

    $R3 = 'C:\path\frame-docs-focused-20261107-2208-r3'
    $R4 = 'C:\path\frame-docs-focused-20261107-2303-r4'
    node .\apply-docs-r4.mjs --check $R3
    if ($LASTEXITCODE -ne 0) { throw 'R3 preflight failed' }
    node .\apply-docs-r4.mjs --apply $R3 $R4
    if ($LASTEXITCODE -ne 0) { throw 'Patch failed; preserve incomplete output' }
    node "$R4\tests\docs-final-cpu-gate.mjs"
    if ($LASTEXITCODE -ne 0) { throw 'R4 CPU gate failed' }

Only when the already authorized Windows browser environment is ready, and its existing Playwright/Chromium installation is resolvable from the NEW R4 folder:

    node .\run-pwa-retest.mjs $R4 --headless
    if ($LASTEXITCODE -ne 0) { throw 'STOP: PWA retest failed' }

This runs ONLY the PWA child with a five-minute outer limit, preserves the exact 30-second popup assertion, and verifies source inventory before/after. Its result is DOCS-R4-PWA-GATE-RESULT.json, never a nine-stage PASS. If dependencies are missing, stop; these instructions do not authorize installation or software-GPU fallback. Reuse only the existing authorized setup. Forced timeout leaves descendant cleanup uncertain; verify cleanup before further tests.

After PWA passes, preserve child reports before any rerun. The coordinator decides when to run the unchanged full focused gate (nine sequential stages):

    node "$R4\tests\docs-integrated-browser-gate.mjs" --headless

No full standard/stress or unrelated Unite gates, printer/CNC operations, user scenes/media, live/main edits, upload or publication. Actual OS IME, installed-PWA launch and broader release qualification remain separate. The patch does not provide general content-hash atomic deployment or rollback.
