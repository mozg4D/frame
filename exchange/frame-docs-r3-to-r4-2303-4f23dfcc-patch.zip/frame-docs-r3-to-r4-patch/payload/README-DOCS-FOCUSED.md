# R4 focused Docs correction

Runtime version 2026 07 nov 23:03. R4 browser qualification is UNRUN. Historical Windows R3 results: CPU15 and first six browser stages PASS, offline PWA FAIL, final two stages NOT RUN. Original Windows reports remain untouched and are not cloud originals. This correction changes only temporary SW URL hash normalization, synchronized index/SW stamps, reviewed regression/diagnostic fixtures and exact source provenance.

No Unite or standard/stress suites, printer/CNC execution, user scenes/media, uploads or publication are authorized by this package. Actual OS IME, installed-PWA and broader release qualification remain open.

## Historical R3 technical instructions and limitations

The following source-bound R3 text is historical. Its version and execution-status statements do not describe R4. Existing focused commands and limits remain applicable.

# Focused Docs qualification package

This is a local technical test package, not a release or site deployment. Runtime version: 2026 07 nov 22:08. The full integration copy passed source-bound CPU checks; the portable subset receives its own inventory and CPU report. Browser, real OS IME and installed-PWA gates have NOT run.

Included: exact final runtime, the complete declared current PWA/plugin assets, installed public models/textures, focused CPU/browser gates, exact public production predecessor asset closure, and necessary technical source/review evidence. Excluded: all unrelated scene/geometry/media fixtures, unrelated test implementations, historical full-tree inventories, dependency folders, credentials, local scratch and transient test outputs. No excluded private filenames are listed here.

This package supports only the two focused commands below. npm test, npm run test:stress, npm run test:all and all other package scripts are NOT supported by this subset unless expressly named here. The standard runner file is retained solely for syntax/entrypoint provenance; its unrelated modules and full-suite inputs are intentionally absent. Do not run full standard/stress suites from this package. Historical source records may identify checksums of files not shipped in this focused subset.

Prerequisites on the separately authorized Windows hardware target: Node.js 22+, Playwright 1.64.1 already resolvable from this folder, and an already installed hardware-capable Chromium. No node_modules are bundled. If anything is missing, stop and report it; these commands do not install software or enable software GPU fallback. Do not use an existing user browser tab. The gates create isolated contexts and ephemeral local servers.

From PowerShell, in this extracted folder:

    powershell -NoProfile -File .\tools\qualify-docs-cpu.ps1

Only when the focused hardware run is authorized and the machine is ready:

    powershell -NoProfile -File .\tools\qualify-docs-browser.ps1

The browser script verifies the inventory, checks the existing browser dependency, then runs exactly one sequential nine-stage gate: file controls; immediate input Save/Share/export/New/Open barrier; detached editor; native HASH Docs; HASH best effort; plugin references; fresh offline Docs; native keyboard Undo/Redo across remote text; captured production-page/new-worker transition. It checks source hashes before and after each child and stops on the first failure, with a five-minute child limit. A forced timeout cannot certify descendant-browser cleanup: check for remaining processes before any later run. Never regenerate the frozen inventory to mask drift.

Reports: DOCS-FINAL-CPU-RESULT.json, DOCS-INTEGRATED-BROWSER-RESULT.json and the focused child reports under tests/results or root DOCS…RESULT.json. An exit 0 is only the stated focused coverage, not a full release pass. Do not overwrite prior failed reports without preserving them separately. Actual OS IME, installed-PWA file launch, broader hardware failures, full standard/stress and deployment remain separate gates. Safe Undo/Redo no-op after a remote patch is explicitly a history limitation.

The worker lacks general content-hash binding to index.html and automatic rollback. The pinned old-live transition does not prove arbitrary mixed-deployment atomicity. No uploads, main-branch changes or site publication are authorized by this package.
