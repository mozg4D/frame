# R4 focused Docs correction

Runtime version 2026 07 nov 23:03. R4 browser qualification is UNRUN. Historical Windows R3 results: CPU15 and first six browser stages PASS, offline PWA FAIL, final two stages NOT RUN. Original Windows reports remain untouched and are not cloud originals. This correction changes only temporary SW URL hash normalization, synchronized index/SW stamps, reviewed regression/diagnostic fixtures and exact source provenance.

No Unite or standard/stress suites, printer/CNC execution, user scenes/media, uploads or publication are authorized by this package. Actual OS IME, installed-PWA and broader release qualification remain open.

## Historical R3 technical instructions and limitations

The following source-bound R3 text is historical. Its version and execution-status statements do not describe R4. Existing focused commands and limits remain applicable.

# Unified Docs candidate

Current index SHA-256: c4dd55f425708ea0ac1f3bae0345db3f4b4084e797f7e6b2ad9f492c0b4402e3

See DOCS-FINAL-QUALIFICATION.md and DOCS-FINAL-LAYERS.json. Original ce96 and composition/PWA qualification records are preserved under qualification. They are historical source evidence, not a current browser pass. Current browser and hardware qualification is not run.
