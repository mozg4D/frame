// Bounded offline Docs gate. No physics work or large scene. Not installed-PWA/OS-IME qualification.
import assert from 'node:assert/strict';import {writeFile} from 'node:fs/promises';import {launch,ready} from '../tools/browser.mjs';
import {observePage,beginGPU,sampleFrames,finishGPUs} from './docs-browser-diagnostics.mjs';
let app,online,page,editor;const report={pass:false,checks:[],timings:[],network:[],limitations:['Normal Chromium service-worker offline gate, not installed PWA placement','Save transport/real OS IME qualification is separate','Initial online navigation happens inside launch() before page/console observers attach; offline page and popup are observed from creation']};
// Preserve the existing page-error assertion while sharing the common observers.
report.errors=report.pageErrors=[];
const track=url=>/\/(?:index\.html|documentation\.html|frame-sw\.js|core\/documentation-[^/?#]+\.mjs)(?:[?#]|$)/.test(url);
const record=entry=>{if(report.network.length<100)report.network.push(entry);};
// Promise.race attaches rejection handlers to pending work even after timeout.
async function captureWithin(work,label){let timer;try{return await Promise.race([work,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error(label+' exceeded 5000 ms; diagnostic evidence incomplete')),5000);})]);}finally{clearTimeout(timer);}}
async function snapshot(target,label){
 if(!target)return;
 if(target.isClosed()){report.pass=false;(report.snapshots??={})[label]={url:target.url(),captureError:'Page closed before diagnostic snapshot',incomplete:true};return;}
 try{(report.snapshots??={})[label]=await captureWithin(target.evaluate(()=>({url:location.href,title:document.title,hash:location.hash,readyState:document.readyState,controller:navigator.serviceWorker?.controller?{scriptURL:navigator.serviceWorker.controller.scriptURL,state:navigator.serviceWorker.controller.state}:null,textarea:document.querySelector('textarea')?{value:document.querySelector('textarea').value,disabled:document.querySelector('textarea').disabled,readOnly:document.querySelector('textarea').readOnly}:null,status:document.querySelector('output')?.textContent||null,docs:window.frameDocumentation?.get()||null})),label+' snapshot');}
 catch(error){report.pass=false;(report.snapshots??={})[label]={url:target.url(),captureError:error.message,incomplete:true};}
}
try{
 app=await launch({headless:process.argv.includes('--headless')});online=app.page;report.browserVersion=app.browser.version();
 observePage(online,'online-shell',report);app.context.on('page',target=>observePage(target,'new-context-page',report));
 app.context.on('requestfailed',request=>{if(track(request.url()))record({event:'requestfailed',url:request.url(),method:request.method(),resourceType:request.resourceType(),error:request.failure()?.errorText});});
 app.context.on('response',response=>{if(track(response.url()))record({event:'response',url:response.url(),status:response.status(),contentType:response.headers()['content-type']||null,fromServiceWorker:response.fromServiceWorker()});});
 await ready(online);await beginGPU(online,'online-shell',report);
 await online.evaluate(async()=>{await navigator.serviceWorker.register('./frame-sw.js',{scope:'./'});await navigator.serviceWorker.ready;});await online.waitForFunction(()=>!!navigator.serviceWorker.controller);
 const cached=await online.evaluate(async()=>{const version=document.querySelector('meta[name="frame-version"]').content,cache=await caches.open('frame-native-'+version);return Promise.all(['documentation.html','core/documentation-window.mjs','core/documentation-editor.mjs','core/documentation-sync.mjs'].map(async path=>{const response=await cache.match(new URL(path,location.href).href);return {path,cached:!!response,status:response?.status||null,contentType:response?.headers.get('content-type')||null,sha256:response?Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await response.arrayBuffer())),x=>x.toString(16).padStart(2,'0')).join(''):null};}));});
 report.cached=cached;assert.ok(cached.every(x=>x.cached));report.checks.push('four Docs resources present before offline fresh launch');await sampleFrames(online,'online-shell',report,'before-offline');
 await app.context.setOffline(true);page=await app.context.newPage();observePage(page,'offline-shell',report);await page.goto(app.url+'/index.html');await ready(page);await beginGPU(page,'offline-shell',report);
 const call=(name,args={})=>page.evaluate(([n,a])=>frameAI.call(n,a),[name,args]);const d=await call('docs.get'),text='Offline Ω 日本 😀';await call('docs.create',{text,version:d.version});
 const started=performance.now(),opening=page.waitForEvent('popup');await page.locator('#btnDocs').click();editor=await opening;observePage(editor,'offline-editor',report);
 // The existing expected-text assertion and default 30-second timeout are unchanged.
 await editor.waitForFunction(text=>document.querySelector('textarea')?.value===text,text);
 report.timings.push({name:'offline Docs popup ready with exact text',elapsedMs:performance.now()-started,waitTimeoutMs:30000});report.checks.push('fresh offline shell imports host module and opens offline document/editor/sync');
 await editor.locator('textarea').focus();await editor.keyboard.press('Control+End');await editor.keyboard.type('!');await page.waitForFunction(text=>frameDocumentation.get().text===text,text+'!');const saved=await call('scene.export',{format:'hash',includeData:true});await call('scene.new');await editor.waitForSelector('textarea:disabled');await call('scene.open',{name:'offline-docs.hash',base64:saved.base64});assert.equal((await call('docs.get')).text,text+'!');await editor.waitForFunction(text=>document.querySelector('textarea').value===text,text+'!');assert.equal(await editor.locator('textarea').isEnabled(),true);report.checks.push('offline editor input acknowledged then native HASH export/new/open roundtrip');assert.equal(report.errors?.length||0,0);
 await sampleFrames(page,'offline-shell',report,'after-offline-roundtrip');report.pass=true;
}catch(e){report.error=e.stack||String(e);process.exitCode=1;}finally{
 await Promise.all([snapshot(online,'online-shell'),snapshot(page,'offline-shell'),snapshot(editor,'offline-editor')]);
 try{await captureWithin(finishGPUs(report),'GPU cleanup capture');}catch(error){report.pass=false;report.gpuCaptureIncomplete=true;report.diagnosticsFailure=error.message;}if(!report.pass)process.exitCode=1;await app?.close();await writeFile(new URL('../DOCS-PWA-RESULT.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}
