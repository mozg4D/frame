// Actual worker fetch handler, CPU fixtures only. No browser/GPU qualification.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
const root=new URL('../',import.meta.url),scope='https://frame.test/frame/';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const paths=['index.html','documentation.html','core/documentation-window.mjs','core/documentation-editor.mjs','core/documentation-sync.mjs'];
// Cache API matching ignores fragments, but keeps the query string significant.
const cacheKey=request=>{const url=new URL(typeof request==='string'?request:request.url);url.hash='';return url.href;};
function fixture(source,assets){
 const handlers={},network=[],lookups=[],stored=new Map(assets.map(([path,bytes])=>[new URL(path,scope).href,bytes]));
 const context={URL,Response,Map,self:{registration:{scope},location:{origin:new URL(scope).origin},addEventListener:(name,handler)=>handlers[name]=handler},caches:{open:async()=>({
  match:async request=>{lookups.push(typeof request==='string'?request:request.url);const key=cacheKey(request),bytes=stored.get(key);return bytes===undefined?undefined:new Response(bytes,{headers:{'Content-Type':new URL(key).pathname.endsWith('.html')?'text/html; charset=utf-8':'text/javascript'}});},
  put:async()=>assert.fail('Cached offline routing must not write cache entries')
 })},fetch:async request=>{network.push(typeof request==='string'?request:request.url);throw Error('Offline fixture network request');}};
 vm.runInNewContext(source,context);
 return {network,lookups,async route(url,{method='GET',mode='navigate'}={}){
  const request=new Request(url,{method});
  // Node cannot construct navigate-mode Requests; only mode/destination are fixtures.
  Object.defineProperty(request,'mode',{value:mode});Object.defineProperty(request,'destination',{value:mode==='navigate'?'document':'script'});
  let response;handlers.fetch({request,respondWith:promise=>{assert.equal(response,undefined,'Only one response');response=Promise.resolve(promise);}});
  if(!response)return {handled:false,requestURL:request.url};
  const received=await response;return {handled:true,requestURL:request.url,status:received.status,mime:received.headers.get('Content-Type'),sha256:hash(new Uint8Array(await received.arrayBuffer()))};
 }};
}
export async function routingChecks(){
 const source=await readFile(new URL('frame-sw.js',root),'utf8'),original=await readFile(new URL('qualification/pwa-fragment/before/frame-sw.js',root),'utf8');
 assert.equal(hash(original),'8a7479df4744389287ebb79142c08784fcbfe0387cd04a13c42eb970b51267d0','Immutable original failing worker');
 const assets=await Promise.all(paths.map(async path=>[path,await readFile(new URL(path,root))]));
 const expected=Object.fromEntries(assets.map(([path,bytes])=>[path,hash(bytes)])),checks=[],timings=[];
 const token='d20ca4f5-9059-41ea-b914-f86357afa301',popupURL=new URL('documentation.html#'+token,scope).href;
 const before=fixture(original,assets),originalPopup=await before.route(popupURL);
 assert.equal((await before.route(new URL('documentation.html',scope).href)).handled,true);
 assert.equal(originalPopup.handled,false,'Original real worker reproduces the confirmed fragment fallthrough');
 assert.equal(before.network.length,0);checks.push('Pinned original worker handles bare Docs but fails the observed fragment navigation');
 const current=fixture(source,assets);
 for(const path of paths){for(const fragment of ['', '#'+token]){
  const url=new URL(path+fragment,scope).href,mode=path.endsWith('.html')?'navigate':'cors',result=await current.route(url,{mode});
  assert.equal(result.handled,true,path+fragment);assert.equal(result.requestURL,url,'Original Request retains the popup token');
  assert.equal(result.sha256,expected[path],'Exact cached resource bytes');assert.equal(result.status,200);
  assert.match(result.mime,path.endsWith('.html')?/^text\/html/:/^text\/javascript/);
 }}checks.push('All five shell/Docs resources serve exact cached bytes with and without fragments; original Request is intact');
 const popup=await current.route(popupURL);assert.equal(popup.sha256,expected['documentation.html']);assert.equal(current.lookups.at(-1),popupURL,'Cache receives the unchanged original Request');
 const rootLaunch=await current.route(scope+'#state');assert.equal(rootLaunch.sha256,expected['index.html']);
 const shellQuery=await current.route(new URL('index.html?existing=1#state',scope).href);assert.equal(shellQuery.sha256,expected['index.html']);
 checks.push('Existing root/shell navigation behavior and popup handshake token are preserved');
 const excluded=[
  ['foreign origin','https://other.test/frame/documentation.html#token'],
  ['different scheme','http://frame.test/frame/documentation.html#token'],
  ['outside registration scope','https://frame.test/documentation.html#token'],
  ['scope prefix sibling','https://frame.test/frame-other/documentation.html#token'],
  ['distinct query',new URL('documentation.html?other=1#token',scope).href],
  ['unknown document',new URL('documentation.html.bak#token',scope).href],
  ['ordinary scene',new URL('user-scene.hash#token',scope).href],
  ['encoded hash in path',new URL('documentation.html%23token',scope).href],
  ['POST',popupURL,'POST'],['HEAD',popupURL,'HEAD'],['POST shell',new URL('index.html#token',scope).href,'POST']
 ];
 for(const [name,url,method='GET'] of excluded){const start=current.lookups.length,result=await current.route(url,{method});assert.equal(result.handled,false,name);assert.equal(current.lookups.length,start,name+' must not consult cache');}
 checks.push('Foreign origins, schemes, scopes, queries, unknown paths, scenes and non-GET requests remain excluded');
 const start=performance.now(),iterations=100;
 for(let i=0;i<iterations;i++){const result=await current.route(popupURL);assert.equal(result.sha256,expected['documentation.html']);}
 const elapsedMs=performance.now()-start,budgetMs=1000;assert.ok(elapsedMs<budgetMs,'100 completed cached Docs responses exceeded 1000 ms CPU fixture budget');
 timings.push({name:'100 completed cached Docs fragment responses',iterations,elapsedMs,budgetMs});
 assert.equal(current.network.length,0,'All cached routing and exclusions avoid the offline network');
 checks.push('Cached fragment responses make zero network requests and satisfy the completed-operation CPU budget');
 return {checks,timings,sourceSHA256:hash(source),originalSHA256:hash(original),originalPopup};
}
if(process.argv[1]===fileURLToPath(import.meta.url))console.log(JSON.stringify({pass:true,qualification:'Actual SW handler CPU fixtures only; no browser/GPU run',...await routingChecks()},null,2));
