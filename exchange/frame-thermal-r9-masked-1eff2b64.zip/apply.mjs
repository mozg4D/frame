// Exact source-only reconstruction. No browser, installer, network or base write.
import {readFile,readdir,lstat,realpath,mkdir,writeFile} from 'node:fs/promises';
import {resolve,relative,dirname,join,sep,isAbsolute} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const packet=dirname(fileURLToPath(import.meta.url)), hash=b=>createHash('sha256').update(b).digest('hex');
const fail=m=>{throw new Error(m);};
const validPath=p=>typeof p==='string'&&p.length>0&&!p.includes('\\')&&!p.includes(':')&&!isAbsolute(p)&&p.split('/').every(s=>s&&s!=='.'&&s!=='..');
const overlap=(a,b)=>a===b||a.startsWith(b+sep)||b.startsWith(a+sep);
const manifest=JSON.parse(await readFile(join(packet,'PATCH-MANIFEST.json'),'utf8'));
if(manifest.format!==1||manifest.noDeletes!==true)fail('Unsupported packet format.');
const baseFiles=manifest.baseFiles,targetFiles=manifest.targetFiles,changes=manifest.changes;
const digest=/^[0-9a-f]{64}$/;
for(const files of [baseFiles,targetFiles]){
 if(!files||Object.getPrototypeOf(files)!==Object.prototype)fail('Invalid source inventory.');
 for(const [p,s] of Object.entries(files))if(!validPath(p)||!digest.test(s))fail('Invalid source identity: '+p);
 if(new Set(Object.keys(files).map(p=>p.toLowerCase())).size!==Object.keys(files).length)fail('Case-colliding source paths.');
}
if(Object.keys(baseFiles).length!==461||Object.keys(targetFiles).length!==483||!Array.isArray(changes)||changes.length!==44)fail('Unexpected source inventory cardinality.');
if(Object.keys(baseFiles).some(p=>!Object.hasOwn(targetFiles,p)))fail('Deletion is not supported.');
const expectedChanges=Object.keys(targetFiles).filter(p=>baseFiles[p]!==targetFiles[p]).sort();
if(JSON.stringify(changes.map(c=>c.path))!==JSON.stringify(expectedChanges))fail('Delta does not exactly cover inventory changes.');
for(const c of changes){if(c.beforeSHA256!==(baseFiles[c.path]??null)||c.afterSHA256!==targetFiles[c.path]||!Number.isSafeInteger(c.bytes)||c.bytes<0)fail('Bad change preconditions: '+c.path);}
const ignored=['.git','native-selection-delivery','node_modules','probe-size-delivery','tests/results','undo-fixture-delivery'];
if(JSON.stringify(manifest.baseIgnoredRoots)!==JSON.stringify(ignored))fail('Ignored source roots changed.');
const isIgnored=p=>ignored.some(x=>p===x||p.startsWith(x+'/'));
async function walk(root,{ignore=false}={}){
 const out=[];
 async function recur(dir,prefix=''){
  for(const e of (await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
   const p=prefix+e.name;if(ignore&&isIgnored(p))continue;
   const path=join(dir,e.name),s=await lstat(path);
   if(s.isSymbolicLink())fail('Symlink in source or packet: '+p);
   if(s.isDirectory())await recur(path,p+'/');else if(s.isFile())out.push(p);else fail('Nonregular source entry: '+p);
  }
 }
 await recur(root);return out.sort();
}
async function verifySource(root,files,{ignore=false}={}){
 const actual=await walk(root,{ignore}),expected=Object.keys(files).sort();
 if(JSON.stringify(actual)!==JSON.stringify(expected)){
  const missing=expected.filter(p=>!actual.includes(p)),extra=actual.filter(p=>!Object.hasOwn(files,p));
  fail('Source inventory mismatch. Missing: '+JSON.stringify(missing)+' Extra: '+JSON.stringify(extra));
 }
 for(const [p,want] of Object.entries(files))if(hash(await readFile(join(root,p)))!==want)fail('Source SHA-256 mismatch: '+p);
 return actual.length;
}
async function verifyPacket(){
 const expected=['PATCH-MANIFEST.json','README.md','apply.mjs',...changes.map(c=>'payload/'+c.path)].sort();
 if(JSON.stringify(await walk(packet))!==JSON.stringify(expected))fail('Unexpected, missing or duplicated packet contents.');
 if(hash(await readFile(join(packet,'apply.mjs')))!==manifest.toolSHA256)fail('Applier SHA-256 mismatch.');
 if(hash(await readFile(join(packet,'README.md')))!==manifest.readmeSHA256)fail('README SHA-256 mismatch.');
 for(const c of changes){const b=await readFile(join(packet,'payload',c.path));if(b.length!==c.bytes||hash(b)!==c.afterSHA256)fail('Payload mismatch: '+c.path);}
}
const args=process.argv.slice(2),[mode,baseArg,targetArg]=args;
if(!['--check','--apply','--verify-target'].includes(mode)||(mode==='--apply'?args.length!==3:args.length!==2))fail('Usage: node apply.mjs --check BASE | --apply BASE NEW_TARGET | --verify-target TARGET');
await verifyPacket();
const source=await realpath(resolve(baseArg));
if(overlap(source,await realpath(packet)))fail('Source and packet must be separate trees.');
if(mode==='--verify-target'){
 await verifySource(source,targetFiles);console.log(JSON.stringify({pass:true,mode,sourceFiles:483,sourceFreezeSHA256:manifest.sourceFreezeSHA256}));
}else{
 await verifySource(source,baseFiles,{ignore:true});
 if(mode==='--check')console.log(JSON.stringify({pass:true,mode,baseFiles:461,targetFiles:483,changedFiles:44,sourceFreezeSHA256:manifest.sourceFreezeSHA256}));
 else{
  const target=resolve(targetArg),parent=await realpath(dirname(target)),canonical=join(parent,relative(dirname(target),target));
  if(overlap(source,canonical)||overlap(await realpath(packet),canonical))fail('Target overlaps source or packet.');
  let exists=true;try{await lstat(target);}catch(e){if(e.code==='ENOENT')exists=false;else throw e;}
  if(exists)fail('Target must not exist; preserve prior targets and failures.');
  await mkdir(target);const changed=new Set(changes.map(c=>c.path));
  for(const [p,want] of Object.entries(targetFiles)){
   const from=changed.has(p)?join(packet,'payload',p):join(source,p),b=await readFile(from);
   if(hash(b)!==want)fail('Input changed before copy: '+p);
   const out=join(target,p);await mkdir(dirname(out),{recursive:true});await writeFile(out,b,{flag:'wx'});
  }
  await verifySource(target,targetFiles);await verifySource(source,baseFiles,{ignore:true});
  console.log(JSON.stringify({pass:true,mode,sourceFiles:483,baseUnchanged:true,sourceFreezeSHA256:manifest.sourceFreezeSHA256,target}));
 }
}
