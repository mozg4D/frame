// Qualification composition only: projection of explicit velocities followed by
// passive scalar transport with an explicit bounded local divergence compromise.
import {assembleMACProjection,projectMACGPU} from './mac-projection-gpu.js';
import {assembleTemperatureAdvection,advectTemperatureGPU} from './temperature-advection-gpu.js';
const error=(code,message)=>Object.assign(new Error(message),{code});
export async function projectTemperatureGPU(context,input,{signal,check=()=>{}}={}){
 const allowed=['flow','temperature','specificHeat','divergenceDriftBudgetK'];
 if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!allowed.includes(k))||!Number.isFinite(input.divergenceDriftBudgetK)||input.divergenceDriftBudgetK<=0||input.divergenceDriftBudgetK>.001||typeof check!=='function')throw error('INVALID_ARGUMENT','Explicit projection/transport inputs and positive local drift budget <=0.001 K required.');
 const device=context?.device,guard=()=>{if(signal?.aborted)throw error('CANCELLED','Projection/transport cancelled.');if(context?.device!==device)throw error('STALE_JOB','Shared device changed.');check();};
 if(input.flow&&['object','function'].includes(typeof input.flow)&&'obstacle' in input.flow)throw error('UNSUPPORTED_DOMAIN','Obstacle projection is not coupled to passive temperature transport.');
 guard();const flow={...input.flow,tolerance:1e-5},plan=assembleMACProjection(flow);
 // Freeze every source array before the first await. The zero-field preflight
 // validates thermal units/ranges without presuming the input is incompressible.
 const scalar={dimensions:[...plan.dimensions],size:[...flow.size],density:flow.density,timeStep:flow.timeStep,specificHeat:input.specificHeat,temperature:Array.from(input.temperature??[]),boundary:['closed','closed','closed'],divergenceDriftBudgetK:input.divergenceDriftBudgetK};
 assembleTemperatureAdvection({...scalar,u:new Float64Array(plan.fields[0].length),v:new Float64Array(plan.fields[1].length),w:new Float64Array(plan.fields[2].length)});
 const projected=await projectMACGPU(context,{...flow,dimensions:[...plan.dimensions],size:[...flow.size],u:plan.fields[0],v:plan.fields[1],w:plan.fields[2]},{signal,check:guard});guard();
 // Never trust the projection's scalar max diagnostic: transport recomputes
 // every physical cell from the ACTUAL dimensional returned velocities.
 const thermal=await advectTemperatureGPU(context,{...scalar,u:projected.u,v:projected.v,w:projected.w},{signal,check:guard});guard();
 return {sceneSolver:false,u:projected.u,v:projected.v,w:projected.w,pressureCorrection:projected.pressure,...thermal,scope:'projection-passive-transport-gpu-qualification',projectionMetrics:projected.metrics,thermalMetrics:thermal.metrics,metrics:{peakGPUBytes:Math.max(projected.metrics.peakGPUBytes,thermal.metrics.peakGPUBytes),retainedGPUBytes:0}};
}
