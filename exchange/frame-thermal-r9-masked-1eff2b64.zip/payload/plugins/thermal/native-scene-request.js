import {filmBoundarySchema,snapshotExteriorFilm} from './exterior-film.js';
// Candidate API request, not native domain/Fan authoring or saved parameters.
const object=properties=>({type:'object',properties,required:Object.keys(properties),additionalProperties:false});
const number={type:'number'},positive={type:'number',exclusiveMinimum:0};
const triple=items=>({type:'array',minItems:3,maxItems:3,items});
const drift={type:'number',exclusiveMinimum:0,maximum:.001};
const settings=object({thermalBoundary:filmBoundarySchema,fluidOccurrence:{type:'integer',minimum:0,maximum:1},fluidDensity:positive,fluidViscosity:positive,solidDensity:positive,initialCelsius:{type:'array',minItems:1,maxItems:4096,items:{type:'number',minimum:-272.15,maximum:1726.85}},timeStep:positive,divergenceDriftBudgetK:drift,fanBox:object({centerMM:triple(number),sizeMM:triple(positive),shutoffPressure:{type:'number',minimum:0},freeFlow:positive,direction:{type:'integer',enum:[-1,1]}})});
settings.required=settings.required.filter(k=>!['initialCelsius','thermalBoundary'].includes(k));
export const nativeSceneSchema=object({dimensions:triple({type:'integer',minimum:2,maximum:16}),cellSizeMM:triple(positive),settings,stepCount:{type:'integer',minimum:1,maximum:10},cumulativeDivergenceDriftBudgetK:drift});
const invalid=()=>{throw Object.assign(Error('Expected explicit two-cuboid duration settings: 2..16 cells per axis, 1..10 steps, total <=0.1 s, positive SI properties and local-X fan, and drift budgets in (0,0.001] K.'),{code:'INVALID_ARGUMENT'});};
// Pure cross-field checks after schema validation, before native capture. A
// missing optional temperature is validated later against native Initial.
export function validateNativeSceneLimits(input,values=input.settings.initialCelsius){
 const count=input.dimensions.reduce((a,b)=>a*b,1);
 if(input.stepCount*input.settings.timeStep>.1||values!==undefined&&(![1,count].includes(values.length)||!Array.from(values).every(v=>Number.isFinite(v)&&v>=-272.15&&v<=1726.85)))invalid();
}
// Validate before the interrupt hook changes any existing job. This small
// contract also protects direct operation calls; Frame validates JSON schemas.
export function snapshotNativeSceneRequest(input,initial){
 const request=snapshotNativeRequest(input,nativeSceneSchema);
 if(request.settings.thermalBoundary!==undefined)request.settings.thermalBoundary=snapshotExteriorFilm(request.settings.thermalBoundary);
 const values=request.settings.initialCelsius??[initial];
 validateNativeSceneLimits(request,values);
 request.settings.initialCelsius=values.slice();
 const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}return v;};
 return freeze(request);
}

export function snapshotNativeRequest(value,schema){
 if(schema.type==='object'){
  if(!value||typeof value!=='object'||![Object.prototype,null].includes(Object.getPrototypeOf(value)))invalid();
  const keys=Reflect.ownKeys(value),d=Object.getOwnPropertyDescriptors(value);
  if(schema.minProperties!==undefined&&keys.length<schema.minProperties||schema.maxProperties!==undefined&&keys.length>schema.maxProperties)invalid();
  if(keys.some(k=>typeof k!=='string'||!Object.hasOwn(schema.properties,k)||!d[k].enumerable||!Object.hasOwn(d[k],'value'))||(schema.required??[]).some(k=>!Object.hasOwn(d,k)))invalid();
  return Object.fromEntries(keys.map(k=>[k,snapshotNativeRequest(d[k].value,schema.properties[k])]));
 }
 if(schema.type==='array'){
  if(!Array.isArray(value)||value.length<schema.minItems||value.length>schema.maxItems||Reflect.ownKeys(value).length!==value.length+1)invalid();
  return Array.from({length:value.length},(_,i)=>{const d=Object.getOwnPropertyDescriptor(value,String(i));if(!d?.enumerable||!Object.hasOwn(d,'value'))invalid();return snapshotNativeRequest(d.value,schema.items);});
 }
 if(schema.type==='string'){if(typeof value!=='string'||schema.minLength!==undefined&&value.length<schema.minLength||schema.maxLength!==undefined&&value.length>schema.maxLength||schema.enum&&!schema.enum.includes(value))invalid();return value;}
 if(typeof value!=='number'||!Number.isFinite(value)||schema.type==='integer'&&!Number.isInteger(value)||schema.minimum!==undefined&&value<schema.minimum||schema.maximum!==undefined&&value>schema.maximum||schema.exclusiveMinimum!==undefined&&value<=schema.exclusiveMinimum||schema.enum&&!schema.enum.includes(value))invalid();
 return value;
}
