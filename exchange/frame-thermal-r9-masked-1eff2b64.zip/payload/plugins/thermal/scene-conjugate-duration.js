import {snapshotExteriorFilm,boundaryDataProperty,plainData,exteriorExchange,exteriorFaces} from './exterior-film.js';
// Internal bounded-duration pipeline. Reused by the native owner jobs; no new solver or UI.
import {assembleConjugateHeatGPU,stepConjugateHeatGPU} from './conjugate-heat-gpu.js';
import {createSceneConjugatePipeline} from './scene-conjugate.js';
import {sharedThermalDeviceState} from './scene-identity.js';
const fail=(code,message)=>{throw Object.assign(new Error(message),{code});};
const need=(ok,code,message)=>{if(!ok)fail(code,message);};
const fields=['temperature','u','v','w'];
const losses=['initialProjectionLoss','fanInitializationLoss','fanProjectionLoss','viscousStepLoss','viscousDissipation'];
const finite=x=>typeof x==='number'&&Number.isFinite(x);
function contract(stepCount,timeStep,budget){
 need(Number.isInteger(stepCount)&&stepCount>=1&&stepCount<=10&&finite(timeStep)&&timeStep>0&&timeStep*stepCount<=.1&&finite(budget)&&budget>0&&budget<=.001,'INVALID_ARGUMENT','Duration requires 1..10 steps, positive timeStep, total time <=0.1 s and explicit cumulative divergence drift budget (0,0.001] K.');
}
const sum=a=>{let s=0,c=0;for(const x of a){const y=x-c,t=s+y;c=(t-s)-y;s=t;}return s;};
const energy=(t,capacity)=>sum(Array.from(t,(x,i)=>x*capacity[i]));
function kinetic(input,state){const volume=input.size.reduce((s,x,a)=>s*x/input.dimensions[a],1);return sum(['u','v','w'].flatMap(k=>Array.from(state[k],v=>.5*input.fluid.density*volume*v*v)));}

// Injection is for tests only. Production always invokes the existing GPU chain.
export function createConjugateDurationStepper(stepGPU=stepConjugateHeatGPU){
 return async function advance(context,input,{stepCount,cumulativeDivergenceDriftBudgetK,signal,check=()=>{}}={}){
  contract(stepCount,input?.timeStep,cumulativeDivergenceDriftBudgetK);
  need(finite(input.divergenceDriftBudgetK)&&input.divergenceDriftBudgetK>0&&input.divergenceDriftBudgetK<=.001,'INVALID_ARGUMENT','Original per-step divergence budget must be numeric and in (0,0.001] K.');
  need(typeof check==='function'&&(!signal||(typeof signal.addEventListener==='function'&&typeof signal.removeEventListener==='function')),'INVALID_ARGUMENT','Invalid duration lifecycle guards.');
  const device=context?.device,loss=sharedThermalDeviceState(device);
  const guard=()=>{need(!signal?.aborted,'CANCELLED','Conjugate duration cancelled.');need(!loss.lost,'DEVICE_LOST','Shared device lost.');need(context?.device===device,'STALE_JOB','Shared device changed.');check();};
  guard();
  // Array.from, unlike structuredClone, detaches SharedArrayBuffer inputs too.
  boundaryDataProperty(input,'boundary');
  const state={...input,dimensions:Array.from(input.dimensions),size:Array.from(input.size),fluid:{...input.fluid},solid:{...input.solid},fan:structuredClone(input.fan),...(input.boundary!==undefined&&input.boundary!=='adiabatic'?{boundary:snapshotExteriorFilm(input.boundary)}:{}),solidSourceDensity:Array.from(input.solidSourceDensity)};
  for(const k of fields)state[k]=Float64Array.from(input[k]);
  state.divergenceDriftBudgetK=Math.min(input.divergenceDriftBudgetK,cumulativeDivergenceDriftBudgetK/stepCount);
  input=null; // Release borrowed initial fields once their private snapshot exists.
  let plan=assembleConjugateHeatGPU(state);
  const capacities=plan.capacities,power=plan.power,lengths=fields.map(k=>state[k].length),sourcePower=sum(power),initialEnergy=energy(state.temperature,capacities),initialKinetic=kinetic(state,state),fluidCells=state.fluidCellsX*state.dimensions[1]*state.dimensions[2];
  const initialRegions=[true,false].map(fluid=>sum(Array.from(state.temperature,(t,i)=>(i%state.dimensions[0]<state.fluidCellsX)===fluid?t*capacities[i]:0)));
  const film=state.boundary!==undefined&&state.boundary!=='adiabatic',boundaryGrid=film?{count:plan.grid.count,timeStep:plan.grid.timeStep,exteriorFilm:plan.grid.exteriorFilm,boundaryAccounting:Float64Array.from({length:2*plan.grid.count},(_,i)=>plan.grid.accounting[4*Math.floor(i/2)+i%2])}:null,activeFilm=boundaryGrid?.exteriorFilm.some(e=>e.g>0)??false;
  plan=null;
  const localDrift=new Float64Array(fluidCells),mechanical=Object.fromEntries(['midpointWork',...losses,'balanceAllowance'].map(k=>[k,0])),stepWallMs=[];
  let candidate=null,peakGPUBytes=0,thermalBalanceAllowance=0,interfaceEnergy=0,regionalAllowance=[0,0],sumMaxStepDriftK=0,sourceEnergy=0,conductionResidualConsistencyK=0,thermalTransportConsistencyK=0;
  let boundaryEnergyOutJ=0,absoluteBoundaryEnergyJ=0;const boundaryEnergyByFaceJ=Object.fromEntries(exteriorFaces.map(f=>[f,0])),regionalBoundaryEnergy=[0,0];
  const started=performance.now();
  try{
   for(let i=0;i<stepCount;i++){
    guard();const t=performance.now();candidate=await stepGPU(context,state,{signal,check:guard});guard();
    need(candidate?.temperatureUnit==='K','INVALID_RESULT','Expected Kelvin duration state.');
    fields.forEach((k,a)=>need(candidate[k] instanceof Float64Array&&candidate[k].length===lengths[a]&&candidate[k].every(x=>finite(x)&&(k!=='temperature'||x>=1&&x<=2000)),'INVALID_RESULT','Incomplete or invalid duration field.'));
    const th=candidate.thermal,m=candidate.mechanical,ad=th?.advection,co=th?.conduction;
    need(th&&ad&&co&&m&&[th.sourceEnergy,th.balanceAllowance,co.interfacePowerFluidToSolid,co.maxResidualK,ad.energyAllowance,ad.maxTemperatureErrorAllowance,m.input,m.afterProjection,m.balanceAllowance,...['midpointWork',...losses].map(k=>m[k])].every(finite)&&th.balanceAllowance>=0&&m.balanceAllowance>=0,'INVALID_RESULT','Missing validated step accounting.');
    need(ad.localDivergenceDriftK instanceof Float64Array&&ad.localDivergenceDriftK.length===fluidCells,'INVALID_RESULT','Missing local divergence drift.');
    const scale=256*Number.EPSILON*Math.max(1,Math.abs(sourcePower*state.timeStep));
    need(Math.abs(th.sourceEnergy-sourcePower*state.timeStep)<=scale,'NUMERICAL_RANGE','Duration step changed source energy.');
    const priorEnergy=energy(state.temperature,capacities),nextEnergy=energy(candidate.temperature,capacities),priorKinetic=kinetic(state,state),nextKinetic=kinetic(state,candidate);
    const roundoff=256*Number.EPSILON*Math.max(1,initialEnergy,nextEnergy);
    let exchange=null;
    if(film){exchange=exteriorExchange(boundaryGrid,candidate.temperature);
     const agree=(a,b)=>finite(a)&&Math.abs(a-b)<=256*Number.EPSILON*Math.max(1,Math.abs(a),Math.abs(b));
     need(agree(co.boundaryEnergyOutJ,exchange.boundaryEnergyOutJ)&&agree(th.boundaryEnergyOutJ,exchange.boundaryEnergyOutJ)&&agree(co.boundaryPowerOutW,exchange.boundaryPowerOutW)&&agree(co.absoluteBoundaryEnergyJ,exchange.absoluteBoundaryEnergyJ)&&exteriorFaces.every(f=>agree(co.boundaryPowerByFaceW?.[f],exchange.boundaryPowerByFaceW[f])&&agree(co.boundaryEnergyByFaceJ?.[f],exchange.boundaryEnergyByFaceJ[f])),'INVALID_RESULT','Step exterior exchange does not match actual returned temperatures.');
     boundaryEnergyOutJ+=exchange.boundaryEnergyOutJ;absoluteBoundaryEnergyJ+=exchange.absoluteBoundaryEnergyJ;for(const f of exteriorFaces)boundaryEnergyByFaceJ[f]+=exchange.boundaryEnergyByFaceJ[f];
     for(let a=0;a<2;a++){const q=sum(Array.from(exchange.cellPower,(q,j)=>(j%state.dimensions[0]<state.fluidCellsX)===(a===0)?q:0)),region=co[a?'solid':'fluid'];need(agree(region?.boundaryPowerOutW,q)&&agree(region?.boundaryEnergyOutJ,q*state.timeStep),'INVALID_RESULT','Step regional exterior exchange does not match its cells.');regionalBoundaryEnergy[a]+=q*state.timeStep;}
    }
    need(Math.abs(nextEnergy-priorEnergy-th.sourceEnergy+(exchange?.boundaryEnergyOutJ??0))<=th.balanceAllowance+roundoff,'NUMERICAL_RANGE','Actual step thermal balance failed.');
    need(Math.abs(m.input-priorKinetic)<=256*Number.EPSILON*Math.max(1,priorKinetic)&&Math.abs(m.afterProjection-nextKinetic)<=256*Number.EPSILON*Math.max(1,nextKinetic),'NUMERICAL_RANGE','Step mechanical endpoints do not match actual state.');
    let maxDrift=0;
    for(let j=0;j<fluidCells;j++){
     const drift=ad.localDivergenceDriftK[j];need(finite(drift)&&drift>=0&&drift<=state.divergenceDriftBudgetK,'DIVERGENCE_BUDGET_EXCEEDED','Invalid per-step local divergence drift.');localDrift[j]+=drift;maxDrift=Math.max(maxDrift,drift);
    }
    sumMaxStepDriftK+=maxDrift;
    need(sumMaxStepDriftK<=cumulativeDivergenceDriftBudgetK*(1+32*Number.EPSILON),'DIVERGENCE_BUDGET_EXCEEDED','Cumulative divergence drift allowance exceeded.');
    for(const k of Object.keys(mechanical))mechanical[k]+=m[k];
    sourceEnergy+=th.sourceEnergy;thermalBalanceAllowance+=th.balanceAllowance;interfaceEnergy+=co.interfacePowerFluidToSolid*state.timeStep;
    for(let a=0;a<2;a++){const r=co[a?'solid':'fluid'];need(r&&finite(r.balanceAllowance)&&r.balanceAllowance>=0,'INVALID_RESULT','Missing regional accounting.');regionalAllowance[a]+=r.balanceAllowance+(a?0:ad.energyAllowance);}
    conductionResidualConsistencyK+=co.maxResidualK;thermalTransportConsistencyK+=ad.maxTemperatureErrorAllowance;
    // Replace only after a fully validated step. No partial state escapes even
    // if a later step fails; the caller must start a fresh job, never resume it.
    for(const k of fields)state[k]=candidate[k];
    peakGPUBytes=Math.max(peakGPUBytes,candidate.metrics?.peakGPUBytes??0);stepWallMs.push(performance.now()-t);
    if(i+1<stepCount){candidate=null;await new Promise(resolve=>setTimeout(resolve,0));guard();}
   }
   guard();const completedTime=stepCount*state.timeStep,expectedSourceEnergy=sourcePower*completedTime,finalEnergy=energy(state.temperature,capacities),thermalEnergyChange=finalEnergy-initialEnergy,thermalBalanceError=thermalEnergyChange-expectedSourceEnergy+boundaryEnergyOutJ;
   const roundoff=256*Number.EPSILON*Math.max(1,initialEnergy,finalEnergy);
   // Explicit energy gate; no accumulation of a per-step 0.001 K accuracy claim.
   const grossDriveEnergy=film?sum(Array.from(power,p=>Math.abs(p*completedTime)))+absoluteBoundaryEnergyJ:Math.abs(expectedSourceEnergy);
   const acceptanceDrive=activeFilm?grossDriveEnergy:Math.abs(expectedSourceEnergy);
   if(acceptanceDrive!==0)thermalBalanceAllowance=Math.min(thermalBalanceAllowance,.001*acceptanceDrive);
   thermalBalanceAllowance+=roundoff;
   need(finite(thermalBalanceAllowance)&&Math.abs(thermalBalanceError)<=thermalBalanceAllowance&&Math.abs(sourceEnergy-expectedSourceEnergy)<=256*Number.EPSILON*Math.max(1,Math.abs(expectedSourceEnergy)),'NUMERICAL_RANGE','Cumulative duration energy balance is unresolved.');
   const finalKinetic=kinetic(state,state);mechanical.initialEnergy=initialKinetic;mechanical.finalEnergy=finalKinetic;mechanical.balanceError=finalKinetic-initialKinetic-mechanical.midpointWork+sum(losses.map(k=>mechanical[k]));mechanical.balanceAllowance+=256*Number.EPSILON*Math.max(1,finalKinetic,initialKinetic,Math.abs(mechanical.midpointWork));
   need(Object.values(mechanical).every(finite)&&Math.abs(mechanical.balanceError)<=mechanical.balanceAllowance,'NUMERICAL_RANGE','Cumulative mechanical balance failed.');
   const regions=[true,false].map((fluid,a)=>{const after=sum(Array.from(state.temperature,(t,i)=>(i%state.dimensions[0]<state.fluidCellsX)===fluid?t*capacities[i]:0)),balanceError=after-initialRegions[a]+(fluid?1:-1)*interfaceEnergy+regionalBoundaryEnergy[a]-(fluid?0:expectedSourceEnergy),balanceAllowance=regionalAllowance[a]+roundoff;need(Math.abs(balanceError)<=balanceAllowance,'NUMERICAL_RANGE','Cumulative reciprocal interface balance failed.');return {energyBefore:initialRegions[a],energyAfter:after,balanceError,balanceAllowance,...(film?{boundaryEnergyOutJ:regionalBoundaryEnergy[a]}:{})};});
   guard();return {...candidate,scope:'two-cuboid-conjugate-duration',duration:{completedSteps:stepCount,completedTime,timeStep:state.timeStep,sourcePower,sourceEnergy:expectedSourceEnergy,thermalEnergyChange,thermalBalanceError,thermalBalanceAllowance,interfaceEnergyFluidToSolid:interfaceEnergy,interfaceEnergySolidToFluid:-interfaceEnergy,fluid:regions[0],solid:regions[1],mechanical,cumulativeDivergenceDriftAllowanceK:cumulativeDivergenceDriftBudgetK,effectiveStepDivergenceDriftBudgetK:state.divergenceDriftBudgetK,maxLocalCumulativeDivergenceDriftK:Math.max(...localDrift),sumMaxStepDivergenceDriftK:sumMaxStepDriftK,conductionResidualConsistencyK,thermalTransportConsistencyK,temperatureAccuracyGuaranteeK:null,accuracy:'No duration accuracy guarantee; cumulative equation and drift checks are consistency gates, not a truncation error estimate.',boundaryEnergy:boundaryEnergyOutJ,...(film?{boundaryEnergyOutJ,absoluteBoundaryEnergyJ,boundaryEnergyByFaceJ,grossDriveEnergy,netBoundaryEnergyResolved:boundaryEnergyOutJ===0?absoluteBoundaryEnergyJ===0:Math.abs(boundaryEnergyOutJ)>1e-3*absoluteBoundaryEnergyJ}:{})},metrics:{peakGPUBytes,retainedGPUBytes:0,stepWallMs,maxStepWallMs:Math.max(...stepWallMs),durationWallMs:performance.now()-started,retainedStateCount:1}};
  }finally{candidate=null;for(const k of fields)state[k]=null;}
 };
}
export const advanceConjugateHeatGPU=createConjugateDurationStepper();
export function createSceneConjugateDurationPipeline({classify,stepGPU=stepConjugateHeatGPU,current,mapInputs}={}){
 return function advance(context,hash,request={}){
  need(request&&typeof request==='object'&&!Array.isArray(request)&&!Object.keys(request).some(k=>!['dimensions','cellSizeMM','settings','signal','stepCount','cumulativeDivergenceDriftBudgetK'].includes(k)),'INVALID_ARGUMENT','Explicit bounded duration scene request required.');
  request=plainData(request,['dimensions','cellSizeMM','settings','signal','stepCount','cumulativeDivergenceDriftBudgetK']);
  const {stepCount,cumulativeDivergenceDriftBudgetK,...sceneRequest}=request;
  const time=sceneRequest.settings&&Object.getOwnPropertyDescriptor(sceneRequest.settings,'timeStep');
  need(time&&Object.hasOwn(time,'value')&&time.enumerable,'INVALID_ARGUMENT','Duration timeStep must be an own data field.');
  contract(stepCount,time.value,cumulativeDivergenceDriftBudgetK);
  const step=createConjugateDurationStepper(stepGPU);
  return createSceneConjugatePipeline({classify,current,mapInputs,stepGPU:(context,input,guards)=>step(context,input,{...guards,stepCount,cumulativeDivergenceDriftBudgetK}),scope:'two-cuboid-conjugate-duration'})(context,hash,sceneRequest);
 };
}
export const advanceTouchingSceneConjugateGPU=createSceneConjugateDurationPipeline();
