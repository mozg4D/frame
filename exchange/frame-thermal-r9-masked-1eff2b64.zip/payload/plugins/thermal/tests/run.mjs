import {launch,ready} from '../../../tools/browser.mjs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {savedFanSourceSnapshot} from './native-saved-fan-browser.mjs';
import {pluginChecks} from './index.mjs';

const sources=await savedFanSourceSnapshot();
let session,result;
try {
  session=await launch({headless:process.argv.includes('--headless')});
  // Allow isolated development without editing the shared catalogue.
  const catalogue=JSON.parse(await readFile(new URL('../../index.json',import.meta.url),'utf8'));
  if(!catalogue.includes('thermal/plugin.json')){
    catalogue.push('thermal/plugin.json');
    await session.page.route('**/plugins/index.json',route=>route.fulfill({contentType:'application/json',body:JSON.stringify(catalogue)}));
    await session.page.reload();
  }
  await ready(session.page);
  const errors=[];session.page.on('pageerror',e=>errors.push(e.stack));
  await session.page.evaluate(()=>{window.__thermalGPU=[];window.__thermalLost=null;const d=frameEngine.renderer.device;d.addEventListener('uncapturederror',e=>__thermalGPU.push(e.error.message));d.lost.then(e=>__thermalLost={reason:e.reason,message:e.message});d.pushErrorScope('validation');});
  result=await pluginChecks(session.page);
  result.gpu=await session.page.evaluate(async()=>({validation:(await frameEngine.renderer.device.popErrorScope())?.message||null,uncaptured:__thermalGPU,lost:__thermalLost}));
  result.errors=errors;result.pass&&=!errors.length&&!result.gpu.validation&&!result.gpu.uncaptured.length&&!result.gpu.lost;
} catch(e) {result={pass:false,checks:[],timings:[],error:e.stack,hardwareVerified:false};}
finally {await session?.close();}
result.sources=sources;result.sourcesAfter=await savedFanSourceSnapshot();result.sourcesUnchanged=JSON.stringify(sources)===JSON.stringify(result.sourcesAfter);
if(!result.sourcesUnchanged){result.pass=false;result.sourceError='Source bytes changed during the Thermal suite; no hardware qualification applies.';}
result.hardwareVerified=result.pass===true;
await mkdir(new URL('../../../tests/results/',import.meta.url),{recursive:true});
await writeFile(new URL('../../../tests/results/thermal.json',import.meta.url),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;
