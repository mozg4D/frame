// Focused, isolated real-hardware gate. Never run implicitly on import.
import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {launch,ready} from '../../../tools/browser.mjs';
import {macProjectionGPUChecks} from './mac-projection-gpu-checks.mjs';
import {maskedProjectionGPUChecks} from './masked-projection-gpu-checks.mjs';
import {maskedFixture,fieldError} from './masked-projection-fixture.mjs';
import {projectMAC} from './mac-projection-reference.mjs';
import {asReference} from './masked-projection-fixture.mjs';
const root=new URL('../../../',import.meta.url);
export async function maskedProjectionSourceSnapshot(){const files={};async function walk(url,prefix=''){for(const e of (await readdir(url,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){if(['node_modules','.git','results'].includes(e.name))continue;const path=prefix+e.name;if(e.isDirectory())await walk(new URL(e.name+'/',url),path+'/');else if(e.isFile())files[path]=createHash('sha256').update(await readFile(new URL(e.name,url))).digest('hex');}}await walk(root);return files;}
export async function maskedProjectionBrowserChecks(parent,check,timed){
 const context=await parent.context().browser().newContext({viewport:{width:1280,height:900},serviceWorkers:'block'}),page=await context.newPage(),errors=[],consoleErrors=[];page.on('pageerror',e=>errors.push(e.stack||String(e)));page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});
 let installed=false;
 try{
  await page.goto(parent.url());await ready(page);
  const hardware=await page.evaluate(async()=>{
   const {macProjectionWGSL}=await import('/plugins/thermal/mac-projection-gpu.js'),d=frameEngine.renderer.device,info=d.adapterInfo;
   window.__maskedDevice=d;window.__maskedErrors=[];window.__maskedLost=null;window.__maskedStats={created:0,destroyed:0,live:0,peak:0};
   d.addEventListener('uncapturederror',e=>__maskedErrors.push(e.error.message));d.lost.then(e=>__maskedLost={reason:e.reason,message:e.message});d.pushErrorScope('validation');
   const original={buffer:d.createBuffer.bind(d),shader:d.createShaderModule.bind(d),pipeline:d.createComputePipelineAsync.bind(d)},modules=new WeakSet();window.__maskedRestore=()=>{d.createBuffer=original.buffer;d.createShaderModule=original.shader;d.createComputePipelineAsync=original.pipeline;};
   window.__maskedPause=async stage=>{const g=window.__maskedGate;if(g?.stage===stage&&!g.entered){g.entered=true;await g.promise;}};
   d.createShaderModule=options=>{const m=original.shader(options);if(options.code===macProjectionWGSL)modules.add(m);return m;};
   d.createComputePipelineAsync=async options=>{if(modules.has(options.compute.module))await __maskedPause('pipeline');return original.pipeline(options);};
   const target=new URL('/plugins/thermal/mac-projection-gpu.js',location.href).href;
   d.createBuffer=options=>{const b=original.buffer(options),caller=(new Error().stack||'').split('\n').slice(1).map(line=>line.match(/(https?:\/\/[^\s)]+):\d+:\d+\)?$/)?.[1]).find(Boolean);if(caller!==target)return b;
    const stats=__maskedStats,destroy=b.destroy.bind(b),map=b.mapAsync.bind(b);let dead=false;stats.created++;stats.live+=options.size;stats.peak=Math.max(stats.peak,stats.live);b.destroy=()=>{if(!dead){dead=true;stats.destroyed++;stats.live-=options.size;}destroy();};b.mapAsync=async(...args)=>{await map(...args);await __maskedPause('map');};return b;};
   return info?Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(k=>[k,info[k]])):null;
  });installed=true;
  check('masked projection uses the actual identifiable nonfallback shared device',hardware&&Object.values(hardware).some(v=>typeof v==='string'&&v)&&!hardware.isFallbackAdapter&&!/swiftshader|llvmpipe|lavapipe|software/i.test(JSON.stringify(hardware)),hardware);
  await macProjectionGPUChecks(page,check,timed); // Preserve the complete old all-fluid fixture.
  await maskedProjectionGPUChecks(page,check,timed);
  const fixture=maskedFixture(),expected=projectMAC(asReference(fixture));
  for(const kind of ['mutation','cancel-pipeline','cancel-map','stale-map','replace']){
   await page.evaluate(async({input,kind})=>{let release;const promise=new Promise(resolve=>release=resolve);window.__maskedGate={stage:kind.endsWith('map')?'map':'pipeline',promise,release,entered:false};window.__maskedController=new AbortController();window.__maskedCurrent=true;window.__maskedInput=input;window.__maskedContext={device:frameEngine.renderer.device};
    const {projectMACGPU}=await import('/plugins/thermal/mac-projection-gpu.js');window.__maskedPending=projectMACGPU(__maskedContext,input,{signal:__maskedController.signal,check(){if(!__maskedCurrent)throw Object.assign(new Error('source changed'),{code:'STALE_JOB'});}}).then(r=>({...r,u:Array.from(r.u),v:Array.from(r.v),w:Array.from(r.w)}),e=>({error:e.code||e.message}));
   },{input:fixture.input,kind});
   await page.waitForFunction(()=>window.__maskedGate?.entered,{},{timeout:15000});
   const result=await timed('masked actual GPU lifecycle '+kind,15000,()=>page.evaluate(async kind=>{if(kind==='mutation'){__maskedInput.obstacle.min.fill(0);__maskedInput.obstacle.max.fill(99);__maskedInput.dimensions.fill(99);for(const k of ['u','v','w'])__maskedInput[k].fill(99);}else if(kind.startsWith('cancel'))__maskedController.abort();else if(kind==='replace')__maskedContext.device=null;else __maskedCurrent=false;__maskedGate.release();const r=await __maskedPending;__maskedGate=null;return r;},kind));
   if(kind==='mutation')check('caller mutation preserves pre-await geometry and field snapshot',!result.error&&fieldError(result,expected)<3e-5,result.error);else check(kind+' refuses result publication',result.error===(kind.startsWith('cancel')?'CANCELLED':'STALE_JOB'),result);
   const stats=await page.evaluate(()=>({...__maskedStats}));check(kind+' releases every actual projection allocation',stats.created>0&&stats.created===stats.destroyed&&stats.live===0,stats);
  }
  const gpu=await page.evaluate(async()=>({validation:(await __maskedDevice.popErrorScope())?.message||null,uncaptured:__maskedErrors,lost:__maskedLost,sameDevice:frameEngine.renderer.device===__maskedDevice,stats:{...__maskedStats}}));installed=false;await page.evaluate(()=>__maskedRestore());
  check('focused projection actual owned-buffer peak stays within 14436 bytes',gpu.stats.peak>0&&gpu.stats.peak<=14436&&gpu.stats.live===0&&gpu.stats.created===gpu.stats.destroyed,gpu.stats);
  check('masked projection has no JS/console/WebGPU errors or shared-device replacement',!errors.length&&!consoleErrors.length&&!gpu.validation&&!gpu.uncaptured.length&&!gpu.lost&&gpu.sameDevice,{errors,consoleErrors,gpu});
  return {hardware,gpu,scope:'Projection only, one explicit strictly interior cuboid. Not obstacle viscosity/advection/fan/heat, native inference, scene solve, R9 qualification or aggregate application verification.'};
 }finally{if(installed)await page.evaluate(async()=>{window.__maskedGate?.release();await window.__maskedPending;await window.__maskedDevice?.popErrorScope();window.__maskedRestore?.();}).catch(()=>{});await context.close();}
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const checks=[],timings=[],sources=await maskedProjectionSourceSnapshot();let session,result;
 const check=(name,pass,detail)=>{checks.push({name,pass:!!pass,detail});if(!pass)throw Error(name+': '+JSON.stringify(detail));},timed=async(name,limit,fn)=>{const start=performance.now(),value=await fn(),ms=performance.now()-start;timings.push({name,ms,limit});check(name+' completed-operation budget',ms<limit,{ms,limit});return value;};
 try{session=await launch({headless:process.argv.includes('--headless')});const evidence=await maskedProjectionBrowserChecks(session.page,check,timed);result={pass:true,hardwareVerified:true,checks,timings,evidence};}catch(e){result={pass:false,hardwareVerified:false,checks,timings,error:e.stack};}finally{await session?.close();}
 result.sources=sources;result.sourcesAfter=await maskedProjectionSourceSnapshot();result.sourcesUnchanged=JSON.stringify(result.sources)===JSON.stringify(result.sourcesAfter);if(!result.sourcesUnchanged){result.pass=false;result.hardwareVerified=false;result.sourceError='Source bytes changed during the focused gate.';}
 await mkdir(new URL('../../../tests/results/',import.meta.url),{recursive:true});await writeFile(new URL('../../../tests/results/thermal-masked-projection.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;
}
