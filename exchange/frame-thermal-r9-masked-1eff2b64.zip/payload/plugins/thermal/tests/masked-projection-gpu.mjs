import {assembleConjugateHeatGPU} from '../conjugate-heat-gpu.js';
import {stepForcedTemperatureGPU} from '../forced-temperature-gpu.js';
import {stepForcedHeatGPU} from '../forced-heat-gpu.js';
import {spawnSync} from 'node:child_process';
import {sharedThermalDeviceState} from '../scene-identity.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {assembleMACProjection,validateMACProjection,validateMaskedPhysicalProjection,projectMACGPU,macProjectionWGSL} from '../mac-projection-gpu.js';
import {projectTemperatureGPU} from '../project-temperature-gpu.js';
import {assembleMACFan} from '../mac-fan-gpu.js';
import {assembleMACViscosity} from '../mac-viscosity-gpu.js';
import {projectMAC} from './mac-projection-reference.mjs';
import {deviceEmulator} from './mac-projection-device-emulator.mjs';
import {maskedFixture,asReference,velocityKeys,fieldError,circulation,addGradient} from './masked-projection-fixture.mjs';
globalThis.GPUBufferUsage={STORAGE:1,COPY_DST:2,COPY_SRC:4,UNIFORM:8,MAP_READ:16};globalThis.GPUShaderStage={COMPUTE:1};globalThis.GPUMapMode={READ:1};
const cleanup=fake=>{const s=fake.stats();assert.equal(s.created,s.destroyed);assert.equal(s.live,0);assert.equal(s.scopes,0);};
const solve=async f=>{const fake=deviceEmulator(),r=await projectMACGPU({device:fake.device},f.input);cleanup(fake);assert.equal(fake.stats().peak,r.metrics.peakGPUBytes);return r;};
const cases=[[[3,3,3],{min:[1,1,1],max:[2,2,2]}],[[5,4,3],{min:[1,1,1],max:[3,3,2]}],[[6,5,4],{min:[1,1,1],max:[5,4,3]}]];
test('exact face ownership, reciprocal GPU masks, graph operator and RHS match independent geometry',()=>{
 for(const [d,o] of cases){const f=maskedFixture(d,o),p=assembleMACProjection(f.input),expected=f.faces.filter(e=>e.open),lookup=new Map(p.edges.map(e=>[`${e.axis}:${e.index}`,e]));assert.equal(p.edges.length,expected.length);assert.deepEqual(p.solid,f.solid);assert.equal(p.fluidCount,p.n-f.solid.reduce((a,b)=>a+b,0));
  const masks=new Uint32Array(p.n),rhs=new Float64Array(p.n),pressure=Float64Array.from({length:p.n},(_,i)=>Math.sin(i*.3)),edgeOperator=new Float64Array(p.n);
  for(const e of expected){const actual=lookup.get(`${e.axis}:${e.index}`);assert.equal(actual.left,e.left);assert.equal(actual.right,e.right);masks[e.left]|=1<<(2*e.axis+1);masks[e.right]|=1<<(2*e.axis);const q=Math.fround(f.input[velocityKeys[e.axis]][e.index]/p.speed)*p.inv[e.axis];rhs[e.left]-=q;rhs[e.right]+=q;const flux=p.inv[e.axis]**2*(pressure[e.left]-pressure[e.right]);edgeOperator[e.left]+=flux;edgeOperator[e.right]-=flux;}
  assert.deepEqual(p.faceMasks,masks);assert.deepEqual(p.rhs,Float32Array.from(rhs));
  const strides=[1,d[0],d[0]*d[1]];for(let i=0;i<p.n;i++){let sum=0;for(let a=0;a<3;a++)for(let side=0;side<2;side++)if(p.faceMasks[i]&(1<<(2*a+side)))sum+=p.inv[a]**2*(pressure[i]-pressure[i+(side?1:-1)*strides[a]]);assert.ok(Math.abs(sum-edgeOperator[i])<1e-14);if(f.solid[i])assert.equal(sum,0);}
 }
 assert.match(macProjectionWGSL,/faceMasks\[i\]/);assert.match(macProjectionWGSL,/if\(s.x==0.\)\{next\[i\]=0.;return;\}/);
});
test('completed masked orchestration compares returned velocity and pressure gradients to independent CPU reference',async()=>{
 for(const [d,o] of cases){const f=maskedFixture(d,o),ref=projectMAC(asReference(f)),start=performance.now(),r=await solve(f),ms=performance.now()-start;
  assert.ok(fieldError(r,ref)<3e-5);assert.equal(r.scope,'closed-interior-cuboid-mac-gpu-qualification');assert.equal(r.sceneSolver,false);assert.match(r.pressureConvention,/not physical pressure/);assert.deepEqual(r.obstacle,o);
  for(const e of f.faces){if(!e.open)assert.equal(r[velocityKeys[e.axis]][e.index],0);else assert.ok(Math.abs((r.pressure[e.right]-r.pressure[e.left])-(ref.pressure[e.right]-ref.pressure[e.left]))<.002);}
  for(let i=0;i<f.solid.length;i++)if(f.solid[i])assert.equal(r.pressure[i],0);
  assert.ok(r.metrics.maxDivergence<=r.metrics.maxDivergenceAllowance);assert.ok(r.metrics.energyAfter<=r.metrics.energyBefore);assert.ok(ms<5000);console.log(`masked completed ${d.join('x')}: ${ms.toFixed(2)} ms`);
 }
});
test('zero, pure gradient, circulation and gradient plus circulation retain the intended nullspace',async()=>{
 const f=circulation(maskedFixture()),expected=structuredClone(f.input),r=await solve(f);assert.ok(fieldError(r,expected)<1e-7);assert.ok(r.metrics.energyAfter>0);
 addGradient(f);const mixed=await solve(f);assert.ok(fieldError(mixed,expected)<3e-5);
 let dot=0,norm=0;for(const key of velocityKeys)for(let i=0;i<mixed[key].length;i++){dot+=mixed[key][i]*(f.input[key][i]-mixed[key][i]);norm+=f.input[key][i]**2;}assert.ok(Math.abs(dot)<1e-4*norm);
 const gradient=circulation(maskedFixture(),0);addGradient(gradient);const g=await solve(gradient);assert.ok(fieldError(g,circulation(maskedFixture(),0).input)<3e-5);
 const z=await solve(circulation(maskedFixture(),0));assert.equal(z.metrics.energyBefore,0);assert.equal(z.metrics.energyAfter,0);assert.equal(z.metrics.maxDivergence,0);
});
test('all blocked faces, including obstacle interior, reject nonzero input before allocation',async()=>{
 const f=maskedFixture([5,5,5],{min:[1,1,1],max:[4,4,4]});let rejected=0;for(const e of f.faces)if(!e.open){const key=velocityKeys[e.axis];f.input[key][e.index]=1e-10;assert.throws(()=>assembleMACProjection(f.input),{code:'INVALID_BOUNDARY'});f.input[key][e.index]=0;rejected++;}assert.ok(rejected>200);
 const fake=deviceEmulator();f.input.u[0]=1;await assert.rejects(projectMACGPU({device:fake.device},f.input),{code:'INVALID_BOUNDARY'});assert.equal(fake.stats().created,0);
});
test('malformed, partial, multiple, touching, rotated, disconnected and arbitrary-mask geometry reject',()=>{
 const f=maskedFixture().input;for(const obstacle of [null,undefined,[],{},[{min:[1,1,1],max:[2,2,2]}],{min:[1,,1],max:[2,2,2]},{min:[1,1,1],max:[2,2]},{min:[1.5,1,1],max:[2,2,2]},{min:[1,1,1],max:[2,2,2],rotation:[0,0,0]},{min:[0,1,1],max:[2,2,2]},{min:[1,1,1],max:[5,3,2]},{min:[2,1,1],max:[2,2,2]},{min:[1,1,1],max:[Infinity,2,2]}])assert.throws(()=>assembleMACProjection({...f,obstacle}));
 for(const extra of [{solid:new Uint8Array(60)},{obstacles:[]},{cutCells:[]}])assert.throws(()=>assembleMACProjection({...f,...extra}),{code:'INVALID_ARGUMENT'});
 assert.throws(()=>assembleMACProjection({...f,dimensions:[2,2,2]}),{code:'UNSUPPORTED_DOMAIN'});
});
test('obstacle inputs are not silently admitted by all-fluid transport, viscosity or fan',async()=>{
 const input=maskedFixture().input;const inherited=Object.assign(Object.create({obstacle:input.obstacle}),input);delete inherited.obstacle;await assert.rejects(projectTemperatureGPU({}, {flow:inherited,temperature:[300],specificHeat:1000,divergenceDriftBudgetK:.0001}),{code:'UNSUPPORTED_DOMAIN'});await assert.rejects(projectTemperatureGPU({}, {flow:input,temperature:[300],specificHeat:1000,divergenceDriftBudgetK:.0001}),{code:'UNSUPPORTED_DOMAIN'});
 assert.throws(()=>assembleMACFan({...input,sheet:{x:2,y:[1,2],z:[1,2]},shutoffPressure:1,freeFlow:1,direction:1}));assert.throws(()=>assembleMACViscosity({...input,viscosity:.01}));
});
test('caller input, cuboid and arrays are snapshotted before the first await',async()=>{
 const f=maskedFixture(),baseline=structuredClone(f),expected=await solve(baseline);let mutated=false;const fake=deviceEmulator({afterPipeline(){if(mutated)return;mutated=true;f.input.dimensions.fill(99);f.input.size.fill(99);f.input.obstacle.min.fill(0);f.input.obstacle.max.fill(99);f.input.density=99;for(const k of velocityKeys)f.input[k].fill(99);}});
 const r=await projectMACGPU({device:fake.device},f.input);assert.equal(fieldError(r,expected),0);assert.deepEqual(r.obstacle,baseline.input.obstacle);cleanup(fake);
});
test('cancel, currentness, replacement, device loss, allocation, validation and map failures clean all owned buffers',async()=>{
 for(const kind of ['preabort','pipeline','stale-pipeline','stale-read','replace','cancel-submit','cancel-map','device-loss','allocation','validation','map','exhausted','limit']){
  const c=new AbortController(),context={};let stale=false,fake;const check=()=>{if(stale)throw Object.assign(new Error('source changed'),{code:'STALE_JOB'});};
  fake=deviceEmulator({pipelineFailure:kind==='pipeline',allocationFailure:kind==='allocation'?3:0,scopeError:kind==='validation'?{message:'test validation'}:null,limits:kind==='limit'?{maxStorageBuffersPerShaderStage:6}:{},afterPipeline(){if(kind==='stale-pipeline')stale=true;},afterSubmit(){if(kind==='replace')context.device=null;if(kind==='cancel-submit')c.abort();if(kind==='device-loss')fake.lose();},beforeMap(){if(kind==='map')throw new Error('map failed');if(kind==='cancel-map')c.abort();},afterMap(){if(kind==='stale-read')stale=true;}});context.device=fake.device;if(kind==='preabort')c.abort();
  const input=maskedFixture().input;if(kind==='exhausted')input.maxIterations=1;await assert.rejects(projectMACGPU(context,input,{signal:c.signal,check}),kind==='device-loss'?{code:'DEVICE_LOST'}:undefined);cleanup(fake);
 }
});
test('corrupted actual GPU pressure or velocity cannot pass normalized and physical gates',async()=>{
 const f=maskedFixture(),p=assembleMACProjection(f.input),r=await solve(f),pressure=Float32Array.from(r.pressure,x=>x/p.pressureScale),velocity=Float32Array.from(p.edges,e=>r[velocityKeys[e.axis]][e.index]/p.speed);
 validateMACProjection(p,pressure,velocity);validateMaskedPhysicalProjection(p,r.pressure,velocityKeys.map(k=>r[k]));
 const broken=pressure.slice();broken[f.solid.findIndex(x=>x===1)]=1;assert.throws(()=>validateMACProjection(p,broken,velocity),{code:'NUMERICAL_RANGE'});
 const physical=velocityKeys.map(k=>r[k].slice());physical[0][0]=1;assert.throws(()=>validateMaskedPhysicalProjection(p,r.pressure,physical),{code:'NUMERICAL_RANGE'});
 const bad=r.pressure.slice();for(let i=0;i<bad.length;i++)if(!f.solid[i])bad[i]+=1e30;assert.throws(()=>validateMaskedPhysicalProjection(p,bad,velocityKeys.map(k=>r[k])),{code:'NUMERICAL_RANGE'});
 const fake=deviceEmulator({afterCopy(a,b,n){if(n>4)new Float32Array(b.data)[0]=NaN;}});await assert.rejects(projectMACGPU({device:fake.device},f.input),{code:'NUMERICAL_RANGE'});cleanup(fake);
});
test('normal Float32 mask contract rejects tiny remote effects without silently flushing them',()=>{
 const f=circulation(maskedFixture()),open=f.faces.find(e=>e.open&&f.input[velocityKeys[e.axis]][e.index]===0);f.input[velocityKeys[open.axis]][open.index]=2**-140;assert.throws(()=>assembleMACProjection(f.input),{code:'NUMERICAL_RANGE'});
 const good=circulation(maskedFixture()),p=assembleMACProjection(good.input),pressure=new Float32Array(p.n);assert.throws(()=>validateMACProjection(p,pressure,new Float32Array(p.edges.length)),{code:'NUMERICAL_RANGE'});
});
test('largest supported one-cell shell has bounded assembly and completed zero projection time',async()=>{
 const f=circulation(maskedFixture([16,16,16],{min:[1,1,1],max:[15,15,15]}),0),start=performance.now(),p=assembleMACProjection(f.input),assembled=performance.now()-start,r=await solve(f),ms=performance.now()-start;assert.equal(p.fluidCount,4096-2744);assert.equal(r.metrics.energyAfter,0);assert.ok(assembled<1500);assert.ok(ms<10000);console.log(`masked shell 16³: plan ${assembled.toFixed(2)} ms, completed ${ms.toFixed(2)} ms`);
});

test('projection reuses one shared device loss subscription across repeated operations and late loss',async()=>{
 const fake=deviceEmulator(),lost=fake.device.lost;let subscriptions=0;fake.device.lost={then(...args){subscriptions++;return lost.then(...args);}};
 const state=sharedThermalDeviceState(fake.device),input=circulation(maskedFixture(),0).input;
 for(let i=0;i<24;i++)await projectMACGPU({device:fake.device},input);
 assert.equal(subscriptions,1);assert.equal(state.lost,false);cleanup(fake);fake.lose();await Promise.resolve();assert.equal(state.lost,true);
 const created=fake.stats().created;await assert.rejects(projectMACGPU({device:fake.device},input),{code:'DEVICE_LOST'});assert.equal(fake.stats().created,created);cleanup(fake);
});
test('pending shared device loss promise does not retain completed operation check closures',()=>{
 const code=`import {projectMACGPU} from './plugins/thermal/mac-projection-gpu.js';
 import {deviceEmulator} from './plugins/thermal/tests/mac-projection-device-emulator.mjs';
 import {maskedFixture,circulation} from './plugins/thermal/tests/masked-projection-fixture.mjs';
 globalThis.GPUBufferUsage={STORAGE:1,COPY_DST:2,COPY_SRC:4,UNIFORM:8,MAP_READ:16};globalThis.GPUShaderStage={COMPUTE:1};globalThis.GPUMapMode={READ:1};
 const fake=deviceEmulator(),refs=[];
 async function once(){const retained={payload:new Uint8Array(100000)};refs.push(new WeakRef(retained));await projectMACGPU({device:fake.device},circulation(maskedFixture(),0).input,{check(){if(retained.payload.length!==100000)throw Error('changed');}});}
 for(let i=0;i<24;i++)await once();for(let i=0;i<6;i++){await new Promise(resolve=>setImmediate(resolve));global.gc();}const held=refs.filter(r=>r.deref()).length;if(held)throw Error('Retained completed operation closures: '+held);console.log('24 completed closures collected while shared device.lost remains pending.');`;
 const r=spawnSync(process.execPath,['--expose-gc','--input-type=module','-e',code],{cwd:new URL('../../../',import.meta.url),encoding:'utf8',timeout:15000});assert.equal(r.status,0,r.stderr||r.error?.message);assert.match(r.stdout,/24 completed closures collected/);
});

test('inherited, hidden, symbol and accessor obstacle geometry reject without invoking getters',()=>{
 const f=maskedFixture().input;let reads=0;const getter=()=>{reads++;return [1,1,1];};
 const variants=[Object.assign(Object.create({obstacle:f.obstacle}),{...f}),{...f,obstacle:Object.assign(Object.create({}),f.obstacle)},{...f,obstacle:{...f.obstacle,[Symbol('cut')]:1}},{...f,obstacle:Object.defineProperty({...f.obstacle},'min',{get:getter})},{...f,obstacle:{min:Object.defineProperty([1,1,1],'0',{get:getter}),max:[2,2,2]}},Object.defineProperty({...f},'obstacle',{get:getter}),Object.defineProperty({...f},'obstacle',{value:f.obstacle,enumerable:false})];
 delete variants[0].obstacle;for(const v of variants)assert.throws(()=>assembleMACProjection(v),{code:'INVALID_ARGUMENT'});assert.equal(reads,0);
});

test('every old projection caller rejects own, hidden and inherited obstacle before GPU allocation',async()=>{
 const f=maskedFixture().input,{obstacle,...plain}=f;
 for(const placement of ['own','hidden','inherited']){
  const withObstacle=value=>placement==='inherited'?Object.assign(Object.create({obstacle}),value):Object.defineProperty({...value},'obstacle',{value:obstacle,enumerable:placement==='own'});
  const flow=withObstacle({...plain,viscosity:.01}),fan={sheet:{x:2,y:[1,2],z:[1,2]},shutoffPressure:1,freeFlow:1,direction:1};
  assert.throws(()=>assembleMACViscosity(flow),{code:'INVALID_ARGUMENT'});assert.throws(()=>assembleMACFan(withObstacle({...plain,...fan})),{code:'INVALID_ARGUMENT'});assert.throws(()=>assembleConjugateHeatGPU(withObstacle({})),{code:'INVALID_ARGUMENT'});
  const step={flow,fan,temperature:new Array(60).fill(300),specificHeat:1000,divergenceDriftBudgetK:.0001},fake=deviceEmulator();
  await assert.rejects(stepForcedTemperatureGPU({device:fake.device},step),{code:'INVALID_ARGUMENT'});
  await assert.rejects(stepForcedHeatGPU({device:fake.device},{step,conductivity:1}),{code:'INVALID_ARGUMENT'});assert.equal(fake.stats().created,0);
 }
});
