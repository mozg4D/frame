import {fixture,latch,gridRequest} from './native-job-fixture.mjs';
import {nativeCreationFixture,math} from './native-creation-fixture.mjs';
import {box} from './box-fixture.mjs';
export {latch,gridRequest,math};
export const domainDimensions=[4,4,4];
export const domainBoundaries=()=>[box([-50,-50,-50],[0,50,50]),box([0,-50,-50],[50,50,50])];
// Test-only numerics, NOT named air or a real material preset. A geometrically
// aligned default Fan does not guarantee acceptance for arbitrary material/dt.
export const domainRequest=(steps=2)=>({fanHash:'fan',fluidHash:'fluid',dimensions:[4,4,4],settings:{fluidDensity:1,fluidViscosity:.002,solidDensity:3,timeStep:.01,initialCelsius:[26.85],divergenceDriftBudgetK:.001},stepCount:steps,cumulativeDivergenceDriftBudgetK:.001});
export const domainMaterials=()=>[
 [{kind:'thermal_material',params:{Conductivity:.02,'Heat capacity':10}}],
 [{kind:'thermal_material',params:{Conductivity:.08,'Heat capacity':21}},{kind:'thermal_heater',uid:'heater',source:'solid',params:{Power:.075}}]
];
export async function domainFixture(options={}){
 let native,owner,fan,probe,sourceNodes,captures=0;
 const f=await fixture({...options,configure(context,f){
  native=nativeCreationFixture();
  owner=native.create('thermal');owner.nativeHash='owner';owner.params.Initial=26.85;native.sync();
  context.document={...native.context.document};context.math=math;
  const register=context.editor.register;context.editor={...native.context.editor,register(hooks){native.entry.editor=hooks;register(hooks);}};
  // The same native create/sync path installs these real records. Fan creation
  // initializer is emulated here only until activate installs its actual hook;
  // separate tests create through the real plugin create-fan transaction.
  fan=native.create('thermal_fan');fan.nativeHash='fan';fan.parent=owner.id;fan.params={Thermal:'owner','Shutoff pressure':.02,'Free flow':.0001,Direction:'Forward'};
  const m=math.I();m[0]=m[5]=m[10]=.25;m.set([-25,-12.5,-12.5],12);fan.creationFrame=Array.from(math.pack(m));
  probe=native.create('thermal_probe');probe.nativeHash='probe';probe.parent=owner.id;probe.params.Thermal='owner';
  sourceNodes=['fluid','solid'].map(hash=>{const n={id:hash+'-id',nativeHash:hash,type:'mesh',emptyMesh:true,parent:owner.id,enabled:true,params:{}};native.nodes.push(n);return n;});native.sync();
  Object.assign(f,{owner,probe});const material=domainMaterials();
  for(const [i,b] of domainBoundaries().entries()){
   const mesh=f.snapshot.meshes[i];mesh.tags=material[i];
   for(const [k,data]of [['positions',b.positions],['indices',b.indices]]){mesh[k].bytes=mesh[k].data=data.buffer;mesh[k].size=data.byteLength;}
  }
  const capture=context.scene.capture;
  context.scene.capture=(...a)=>{captures++;const s=capture(...a),inverse=math.inv(native.world(a[0]));
   // Native empty-mesh registration installs source frame/parent records; actual
   // independent triangle buffers are supplied by the capture adapter above.
   // This is the actual core pluginSnapshot matrix calculation. Never replace
   // inverse*world roundoff by the cleaner native child local matrix.
   return {...s,meshes:s.meshes.map(mesh=>({...mesh,matrix:Array.from(math.mul(inverse,native.world(mesh.hash)))}))};
  };
 }});
 return {...f,native,owner,fan,probe,sourceNodes,args:domainRequest,get captures(){return captures;},get borrowedDestroyed(){return f.borrowedDestroyed;},
  solveDomain:async(args=domainRequest())=>{const start=await f.call('solve-domain',args);await f.drain();return {start,status:f.direct('status')};},
  parent(){const n={id:'parent-id',nativeHash:'parent',type:'group',enabled:true,parent:null,params:{}};native.nodes.push(n);owner.parent=n.id;native.sync();return n;}};
}
