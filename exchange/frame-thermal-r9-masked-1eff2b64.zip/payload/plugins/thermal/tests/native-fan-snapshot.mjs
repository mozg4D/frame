import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {captureNativeFanRequest,assertNativeFanRequestCurrent,nativeFanSceneInputs} from '../native-fan-snapshot.js';
import {sceneConjugateInputs} from '../scene-conjugate.js';
import {classifyTouchingSceneBoxes} from '../touching-classifier.js';
import {advanceConjugateHeatGPU,createConjugateDurationStepper} from '../scene-conjugate-duration.js';
import {stepConjugateHeatGPU} from '../conjugate-heat-gpu.js';
import {nativeCreationFixture,math} from './native-creation-fixture.mjs';
import {captured,request} from './scene-conjugate-fixture.mjs';
import {box} from './box-fixture.mjs';
import {deviceEmulator} from './conjugate-device-emulator.mjs';
globalThis.GPUBufferUsage={STORAGE:1,COPY_DST:2,COPY_SRC:4,UNIFORM:8,MAP_READ:16};globalThis.GPUShaderStage={COMPUTE:1};globalThis.GPUMapMode={READ:1};
let sceneSerial=0,deviceSerial=0;const devices=new WeakMap();
function deviceId(device){if(!devices.has(device))devices.set(device,++deviceSerial);return devices.get(device);}
function fixture(){
 const f=captured(),native=nativeCreationFixture(),owner=native.create('thermal');owner.nativeHash='owner';owner.params.Initial=26.85;native.sync();
 const fan=native.create('thermal_fan');fan.nativeHash='fan';fan.parent=owner.id;fan.params={Thermal:'owner','Shutoff pressure':2,'Free flow':.1,Direction:'Forward'};native.sync();
 const fanFrame=math.I();fanFrame[0]=2.5;fanFrame[5]=2.5;fanFrame[10]=5;fanFrame.set([-250,0,-250],12);native.setLocal('fan',fanFrame);
 f.context.document={...native.context.document};f.context.math=math;
 const capture=f.context.scene.capture,sceneId=++sceneSerial;f.context.scene.capture=hash=>{const source=capture();return {...source,signature:JSON.stringify([source.signature,sceneId,deviceId(source.device),hash])};};

 const explicit={...request(),stepCount:2,cumulativeDivergenceDriftBudgetK:.001},args=structuredClone(explicit);delete args.settings.fanBox;
 return {...f,native,owner,fan,fanFrame,explicit,args,
  capture:()=>captureNativeFanRequest(f.context,'owner','fan',args),
  classify:()=>classifyTouchingSceneBoxes(f.context,'owner',args),
  parent(){const parent={id:'parent-id',nativeHash:'parent',type:'group',parent:null,enabled:true,params:{}};native.nodes.push(parent);owner.parent=parent.id;native.sync();return parent;}};
}
const near=(a,b)=>assert.ok(Math.abs(a-b)<=1e-12*Math.max(1,Math.abs(b)),`${a} != ${b}`);
async function mapped(f){const snapshot=f.capture(),classified=await f.classify();return {snapshot,classified,value:nativeFanSceneInputs(f.context,snapshot,classified.source,classified.classification)};}
function useEmulator(f,gpu){
 f.context.device=gpu.device;f.snapshot.device=gpu.device;
 // Borrow the same scene's geometry buffers through the emulator's byte reader.
 for(const mesh of f.snapshot.meshes)for(const key of ['positions','indices'])mesh[key].data=mesh[key].bytes;
}
const assertStale=(f,snapshot)=>assert.throws(()=>assertNativeFanRequestCurrent(f.context,snapshot),{code:'STALE_JOB'});

test('saved native Fan produces exactly existing numerical input after actual independent cuboid classification, without adapter GPU work',async()=>{
 const f=fixture(),snapshot=f.capture();assert.equal(f.buffers.length,0);assert.equal(snapshot.executed,false);assert.deepEqual(snapshot.request,f.explicit);
 const c=await f.classify(),buffers=f.buffers.length,result=nativeFanSceneInputs(f.context,snapshot,c.source,c.classification),expected=sceneConjugateInputs(c.source,c.classification,Array.from(f.native.world('owner')),f.explicit.settings);
 assert.deepEqual(result.input,expected.input);assert.deepEqual(result.fan,expected.fan);assert.deepEqual(result.fieldFrame,expected.fieldFrame);assert.deepEqual(result.duration,{stepCount:2,cumulativeDivergenceDriftBudgetK:.001});assert.equal(result.executed,false);
 assert.equal(f.buffers.length,buffers);assert.equal(buffers,4);assert.ok(f.buffers.every(b=>b.destroyed&&b.unmapped));assert.equal(f.borrowedDestroyed,0);
 const visit=x=>{if(x&&typeof x==='object'){assert.equal(ArrayBuffer.isView(x),false);assert.equal(Object.isFrozen(x),true);for(const [k,v] of Object.entries(x)){assert.ok(!['device','positions','indices','node'].includes(k));visit(v);}}};visit(snapshot);
});
test('caller arrays/defaults are detached and snapshot/provenance cannot be forged or changed',async()=>{
 const f=fixture();delete f.args.settings.initialCelsius;const snapshot=f.capture();assert.deepEqual(snapshot.request.settings.initialCelsius,[26.85]);
 f.args.dimensions[0]=12;f.args.cellSizeMM[0]=1;f.args.settings.fluidDensity=50;assert.equal(snapshot.request.dimensions[0],4);assert.equal(snapshot.request.settings.fluidDensity,1);
 for(const change of [()=>snapshot.request.settings.fanBox.centerMM[0]=0,()=>snapshot.request.settings.fanBox.shutoffPressure=0,()=>snapshot.ownerWorld[0]=2,()=>snapshot.source.signature='other',()=>snapshot.token='fake'])assert.throws(change,TypeError);
 assert.throws(()=>assertNativeFanRequestCurrent(f.context,structuredClone(snapshot)),{code:'INVALID_ARGUMENT'});
 f.owner.params.Initial=30;assertStale(f,snapshot);
});
test('explicit Fan/pressure conflicts and unspecified physical decisions fail before allocation, even equal fanBox',()=>{
 for(const change of [f=>f.args.settings.fanBox=f.explicit.settings.fanBox,f=>f.args.settings.fanBox=undefined,f=>f.args.settings.shutoffPressure=2,f=>f.args.settings.freeFlow=.1,f=>f.args.settings.direction=1,f=>f.args.fanBox={},f=>f.args.savedFan='fan',f=>delete f.args.settings.fluidOccurrence,f=>delete f.args.settings.fluidDensity,f=>delete f.args.dimensions,f=>f.args.stepCount=11,f=>f.args.settings.timeStep=.1,f=>f.args.settings.initialCelsius=[NaN],f=>f.args.settings.boundary={xMin:20}]){const f=fixture();change(f);assert.throws(()=>f.capture(),{code:'INVALID_ARGUMENT'});assert.equal(f.buffers.length,0);}
 for(const params of [{'Free flow':0},{'Shutoff pressure':-1},{Direction:'Y'}]){const f=fixture();Object.assign(f.fan.params,params);assert.throws(()=>f.capture(),{code:'INVALID_ARGUMENT'});}
});
test('explicit identities never infer ownership from child location or select the first Fan',()=>{
 const f=fixture(),second={...f.fan,id:'other-id',nativeHash:'other',params:{...f.fan.params}};f.native.nodes.push(second);
 assert.equal(f.capture().fanHash,'fan');f.fan.params.Thermal='';assert.throws(()=>f.capture(),{code:'INVALID_FAN'});
 f.fan.params.Thermal='owner';assert.throws(()=>captureNativeFanRequest(f.context,'owner','missing',f.args),{code:'INVALID_FAN'});assert.throws(()=>captureNativeFanRequest(f.context,'fan','owner',f.args),{code:'INVALID_ARGUMENT'});
});
test('identity/params/flags/reference/local/world changes stale the exact Fan capture',()=>{
 for(const change of [f=>f.fan.params.Direction='Reverse',f=>f.fan.params['Shutoff pressure']=0,f=>f.fan.params['Free flow']=.2,f=>f.fan.params.Thermal='',f=>f.fan.enabled=false,f=>f.owner.enabled=false,f=>f.owner.params.Initial++,f=>f.owner.params.Ambient++,f=>{const m=math.I();m[12]=1;f.native.setLocal('owner',m);},f=>{const m=f.fanFrame.slice();m[12]+=1e-13;f.native.setLocal('fan',m);},f=>{const local=f.context.document.local;f.context.document.local=h=>{const a=Array.from(local(h));if(h==='fan')a[12]+=1e-13;return a;};},f=>{const world=f.context.document.world;f.context.document.world=h=>{const a=Array.from(world(h));if(h==='fan')a[12]+=1e-13;return a;};},f=>f.fan.id='changed-id',f=>f.owner.id='changed-owner-id',f=>f.fan.parent=null,f=>f.native.nodes.splice(f.native.nodes.indexOf(f.fan),1),f=>f.native.nodes.splice(f.native.nodes.indexOf(f.owner),1),f=>f.native.nodes.splice(f.native.nodes.indexOf(f.fan),1,{...f.fan,params:{...f.fan.params}}),f=>f.native.nodes.splice(f.native.nodes.indexOf(f.owner),1,{...f.owner,params:{...f.owner.params}})]){const f=fixture(),snapshot=f.capture();change(f);assertStale(f,snapshot);}
});
test('ancestor enable policy is explicit all-enabled and malformed/cyclic/ambiguous chains fail closed',()=>{
 for(const change of [(f,p)=>p.enabled=false,(f,p)=>p.enabled=null,(f,p)=>p.type={},(f,p)=>p.parent=p.id,(f,p)=>p.parent='missing',(f,p)=>f.owner.parent='missing',(f,p)=>f.native.nodes.push({...p}),(f,p)=>f.native.nodes.push({...p,id:'another'})]){const f=fixture(),p=f.parent();change(f,p);assert.throws(()=>f.capture());assert.equal(f.buffers.length,0);}
 for(const change of [(f,p)=>p.enabled=false,(f,p)=>p.id='new-parent-id',(f,p)=>p.parent='missing',(f,p)=>f.native.nodes.splice(f.native.nodes.indexOf(p),1,{...p}),(f,p)=>{const m=math.I();m[12]=1;f.native.setLocal(p.nativeHash,m);},(f,p)=>f.owner.parent=null]){const f=fixture(),p=f.parent(),snapshot=f.capture();change(f,p);assertStale(f,snapshot);}
 const f=fixture();f.native.nodes.push({...f.fan,id:'duplicate-hash'});assert.throws(()=>f.capture(),{code:'INVALID_FAN'});
});
test('visibility, labels, unrelated authoring and other Fans are not implicit selection or stale inputs',()=>{
 const f=fixture(),p=f.parent(),snapshot=f.capture();for(const n of [f.fan,f.owner,p]){n.visible=false;n.name='Presentation only';}
 f.native.nodes.push({id:'unrelated',nativeHash:'unrelated',type:'group',enabled:false,parent:null});f.native.nodes.push({...f.fan,id:'other-fan',nativeHash:'other-fan',params:{...f.fan.params,'Shutoff pressure':999}});
 assert.doesNotThrow(()=>assertNativeFanRequestCurrent(f.context,snapshot));
});
test('owner rotation, reflection and nonuniform scale convert physical lengths/volume exactly once; native pressure/free flow stay SI',async()=>{
 const f=fixture(),scale=math.I();scale[0]=-2;scale[5]=3;scale[10]=.5;scale.set([11,-23,79],12);f.native.setLocal('owner',math.mul(math.rotation([1,2,3],.713),scale));f.fan.params.Direction='Reverse';f.explicit.settings.fanBox.direction=-1;
 const {value,classified}=await mapped(f),expected=sceneConjugateInputs(classified.source,classified.classification,Array.from(f.native.world('owner')),f.explicit.settings);
 assert.deepEqual(value.input,expected.input);value.cellSize.forEach((x,i)=>near(x,[.5,.75,.25][i]));value.input.size.forEach((x,i)=>near(x,[2,2.25,.5][i]));
 assert.deepEqual(value.input.fan.sheet,{x:1,y:[1,2],z:[0,1]});assert.equal(value.input.fan.direction,-1);assert.equal(value.input.fan.shutoffPressure,2);assert.equal(value.input.fan.freeFlow,.1);assert.equal(value.heaters[0].powerW,75);near(value.heaters[0].volumeM3,1.125);assert.equal(value.input.temperature[0],300);
});
test('exact unsupported native frames, exterior/off-grid/full-span boxes reject via existing mappers',async()=>{
 for(const change of [m=>m[4]=Number.MIN_VALUE,m=>m[0]=-2.5,m=>m[0]=0]){const f=fixture(),m=f.fanFrame.slice();change(m);f.native.setLocal('fan',m);assert.throws(()=>f.capture(),{code:'UNSUPPORTED_FAN_FRAME'},change.toString());}
 {const f=fixture(),local=f.context.document.local;f.context.document.local=h=>{const m=Array.from(local(h));if(h==='fan')m[3]=.1;return m;};assert.throws(()=>f.capture(),{code:'UNSUPPORTED_FAN_FRAME'});}
 for(const change of [m=>m[12]=0,m=>m[12]+=.001,m=>m[5]=2.49,m=>m[0]=10,m=>{m[5]=7.5;m[10]=10;m[14]=0;}]){const f=fixture(),m=f.fanFrame.slice();change(m);f.native.setLocal('fan',m);const snapshot=f.capture(),c=await f.classify();assert.throws(()=>nativeFanSceneInputs(f.context,snapshot,c.source,c.classification));assert.equal(f.buffers.length,4);}
});
test('stale source, sub-signature occurrence transform, device replacement and device loss reject',async()=>{
 for(const change of [f=>f.change(),f=>f.snapshot.meshes[1].matrix[12]=1e-13,f=>f.snapshot.meshes.reverse(),f=>f.context.device={},f=>f.snapshot.device={}]){const f=fixture(),snapshot=f.capture();change(f);assertStale(f,snapshot);}
 const f=fixture();let lose,subscriptions=0;f.context.device.lost={then(fn){subscriptions++;lose=fn;}};const snapshot=f.capture();f.capture();assertNativeFanRequestCurrent(f.context,snapshot);assert.equal(subscriptions,1);lose();assert.throws(()=>assertNativeFanRequestCurrent(f.context,snapshot),{code:'DEVICE_LOST'});
});
test('stale classification, wrong explicit domain, fluid role and missing material/source coverage cannot be reused',async()=>{
 for(const change of [c=>c.source.signature='old',c=>c.classification.signature='old',c=>c.source.transformStamp='other',c=>c.classification.transformStamp='other',c=>c.classification.ownerWorld=Array.from(c.classification.ownerWorld,(x,i)=>i===12?1e-13:x),c=>c.classification.dimensions[0]=6,c=>c.classification.cellSizeMM[0]*=2,c=>c.classification.occurrences[0]=1,c=>c.classification.completeOccurrences=[0],c=>c.source.meshes[0].tags=[],c=>c.source.meshes[0].tags.push(c.source.meshes[1].tags[1])]){const f=fixture(),snapshot=f.capture(),c=await f.classify();change(c);assert.throws(()=>nativeFanSceneInputs(f.context,snapshot,c.source,c.classification));}
 const f=fixture();f.args.settings.fluidOccurrence=1;const snapshot=f.capture(),c=await f.classify();assert.throws(()=>nativeFanSceneInputs(f.context,snapshot,c.source,c.classification),{code:'UNSUPPORTED_DOMAIN'});
});
test('explicit reversed capture occurrence order is honored, never inferred from tags or first object',async()=>{
 const f=fixture();f.snapshot.meshes.reverse();f.args.settings.fluidOccurrence=1;const {value}=await mapped(f);assert.equal(value.input.fluid.conductivity,2);assert.equal(value.input.solid.conductivity,8);assert.equal(value.heaters[0].powerW,75);
});
test('saved Fan edit during classifier await rejects before assembly and preserves borrowed geometry',async()=>{
 const f=fixture(),snapshot=f.capture();f.onMap(()=>{f.fan.params['Shutoff pressure']=0;});const c=await f.classify();assert.throws(()=>nativeFanSceneInputs(f.context,snapshot,c.source,c.classification),{code:'STALE_JOB'});assert.ok(f.buffers.every(b=>b.destroyed));assert.equal(f.borrowedDestroyed,0);
});
test('saved Fan maps through real duration orchestration in CPU emulator exactly like explicit input, both directions and fan-off',async()=>{
 for(const direction of ['Forward','Reverse'])for(const pressure of [0,2]){const f=fixture();f.fan.params.Direction=direction;f.fan.params['Shutoff pressure']=pressure;
 const gpu=deviceEmulator();useEmulator(f,gpu);
 const snapshot=f.capture(),c=await f.classify(),value=nativeFanSceneInputs(f.context,snapshot,c.source,c.classification),explicit=sceneConjugateInputs(c.source,c.classification,Array.from(f.native.world('owner')),{...f.explicit.settings,fanBox:{...f.explicit.settings.fanBox,direction:direction==='Forward'?1:-1,shutoffPressure:pressure}});
 const a=await advanceConjugateHeatGPU(f.context,value.input,{...value.duration,check:()=>assertNativeFanRequestCurrent(f.context,snapshot)}),b=await advanceConjugateHeatGPU(f.context,explicit.input,value.duration);
 for(const k of ['temperature','u','v','w'])assert.deepEqual(a[k],b[k]);assert.deepEqual(a.duration,b.duration);assert.equal(gpu.stats().live,0);assert.equal(gpu.stats().scopes,0);
 }
});
test('saved Fan stale guard during final emulated GPU step publishes nothing and cleans all resources',async()=>{
 const f=fixture(),gpu=deviceEmulator();useEmulator(f,gpu);const snapshot=f.capture(),c=await f.classify(),value=nativeFanSceneInputs(f.context,snapshot,c.source,c.classification);let calls=0;
 const advance=createConjugateDurationStepper(async(context,input,guards)=>{const result=await stepConjugateHeatGPU(context,input,guards);if(++calls===2)f.fan.params.Direction='Reverse';return result;});
 await assert.rejects(advance(f.context,value.input,{...value.duration,check:()=>assertNativeFanRequestCurrent(f.context,snapshot)}),{code:'STALE_JOB'});assert.equal(calls,2);assert.equal(gpu.stats().live,0);assert.equal(gpu.stats().scopes,0);
});
test('capture, currentness and assembly have completed-operation budgets with 10000 nodes and 16 ancestors',async()=>{
 const f=fixture();let parent=f.parent();for(let i=1;i<16;i++){const next={id:'chain-id'+i,nativeHash:'chain'+i,type:'group',parent:null,enabled:true,params:{}};parent.parent=next.id;f.native.nodes.push(next);parent=next;}f.native.sync();
 const c=await f.classify();for(let i=f.native.nodes.length;i<10000;i++)f.native.nodes.push({id:'extra-id'+i,nativeHash:'extra'+i,type:'group',enabled:true,parent:null});
 const start=performance.now();let snapshot,captureMs=0,currentnessMs=0;for(let i=0;i<100;i++){let t=performance.now();snapshot=f.capture();captureMs+=performance.now()-t;t=performance.now();assertNativeFanRequestCurrent(f.context,snapshot);currentnessMs+=performance.now()-t;}const snapshotMs=performance.now()-start;
 assert.ok(captureMs<1500,`${captureMs} ms capture`);assert.ok(currentnessMs<1500,`${currentnessMs} ms currentness`);assert.ok(snapshotMs<2500,`${snapshotMs} ms combined`);
 let t=performance.now();for(let i=0;i<100;i++)nativeFanSceneInputs(f.context,snapshot,c.source,c.classification);const documentAssemblyMs=performance.now()-t;assert.ok(documentAssemblyMs<2500,`${documentAssemblyMs} ms document assembly`);
 const small=fixture(),s=small.capture(),classified=await small.classify();t=performance.now();for(let i=0;i<100;i++)nativeFanSceneInputs(small.context,s,classified.source,classified.classification);const assemblyMs=performance.now()-t;assert.ok(assemblyMs<1500,`${assemblyMs} ms`);
 console.log(JSON.stringify({operation:'100 captures/currentness checks/assemblies, 10000 nodes and 16 ancestors; 100 small assemblies',captureMs,captureBudgetMs:1500,currentnessMs,currentnessBudgetMs:1500,snapshotMs,snapshotBudgetMs:2500,documentAssemblyMs,documentAssemblyBudgetMs:2500,assemblyMs,assemblyBudgetMs:1500,hardwareVerified:false}));
});
test('4096-cell saved-Fan actual independent triangle classification and numerical assembly completes within 1500 ms',async()=>{
 const f=fixture(),d=[16,16,16],h=[100,100,100],frame=math.I();frame[0]=2;frame[5]=frame[10]=4;frame.set([-400,0,0],12);f.native.setLocal('fan',frame);f.args.dimensions=d;f.args.cellSizeMM=h;
 const boundaries=[box([-800,-800,-800],[0,800,800]),box([0,-800,-800],[800,800,800])];
 f.snapshot.meshes.forEach((mesh,i)=>{mesh.positions={...mesh.positions,bytes:boundaries[i].positions.buffer};mesh.indices={...mesh.indices,bytes:boundaries[i].indices.buffer};});
 const start=performance.now(),snapshot=f.capture(),c=await f.classify(),result=nativeFanSceneInputs(f.context,snapshot,c.source,c.classification),wallMs=performance.now()-start;
 assert.equal(result.input.temperature.length,4096);assert.ok(wallMs<1500,`${wallMs} ms`);assert.ok(f.buffers.every(b=>b.destroyed));console.log(JSON.stringify({operation:'4096-cell saved-Fan actual independent triangle classification and numerical assembly',wallMs,budgetMs:1500,hardwareVerified:false}));
});
test('adapter assets are complete, catalogue unregistered and explicit solve-scene remains detached',async()=>{
 const runtime=await readFile(new URL('../plugin.js',import.meta.url),'utf8'),manifest=await readFile(new URL('../plugin.json',import.meta.url),'utf8');const explicit=runtime.slice(runtime.indexOf("{id:'solve-scene'"),runtime.indexOf("{id:'solve-saved-fan'"));assert.ok(explicit);assert.equal(explicit.includes('native-fan-snapshot'),false);assert.equal(explicit.includes('preflightNativeSavedFan'),false);assert.match(explicit,/advanceTouchingSceneConjugateGPU/);assert.ok(JSON.parse(manifest).assets.includes('native-fan-snapshot.js'));assert.ok(JSON.parse(manifest).assets.includes('native-fan-job.js'));const catalogue=JSON.parse(await readFile(new URL('../../index.json',import.meta.url),'utf8'));assert.ok(!catalogue.includes('thermal/plugin.json'));assert.match(runtime,/Saved Fan objects are not consumed/);
});

test('complete ancestry validation rejects invalid chains before calling any native frame evaluator',()=>{
 for(const change of [(f,p)=>p.parent=p.id,(f,p)=>p.parent='missing',(f,p)=>p.enabled=false,(f,p)=>f.native.nodes.push({...p})]){
  const f=fixture(),p=f.parent();change(f,p);let calls=0;f.context.document.local=f.context.document.world=()=>{calls++;throw Error('Must validate topology first');};
  assert.throws(()=>f.capture());assert.equal(calls,0);
 }
});
test('exact token detects sub-quantization owner/ancestor frames and enabled representation changes',()=>{
 for(const target of ['owner','parent']){const f=fixture();f.parent();const snapshot=f.capture(),local=f.context.document.local,world=f.context.document.world;
  f.context.document.local=h=>{const a=Array.from(local(h));if(h===target)a[12]=1e-13;return a;};f.context.document.world=h=>{const a=Array.from(world(h));if(h===target)a[12]=1e-13;return a;};assertStale(f,snapshot);
 }
 const f=fixture();f.fan.enabled=true;const snapshot=f.capture();delete f.fan.enabled;assertStale(f,snapshot);
});

test('foreign owner/scene/device classifier output cannot substitute for matching provenance',async()=>{
 const a=fixture(),b=fixture(),snapshot=a.capture(),foreign=await b.classify();assert.throws(()=>nativeFanSceneInputs(a.context,snapshot,foreign.source,foreign.classification),{code:'STALE_CLASSIFICATION'});
 const old=await a.classify(),gpu=deviceEmulator();useEmulator(a,gpu);const fresh=a.capture();assert.throws(()=>nativeFanSceneInputs(a.context,fresh,old.source,old.classification),{code:'STALE_CLASSIFICATION'});
});
test('owner parameter stamps reject nested/cyclic/nonfinite/unbounded authoring and track additional finite scalars',()=>{
 const cycle={};cycle.self=cycle;
 for(const value of [{},[],cycle,()=>{},NaN,Infinity,'x'.repeat(4097)]){const f=fixture();f.owner.params.extra=value;assert.throws(()=>f.capture(),{code:'INVALID_ARGUMENT'});}
 const f=fixture();f.owner.params.extra='finite scalar';const snapshot=f.capture();f.owner.params.extra='changed';assertStale(f,snapshot);
 const many=fixture();for(let i=0;i<65;i++)many.owner.params['extra'+i]=i;assert.throws(()=>many.capture(),{code:'INVALID_ARGUMENT'});
});

test('inherited/nonenumerable/accessor parameters cannot escape exact default or curve stamps',()=>{
 for(const target of ['owner','fan'])for(const kind of ['inherited','nonenumerable','accessor','symbol']){const f=fixture(),node=f[target],key=target==='owner'?'Initial':'Shutoff pressure',values={...node.params};
  if(kind==='inherited'){node.params=Object.create(values);}else if(kind==='nonenumerable'){Object.defineProperty(node.params,key,{value:values[key],enumerable:false});}else if(kind==='accessor'){Object.defineProperty(node.params,key,{get(){throw Error('Accessor must never be invoked');},enumerable:true});}else node.params[Symbol('hidden')]=1;
  assert.throws(()=>f.capture(),{code:'INVALID_ARGUMENT'});
 }
});
