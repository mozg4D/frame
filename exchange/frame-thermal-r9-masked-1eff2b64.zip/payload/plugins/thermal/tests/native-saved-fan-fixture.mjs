import {fixture,sceneRequest,latch,gridRequest} from './native-job-fixture.mjs';
import {math} from './native-creation-fixture.mjs';
export {latch,gridRequest,sceneRequest};
export async function savedFixture(options={}){
 const f=await fixture(options);f.owner.id='owner-id';f.owner.parent=null;f.probe.id='probe-id';f.probe.parent=null;
 const fan={id:'fan-id',nativeHash:'fan',type:'thermal_fan',parent:f.owner.id,enabled:true,params:{Thermal:'owner','Shutoff pressure':2,'Free flow':.1,Direction:'Forward'}},fanFrame=math.I();fanFrame[0]=fanFrame[5]=2.5;fanFrame[10]=5;fanFrame.set([-250,0,-250],12);
 const locals={owner:math.I(),probe:math.I(),fan:fanFrame};f.context.document.nodes.push(fan);f.context.math=math;
 f.context.document.local=hash=>locals[hash];f.context.document.world=hash=>{const node=f.context.document.nodes.find(n=>n.nativeHash===hash),parent=node?.parent&&f.context.document.nodes.find(n=>n.id===node.parent);return parent?math.mul(f.context.document.world(parent.nativeHash),locals[hash]):locals[hash];};
 const args=(steps=2)=>{const r=sceneRequest(steps);delete r.settings.fanBox;return {...r,fanHash:'fan'};};
 let captures=0;const capture=f.context.scene.capture;f.context.scene.capture=(...a)=>{captures++;return capture(...a);};
 return {...f,fan,fanFrame,locals,args,get captures(){return captures;},get borrowedDestroyed(){return f.borrowedDestroyed;},
  solveSaved:async(r=args())=>{const start=await f.call('solve-saved-fan',r);await f.drain();return {start,status:f.direct('status')};},
  parent(){const n={id:'parent-id',nativeHash:'parent',type:'group',enabled:true,parent:null};f.context.document.nodes.push(n);f.owner.parent=n.id;locals.parent=math.I();return n;}};
}
