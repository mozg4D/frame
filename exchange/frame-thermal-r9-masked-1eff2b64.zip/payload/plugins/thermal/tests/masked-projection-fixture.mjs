// TEST ONLY: geometry/face ownership enumerated independently of runtime masks.
export const velocityKeys=['u','v','w'];
export function maskedFixture(dimensions=[5,4,3],obstacle={min:[1,1,1],max:[3,3,2]}){
 const [nx,ny,nz]=dimensions,solid=new Uint8Array(nx*ny*nz),id=p=>p[0]+nx*(p[1]+ny*p[2]);
 for(let z=0;z<nz;z++)for(let y=0;y<ny;y++)for(let x=0;x<nx;x++){const p=[x,y,z];solid[id(p)]=p.every((v,a)=>v>=obstacle.min[a]&&v<obstacle.max[a])?1:0;}
 const faces=[],fields=dimensions.map((_,axis)=>{const shape=dimensions.map((v,a)=>v+(a===axis?1:0)),field=new Float64Array(shape.reduce((a,b)=>a*b));
  for(let i=0;i<field.length;i++){const p=[i%shape[0],Math.floor(i/shape[0])%shape[1],Math.floor(i/(shape[0]*shape[1]))];const left=[...p];left[axis]--;
   const open=p[axis]>0&&p[axis]<dimensions[axis]&&!solid[id(left)]&&!solid[id(p)];faces.push({axis,index:i,open,left:open?id(left):-1,right:open?id(p):-1});if(open)field[i]=Math.sin(i*1.37+axis)*.1;
  }return field;
 });
 return {input:{dimensions:[...dimensions],size:dimensions.map((v,a)=>v*[.125,.25,.375][a]),obstacle:{min:[...obstacle.min],max:[...obstacle.max]},density:1.2,timeStep:.01,u:fields[0],v:fields[1],w:fields[2]},solid,faces};
}
export function asReference(f){const {obstacle,...input}=f.input;return {...input,u:Float64Array.from(input.u),v:Float64Array.from(input.v),w:Float64Array.from(input.w),solid:f.solid,tolerance:1e-10,maxIterations:4000};}
export function fieldError(a,b){let error=0;for(const key of velocityKeys)for(let i=0;i<a[key].length;i++)error=Math.max(error,Math.abs(a[key][i]-b[key][i]));return error;}
export function circulation(f,scale=1){
 for(const key of velocityKeys)f.input[key].fill(0);const [nx,ny]=f.input.dimensions,[hx,hy]=f.input.size.map((v,a)=>v/f.input.dimensions[a]);
 // A four-face loop in z=0 lies in the guaranteed fluid shell.
 f.input.u[1]=hx*scale;f.input.u[1+(nx+1)]=-hx*scale;f.input.v[1+nx]=hy*scale;f.input.v[nx]=-hy*scale;
 return f;
}
export function addGradient(f,scale=.01){
 const h=f.input.size.map((v,a)=>v/f.input.dimensions[a]),potential=Float64Array.from(f.solid,(_,i)=>Math.cos(i*.73)*scale);
 for(const e of f.faces)if(e.open)f.input[velocityKeys[e.axis]][e.index]+=(potential[e.right]-potential[e.left])/h[e.axis];return f;
}
