// TEST ONLY. Independent Float64 physical oracle. No production imports or
// production assembly/diagnostics. Fixtures are not user cooling defaults.
import {solveDense} from './reference.mjs';
import {stepMACFan} from './mac-fan-step-reference.mjs';
import {projectMAC} from './mac-projection-reference.mjs';
import {advectTemperature} from './temperature-advection-reference.mjs';

export const filmFaces=['xMin','xMax','yMin','yMax','zMin','zMax'];
const total=a=>Array.from(a).reduce((sum,x)=>sum+x,0);
const mapFaces=()=>Object.fromEntries(filmFaces.map(f=>[f,0]));
export function filmFixture(options={}){
 const {steps=1,size=[.1,.1,.1],power=.075,initialKelvin=300,pressure=.02,direction=1,faces={xMax:{hWPerM2K:.1,ambientKelvin:280}}}=options;
 return {steps,size:[...size],power,initialKelvin,pressure,direction,faces:structuredClone(faces),dimensions:[4,4,4],fluidCellsX:2,timeStep:.01,
  fluid:{density:1,specificHeat:10,conductivity:.02},solid:{density:3,specificHeat:7,conductivity:.08}};
}
export function filmPhysics(input){
 const f=filmFixture(input),[nx,ny,nz]=f.dimensions,n=nx*ny*nz,delta=f.size.map((s,a)=>s/f.dimensions[a]),volume=delta[0]*delta[1]*delta[2],id=(x,y,z)=>x+nx*(y+ny*z);
 const capacities=Float64Array.from({length:n},(_,i)=>(i%nx<f.fluidCellsX?10:21)*volume),k=Float64Array.from({length:n},(_,i)=>(i%nx<f.fluidCellsX?.02:.08)),sources=Float64Array.from({length:n},(_,i)=>i%nx<f.fluidCellsX?0:f.power/(n/2)),links=[],films=[];
 for(let z=0;z<nz;z++)for(let y=0;y<ny;y++)for(let x=0;x<nx;x++){
  const p=[x,y,z],i=id(x,y,z);
  for(let a=0;a<3;a++){
   const area=delta[(a+1)%3]*delta[(a+2)%3];
   if(p[a]+1<f.dimensions[a]){const j=i+[1,nx,nx*ny][a];links.push({i,j,g:area/(delta[a]/(2*k[i])+delta[a]/(2*k[j])),interface:a===0&&x===f.fluidCellsX-1});}
   for(let side=0;side<2;side++)if(p[a]===(side?f.dimensions[a]-1:0)){
    const face=filmFaces[a*2+side],bath=f.faces[face];if(bath)films.push({i,face,area,g:bath.hWPerM2K===0?0:area/(delta[a]/(2*k[i])+1/bath.hWPerM2K),ambient:bath.ambientKelvin});
   }
  }
 }
 return {...f,n,delta,volume,capacities,sources,links,films};
}
export function filmExchange(temperature,input){
 const p=filmPhysics(input),byFace=mapFaces(),regional=[0,0],cellPower=new Float64Array(p.n);let absolute=0,interfacePower=0;
 for(const e of p.films){const q=e.g*(temperature[e.i]-e.ambient);byFace[e.face]+=q;regional[e.i%4<2?0:1]+=q;cellPower[e.i]+=q;absolute+=Math.abs(q);}
 for(const e of p.links)if(e.interface)interfacePower+=e.g*(temperature[e.i]-temperature[e.j]);
 return {power:total(Object.values(byFace)),byFace,regional,absolute,interfacePower,cellPower};
}
export function filmEnergy(temperature,input){const p=filmPhysics(input),regional=[0,0];for(let i=0;i<p.n;i++)regional[i%4<2?0:1]+=p.capacities[i]*temperature[i];return {total:total(regional),regional};}
// Reconstruct duration exchange from independently observed ACTUAL step fields,
// not runtime power diagnostics and not final power multiplied by duration.
export function filmTrajectory(temperatures,input){
 const p=filmPhysics(input),byFace=mapFaces(),regional=[0,0];let boundaryEnergy=0,absoluteBoundaryEnergy=0,interfaceEnergy=0;
 for(const temperature of temperatures){const x=filmExchange(temperature,p);boundaryEnergy+=p.timeStep*x.power;absoluteBoundaryEnergy+=p.timeStep*x.absolute;interfaceEnergy+=p.timeStep*x.interfacePower;for(const face of filmFaces)byFace[face]+=p.timeStep*x.byFace[face];for(let a=0;a<2;a++)regional[a]+=p.timeStep*x.regional[a];}
 const first=filmEnergy(new Float64Array(p.n).fill(p.initialKelvin),p),last=filmEnergy(temperatures.at(-1),p),sourceEnergy=p.power*p.timeStep*temperatures.length;
 return {boundaryEnergy,absoluteBoundaryEnergy,byFace,regional,interfaceEnergy,sourceEnergy,energyChange:last.total-first.total,balance:last.total-first.total-sourceEnergy+boundaryEnergy,
  regionalBalance:[last.regional[0]-first.regional[0]+interfaceEnergy+regional[0],last.regional[1]-first.regional[1]-interfaceEnergy+regional[1]-sourceEnergy],first,last};
}
function flowStep(p,state){
 const small=[2,4,4],large=[4,4,4],sub=['u','v','w'].map((key,a)=>{const sh=[...small],lh=[...large];sh[a]++;lh[a]++;const out=new Float64Array(sh[0]*sh[1]*sh[2]);for(let z=0;z<sh[2];z++)for(let y=0;y<sh[1];y++)for(let x=0;x<sh[0];x++)out[x+sh[0]*(y+sh[1]*z)]=state[key][x+lh[0]*(y+lh[1]*z)];return out;});
 const base={dimensions:small,size:[p.size[0]/2,p.size[1],p.size[2]],solid:new Uint8Array(32),u:sub[0],v:sub[1],w:sub[2],density:1,timeStep:p.timeStep},fan=stepMACFan({...base,sheet:{x:1,y:[1,2],z:[1,2]},shutoffPressure:p.pressure,freeFlow:.0001,direction:p.direction,viscosity:.002}),ready=projectMAC({...base,u:fan.u,v:fan.v,w:fan.w,tolerance:1e-12});
 const fields=Object.fromEntries(['u','v','w'].map((key,a)=>{const sh=[...small],lh=[...large];sh[a]++;lh[a]++;const out=new Float64Array(80);for(let z=0;z<sh[2];z++)for(let y=0;y<sh[1];y++)for(let x=0;x<sh[0];x++)out[x+lh[0]*(y+lh[1]*z)]=ready[key][x+sh[0]*(y+sh[1]*z)];return [key,out];}));
 const subT=new Float64Array(32);for(let z=0;z<4;z++)for(let y=0;y<4;y++)for(let x=0;x<2;x++)subT[x+2*(y+4*z)]=state.temperature[x+4*(y+4*z)];
 const adv=advectTemperature({...base,u:ready.u,v:ready.v,w:ready.w,temperature:subT,density:1,specificHeat:10,boundary:['closed','closed','closed']}),advected=state.temperature.slice();
 for(let z=0;z<4;z++)for(let y=0;y<4;y++)for(let x=0;x<2;x++)advected[x+4*(y+4*z)]=adv.temperature[x+2*(y+4*z)];
 return {...fields,advected};
}
export function exteriorFilmOracle(options={}){
 const p=filmPhysics(options);let state={temperature:new Float64Array(p.n).fill(p.initialKelvin),u:new Float64Array(80),v:new Float64Array(80),w:new Float64Array(80)};const temperatures=[];
 for(let step=0;step<p.steps;step++){
  const next=flowStep(p,state),A=Array.from({length:p.n},()=>new Float64Array(p.n)),b=new Float64Array(p.n);
  for(let i=0;i<p.n;i++){A[i][i]=p.capacities[i]/p.timeStep;b[i]=A[i][i]*next.advected[i]+p.sources[i];}
  for(const e of p.links){A[e.i][e.i]+=e.g;A[e.j][e.j]+=e.g;A[e.i][e.j]-=e.g;A[e.j][e.i]-=e.g;}
  for(const e of p.films){A[e.i][e.i]+=e.g;b[e.i]+=e.g*e.ambient;}
  const temperature=solveDense({A,b});temperatures.push(temperature);state={temperature,u:next.u,v:next.v,w:next.w};
 }
 return {...state,temperatures,trajectory:filmTrajectory(temperatures,p),physics:p};
}
export function filmProbe(temperature,pointMM){
 // Native grid is [-50,50]^3 mm. Cell-centre reconstruction clamps the outer
 // half cell; it is deliberately not a surface-temperature reconstruction.
 const c=pointMM.map(x=>Math.max(0,Math.min(3,(x+50)/25-.5))),lo=c.map(Math.floor),hi=lo.map(x=>Math.min(3,x+1));let value=0;
 const weights=c.map((x,a)=>{const f=x-lo[a];return [1-f,f];});
 // At the exact interface (x=0) the correct .2/.8 resistance weights apply.
 if(lo[0]===1&&hi[0]===2){const x=c[0]-lo[0];const resistance=x<=.5?x/.02:.5/.02+(x-.5)/.08;weights[0]=[1-resistance/(.5/.02+.5/.08),resistance/(.5/.02+.5/.08)];}
 for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++)value+=temperature[[lo[0],hi[0]][x]+4*([lo[1],hi[1]][y]+4*[lo[2],hi[2]][z])]*weights[0][x]*weights[1][y]*weights[2][z];
 return value-273.15;
}
