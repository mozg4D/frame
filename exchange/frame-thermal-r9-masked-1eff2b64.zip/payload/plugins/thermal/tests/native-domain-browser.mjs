import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {launch,ready} from '../../../tools/browser.mjs';
import {domainBoundaries,domainRequest,domainMaterials} from './native-domain-fixture.mjs';
import {savedFanSourceSnapshot} from './native-saved-fan-browser.mjs';
import {stepFanConjugate} from './fan-conjugate-reference.mjs';
import {fixtureFluidOccurrence} from './native-fluid-fixture.mjs';
import {checkDefaultProbeFrame} from './native-probe-browser.mjs';

const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const near=(a,b,tolerance=1e-10)=>Array.isArray(a)&&a.length===b.length&&a.every((v,i)=>Number.isFinite(v)&&Math.abs(v-b[i])<=tolerance);
const maxDifference=(a,b)=>a.length===b.length?Math.max(...a.map((v,i)=>Math.abs(v-b[i]))):Infinity;
const components=[['u',80],['v',80],['w',80]];
const packedFan=[.25,0,0,0,.25,0,0,0,.25,-25,-12.5,-12.5];
const identityMatrix=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
const root=new URL('../../../',import.meta.url);
export const nativeDomainSourceSnapshot=savedFanSourceSnapshot;
// Independent Float64 physics oracle; fixture values are NOT an air preset.
// Never inject this oracle, its fields or clean transforms into the browser.
export function nativeDomainOracle({steps=1,direction=1,pressure=.02,power=.075,size=[.1,.1,.1]}={}){
 const material=domainMaterials(),r=domainRequest(steps),volume=size.reduce((a,b)=>a*b),s=r.settings;
 let state={dimensions:[...r.dimensions],size,fluidCellsX:2,
  fluid:{density:s.fluidDensity,specificHeat:material[0][0].params['Heat capacity']/s.fluidDensity,conductivity:material[0][0].params.Conductivity},
  solid:{density:s.solidDensity,specificHeat:material[1][0].params['Heat capacity']/s.solidDensity,conductivity:material[1][0].params.Conductivity},
  temperature:new Float64Array(64).fill(s.initialCelsius[0]+273.15),u:new Float64Array(80),v:new Float64Array(80),w:new Float64Array(80),
  timeStep:s.timeStep,boundary:{},solidSourceDensity:new Float64Array(32).fill(power/(volume/2)),
  fan:{sheet:{x:1,y:[1,2],z:[1,2]},shutoffPressure:pressure,freeFlow:.0001,direction,viscosity:s.fluidViscosity}};
 for(let i=0;i<steps;i++){const next=stepFanConjugate(state);state={...state,temperature:next.temperature,u:next.u,v:next.v,w:next.w};}
 let probe=0;for(const y of [1,2])for(const z of [1,2])probe+=(.2*state.temperature[1+4*(y+4*z)]+.8*state.temperature[2+4*(y+4*z)]-273.15)/4;
 return {...state,probe};
}

// A new isolated context, ordinary native authoring, and the shared real device.
// Observers retain actual identities only. Await gates hold genuine async work;
// no input/frame writes, solver replacement, CPU fallback or success injection.
export async function nativeDomainBrowserChecks(parent,check,timed){
 const sources=await nativeDomainSourceSnapshot();
 const context=await parent.context().browser().newContext({viewport:{width:1280,height:900},serviceWorkers:'block'}),page=await context.newPage(),errors=[],consoleErrors=[],evidence=[];
 page.on('pageerror',error=>errors.push(error.stack||String(error)));
 page.on('console',message=>{if(message.type()==='error')consoleErrors.push(message.text());});
 try{
  const catalogue=JSON.parse(await readFile(new URL('../../index.json',import.meta.url),'utf8'));
  check('native domain candidate stays absent from public catalogue',!catalogue.includes('thermal/plugin.json'),catalogue);
  await page.route('**/plugins/index.json',route=>route.fulfill({json:[...catalogue,'thermal/plugin.json']}));
  const module=await readFile(new URL('../plugin.js',import.meta.url),'utf8'),activation='export async function activate(context) {',publication='result=await solve(job);current(job);',editor='context.editor.register({';
  for(const marker of [activation,publication,editor])if(module.split(marker).length!==2)throw Error('Native-domain observer/await marker changed: '+marker);
  await page.route('**/plugins/thermal/plugin.js',route=>route.fulfill({contentType:'text/javascript',body:module.replace(activation,activation+'\nwindow.__nativeDomainContext=context;').replace(editor,'context.editor.register(window.__nativeDomainEditor={').replace(publication,'result=await solve(job);await window.__nativeDomainGateAt?.("final");current(job);')}));
  await page.goto(parent.url());await ready(page);
  const call=(name,args={})=>page.evaluate(([name,args])=>frameAI.call(name,args),[name,args]);
  const objects=async()=> (await call('scene.inspect')).objects;
  const hardware=await page.evaluate(async()=>{
   const [{macProjectionWGSL},{macViscosityWGSL},{conductionWGSL}]=await Promise.all([import('/plugins/thermal/mac-projection-gpu.js'),import('/plugins/thermal/mac-viscosity-gpu.js'),import('/plugins/thermal/plugin.js')]);
   const device=frameEngine.renderer.device,info=device.adapterInfo;window.__nativeDomainDevice=device;
   window.__nativeDomainGPU=[];window.__nativeDomainLost=null;window.__nativeDomainOwned={live:0,peak:0,created:0,destroyed:0,unlabelled:0,unresolvedLabels:0,unrecognizedCallsites:[],byModule:{}};
   device.addEventListener('uncapturederror',event=>__nativeDomainGPU.push(event.error.message));device.lost.then(info=>__nativeDomainLost={reason:info.reason,message:info.message});device.pushErrorScope('validation');
   window.__nativeDomainGateAt=async stage=>{const gate=window.__nativeDomainGate;if(gate?.stage===stage&&!gate.entered){gate.entered=true;await gate.promise;}};
   const allocationSources=new Set(['touching-classifier.js','plugin.js','mac-projection-gpu.js','mac-viscosity-gpu.js','mac-fan-gpu.js','temperature-advection-gpu.js'].map(name=>new URL('/plugins/thermal/'+name,location.href).href));
   const make=device.createBuffer.bind(device),shader=device.createShaderModule.bind(device),pipeline=device.createComputePipelineAsync.bind(device),modules=new WeakSet(),conductionModules=new WeakSet();window.__nativeDomainConductionPipelines=0;
   device.createShaderModule=options=>{const result=shader(options);if(options.code===macProjectionWGSL||options.code===macViscosityWGSL)modules.add(result);if(options.code===conductionWGSL)conductionModules.add(result);return result;};
   device.createComputePipelineAsync=async options=>{if(modules.has(options.compute?.module))await __nativeDomainGateAt('pipeline');const result=await pipeline(options);if(conductionModules.has(options.compute?.module)){__nativeDomainConductionPipelines++;await __nativeDomainGateAt('conduction');}return result;};
   device.createBuffer=options=>{
    // MAC/advection allocations have no labels. The immediate synchronous
    // source callsite identifies ownership, not transitive plugin callers or
    // every buffer on the shared device. Never rewrite production modules.
    const caller=(new Error().stack||'').split('\n').slice(1).map(line=>line.match(/(https?:\/\/[^\s)]+):\d+:\d+\)?$/)?.[1]).find(Boolean),path=caller?new URL(caller).pathname:null,stats=__nativeDomainOwned;
    const buffer=make(options);if(!allocationSources.has(caller)){if(options.label?.startsWith('Thermal '))stats.unresolvedLabels++;if(path?.startsWith('/plugins/thermal/')&&!stats.unrecognizedCallsites.includes(caller))stats.unrecognizedCallsites.push(caller);return buffer;}
    stats.byModule[path]=(stats.byModule[path]||0)+1;if(!options.label)stats.unlabelled++;
    const destroy=buffer.destroy.bind(buffer),map=buffer.mapAsync.bind(buffer);let dead=false;stats.created++;stats.live+=options.size;stats.peak=Math.max(stats.peak,stats.live);
    buffer.destroy=()=>{if(!dead){dead=true;stats.destroyed++;stats.live-=options.size;}destroy();};
    buffer.mapAsync=async(...args)=>{await map(...args);if(options.label==='Thermal independent occurrence readback')await __nativeDomainGateAt('classification');if(options.label==='Thermal bounded temperature inspection')await __nativeDomainGateAt('heat');};return buffer;
   };
   return info?Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(key=>[key,info[key]])):null;
  });
  check('native domain uses identifiable nonfallback hardware WebGPU',hardware&&Object.values(hardware).some(v=>typeof v==='string'&&v)&&!hardware.isFallbackAdapter&&!/swiftshader|llvmpipe|lavapipe|software/i.test(JSON.stringify(hardware)),hardware);
  const old=await objects();if(old.length)await call('scene.delete',{ids:old.filter(n=>!n.parent).map(n=>n.hash)});
  const owner=await timed('native domain owner creation',10000,()=>call('plugins.create',{plugin:'thermal'}));
  const cmd=(operation,args={},id=owner.hash)=>call('plugins.command',{id,operation,args});
  const description=await call('plugins.describe',{plugin:'thermal'}),op=description.operations.find(op=>op.id==='solve-domain'),schema=op?.inputSchema;
  check('native domain has strict discoverable canonical-role schema',op?.readOnly===false&&op.interruptible===true&&schema?.additionalProperties===false&&equal([...schema.required].sort(),['fanHash','fluidHash','dimensions','settings','stepCount','cumulativeDivergenceDriftBudgetK'].sort())&&schema.properties.settings.additionalProperties===false&&['cellSizeMM','domain','ownerWorld','size'].every(k=>!Object.hasOwn(schema.properties,k))&&['fanBox','fluidOccurrence'].every(k=>!Object.hasOwn(schema.properties.settings.properties,k)),description);
  check('old explicit-domain operations remain separate schemas',description.operations.find(op=>op.id==='solve-saved-fan')?.inputSchema.required.includes('cellSizeMM')&&description.operations.find(op=>op.id==='solve-scene')?.inputSchema.properties.settings.required.includes('fanBox'),description.operations);
  check('native domain reuses bounded read-only native reads',['status','inspect','inspect-velocity','measure','fan-inputs'].every(id=>description.operations.find(op=>op.id===id)?.readOnly===true),description.operations);
  await call('scene.select',{ids:[owner.hash]});await page.locator('#tabAttributes').click();
  check('native domain adds no Solve Attributes action',await page.locator('#attrContent [data-plugin-action-button^="solve"]').count()===0);
  const clearButton=page.locator('#attrContent [data-plugin-action-button="clear"]');
  check('native domain uses stable disabled idle Clear action',await clearButton.count()===1&&await clearButton.isDisabled()&&(await clearButton.textContent())==='Clear');
  const ownerBefore=(await objects()).find(n=>n.hash===owner.hash),fan=await timed('native domain native creation',10000,()=>cmd('create-fan'));
  const fanInputs=()=>cmd('fan-inputs',{},fan.hash),defaultFan=(await objects()).find(n=>n.hash===fan.hash),defaultInputs=await fanInputs();
  check('native domain begins as selected native 25 mm child',defaultFan.selected&&defaultFan.parent===owner.hash&&defaultFan.params.Thermal===owner.hash&&equal(defaultFan.matrix,[.25,0,0,0,.25,0,0,0,.25,-25,-12.5,-12.5])&&equal(defaultInputs.fan.mapping.sizeMM,[25,25,25])&&equal(defaultInputs.fan.mapping.centerMM,[-25,-12.5,-12.5]),{defaultFan,defaultInputs});
  // Deliberately no selection repair: creation must await native selectOwner.
  await timed('native Fan immediate selected-child transform',1500,()=>call('transform.set',{channel:'position',axis:0,value:-24,coordinates:'world'}));
  const moved=(await objects()).find(n=>n.hash===fan.hash),ownerAfter=(await objects()).find(n=>n.hash===owner.hash);
  check('immediate Fan transform changes child local/world only',equal(moved.matrix,[.25,0,0,0,.25,0,0,0,.25,-24,-12.5,-12.5])&&near(moved.worldMatrix.slice(12,15),[-24,-12.5,-12.5])&&equal(ownerAfter.matrix,ownerBefore.matrix)&&equal(ownerAfter.worldMatrix,ownerBefore.worldMatrix),{moved,ownerBefore,ownerAfter});
  await call('edit.history',{action:'undo'});
  await call('scene.update',{id:fan.hash,params:{Direction:'Forward','Shutoff pressure':.02,'Free flow':.0001}});
  const assertFan=async label=>{const record=(await objects()).find(n=>n.hash===fan.hash),metadata=await fanInputs();check(label+' has native default box and exact physical mapping',equal(record.matrix,packedFan)&&metadata.fan.mapping.status==='supported-frame'&&equal(metadata.fan.mapping.centerMM,[-25,-12.5,-12.5])&&equal(metadata.fan.mapping.sizeMM,[25,25,25])&&!metadata.solverEligible&&!metadata.solverCoupled,{record,metadata});return metadata;};
  await assertFan('Authored domain Fan');
  check('sole domain is actual native 100 mm Thermal helper',near(ownerBefore.bounds.min,[-50,-50,-50])&&near(ownerBefore.bounds.max,[50,50,50])&&equal(ownerBefore.worldMatrix,identityMatrix)&&equal(Object.keys(ownerBefore.params).sort(),['Ambient','Initial']),ownerBefore);
  const groups=[],meshes=[];
  // Author SOLID first deliberately. Canonical fluidHash must resolve index 1,
  // rather than inheriting synthetic oracle order or guessing from material.
  await timed('native domain actual two-cuboid material authoring',10000,async()=>{for(const i of [1,0]){
   const box=domainBoundaries()[i],group=await call('scene.create',{type:'group'}),mesh=await call('mesh.create',{vertices:Array.from(box.positions),indices:Array.from(box.indices),storage:'auto'});groups[i]=group.hash;meshes[i]=mesh.hash;
   await call('scene.update',{id:group.hash,parent:owner.hash});await call('scene.update',{id:mesh.hash,parent:group.hash});
   for(const tag of domainMaterials()[i])await call('tag.set',{ids:[group.hash],kind:tag.kind,enabled:true,params:tag.params});
  }});
  const probe=await timed('native domain bounded Probe creation',2000,()=>cmd('create-probe'));
  checkDefaultProbeFrame(check,await objects(),probe.hash,owner.hash,'Native-domain Probe');
  const probeOwnerBefore=(await objects()).find(n=>n.hash===owner.hash);
  await call('transform.set',{channel:'position',axis:1,value:1,coordinates:'world'});
  const movedProbe=(await objects()).find(n=>n.hash===probe.hash);
  check('immediate Probe transform changes selected child and preserves owner',near(movedProbe.worldMatrix.slice(12,15),[0,1,0])&&equal((await objects()).find(n=>n.hash===owner.hash).worldMatrix,probeOwnerBefore.worldMatrix),movedProbe);
  await call('edit.history',{action:'undo'});checkDefaultProbeFrame(check,await objects(),probe.hash,owner.hash,'Undo native-domain Probe');
  const initialCapture=await cmd('scene-inputs'),nativeMeshes=(await objects()).filter(n=>meshes.includes(n.hash));
  check('domain capture contains only actual buffer-backed 12-triangle cuboids with native parent records',initialCapture.totalOccurrences===2&&fixtureFluidOccurrence(initialCapture,meshes[0])===1&&nativeMeshes.length===2&&nativeMeshes.every(n=>n.mesh?.triangles===12&&n.mesh.storage==='buffer'&&n.parent===groups[meshes.indexOf(n.hash)]),{initialCapture,nativeMeshes});
  const args=async(steps=2,operation='solve-domain')=>{
   const r=domainRequest(steps);r.fanHash=fan.hash;r.fluidHash=meshes[0];
   if(operation!=='solve-domain'){delete r.fluidHash;r.cellSizeMM=r.dimensions.map(n=>100/n);r.settings.fluidOccurrence=fixtureFluidOccurrence(await cmd('scene-inputs'),meshes[0]);
    if(operation==='solve-scene'){delete r.fanHash;const f=(await objects()).find(n=>n.hash===fan.hash);r.settings.fanBox={centerMM:[-25,-12.5,-12.5],sizeMM:[25,25,25],shutoffPressure:f.params['Shutoff pressure'],freeFlow:f.params['Free flow'],direction:f.params.Direction==='Forward'?1:-1};}
   }return r;
  };
  const finish=async()=>{const until=performance.now()+15000;while(performance.now()<until){const state=await cmd('status');if(state.state!=='running')return state;await new Promise(resolve=>setTimeout(resolve,10));}throw Error('Native-domain native job exceeded 15 s');};
  const resource=()=>page.evaluate(()=>({...__nativeDomainOwned}));
  const clean=async label=>{const stats=await resource();check(label+' releases every tracked Thermal-owned buffer',stats.live===0&&stats.created===stats.destroyed&&stats.unresolvedLabels===0&&!stats.unrecognizedCallsites.length,stats);};
  const fields=async()=>{const result={temperature:(await cmd('inspect',{offset:0,count:64})).temperatures};for(const [component,count]of components)result[component]=(await cmd('inspect-velocity',{component,offset:0,count})).values;return result;};
  const noField=async label=>{for(const [operation,input,id]of [['inspect',{count:64},owner.hash],...components.map(([component,count])=>['inspect-velocity',{component,count},owner.hash]),['measure',{},probe.hash]]){const rejection=await page.evaluate(async({id,operation,args})=>{try{await frameAI.call('plugins.command',{id,operation,args});return null;}catch(error){return {code:error.code,message:error.message};}},{id,operation,args:input});check(label+' rejects '+operation+(input.component?' '+input.component:''),rejection?.code==='NO_RESULT',rejection);}};
  const solve=async(steps=1,input=null,operation='solve-domain')=>{input??=await args(steps,operation);return timed(`${operation} completed ${steps}-step operation`,15000,async()=>{const began=performance.now(),start=await cmd(operation,input),done=await finish();check(operation+' returns running then publishes complete duration',start.state==='running'&&done.state==='ready'&&done.duration?.completedSteps===steps&&done.duration.completedTime===steps*.01,{start,done});return {start,done,wallMs:performance.now()-began};});};
  const pause=stage=>page.evaluate(stage=>{let release;const promise=new Promise(resolve=>release=resolve);window.__nativeDomainGate={stage,promise,release,entered:false};},stage);
  const waitGate=()=>page.waitForFunction(()=>window.__nativeDomainGate?.entered,{},{timeout:15000});
  const resume=()=>page.evaluate(()=>{window.__nativeDomainGate?.release();window.__nativeDomainGate=null;});
  const unobserved=(operation,input={},name='__nativeDomainPending')=>page.evaluate(({hash,operation,input,name})=>{window[name]=frameAI.call('plugins.command',{id:hash,operation,args:input});window[name].catch(()=>{});},{hash:owner.hash,operation,input,name});
  const rememberIdentity=()=>page.evaluate(({owner,fan,fluid,solid})=>{const nodes=__nativeDomainContext.document.nodes;window.__nativeDomainIdentity={owner:nodes.find(n=>n.nativeHash===owner),fan:nodes.find(n=>n.nativeHash===fan),fluid:nodes.find(n=>n.nativeHash===fluid),solid:nodes.find(n=>n.nativeHash===solid)};if(!__nativeDomainIdentity.owner||!__nativeDomainIdentity.fan)throw Error('Missing observed native identities');},{owner:owner.hash,fan:fan.hash,fluid:meshes[0],solid:meshes[1]});
  const identity=()=>page.evaluate(({owner,fan,fluid,solid})=>{const nodes=__nativeDomainContext.document.nodes,o=nodes.find(n=>n.nativeHash===owner),f=nodes.find(n=>n.nativeHash===fan);return {fluidPresent:nodes.some(n=>n.nativeHash===fluid),fluidSame:nodes.find(n=>n.nativeHash===fluid)===__nativeDomainIdentity.fluid,solidSame:nodes.find(n=>n.nativeHash===solid)===__nativeDomainIdentity.solid,ownerPresent:!!o,fanPresent:!!f,ownerSame:o===__nativeDomainIdentity.owner,fanSame:f===__nativeDomainIdentity.fan,ownerHash:o?.nativeHash,fanHash:f?.nativeHash,ownerId:o?.id,fanId:f?.id};},{owner:owner.hash,fan:fan.hash,fluid:meshes[0],solid:meshes[1]});
  const selectProbe=async()=>{await call('scene.select',{ids:[probe.hash]});await page.locator('#tabAttributes').click();};
  const measureButton=page.locator('#attrContent [data-plugin-action-button="measure"]');
  const measuredLabel=async()=>{const measurement=await cmd('measure',{},probe.hash);await selectProbe();check('native domain Probe is bounded physical sampling',Number.isFinite(measurement.temperature)&&measurement.cellsRead<=8&&measurement.interpolation==='perfect-contact-resistance-weighted'&&measurement.unit==='°C',measurement);return {measurement,label:await measureButton.textContent()};};
  const nativeFrames=()=>page.evaluate(hash=>{const c=__nativeDomainContext,w=Array.from(c.document.world(hash)),snapshot=c.scene.capture(hash,[],['thermal_material','thermal_heater']);return {ownerWorld:w,ownerLocal:Array.from(c.document.local(hash)),lengthMM:[0,4,8].map(i=>100*Math.hypot(...w.slice(i,i+3))),determinant:w[0]*(w[5]*w[10]-w[6]*w[9])-w[4]*(w[1]*w[10]-w[2]*w[9])+w[8]*(w[1]*w[6]-w[2]*w[5]),sources:snapshot.meshes.map(m=>({hash:m.hash,matrix:Array.from(m.matrix),world:Array.from(c.document.world(m.hash)),triangles:m.triangleCount,storage:m.storage}))};},owner.hash);
  const beforeFrames=await call('diagnostics.frame',{frames:6});
  await call('scene.select',{ids:[owner.hash]});await page.locator('#tabAttributes').click();
  check('first domain Solve starts from stable disabled Clear action',await clearButton.isDisabled()&&(await clearButton.textContent())==='Clear');
  const firstInput=await args(10);await pause('pipeline');await cmd('solve-domain',firstInput);await waitGate();
  check('first domain Solve changes idle Clear to Stop without reselecting owner',await clearButton.isEnabled()&&(await clearButton.textContent())==='Stop');
  await clearButton.click();await resume();check('idle-origin native action cancels first domain Solve',(await timed('first domain Solve native Stop drain',15000,finish)).state==='cancelled');await noField('first native Stop');await clean('first native Stop');
  await clearButton.click();check('same idle-origin action clears stopped domain job',(await cmd('status')).state==='idle'&&await clearButton.isDisabled());

  // Production stays GPU-only. The independent Float64 solver never runs in
  // the browser and cannot mutate or replace any production state.
  for(const variant of [{name:'forward',direction:'Forward',pressure:.02,power:.075,steps:10},{name:'reverse',direction:'Reverse',pressure:.02,power:.075,steps:2},{name:'off',direction:'Forward',pressure:0,power:.075,steps:1},{name:'signed-source',direction:'Forward',pressure:.02,power:-.075,steps:2}]){
   await call('scene.update',{id:fan.hash,params:{Direction:variant.direction,'Shutoff pressure':variant.pressure,'Free flow':.0001}});await call('tag.set',{ids:[groups[1]],kind:'thermal_heater',enabled:true,params:{Power:variant.power}});
   const metadata=await assertFan(variant.name),saved=await solve(variant.steps),actual=await fields(),expected=nativeDomainOracle({...variant,direction:variant.direction==='Forward'?1:-1});
   const oracleErrors={temperatureK:maxDifference(actual.temperature.map(value=>value+273.15),Array.from(expected.temperature))};for(const [component]of components)oracleErrors[component]=maxDifference(actual[component],Array.from(expected[component]));
   check(variant.name+' native T/u/v/w match independent Float64 duration oracle',actual.temperature.length===64&&actual.temperature.every(Number.isFinite)&&components.every(([key,count])=>actual[key].length===count&&actual[key].every(Number.isFinite))&&oracleErrors.temperatureK<=.0005&&components.every(([key])=>oracleErrors[key]<=.00002),oracleErrors);
   const d=saved.done.duration;
   check(variant.name+' native helper SI pitch/length/volume and signed adiabatic accounting agree',saved.done.authoring==='native-box-explicit-grid'&&saved.done.geometryCoupled&&!saved.done.sceneSolver&&!saved.done.generalSceneSolver&&equal(saved.done.cellSize,[.025,.025,.025])&&equal(saved.done.dimensions,[4,4,4])&&near(saved.done.dimensions.map((n,a)=>n*saved.done.cellSize[a]),[.1,.1,.1])&&Math.abs(saved.done.cellSize.reduce((a,b)=>a*b)*64-.001)<1e-18&&saved.done.boundary==='adiabatic'&&saved.done.initialVelocity==='rest'&&saved.done.retainedHostFieldBytes===2432&&saved.done.retainedGPUBytes===0&&saved.done.maxStepWallMs<5000&&d.temperatureAccuracyGuaranteeK===null&&[saved.done.pressureRise,saved.done.correctedFlow,d.sourcePower,d.sourceEnergy,d.thermalEnergyChange,d.thermalBalanceError,d.thermalBalanceAllowance,d.mechanical.balanceError,d.mechanical.balanceAllowance,d.mechanical.midpointWork,d.fluid.balanceError,d.solid.balanceError].every(Number.isFinite)&&d.sourcePower===variant.power&&Math.abs(d.sourceEnergy-variant.power*.01*variant.steps)<1e-10&&Math.abs(d.thermalBalanceError)<=d.thermalBalanceAllowance&&Math.abs(d.mechanical.balanceError)<=d.mechanical.balanceAllowance&&Math.abs(d.fluid.balanceError)<=d.fluid.balanceAllowance&&Math.abs(d.solid.balanceError)<=d.solid.balanceAllowance&&d.boundaryEnergy===0,saved.done);
   check(variant.name+' uses actual native Fan settings',metadata.fan.authored.params.Direction===variant.direction&&metadata.fan.authored.params['Shutoff pressure']===variant.pressure&&(variant.pressure===0?Math.abs(saved.done.correctedFlow)<1e-12:Math.sign(saved.done.correctedFlow)===(variant.direction==='Forward'?1:-1)),{metadata,status:saved.done});
   const measured=await measuredLabel();check(variant.name+' bounded Probe matches resistance-weighted independent oracle',Math.abs(measured.measurement.temperature-expected.probe)<=.0005,{measured,expected:expected.probe});await call('scene.select',{ids:[owner.hash]});await selectProbe();check(variant.name+' selection preserves cached Probe label',/°C/.test(measured.label)&&(await measureButton.textContent())===measured.label,measured);
   const comparisons=[];for(const operation of ['solve-saved-fan','solve-scene']){
    const explicitSolve=await solve(variant.steps,await args(variant.steps,operation),operation),comparison=await fields(),pathErrors={temperatureK:maxDifference(actual.temperature,comparison.temperature)};for(const [key]of components)pathErrors[key]=maxDifference(actual[key],comparison[key]);
    check(variant.name+' native box equals matched existing '+operation,explicitSolve.done.authoring===(operation==='solve-scene'?'explicit-request':'saved-fan-explicit-domain')&&pathErrors.temperatureK<=.0005&&components.every(([key])=>pathErrors[key]<=.00002),pathErrors);comparisons.push({operation,explicitSolve,pathErrors});
   }
   await clean(variant.name);evidence.push({variant,saved,comparisons,oracleErrors,measured});
  }
  await call('scene.update',{id:fan.hash,params:{Direction:'Forward','Shutoff pressure':.02}});await call('tag.set',{ids:[groups[1]],kind:'thermal_heater',enabled:true,params:{Power:.075}});

  // Invalid schema/preflight never cancels a valid predecessor. Invalid geometry
  // may honestly fail after acceptance/classification; it is tested separately.
  await solve();const baseline=await fields(),predecessor=await cmd('status');
  for(const [operation,input]of [['inspect',{count:257}],['inspect-velocity',{component:'u',count:257}]])check('domain field bounded read rejects '+operation+' overflow',await cmd(operation,input).then(()=>false,()=>true));
  const badFan=await cmd('create-fan');await call('scene.update',{id:badFan.hash,enabled:false});
  for(const change of [r=>delete r.fanHash,r=>r.fanHash='missing',r=>r.fanHash=owner.hash,r=>r.fanHash=badFan.hash,r=>delete r.fluidHash,r=>r.fluidHash='',r=>r.fluidHash='missing',r=>r.fluidHash=owner.hash,r=>r.fluidHash=groups[0],r=>r.fluidHash=nativeMeshes.find(n=>n.hash===meshes[0]).id,r=>r.cellSizeMM=[25,25,25],r=>r.domain={},r=>r.ownerWorld=identityMatrix,r=>r.settings.fluidOccurrence=1,r=>r.settings.fanBox={},r=>r.settings.direction=-1,r=>r.dimensions=[4,4,17],r=>r.dimensions=[4,11,4],r=>r.stepCount=11,r=>r.settings.initialCelsius=[1,2],r=>r.settings.timeStep=.2]){
   const input=await args();change(input);const rejected=await cmd('solve-domain',input).then(()=>false,()=>true),state=await cmd('status');check('invalid domain request preserves ready predecessor and exact fields',rejected&&state.job===predecessor.job&&state.state==='ready'&&equal(await fields(),baseline),{input,state});
  }
  await call('scene.update',{id:badFan.hash,enabled:true});await call('scene.select',{ids:[badFan.hash]});await call('transform.set',{channel:'rotation',axis:2,value:30,coordinates:'object'});
  const rotatedMetadata=await cmd('fan-inputs',{},badFan.hash),rotatedArgs=await args();rotatedArgs.fanHash=badFan.hash;
  const rotatedRejected=await cmd('solve-domain',rotatedArgs).then(()=>false,()=>true),afterRotated=await cmd('status');
  check('unsupported native rotated Fan rejects in preflight without replacing predecessor',rotatedMetadata.fan.mapping.status==='unsupported-frame'&&rotatedRejected&&afterRotated.state==='ready'&&afterRotated.job===predecessor.job&&equal(await fields(),baseline),{rotatedMetadata,afterRotated});
  await call('scene.delete',{ids:[badFan.hash]});
  const activeArgs=await args(10);await pause('pipeline');const active=await cmd('solve-domain',activeArgs);await waitGate();const allocations=await resource();
  for(const mutate of [r=>r.settings.timeStep=.02,r=>r.dimensions=[4,11,4],r=>r.fluidHash='missing',r=>r.cellSizeMM=[25,25,25]]){const invalidArgs=await args(10);mutate(invalidArgs);const rejection=await cmd('solve-domain',invalidArgs).then(()=>null,error=>({code:error.code,message:error.message}));check('pure input/native binding rejection preserves running predecessor before interruption',!!rejection&&(await cmd('status')).job===active.job&&(await cmd('status')).state==='running'&&(await resource()).created===allocations.created,{invalidArgs,rejection});}
  await timed('native domain in-flight native API responsiveness',1500,async()=>{await cmd('status');await call('scene.select',{ids:[probe.hash]});await call('scene.select',{ids:[owner.hash]});});
  await page.locator('#tabAttributes').click();check('native domain running action exposes Stop',await clearButton.isEnabled()&&(await clearButton.textContent())==='Stop');
  await clearButton.click();await resume();check('native domain native Stop cancels without partial publication',(await timed('native domain native Stop drain',15000,finish)).state==='cancelled');await noField('Native Stop');await clean('Native Stop');
  await clearButton.click();check('same native action clears cancelled domain job',(await cmd('status')).state==='idle'&&await clearButton.isDisabled());

  // Pure binding errors preserve a predecessor; these geometric errors are
  // deliberately accepted first and may retire it before async classification.
  for(const kind of ['wrong-fluid-role','moved-source','holed-solid','distorted-solid']){
   await solve();const previous=(await cmd('status')).job,input=await args(1),solidHash=meshes[1];
   if(kind==='wrong-fluid-role')input.fluidHash=meshes[1];
   else if(kind==='moved-source'){await call('scene.select',{ids:[meshes[0]]});await call('transform.set',{channel:'position',axis:0,value:1,coordinates:'world'});}
   else{const box=domainBoundaries()[1],vertices=Array.from(box.positions);if(kind==='distorted-solid')vertices[0]+=1;const changed=await call('mesh.replace',{id:solidHash,vertices,indices:Array.from(kind==='holed-solid'?box.indices.slice(3):box.indices)});meshes[1]=changed.object.hash;}
   const accepted=await cmd('solve-domain',input),done=await timed(kind+' actual-domain rejection',15000,finish);
   check(kind+' actual geometry rejects after native acceptance without helper-bound filling',accepted.state==='running'&&accepted.job!==previous&&done.state==='failed'&&!!done.error?.code,{accepted,done});await noField(kind);await clean(kind);
   if(['moved-source','holed-solid','distorted-solid'].includes(kind)){await call('edit.history',{action:'undo'});meshes[1]=solidHash;}
  }

  // Actual native transforms are authored through public APIs, not capture
  // substitutions. Binary signed scales avoid inverse-product residue; ordinary
  // arbitrary rotations must retain their genuine classifier rejection.
  for(const pose of [{name:'translated',position:[16,-32,64]},{name:'nonuniform',size:[200,400,50]},{name:'reflected-binary',scale:[-2,4,.5]}]){
   await cmd('clear');let edits=0;
   if(pose.scale){await call('animation.key',{id:owner.hash,path:'scale',frame:0,value:pose.scale,interpolation:'hard'});edits++;}
   else{await call('scene.select',{ids:[owner.hash]});for(const [axis,value]of (pose.position||pose.size).entries()){await call('transform.set',{channel:pose.position?'position':'size',axis,value,coordinates:pose.position?'world':'object'});edits++;}}
   const frames=await nativeFrames();check(pose.name+' is the actual intended native physical pose',pose.scale?frames.determinant<0&&near(frames.lengthMM,[200,400,50]):pose.position?near(frames.ownerWorld.slice(12,15),pose.position):near(frames.lengthMM,pose.size),frames);
   check(pose.name+' actual inverse-owner capture is exactly identity',frames.sources.length===2&&frames.sources.every(m=>equal(m.matrix,identityMatrix)),frames);
   const solved=await solve(1),actual=await fields(),size=frames.lengthMM.map(x=>x*.001),expected=nativeDomainOracle({size}),oracleErrors={temperatureK:maxDifference(actual.temperature.map(x=>x+273.15),Array.from(expected.temperature))};for(const [key]of components)oracleErrors[key]=maxDifference(actual[key],Array.from(expected[key]));
   check(pose.name+' physical SI lengths, volume, T/u/v/w and Probe agree',near(solved.done.cellSize,size.map(x=>x/4))&&Math.abs(solved.done.cellSize.reduce((a,b)=>a*b)*64-size.reduce((a,b)=>a*b))<1e-16&&oracleErrors.temperatureK<=.0005&&components.every(([key])=>oracleErrors[key]<=.00002)&&Math.abs((await cmd('measure',{},probe.hash)).temperature-expected.probe)<=.0005,{frames,status:solved.done,oracleErrors});
   const framesAfter=await nativeFrames();check(pose.name+' native physical frame stays exact through solve, field reads and Probe',equal(framesAfter,frames)&&(!pose.scale||framesAfter.determinant<0),{frames,framesAfter});
   evidence.push({pose,frames,framesAfter,solved,oracleErrors});await cmd('clear');for(let i=0;i<edits;i++)await call('edit.history',{action:'undo'});
   check(pose.name+' native Undo restores the original physical frame',equal((await nativeFrames()).ownerWorld,identityMatrix));
  }
  await call('scene.select',{ids:[owner.hash]});for(const [axis,value]of [17,29,37].entries())await call('transform.set',{channel:'rotation',axis,value,coordinates:'object'});
  const rotatedFrames=await nativeFrames(),rotatedStart=await cmd('solve-domain',await args(1)),rotatedDone=await timed('arbitrary common rotation exact-classifier rejection',15000,finish);
  check('arbitrary common rotation keeps real inverse-product roundoff and rejects honestly',rotatedFrames.sources.some(m=>!equal(m.matrix,identityMatrix))&&rotatedStart.state==='running'&&rotatedDone.state==='failed'&&rotatedDone.error?.code==='UNSUPPORTED_TRANSFORM',{rotatedFrames,rotatedStart,rotatedDone});await noField('common rotation');await clean('common rotation');for(let i=0;i<3;i++)await call('edit.history',{action:'undo'});

  const other=await call('plugins.create',{plugin:'thermal'});
  const edits=[
   ['direction',()=>call('scene.update',{id:fan.hash,params:{Direction:'Reverse'}}),()=>call('scene.update',{id:fan.hash,params:{Direction:'Forward'}})],
   ['pressure',()=>call('scene.update',{id:fan.hash,params:{'Shutoff pressure':0}}),()=>call('scene.update',{id:fan.hash,params:{'Shutoff pressure':.02}})],
   ['free flow',()=>call('scene.update',{id:fan.hash,params:{'Free flow':.0002}}),()=>call('scene.update',{id:fan.hash,params:{'Free flow':.0001}})],
   ['reference',()=>call('scene.update',{id:fan.hash,params:{Thermal:other.hash}}),()=>call('scene.update',{id:fan.hash,params:{Thermal:owner.hash}})],
   ['enable',()=>call('scene.update',{id:fan.hash,enabled:false}),()=>call('scene.update',{id:fan.hash,enabled:true})],
   ['hierarchy',()=>call('scene.update',{id:fan.hash,parent:other.hash}),()=>call('scene.update',{id:fan.hash,parent:owner.hash})],
   ['transform',async()=>{await call('scene.select',{ids:[fan.hash]});await call('transform.set',{channel:'position',axis:0,value:-24,coordinates:'world'});},async()=>{await call('scene.select',{ids:[fan.hash]});await call('transform.set',{channel:'position',axis:0,value:-25,coordinates:'world'});}]
  ];
  for(const [name,edit,restore]of edits){await solve();await measuredLabel();await edit();const stale=await cmd('status');await selectProbe();check('actual native Fan '+name+' edit invalidates ready field and cached Probe',stale.state==='stale'&&(await measureButton.textContent())==='Measure',stale);await noField(name);await restore();check(name+' restoration never resurrects old result',(await cmd('status')).state!=='ready');await clean(name);}
  const physicalEdits=[
   ['owner translation',async()=>{await call('scene.select',{ids:[owner.hash]});await call('transform.set',{channel:'position',axis:0,value:1,coordinates:'world'});}],
   ['owner box resize',async()=>{await call('scene.select',{ids:[owner.hash]});await call('transform.set',{channel:'size',axis:0,value:200,coordinates:'object'});}],
   ['Fluid enable',()=>call('scene.update',{id:meshes[0],enabled:false})],
   ['Fluid source ancestry',()=>call('scene.update',{id:meshes[0],parent:owner.hash})],
   ['solid source ancestry',()=>call('scene.update',{id:meshes[1],parent:owner.hash})],
   ['source ancestor enable',()=>call('scene.update',{id:groups[0],enabled:false})],
   ['owner Initial',()=>call('scene.update',{id:owner.hash,params:{Initial:27.85}})]
  ];
  for(const [name,edit]of physicalEdits){await solve();await measuredLabel();await edit();await selectProbe();const stale=await cmd('status');check(name+' retires ready domain and cached Probe',stale.state==='stale'&&(await measureButton.textContent())==='Measure',stale);await noField(name);await call('edit.history',{action:'undo'});check(name+' Undo does not resurrect numeric state',(await cmd('status')).state!=='ready');await clean(name);}
  // Presentation edits and selection do not change physical provenance.
  await solve();const presentation=(await cmd('status')).job,{label}=await measuredLabel();await call('scene.update',{id:fan.hash,name:'Authored Fan',visible:false});await selectProbe();check('Fan name/visibility preserve ready job and cached Probe',(await cmd('status')).job===presentation&&(await cmd('status')).state==='ready'&&(await measureButton.textContent())===label);await call('scene.update',{id:fan.hash,visible:true});
  const ancestor=await call('scene.create',{type:'group'});await call('scene.update',{id:owner.hash,parent:ancestor.hash});
  for(const kind of ['enable','transform']){await solve();await measuredLabel();if(kind==='enable')await call('scene.update',{id:ancestor.hash,enabled:false});else{await call('scene.select',{ids:[ancestor.hash]});await call('transform.set',{channel:'position',axis:0,value:1,coordinates:'world'});}await selectProbe();check('native ancestor '+kind+' edit invalidates field and Probe',(await cmd('status')).state==='stale'&&(await measureButton.textContent())==='Measure');await noField('ancestor '+kind);if(kind==='enable')await call('scene.update',{id:ancestor.hash,enabled:true});else{await call('scene.select',{ids:[ancestor.hash]});await call('transform.set',{channel:'position',axis:0,value:0,coordinates:'world'});}}
  await call('scene.update',{id:owner.hash,parent:''});await call('scene.delete',{ids:[ancestor.hash]});await assertFan('Ancestry restored');

  // Existing operations keep their explicit input contracts. In particular,
  // solve-scene ignores saved Fan-only edits, and numeric transform Undo is not
  // mistaken for same-hash node replacement.
  await solve(1,await args(1,'solve-scene'),'solve-scene');const explicitJob=(await cmd('status')).job,explicitFields=await fields();await rememberIdentity();
  for(const [name,edit,restore]of edits){await edit();const state=await cmd('status');check('explicit scene ignores native Fan '+name+' edit',state.state==='ready'&&state.job===explicitJob&&state.authoring==='explicit-request'&&equal(await fields(),explicitFields),state);await restore();}
  await call('scene.select',{ids:[fan.hash]});await call('transform.set',{channel:'position',axis:0,value:-24,coordinates:'world'});await call('edit.history',{action:'undo'});const transformUndoIdentity=await identity();
  check('ordinary transform Undo preserves actual owner/source identities and explicit fields',transformUndoIdentity.ownerSame&&transformUndoIdentity.fanSame&&transformUndoIdentity.fluidSame&&(await cmd('status')).state==='ready'&&equal(await fields(),explicitFields),transformUndoIdentity);await assertFan('Ordinary transform Undo');

  for(const stage of ['classification','pipeline','conduction','heat','final']){
   const input=await args(2);await pause(stage);await cmd('solve-domain',input);await waitGate();const conductionPipelines=await page.evaluate(()=>__nativeDomainConductionPipelines);await noField('held '+stage);
   if(stage==='classification')await call('scene.update',{id:meshes[0],enabled:false});else if(stage==='pipeline')await call('scene.update',{id:owner.hash,params:{Initial:27.85}});else if(stage==='conduction')await call('scene.update',{id:meshes[1],parent:owner.hash});else if(stage==='heat')await call('scene.update',{id:fan.hash,params:{'Free flow':.0002}});else await call('scene.update',{id:groups[0],enabled:false});await resume();const stale=await timed('late native domain edit at '+stage+' drain',15000,finish);
   check('late native domain edit at '+stage+' prevents atomic publication',stale.state==='stale',stale);if(stage==='conduction')check('late native edit stops immediately after genuine conduction pipeline await',await page.evaluate(()=>__nativeDomainConductionPipelines)===conductionPipelines);await noField('late '+stage);await clean('late '+stage);await call('edit.history',{action:'undo'});
  }
  for(const stage of ['classification','pipeline','conduction','heat','final']){
   const input=await args(2);await pause(stage);await cmd('solve-domain',input);await waitGate();const conductionPipelines=await page.evaluate(()=>__nativeDomainConductionPipelines);await call('scene.select',{ids:[owner.hash]});await page.locator('#tabAttributes').click();await clearButton.click();await resume();const done=await timed('Stop at '+stage+' drain',15000,finish);check('Stop at '+stage+' publishes no candidate',done.state==='cancelled',done);if(stage==='conduction')check('Stop halts after genuine conduction pipeline await',await page.evaluate(()=>__nativeDomainConductionPipelines)===conductionPipelines);await noField('Stop '+stage);await clean('Stop '+stage);
  }
  for(const flag of ['author','output','render']){
   const input=await args();await pause('pipeline');await cmd('solve-domain',input);await waitGate();
   await page.evaluate(flag=>{window.__nativeDomainBarrierDone=false;window.__nativeDomainBarrier=__nativeDomainEditor.flush({[flag]:true}).then(()=>__nativeDomainBarrierDone=true);},flag);
   await cmd('status');check(flag+' barrier waits for genuine active domain work',!await page.evaluate(()=>__nativeDomainBarrierDone));await unobserved('clear');await resume();await timed(flag+' Clear and work-tail drain',15000,()=>page.evaluate(async()=>{await __nativeDomainPending;await __nativeDomainBarrier;}));check(flag+' barrier drains retired work',(await cmd('status')).state==='idle'&&await page.evaluate(()=>__nativeDomainBarrierDone));await clean(flag);
  }
  for(const operation of ['cancel','clear']){
   const input=await args(),queued=await timed('queued domain Solve then '+operation,15000,()=>page.evaluate(async({owner,args,operation})=>{const solve=frameAI.call('plugins.command',{id:owner,operation:'solve-domain',args}),stop=frameAI.call('plugins.command',{id:owner,operation,args:{}});return {start:await solve,end:await stop};},{owner:owner.hash,args:input,operation}));
   check('native API queue '+operation+' never publishes domain field',queued.end.state===(operation==='clear'?'idle':'cancelled'),queued);await noField('queued '+operation);await clean('queued '+operation);
  }
  for(const replacement of ['solve-domain','solve-saved-fan','solve-scene','solve-grid']){
   const firstArgs=await args(2),secondArgs=replacement==='solve-grid'?{dimensions:[2,1,1],cellSize:[1,1,1],conductivity:[1],boundary:{xMin:0,xMax:1}}:await args(1,replacement);await pause('pipeline');const first=await cmd('solve-domain',firstArgs);await waitGate();const before=await resource(),second=await cmd(replacement,secondArgs);
   check(replacement+' replacement retains old work tail before allocation',second.state==='running'&&second.job!==first.job&&(await resource()).created===before.created,{first,second,before,after:await resource()});await resume();const done=await timed(replacement+' replacement completed drain',15000,finish);check(replacement+' replacement publishes only the fresh job',done.state==='ready'&&done.job===second.job&&(replacement==='solve-grid'?!done.geometryCoupled:done.duration.completedSteps===1),done);if(replacement==='solve-grid')await cmd('clear');await clean(replacement+' replacement');
  }
  await solve();await measuredLabel();await cmd('clear');check('Clear immediately removes selected domain Probe label',(await measureButton.textContent())==='Measure');await noField('Clear');

  // Re-publish identical SOLID triangles through native topology Undo. Core
  // appends the new solid hash, changing real capture order while the canonical
  // Fluid remains the same. Never reorder the observer's captured arrays.
  await solve();await measuredLabel();const beforeOrder=await cmd('scene-inputs'),stableFluidHash=meshes[0],oldSolidHash=meshes[1],sameBox=domainBoundaries()[1];
  const republished=await timed('native solid republish and source-order change',5000,()=>call('mesh.replace',{id:oldSolidHash,vertices:Array.from(sameBox.positions),indices:Array.from(sameBox.indices)}));meshes[1]=republished.object.hash;
  const reordered=await cmd('scene-inputs');await selectProbe();
  check('native source identity/order changes retire field and Probe without changing fluid hash',meshes[1]!==oldSolidHash&&meshes[0]===stableFluidHash&&fixtureFluidOccurrence(beforeOrder,stableFluidHash)===1&&fixtureFluidOccurrence(reordered,stableFluidHash)===0&&(await cmd('status')).state==='stale'&&(await measureButton.textContent())==='Measure',{beforeOrder,reordered,oldSolidHash,newSolidHash:meshes[1]});await noField('actual source reorder');await clean('actual source reorder');
  const reorderSolve=await solve(1),reorderFields=await fields(),reorderOracle=nativeDomainOracle();check('canonical fluidHash resolves new actual capture order for a fresh solve',maxDifference(reorderFields.temperature.map(x=>x+273.15),Array.from(reorderOracle.temperature))<=.0005&&components.every(([key])=>maxDifference(reorderFields[key],Array.from(reorderOracle[key]))<=.00002),{reorderSolve,reordered});evidence.push({sourceReorder:{beforeOrder,reordered,reorderSolve,fluidHash:stableFluidHash}});

  // Real deletion/document restoration replaces JS nodes. Native frame Undo does
  // not; never use equal hashes or ordinary frame history as replacement proof.
  await solve();await rememberIdentity();const originalIdentity=await identity();await measuredLabel();
  await call('scene.delete',{ids:[owner.hash]});const absent=await identity();check('native deletion removes actual owner and Fan nodes',!absent.ownerPresent&&!absent.fanPresent,absent);
  await call('edit.history',{action:'undo'});const restored=await identity(),retired=await cmd('status');check('delete Undo restores hashes with new owner/Fan identities and no field',restored.ownerPresent&&restored.fanPresent&&!restored.ownerSame&&!restored.fanSame&&!restored.fluidSame&&!restored.solidSame&&restored.ownerHash===owner.hash&&restored.fanHash===fan.hash&&restored.ownerId===originalIdentity.ownerId&&retired.state==='idle'&&retired.job===null,{originalIdentity,restored,retired});await noField('delete Undo');await selectProbe();check('delete Undo never restores numeric Probe label',(await measureButton.textContent())==='Measure');await solve();
  // The restored owner must retain the old pending tail even while its new
  // same-hash job is accepted, with no second allocation before old work drains.
  const heldArgs=await args(2);await pause('pipeline');const held=await cmd('solve-domain',heldArgs);await waitGate();const heldResources=await resource();await rememberIdentity();await call('scene.delete',{ids:[owner.hash]});await call('edit.history',{action:'undo'});const replaced=await identity(),restart=await cmd('solve-domain',await args(1));
  check('in-flight delete Undo requires new identity and drains before allocation',!replaced.ownerSame&&!replaced.fanSame&&!replaced.fluidSame&&restart.job!==held.job&&restart.state==='running'&&(await resource()).created===heldResources.created,{held,restart,replaced,heldResources,now:await resource()});
  await page.evaluate(()=>{window.__nativeDomainBarrierDone=false;window.__nativeDomainBarrier=__nativeDomainEditor.flush({render:true}).then(()=>__nativeDomainBarrierDone=true);});await cmd('status');check('restored owner render barrier includes retired job',!await page.evaluate(()=>__nativeDomainBarrierDone));await resume();await timed('delete Undo old/new domain work drain',15000,()=>page.evaluate(()=>__nativeDomainBarrier));const restarted=await finish();check('old completion cannot overwrite restored domain owner',restarted.state==='ready'&&restarted.job===restart.job&&restarted.duration.completedSteps===1,restarted);await clean('delete Undo replacement');
  const exported=await call('scene.export',{includeData:true}),beforeOpenFan=(await objects()).find(n=>n.hash===fan.hash),beforeOpenJob=(await cmd('status')).job;await rememberIdentity();await call('scene.open',{name:'thermal-native-domain.hash',base64:exported.base64});
  const reopened=await identity(),openStatus=await cmd('status'),openObjects=await objects(),openFan=openObjects.find(n=>n.hash===fan.hash),openCapture=await cmd('scene-inputs'),fluidOccurrence=fixtureFluidOccurrence(openCapture,meshes[0]);
  check('HASH Open restores authoring with replacement identities, never runtime state',!reopened.ownerSame&&!reopened.fanSame&&!reopened.fluidSame&&reopened.ownerHash===owner.hash&&reopened.fanHash===fan.hash&&openStatus.state==='idle'&&openStatus.job===null&&equal(openFan.params,beforeOpenFan.params)&&equal(openFan.matrix,beforeOpenFan.matrix)&&openFan.params.Thermal===owner.hash,{reopened,openStatus,openFan});
  check('HASH Open explicitly resolves stable fluid hash in the current capture',openCapture.occurrences.filter(o=>o.hash===meshes[0]).length===1&&openCapture.occurrences.find(o=>o.occurrence===fluidOccurrence)?.hash===meshes[0],{initialCapture,reordered,openCapture,fluidHash:meshes[0],fluidOccurrence,hashChangedCaptureOrder:fixtureFluidOccurrence(reordered,meshes[0])!==fluidOccurrence});checkDefaultProbeFrame(check,openObjects,probe.hash,owner.hash,'HASH native-domain Probe');await noField('HASH Open');
  await assertFan('HASH native domain');const fresh=await solve(1);check('HASH fresh canonical binding preserves the independent numerical field',maxDifference((await fields()).temperature,reorderFields.temperature)<=.0005);check('HASH requires a fresh domain job',fresh.done.job!==beforeOpenJob&&fresh.done.authoring==='native-box-explicit-grid',fresh);await measuredLabel();await cmd('clear');await clean('final Clear');
  await call('view.set',{index:0,single:true,focus:owner.hash});await call('diagnostics.frame',{frames:6});const afterFrames=await call('diagnostics.frame',{frames:12});
  check('native domain fixture has bounded current CPU/GPU frame timings',afterFrames.timestampQueries&&afterFrames.frames.length===12&&afterFrames.frames.every(frame=>Number.isFinite(frame.cpuMs)&&Number.isFinite(frame.gpuMs)&&frame.cpuMs<50&&frame.gpuMs<50),{beforeFrames,afterFrames});
  const gpu=await page.evaluate(async()=>({validation:(await frameEngine.renderer.device.popErrorScope())?.message||null,uncaptured:__nativeDomainGPU,lost:__nativeDomainLost,resources:__nativeDomainOwned,sameDevice:frameEngine.renderer.device===__nativeDomainDevice}));
  check('native domain completes without validation/device-loss/page errors or owned buffer leaks',gpu.sameDevice&&!gpu.validation&&!gpu.uncaptured.length&&!gpu.lost&&!errors.length&&!consoleErrors.length&&gpu.resources.live===0&&gpu.resources.created===gpu.resources.destroyed&&gpu.resources.unresolvedLabels===0&&!gpu.resources.unrecognizedCallsites.length,{gpu,errors,consoleErrors});
  check('allocation observer covers unlabelled MAC/advection plus classification and conduction',gpu.resources.unlabelled>0&&['touching-classifier.js','plugin.js','mac-projection-gpu.js','mac-viscosity-gpu.js','mac-fan-gpu.js','temperature-advection-gpu.js'].every(file=>gpu.resources.byModule['/plugins/thermal/'+file]>0),gpu.resources);
  const sourcesAfter=await nativeDomainSourceSnapshot();check('native domain tested source bytes remain unchanged',equal(sources,sourcesAfter),{sources,sourcesAfter});
  return {hardware,beforeFrames,afterFrames,evidence,gpu,errors,consoleErrors,sources,sourcesAfter,missingGates:['Deliberate destruction/loss of the shared renderer device is not injected in this gate; native-device-loss CPU lifecycle tests are not hardware loss proof.','Maximum-grid duration, large native scenes, general geometry and complete application/stress/release qualification remain separate.','Reflected static key authoring is tested at one paused native pose only; this is not timeline or animation-physics qualification.']};
 }catch(error){error.nativeDomainEvidence={sources,errors,consoleErrors,gpu:await page.evaluate(()=>({uncaptured:window.__nativeDomainGPU||[],lost:window.__nativeDomainLost||null,resources:window.__nativeDomainOwned||null,gate:window.__nativeDomainGate?{stage:__nativeDomainGate.stage,entered:__nativeDomainGate.entered}:null})).catch(()=>null)};throw error;}
 finally{await page.evaluate(()=>window.__nativeDomainGate?.release()).catch(()=>{});await context.close();}
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const checks=[],timings=[],sources=await nativeDomainSourceSnapshot();let session,result;
 const check=(name,pass,detail)=>{checks.push({name,pass:!!pass,detail});if(!pass)throw Error(name+': '+JSON.stringify(detail));};
 const timed=async(name,limit,fn)=>{const start=performance.now(),value=await fn(),ms=performance.now()-start;timings.push({name,ms,limit});check(name+' latency',ms<limit,{ms,limit});return value;};
 try{session=await launch({headless:process.argv.includes('--headless')});const evidence=await nativeDomainBrowserChecks(session.page,check,timed);result={pass:true,hardwareVerified:true,checks,timings,evidence};}
 catch(error){result={pass:false,hardwareVerified:false,checks,timings,evidence:error.nativeDomainEvidence||null,error:error.stack||String(error)};}
 finally{await session?.close();}
 result.sources=sources;result.sourcesAfter=await nativeDomainSourceSnapshot();result.sourcesUnchanged=equal(sources,result.sourcesAfter);if(!result.sourcesUnchanged){result.pass=false;result.hardwareVerified=false;result.sourceError='Source bytes changed during the run; no hardware qualification applies.';}
 await mkdir(new URL('tests/results/',root),{recursive:true});await writeFile(new URL('tests/results/thermal-native-domain.json',root),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;
}
