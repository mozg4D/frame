import {maskedProjectionGPUChecks} from './masked-projection-gpu-checks.mjs';
import {durationBrowserChecks} from './duration-browser-fixtures.mjs';
import {nativeJobBrowserChecks} from './native-job-browser.mjs';
import {exteriorFilmBrowserChecks} from './exterior-film-browser.mjs';
import {nativeDomainBrowserChecks} from './native-domain-browser.mjs';
import {nativeSavedFanBrowserChecks} from './native-saved-fan-browser.mjs';
import {nativeFanBrowserChecks} from './native-fan-browser.mjs';
import {nativeProbeBrowserChecks,checkDefaultProbeFrame} from './native-probe-browser.mjs';
import {sceneConjugateBrowserChecks} from './scene-conjugate-browser.mjs';
import {conjugateHeatGPUChecks} from './conjugate-heat-gpu-checks.mjs';
import {forcedHeatGPUChecks} from './forced-heat-gpu-checks.mjs';
import {forcedTemperatureGPUChecks} from './forced-temperature-gpu-checks.mjs';
import {projectTemperatureGPUChecks} from './project-temperature-gpu-checks.mjs';
import {temperatureAdvectionGPUChecks} from './temperature-advection-gpu-checks.mjs';
import {macFanGPUChecks} from './mac-fan-gpu-checks.mjs';
import {macViscosityGPUChecks} from './mac-viscosity-gpu-checks.mjs';
import {macProjectionGPUChecks} from './mac-projection-gpu-checks.mjs';
import {layeredGPUChecks} from './layered-gpu-checks.mjs';
import {cases,referenceSystem,solveDense} from './reference.mjs';

export async function pluginChecks(page) {
  const checks=[],timings=[];
  const check=(name,pass,detail)=>{checks.push({name:'Thermal: '+name,pass:!!pass,detail});if(!pass)throw Error(name+': '+JSON.stringify(detail));};
  const timed=async(name,limit,fn)=>{const started=performance.now(),result=await fn(),ms=performance.now()-started;timings.push({name:'Thermal '+name,ms,limit});check(name+' latency',ms<limit,{ms,limit});return result;};
  const call=(name,args={})=>page.evaluate(([name,args])=>frameAI.call(name,args),[name,args]);
  try {
    const adapter=await page.evaluate(async()=>{const a=await navigator.gpu?.requestAdapter();if(!a)return null;return {fallback:!!a.isFallbackAdapter,...Object.fromEntries(['vendor','architecture','device','description'].map(k=>[k,a.info?.[k]||'']))};});
    check('hardware WebGPU is available (no software fallback)',!!adapter&&!adapter.fallback&&!/swiftshader|llvmpipe|lavapipe|software/i.test(JSON.stringify(adapter)),adapter);
    for(const [name,problem]of Object.entries(cases)) {
      const input={...problem,tolerance:2e-5};
      const result=await timed('completed GPU '+name,15000,()=>page.evaluate(async input=>{
        const m=await import('/plugins/thermal/plugin.js'),grid=m.assembleConduction(input),result=await m.solveConductionGPU(frameEngine.renderer.device,grid);
        try {const sample=await result.inspect(0,grid.count);return {values:sample.temperatures,metrics:{...result.metrics}};} finally {result.dispose();}
      },input));
      const expected=solveDense(referenceSystem(input)),maxError=Math.max(...expected.map((t,i)=>Math.abs(t-result.values[i])));
      check(name+' GPU field agrees with independent Float64 solve',maxError<.01,{maxError,metrics:result.metrics});
      check(name+' residual meets requested criterion',result.metrics.residualK<=input.tolerance,result.metrics);
      check(name+' energy accounting closes',Math.abs(result.metrics.energyImbalanceW)<Math.max(.0001,Math.abs(result.metrics.sourcePowerW)*.0001),result.metrics);
      check(name+' bounded metrics readback',result.metrics.readbackBytes<=32*(2+Math.ceil(result.metrics.iterations/64))+problem.dimensions.reduce((a,b)=>a*b)*4,result.metrics);
    }
    await layeredGPUChecks(page,check,timed);
    await macProjectionGPUChecks(page,check,timed);
    await maskedProjectionGPUChecks(page,check,timed);
    await macViscosityGPUChecks(page,check,timed);
    await macFanGPUChecks(page,check,timed);
    await temperatureAdvectionGPUChecks(page,check,timed);
    await projectTemperatureGPUChecks(page,check,timed);
    await forcedTemperatureGPUChecks(page,check,timed);
    await forcedHeatGPUChecks(page,check,timed);
    await conjugateHeatGPUChecks(page,check,timed);
    await sceneConjugateBrowserChecks(page,check,timed);
    await durationBrowserChecks(page,check,timed);
    await nativeJobBrowserChecks(page,check,timed);
    await nativeSavedFanBrowserChecks(page,check,timed);
    await nativeDomainBrowserChecks(page,check,timed);
    await exteriorFilmBrowserChecks(page,check,timed);
    await nativeFanBrowserChecks(page,check,timed);
    await nativeProbeBrowserChecks(page,check,timed);
    const cancelled=await page.evaluate(async()=>{
      const m=await import('/plugins/thermal/plugin.js'),g=m.assembleConduction({dimensions:[32,1,1],cellSize:[.01,.01,.01],conductivity:[1],boundary:{xMin:0,xMax:100}});
      let count=0;try{await m.solveConductionGPU(frameEngine.renderer.device,g,{check(){if(++count>3)throw Object.assign(Error('cancelled'),{code:'CANCELLED'});}});return null;}catch(e){return e.code;}
    });check('cancellation never publishes a field',cancelled==='CANCELLED',cancelled);
    const nonconverged=await page.evaluate(async()=>{
      const m=await import('/plugins/thermal/plugin.js'),g=m.assembleConduction({dimensions:[16,1,1],cellSize:[.01,.01,.01],conductivity:[1],boundary:{xMin:0,xMax:100},maxIterations:1});
      try{const result=await m.solveConductionGPU(frameEngine.renderer.device,g);result.dispose();return null;}catch(e){return e.code;}
    });check('iteration limit does not publish an approximate success',nonconverged==='NOT_CONVERGED',nonconverged);

    const old=await call('scene.inspect');if(old.objects.length)await call('scene.delete',{ids:old.objects.filter(n=>!n.parent).map(n=>n.hash)});
    const owner=await timed('native creation',10000,()=>call('plugins.create',{plugin:'thermal'}));
    const cmd=(operation,args={},id=owner.hash)=>call('plugins.command',{id,operation,args});
    const idle=await cmd('status');check('foundation is not advertised as a scene solver',idle.sceneSolver===false&&idle.state==='idle',idle);
    const tools=await call('plugins.describe',{plugin:'thermal'});check('numerical API is discoverable',JSON.stringify(tools).includes('solve-grid'),tools);
    const group=await call('scene.create',{type:'group'}),body=await call('scene.create',{type:'cube',parent:group.hash});
    await timed('native Material and Heater tagging',2000,async()=>{
      await call('tag.set',{ids:[group.hash],kind:'thermal_material',enabled:true,params:{Conductivity:16,'Heat capacity':3800000}});
      await call('tag.set',{ids:[group.hash],kind:'thermal_heater',enabled:true,params:{Power:-25}});
    });
    const inputs=await timed('scene input inspection',2000,()=>cmd('scene-inputs'));
    const tagged=inputs.occurrences.find(m=>m.hash===body.hash);
    check('scene capture reads inherited Material and signed Heater without claiming physics',tagged?.tags.find(t=>t.kind==='thermal_material')?.params.Conductivity===16&&tagged.tags.find(t=>t.kind==='thermal_heater')?.params.Power===-25&&inputs.sceneSolver===false&&inputs.powerNormalized===false,inputs);
    check('scene tags preserve native source provenance',tagged.tags.every(t=>t.source===group.hash));
    const invalidTag=await call('tag.set',{ids:[group.hash,body.hash],kind:'thermal_material',enabled:true,params:{Conductivity:0}}).then(()=>false,()=>true);
    check('invalid material rejects atomically',invalidTag&&JSON.stringify(inputs.occurrences)===JSON.stringify((await cmd('scene-inputs')).occurrences));
    await call('tag.set',{ids:[group.hash],kind:'thermal_heater',enabled:true,params:{Power:50}});
    await call('edit.history',{action:'undo'});
    check('Heater edit Undo restores signed power',(await cmd('scene-inputs')).occurrences.find(m=>m.hash===body.hash).tags.find(t=>t.kind==='thermal_heater').params.Power===-25);
    const boundary=await timed('aggregate boundary inspection',15000,()=>cmd('inspect-geometry'));
    check('aggregate boundary inspection does not claim material volume or solve',boundary.aggregateBoundaryValidated&&boundary.triangleCount>0&&!boundary.materialVolumesClassified&&!boundary.sceneSolver,boundary);
    await call('scene.delete',{ids:[group.hash]});
    const start=await cmd('solve-grid',cases.slab);check('solve returns a nonblocking job',start.state==='running',start);
    let done;await timed('native numerical job completion',15000,async()=>{for(let i=0;i<600;i++){done=await cmd('status');if(done.state!=='running')return;await new Promise(r=>setTimeout(r,10));}throw Error('Thermal job timed out');});
    check('native numerical job completes',done.state==='ready',done);
    const before=(await cmd('inspect',{offset:0,count:16})).temperatures;
    const probe=await timed('native Probe creation',2000,()=>cmd('create-probe'));
    checkDefaultProbeFrame(check,(await call('scene.inspect')).objects,probe.hash,owner.hash,'Explicit-grid Probe');
    const measured=await timed('Probe measurement',2000,()=>cmd('measure',{},probe.hash));
    check('Probe samples centre of explicit grid',Math.abs(measured.temperature-50)<.01&&measured.cellsRead<=8,measured);
    await call('scene.select',{ids:[probe.hash]});await page.locator('#tabAttributes').click();
    const measureButton=page.locator('#attrContent [data-plugin-action-button="measure"]');
    check('Probe shows its bounded temperature in the native action',/50\.00.*°C/.test(await measureButton.textContent()));
    await measureButton.click();
    check('repeated native measurement preserves result',Math.abs((await cmd('measure',{},probe.hash)).temperature-50)<.01);
    const invalid=await cmd('solve-grid',{...cases.slab,conductivity:[-1]}).then(()=>false,()=>true);check('invalid request rejects before replacing a completed field',invalid&&(await cmd('status')).state==='ready');
    check('invalid request preserves the exact field',JSON.stringify(before)===JSON.stringify((await cmd('inspect',{offset:0,count:16})).temperatures));
    const a=await call('scene.export',{includeData:true});
    const copy=(await call('scene.duplicate',{ids:[owner.hash]})).objects.find(n=>n.type==='thermal');
    check('duplicates have independent runtime state',(await cmd('status',{},copy.hash)).state==='idle');
    await cmd('clear');check('clear releases numerical state',(await cmd('status')).state==='idle');
    check('Probe rejects cleared fields',await cmd('measure',{},probe.hash).then(()=>false,()=>true));
    await call('scene.open',{name:'thermal-foundation.hash',base64:a.base64});
    check('Probe HASH restores its native Thermal reference',(await call('scene.inspect')).objects.some(n=>n.hash===probe.hash&&n.params?.Thermal===owner.hash));
    checkDefaultProbeFrame(check,(await call('scene.inspect')).objects,probe.hash,owner.hash,'HASH-restored Probe');
    check('HASH restores authoring but no derived field',(await cmd('status')).state==='idle');
    await call('scene.select',{ids:[owner.hash]});await page.locator('#tabAttributes').click();
    const labels=await page.locator('#attrContent .attr-lab').allTextContents();check('native editable Celsius attributes only',labels.includes('Ambient (°C)')&&labels.includes('Initial (°C)'),labels);
    check('no unimplemented scene Solve button',await page.locator('#attrContent [data-plugin-action-button="solve"]').count()===0);
    await call('scene.delete',{ids:[owner.hash]});
    return {pass:true,checks,timings};
  } catch(e) {return {pass:false,checks,timings,error:e.stack};}
}
