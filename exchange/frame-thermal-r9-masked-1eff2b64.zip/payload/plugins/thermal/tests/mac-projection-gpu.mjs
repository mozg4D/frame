import test from 'node:test';
import assert from 'node:assert/strict';
import {assembleMACProjection,validateMACProjection,projectMACGPU} from '../mac-projection-gpu.js';
import {projectMAC} from './mac-projection-reference.mjs';
export function fixture(d=[4,3,2]){
 const fields=d.map((_,a)=>{const s=[...d];s[a]++;return Array.from({length:s.reduce((a,b)=>a*b)},(_,i)=>{const p=[i%s[0],Math.floor(i/s[0])%s[1],Math.floor(i/(s[0]*s[1]))];return p[a]===0||p[a]===d[a]?0:Math.sin(i*1.37+a)*.1;});});
 return {dimensions:d,size:[1,.8,.6],density:1.2,timeStep:.01,u:fields[0],v:fields[1],w:fields[2]};
}
function reference(f){return projectMAC({...f,u:Float64Array.from(f.u),v:Float64Array.from(f.v),w:Float64Array.from(f.w),solid:new Uint8Array(f.dimensions.reduce((a,b)=>a*b)),tolerance:1e-10});}
test('host assembly and returned-field gate agree with independent MAC reference',()=>{
 for(const dimensions of [[2,2,2],[4,3,2],[5,4,3]]){const f=fixture(dimensions),p=assembleMACProjection(f),r=reference(f),pressure=Float32Array.from(r.pressure,x=>x/p.pressureScale),velocity=Float32Array.from(p.edges,e=>r[['u','v','w'][e.axis]][e.index]/p.speed),m=validateMACProjection(p,pressure,velocity);assert.ok(m.energyAfter<m.energyBefore);assert.ok(m.maxDivergence<=m.maxDivergenceAllowance);}
});
test('actual nonconservative or inconsistent GPU outputs cannot pass',()=>{
 const p=assembleMACProjection(fixture());assert.throws(()=>validateMACProjection(p,new Float32Array(p.n),Float32Array.from(p.edges,e=>e.q)),{code:'NONCONVERGENCE'});
 assert.throws(()=>validateMACProjection(p,new Float32Array(p.n),new Float32Array(p.edges.length)),{code:'NUMERICAL_RANGE'});
 assert.throws(()=>validateMACProjection(p,new Float32Array(p.n).fill(NaN),new Float32Array(p.edges.length)),{code:'NUMERICAL_RANGE'});
});
test('strict unsupported and numerical gates',()=>{
 const f=fixture();for(const input of [{...f,solid:[]},{...f,dimensions:[4,,2]},{...f,u:new Array(f.u.length)},{...f,size:[1,1,1e-9]},{...f,density:1e300,timeStep:1e-300}])assert.throws(()=>assembleMACProjection(input));
 const g=fixture();g.u[0]=1;assert.throws(()=>assembleMACProjection(g),{code:'INVALID_BOUNDARY'});
 const h=fixture();h.u[1]=Number.MIN_VALUE;assert.throws(()=>assembleMACProjection(h),{code:'NUMERICAL_RANGE'});
});
test('no device, pre-abort and caller stale reject without CPU fallback',async()=>{
 await assert.rejects(projectMACGPU({},fixture()),{code:'WEBGPU_REQUIRED'});const c=new AbortController();c.abort();await assert.rejects(projectMACGPU({},fixture(),{signal:c.signal}),{code:'CANCELLED'});
 await assert.rejects(projectMACGPU({},fixture(),{check(){throw Object.assign(new Error('stale'),{code:'STALE_JOB'});}}),{code:'STALE_JOB'});
});
import {deviceEmulator} from './mac-projection-device-emulator.mjs';
globalThis.GPUBufferUsage={STORAGE:1,COPY_DST:2,COPY_SRC:4,UNIFORM:8,MAP_READ:16};globalThis.GPUShaderStage={COMPUTE:1};globalThis.GPUMapMode={READ:1};
test('emulated command orchestration matches independent solve and releases all allocations',async()=>{
 const f=fixture(),fake=deviceEmulator(),r=await projectMACGPU({device:fake.device},f),expected=reference(f);
 for(const key of ['u','v','w'])assert.ok(Math.max(...r[key].map((x,i)=>Math.abs(x-expected[key][i])))<1e-4);
 const stats=fake.stats();assert.equal(stats.created,stats.destroyed);assert.equal(stats.live,0);assert.equal(stats.scopes,0);assert.ok(stats.peak<=r.metrics.peakGPUBytes);assert.equal(r.metrics.retainedGPUBytes,0);
});
test('pipeline failure, stale device, exhausted iteration and in-flight abort clean all owned buffers',async()=>{
 for(const kind of ['pipeline','stale','cancel','exhausted']){const controller=new AbortController(),context={};const fake=deviceEmulator({pipelineFailure:kind==='pipeline',afterSubmit(){if(kind==='stale')context.device=null;if(kind==='cancel')controller.abort();}});context.device=fake.device;
 await assert.rejects(projectMACGPU(context,{...fixture(),...kind==='exhausted'?{maxIterations:1}:{}},{signal:controller.signal}));const stats=fake.stats();assert.equal(stats.created,stats.destroyed);assert.equal(stats.scopes,0);}
});
test('16³ bounded upload plan performance',()=>{const start=performance.now(),p=assembleMACProjection(fixture([16,16,16])),ms=performance.now()-start;console.log(`MAC GPU plan 16³: ${ms.toFixed(2)} ms; cells=${p.n}, edges=${p.edges.length}`);assert.ok(ms<1500);assert.equal(p.n,4096);});
test('analytic pure gradient cancels and zero field stays zero in command orchestration',async()=>{
 const f=fixture([3,3,3]),p=assembleMACProjection(f);for(const key of ['u','v','w'])f[key].fill(0);
 const potential=Array.from({length:p.n},(_,i)=>Math.cos(i*.7)*.01);
 for(const e of p.edges)f[['u','v','w'][e.axis]][e.index]=(potential[e.right]-potential[e.left])/p.h[e.axis];
 const fake=deviceEmulator(),r=await projectMACGPU({device:fake.device},f);assert.ok(Math.max(...r.u.map(Math.abs),...r.v.map(Math.abs),...r.w.map(Math.abs))<1e-5);
 for(const key of ['u','v','w'])f[key].fill(0);const zero=await projectMACGPU({device:fake.device},f);assert.equal(zero.metrics.energyAfter,0);assert.equal(zero.metrics.maxDivergence,0);
});
test('constant pressure gauge cannot erase divergence-free circulation',()=>{
 for(const sign of [-1,1])for(const gauge of [0,1e8,-1e8,1e30]){
  const f={dimensions:[2,2,2],size:[1,1,1],density:1,timeStep:.1,u:new Float64Array(12),v:new Float64Array(12),w:new Float64Array(12)};
  f.u[1]=sign;f.u[4]=-sign;f.v[3]=sign;f.v[2]=-sign;
  const p=assembleMACProjection(f),pressure=new Float32Array(p.n).fill(gauge);
  assert.equal(p.rhsNorm,0);
  assert.throws(()=>validateMACProjection(p,pressure,new Float32Array(p.edges.length)),{code:'NUMERICAL_RANGE'});
  const m=validateMACProjection(p,pressure,Float32Array.from(p.edges,e=>e.q));
  assert.equal(m.energyBefore,.25);assert.equal(m.energyAfter,.25);assert.equal(m.maxDivergence,0);
 }
});
