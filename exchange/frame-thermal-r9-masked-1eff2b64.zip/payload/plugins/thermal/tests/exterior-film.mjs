import test from 'node:test';
import assert from 'node:assert/strict';
import {assembleConduction,gridSchema} from '../plugin.js';
import {snapshotExteriorFilm,exteriorFaces} from '../exterior-film.js';
import {assembleLayeredHeatGPU,solveLayeredHeatGPU} from '../layered-heat-gpu.js';
import {assembleConjugateHeatGPU,stepConjugateHeatGPU} from '../conjugate-heat-gpu.js';
import {createConjugateDurationStepper,advanceConjugateHeatGPU} from '../scene-conjugate-duration.js';
import {snapshotNativeSceneRequest} from '../native-scene-request.js';
import {deviceEmulator} from './conjugate-device-emulator.mjs';
import {fixture as nativeFixture,sceneRequest,gridRequest} from './native-job-fixture.mjs';
globalThis.GPUBufferUsage={STORAGE:1,COPY_DST:2,COPY_SRC:4,UNIFORM:8,MAP_READ:16};globalThis.GPUShaderStage={COMPUTE:1};globalThis.GPUMapMode={READ:1};
const boundary=(ambientKelvin=280,hWPerM2K=5)=>({kind:'exterior-film',faces:{xMax:{hWPerM2K,ambientKelvin}}});
function input(b=boundary()){return {dimensions:[4,3,2],size:[1,.8,1.2],fluidCellsX:2,fluid:{density:1,specificHeat:10,conductivity:2,viscosity:.2},solid:{density:3,specificHeat:7,conductivity:8},timeStep:.01,u:new Float64Array(30),v:new Float64Array(32),w:new Float64Array(36),temperature:new Float64Array(24).fill(300),solidSourceDensity:[0],fan:{sheet:{x:1,y:[1,2],z:[0,1]},shutoffPressure:0,freeFlow:.1,direction:1},divergenceDriftBudgetK:.001,...b===undefined?{}:{boundary:b}};}
const options=n=>({stepCount:n,cumulativeDivergenceDriftBudgetK:.001});
const clean=f=>{assert.equal(f.stats().live,0);assert.equal(f.stats().scopes,0);assert.equal(f.stats().created,f.stats().destroyed);};
const layer=f=>({dimensions:f.dimensions,size:f.size,fluidCellsX:f.fluidCellsX,fluid:{density:f.fluid.density,specificHeat:f.fluid.specificHeat,conductivity:f.fluid.conductivity},solid:f.solid,temperature:f.temperature,solidSourceDensity:f.solidSourceDensity,timeStep:f.timeStep,boundary:f.boundary,tolerance:1e-5});

test('omitted and explicit zero-h boundaries preserve the original adiabatic arrays and actual duration fields',async()=>{
 const a=input('adiabatic'),b=input(boundary(1400,0));delete a.boundary;const p=assembleConjugateHeatGPU(a),q=assembleConjugateHeatGPU(b);
 for(const k of ['coefficients','accounting','initial'])assert.deepEqual(p.grid[k],q.grid[k]);
 const f=deviceEmulator(),g=deviceEmulator(),x=await advanceConjugateHeatGPU({device:f.device},a,options(3)),y=await advanceConjugateHeatGPU({device:g.device},b,options(3));
 for(const k of ['temperature','u','v','w'])assert.deepEqual(x[k],y[k]);assert.equal(y.duration.boundaryEnergyOutJ,0);assert.equal(y.duration.sourceEnergy,x.duration.sourceEnergy);clean(f);clean(g);
});
test('whole-face film carries half-cell resistance and heterogeneous transverse material conductance',()=>{
 const f=input();f.boundary.faces.yMax={hWPerM2K:5,ambientKelvin:320};const g=assembleConjugateHeatGPU(f).grid;
 const area=g.cellSize[0]*g.cellSize[2],side=g.exteriorFilm.filter(e=>e.face==='yMax');assert.equal(side.length,8);
 for(const e of side){const k=e.cell%4<2?2:8;assert.equal(e.g,area/(g.cellSize[1]/(2*k)+1/5));}
 assert.ok(side.find(e=>e.cell%4===3).g>side.find(e=>e.cell%4===0).g);
 assert.equal(g.exteriorFilm.filter(e=>e.cell===11).length,2);
});
test('ten-step signed bath energy is accumulated from every actual step, not its endpoint',async()=>{
 for(const bath of [280,320]){const f=input(boundary(bath)),gpu=deviceEmulator(),qs=[],advance=createConjugateDurationStepper(async(c,i,o)=>{const r=await stepConjugateHeatGPU(c,i,o);qs.push(r.thermal.conduction.boundaryPowerOutW);return r;}),r=await advance({device:gpu.device},f,options(10)),energy=qs.reduce((s,q)=>s+q*f.timeStep,0);
  assert.equal(r.duration.boundaryEnergyOutJ,energy);assert.equal(r.duration.boundaryEnergyByFaceJ.xMax,energy);assert.equal(Math.sign(energy),Math.sign(300-bath));assert.ok(Math.abs(energy-qs.at(-1)*.1)>.01);assert.ok(Math.abs(r.duration.thermalBalanceError)<r.duration.thermalBalanceAllowance);assert.equal(r.duration.boundaryEnergyOutJ,r.duration.solid.boundaryEnergyOutJ);clean(gpu);
 }
});
test('solid heater/source sign remains separate from bath and mechanical work',async()=>{
 for(const sign of [-1,1]){const f=input();f.solidSourceDensity=[200*sign];f.fan.shutoffPressure=2;const gpu=deviceEmulator(),r=await advanceConjugateHeatGPU({device:gpu.device},f,options(2));
  assert.ok(Math.abs(r.duration.sourceEnergy-sign*1.92)<1e-12);assert.ok(r.duration.boundaryEnergyOutJ>0);assert.ok(r.duration.mechanical.midpointWork>0);assert.ok(Math.abs(r.duration.thermalEnergyChange-r.duration.sourceEnergy+r.duration.boundaryEnergyOutJ)<=r.duration.thermalBalanceAllowance);clean(gpu);
 }
});
test('duration freezes nested film before first asynchronous stage and never borrows caller h or ambient',async()=>{
 const f=input(),expected=structuredClone(f),gpu=deviceEmulator();let calls=0;
 const advance=createConjugateDurationStepper(async(c,i,o)=>{assert.ok(Object.isFrozen(i.boundary.faces.xMax));if(++calls===1){f.boundary.faces.xMax.hWPerM2K=0;f.boundary.faces.xMax.ambientKelvin=1900;f.boundary.faces.yMin={hWPerM2K:100,ambientKelvin:500};}return stepConjugateHeatGPU(c,i,o);});
 const r=await advance({device:gpu.device},f,options(2)),other=deviceEmulator(),q=await advanceConjugateHeatGPU({device:other.device},expected,options(2));assert.deepEqual(r.temperature,q.temperature);assert.deepEqual(r.duration.boundaryEnergyByFaceJ,q.duration.boundaryEnergyByFaceJ);clean(gpu);clean(other);
});
test('strict film and native snapshots reject unknown, hidden, inherited and accessor fields without executing getters',()=>{
 const bad=[];for(const mutate of [b=>b.kind='film',b=>b.faces={},b=>b.faces.interface=b.faces.xMax,b=>b.faces.xMax.hWPerM2K=-1,b=>b.faces.xMax.ambientKelvin=.9,b=>b.faces.xMax.ambientKelvin=Infinity,b=>b.faces.xMax.ambientKelvin='300',b=>b.extra=0,b=>b.faces.xMax.extra=0,b=>Object.setPrototypeOf(b.faces,{xMin:{}}),b=>Object.defineProperty(b.faces.xMax,'hidden',{value:0}),b=>Object.defineProperty(b.faces.xMax,'hWPerM2K',{get(){throw Error('getter was executed');},enumerable:true})]){const b=boundary();mutate(b);bad.push(b);}
 for(const b of bad){assert.throws(()=>snapshotExteriorFilm(b),e=>['INVALID_ARGUMENT','UNSUPPORTED_BOUNDARY'].includes(e.code));const r=sceneRequest();r.settings.thermalBoundary=b;assert.throws(()=>snapshotNativeSceneRequest(r,20),{code:'INVALID_ARGUMENT'});}
 const x=snapshotExteriorFilm(boundary());assert.ok(Object.isFrozen(x)&&Object.isFrozen(x.faces)&&Object.isFrozen(x.faces.xMax));
});
test('native solve-scene interrupt keeps its original immutable film request and reports actual boundary',async()=>{
 const f=await nativeFixture(),r=sceneRequest(1);r.settings.thermalBoundary=boundary();const start=f.call('solve-scene',r);r.settings.thermalBoundary.faces.xMax.hWPerM2K=0;r.settings.thermalBoundary.faces.xMax.ambientKelvin=1800;await start;await f.drain();const s=f.direct('status');assert.equal(s.state,'ready',JSON.stringify(s));assert.deepEqual(s.boundary,boundary());assert.ok(s.duration.boundaryEnergyOutJ>0);await f.call('clear');clean(f.gpu);
});
test('internal Robin assembly is not an unchecked public solve-grid capability and rejects overlap including zero',async()=>{
 assert.equal(Object.hasOwn(gridSchema.properties,'boundaryRobin'),false);const robin={xMax:{hWPerM2K:0,ambientCelsius:20}};
 for(const patch of [{boundary:{xMax:0}},{boundaryFlux:{xMax:0}}])assert.throws(()=>assembleConduction({...gridRequest,boundary:{},...patch,boundaryRobin:robin}),{code:'INVALID_ARGUMENT'});
 for(const source of [[0],[10]])assert.throws(()=>assembleConduction({...gridRequest,source,boundary:{},boundaryRobin:robin,timeStep:undefined}),{code:'UNANCHORED_DOMAIN'});
 const f=await nativeFixture();await f.solve(sceneRequest(1));const old=f.direct('status').job;await assert.rejects(f.call('solve-grid',{...gridRequest,boundaryRobin:robin}),{code:'UNSUPPORTED_BOUNDARY'});assert.equal(f.direct('status').job,old);assert.equal(f.direct('status').state,'ready');await f.call('clear');clean(f.gpu);
});
test('duration independently recomputes boundary energy and rejects corrupt sign, face and absolute diagnostics',async()=>{
 for(const corrupt of [r=>r.thermal.conduction.boundaryEnergyOutJ*=-1,r=>r.thermal.conduction.boundaryEnergyByFaceJ.xMax+=1,r=>r.thermal.conduction.absoluteBoundaryEnergyJ=0]){let calls=0;const gpu=deviceEmulator(),advance=createConjugateDurationStepper(async(c,i,o)=>{calls++;const r=await stepConjugateHeatGPU(c,i,o);corrupt(r);return r;});await assert.rejects(advance({device:gpu.device},input(),options(2)),{code:'INVALID_RESULT'});assert.equal(calls,1);clean(gpu);}
});
test('layered film verifies actual field and retains only its existing conduction buffer until disposal',async()=>{
 const gpu=deviceEmulator(),field=await solveLayeredHeatGPU({device:gpu.device},layer(input()));assert.ok(field.metrics.exteriorFilm.boundaryPowerOutW>0);assert.ok((await field.inspect(3,1)).temperatures[0]<300);assert.equal(field.metrics.retainedGPUBytes,24*4);field.dispose();clean(gpu);
 const equilibrium=input(boundary(273.15));equilibrium.temperature.fill(273.15);const g=deviceEmulator(),eq=await solveLayeredHeatGPU({device:g.device},layer(equilibrium));assert.equal(eq.metrics.exteriorFilm.boundaryEnergyOutJ,0);assert.deepEqual((await eq.inspect(0,24)).temperatures,new Array(24).fill(273.15));eq.dispose();clean(g);
});
test('unresolved bath signal, post-film heater loss and near-equilibrium original exchange fail closed',async()=>{
 assert.throws(()=>assembleConjugateHeatGPU(input(boundary(280,1e-12))),{code:'NUMERICAL_RANGE'});
 const f=input();f.solidSourceDensity=[1e-12];assert.throws(()=>assembleConjugateHeatGPU(f),{code:'NUMERICAL_RANGE'});
 const g=deviceEmulator();await assert.rejects(stepConjugateHeatGPU({device:g.device},input(boundary(300))),{code:'NUMERICAL_RANGE'});clean(g);
});
test('16³ six-face exterior-film planning completes under 1000ms without GPU allocation',()=>{
 const f=input();f.dimensions=[16,16,16];f.size=[1.6,1.6,1.6];f.fluidCellsX=8;f.temperature=new Float64Array(4096).fill(300);f.fan.sheet={x:4,y:[4,8],z:[4,8]};for(let a=0;a<3;a++)f[['u','v','w'][a]]=new Float64Array(f.dimensions.reduce((s,n,b)=>s*(n+Number(a===b)),1));f.boundary={kind:'exterior-film',faces:Object.fromEntries(exteriorFaces.map(k=>[k,{hWPerM2K:5,ambientKelvin:280}]))};const start=performance.now(),plan=assembleConjugateHeatGPU(f),wallMs=performance.now()-start;assert.equal(plan.grid.exteriorFilm.length,1536);assert.ok(wallMs<1000);console.log(JSON.stringify({operation:'4096-cell six-face film preflight',wallMs,budgetMs:1000,hardwareVerified:false}));
});

test('actual shared-device loss retires a published standalone film on metrics/inspect with one shared subscription',async()=>{
 const gpu=deviceEmulator();let lose,subscriptions=0;gpu.device.lost={then(fn){subscriptions++;lose=fn;}};
 const a=await solveLayeredHeatGPU({device:gpu.device},layer(input())),b=await solveLayeredHeatGPU({device:gpu.device},layer(input()));assert.equal(subscriptions,1);lose();
 assert.throws(()=>a.metrics,{code:'DEVICE_LOST'});await assert.rejects(b.inspect(),{code:'DEVICE_LOST'});await assert.rejects(a.inspect(),{code:'RETIRED_RESULT'});a.dispose();b.dispose();clean(gpu);
});
