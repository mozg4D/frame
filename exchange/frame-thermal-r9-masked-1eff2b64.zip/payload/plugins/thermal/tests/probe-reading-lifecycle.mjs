import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {nativeDomainSchema,preflightNativeDomain,nativeSavedFanSchema,preflightNativeSavedFan,advanceNativeSavedFanGPU} from '../native-fan-job.js';
import {assertNativeFanRequestCurrent} from '../native-fan-snapshot.js';
import {assembleConduction,gridSchema} from '../plugin.js';
import {validateFanParameters,inspectNativeFans} from '../native-fan.js';
import {sampleProbe} from '../probe.js';
import {THERMAL_TAGS,inspectSceneInputs} from '../scene-inputs.js';
import {inspectGeometry} from '../geometry.js';
import {nativeSceneSchema,snapshotNativeSceneRequest} from '../native-scene-request.js';
import {advanceTouchingSceneConjugateGPU} from '../scene-conjugate-duration.js';
import {exactOccurrenceStamp,sceneIdentityMatches,sharedThermalDeviceState} from '../scene-identity.js';

// Execute the shipped native controller. Only the numerical solve is replaced
// with a test-only field to isolate cache ownership; this is not a GPU test.
const source=await readFile(new URL('../plugin.js',import.meta.url),'utf8');
const marker='export async function activate(context) {';
assert.equal(source.split(marker).length,2);
const body=source.slice(source.indexOf(marker)).replace('export async function','async function');
const objectSchema=properties=>({type:'object',properties,additionalProperties:false});
const makeActivate=solve=>new Function('nativeDomainSchema','preflightNativeDomain','nativeSavedFanSchema','preflightNativeSavedFan','advanceNativeSavedFanGPU','assertNativeFanRequestCurrent','validateFanParameters','inspectNativeFans','solveConductionGPU','assembleConduction','gridSchema','objectSchema','emptySchema','error','sampleProbe','THERMAL_TAGS','inspectSceneInputs','inspectGeometry','nativeSceneSchema','snapshotNativeSceneRequest','advanceTouchingSceneConjugateGPU','exactOccurrenceStamp','sceneIdentityMatches','sharedThermalDeviceState',body+';return activate;')(nativeDomainSchema,preflightNativeDomain,nativeSavedFanSchema,preflightNativeSavedFan,advanceNativeSavedFanGPU,assertNativeFanRequestCurrent,validateFanParameters,inspectNativeFans,solve,assembleConduction,gridSchema,objectSchema,objectSchema({}),(code,message)=>Object.assign(Error(message),{code}),sampleProbe,THERMAL_TAGS,inspectSceneInputs,inspectGeometry,nativeSceneSchema,snapshotNativeSceneRequest,advanceTouchingSceneConjugateGPU,exactOccurrenceStamp,sceneIdentityMatches,sharedThermalDeviceState);
const I=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
const args={dimensions:[2,2,2],cellSize:[.01,.01,.01],conductivity:[2],boundary:{xMin:0,xMax:100}};
async function fixture(){
 const owner={nativeHash:'owner',type:'thermal',enabled:true,params:{Ambient:20,Initial:20}},probe={nativeHash:'probe',type:'thermal_probe',enabled:true,params:{Thermal:'owner'}},worlds={owner:[...I],probe:[...I]},fields=[];
 let operations,editor,attributes,readHook=()=>{},solveHook=()=>{},value=50,reads=0,selected='probe';
 const context={version:1,device:{},document:{nodes:[owner,probe],world:hash=>worlds[hash],get selected(){return [this.nodes.find(n=>n.nativeHash===selected)];}},math:{inv:()=>I},operations:{register:v=>{operations=v;}},editor:{register:v=>{editor=v;}},attributes:{register:v=>{attributes=v;}},viewport:{register:async()=>{}},requestAttributes(){},requestDraw(){}};
 await makeActivate(async(_device,grid,{check})=>{check();await solveHook();check();const solved=value;
  const field={dimensions:grid.dimensions,cellSize:grid.cellSize,metrics:{},disposed:0,dispose(){this.disposed++;},async inspect(){reads++;await readHook();return {temperatures:[solved]};}};fields.push(field);return field;
 })(context);
 const call=(id,input={},hash='owner')=>operations.find(o=>o.id===id).run(hash,input),label=()=>attributes('probe').actions[0].label;
 const solve=async()=>{call('solve-grid',structuredClone(args));await editor.flush({author:true});};
 await solve();await call('measure',{},'probe');assert.equal(label(),'50.00 °C');
 return {context,owner,probe,worlds,fields,editor,call,label,solve,get reads(){return reads;},select(hash){selected=hash;editor.documentChanged();},onRead(fn){readHook=fn;},onSolve(fn){solveHook=fn;},setValue(v){value=v;}};
}
test('same-Probe selection and selection-away/back preserve the current label without resampling',async()=>{
 const f=await fixture(),reads=f.reads;
 for(let i=0;i<100;i++){f.select('probe');f.select('owner');f.select('probe');assert.equal(f.label(),'50.00 °C');}
 assert.equal(f.reads,reads);assert.equal(f.call('status').state,'ready');assert.equal(f.fields[0].disposed,0);
});
test('Probe position, link, enabled state, type, removal or replacement invalidates only its reading',async()=>{
 const mutations=[f=>f.worlds.probe[12]++,f=>f.probe.params.Thermal='',f=>f.probe.enabled=false,f=>f.probe.type='group',f=>f.context.document.nodes.pop(),f=>f.context.document.nodes[1]={...f.probe,params:{...f.probe.params}}];
 for(const mutate of mutations){const f=await fixture();mutate(f);f.editor.documentChanged();assert.notEqual(f.label(),'50.00 °C');assert.equal(f.call('status').state,'ready');assert.equal(f.fields[0].disposed,0);
  // A removed/non-Probe object has no Measure action. Restoring the original
  // identity/values must still require a fresh measurement, not revive cache.
  Object.assign(f.probe,{type:'thermal_probe',enabled:true,params:{Thermal:'owner'}});f.worlds.probe=[...I];f.context.document.nodes=[f.owner,f.probe];f.editor.documentChanged();assert.equal(f.label(),'Measure');
 }
});
test('owner transform/settings/enabled/removal/replacement and shared-device changes retire both reading and source',async()=>{
 const mutations=[f=>f.worlds.owner[12]++,f=>f.owner.params.Initial++,f=>f.owner.params.Ambient++,f=>f.owner.enabled=false,f=>f.context.document.nodes.shift(),f=>f.context.document.nodes[0]={...f.owner,params:{...f.owner.params}},f=>f.context.device={}];
 for(const mutate of mutations){const f=await fixture();mutate(f);f.editor.documentChanged();assert.equal(f.label(),'Measure');assert.equal(f.fields[0].disposed,1);await assert.rejects(f.call('measure',{},'probe'));}
});
test('a new numerical solution or clear cannot reuse an older measured value',async()=>{
 const f=await fixture();f.setValue(80);await f.solve();assert.equal(f.label(),'Measure');assert.equal(f.fields[0].disposed,1);
 await f.call('measure',{},'probe');assert.equal(f.label(),'80.00 °C');await f.call('clear');assert.equal(f.label(),'Measure');assert.equal(f.fields[1].disposed,1);
});
test('a failed replacement solution never revives the previous measured value',async()=>{
 const f=await fixture();f.onSolve(()=>{throw Error('injected solve failure');});await f.solve();assert.equal(f.call('status').state,'failed');assert.equal(f.label(),'Measure');assert.equal(f.fields[0].disposed,1);
});
test('restore with replaced native identity clears cached readings even with identical values',async()=>{
 const f=await fixture();f.context.document.nodes=f.context.document.nodes.map(n=>({...n,params:{...n.params}}));f.editor.restored();assert.equal(f.label(),'Measure');assert.equal(f.fields[0].disposed,1);
});
test('Probe change then reversal does not resurrect the discarded old cache entry',async()=>{
 const f=await fixture();f.worlds.probe[12]=1;f.editor.documentChanged();f.worlds.probe[12]=0;f.editor.documentChanged();assert.equal(f.label(),'Measure');
 await f.call('measure',{},'probe');assert.equal(f.label(),'50.00 °C');
});
test('selection during asynchronous reads succeeds; substantive changes abort without publishing',async()=>{
 const f=await fixture();f.onRead(()=>f.select('probe'));await f.call('measure',{},'probe');assert.equal(f.label(),'50.00 °C');
 for(const mutate of [f=>f.worlds.probe[12]++,f=>f.owner.params.Initial++,f=>f.context.device={}]){const f=await fixture();f.onRead(()=>{mutate(f);f.editor.documentChanged();});await assert.rejects(f.call('measure',{},'probe'));assert.equal(f.label(),'Measure');}
});
test('10000 selection notifications and label checks finish within 1000 ms without GPU reads',async()=>{
 const f=await fixture(),reads=f.reads,started=performance.now();for(let i=0;i<10000;i++){f.select('probe');assert.equal(f.label(),'50.00 °C');}const ms=performance.now()-started;
 assert.equal(f.reads,reads);assert.ok(ms<1000);console.log(JSON.stringify({operation:'10000 selection/Probe cache checks (controller fixture)',wallMs:ms,budgetMs:1000,hardwareVerified:false}));
});
