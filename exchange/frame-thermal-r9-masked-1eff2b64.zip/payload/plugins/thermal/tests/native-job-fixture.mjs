import {readFile} from 'node:fs/promises';
import {nativeDomainSchema,preflightNativeDomain,nativeSavedFanSchema,preflightNativeSavedFan,advanceNativeSavedFanGPU} from '../native-fan-job.js';
import {assertNativeFanRequestCurrent} from '../native-fan-snapshot.js';
import * as thermal from '../plugin.js';
import {validateFanParameters,inspectNativeFans} from '../native-fan.js';
import {sampleProbe} from '../probe.js';
import {THERMAL_TAGS,inspectSceneInputs} from '../scene-inputs.js';
import {inspectGeometry} from '../geometry.js';
import {nativeSceneSchema,snapshotNativeSceneRequest} from '../native-scene-request.js';
import {advanceTouchingSceneConjugateGPU} from '../scene-conjugate-duration.js';
import {exactOccurrenceStamp,sceneIdentityMatches,sharedThermalDeviceState} from '../scene-identity.js';
import {captured,request,identity} from './scene-conjugate-fixture.mjs';
import {deviceEmulator} from './conjugate-device-emulator.mjs';

export const sceneRequest=(steps=2)=>({...request(),stepCount:steps,cumulativeDivergenceDriftBudgetK:.001});
export const gridRequest={dimensions:[4,3,2],cellSize:[.25,.25,.5],conductivity:[2],initial:[26.85],boundary:{},timeStep:.01};
export const latch=()=>{let release;const promise=new Promise(r=>release=r);return {promise,release};};
export async function fixture({sceneSolve,savedFanSolve,deviceOptions,configure}={}){
 const f=captured(),gpu=deviceEmulator(deviceOptions);f.context.device=f.snapshot.device=gpu.device;
 for(const m of f.snapshot.meshes)for(const k of ['positions','indices'])m[k].data=m[k].bytes;
 let operations,editor,attributes,viewport,tail=Promise.resolve();
 Object.assign(f.context,{version:1,math:{inv:()=>identity},operations:{register:v=>operations=v},editor:{register:v=>editor=v},attributes:{register:v=>attributes=v},viewport:{register:async v=>viewport=v},requestAttributes(){},requestDraw(){}});
 let activate=thermal.activate;
 if(sceneSolve||savedFanSolve){
  // Only a final-resolution race seam. Normal fixtures execute shipped activate
  // and every numerical GPU stage through the CPU command emulator, NOT hardware.
  const source=await readFile(new URL('../plugin.js',import.meta.url),'utf8'),body=source.slice(source.indexOf('export async function activate(context) {')).replace('export async function','async function');
  const objectSchema=properties=>({type:'object',properties,additionalProperties:false});
  const names={...thermal,nativeDomainSchema,preflightNativeDomain,nativeSavedFanSchema,preflightNativeSavedFan,advanceNativeSavedFanGPU:savedFanSolve??advanceNativeSavedFanGPU,assertNativeFanRequestCurrent,validateFanParameters,inspectNativeFans,objectSchema,emptySchema:objectSchema({}),error:(code,message)=>Object.assign(Error(message),{code}),sampleProbe,THERMAL_TAGS,inspectSceneInputs,inspectGeometry,nativeSceneSchema,snapshotNativeSceneRequest,advanceTouchingSceneConjugateGPU:sceneSolve??advanceTouchingSceneConjugateGPU,exactOccurrenceStamp,sceneIdentityMatches,sharedThermalDeviceState};
  activate=new Function(...Object.keys(names),body+';return activate;')(...Object.values(names));
 }
 configure?.(f.context,f);
 await activate(f.context);
 const operation=id=>operations.find(o=>o.id===id);
 const direct=(id,args={},hash='owner')=>operation(id).run(hash,args);
 // Match the core's interrupt-before-tail and pre/post generic flush ordering.
 // Full real schema/editor/API behavior is separately tested in the browser.
 const call=(id,args={},hash='owner')=>{
  const o=operation(id);let token;try{token=o.interrupt?.(hash,args);}catch(e){return Promise.reject(e);}
  const task=tail.catch(()=>{}).then(async()=>{await editor.flush();const value=await o.run(hash,args,token);await editor.flush();return value;});tail=task;return task;
 };
 const drain=()=>editor.flush({author:true}),solve=async(args=sceneRequest())=>{const start=await call('solve-scene',args);await drain();return {start,status:direct('status')};};
 return {...f,get borrowedDestroyed(){return f.borrowedDestroyed;},gpu,operations,editor,attributes,viewport,operation,direct,call,drain,solve};
}
