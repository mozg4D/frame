import {projectMAC} from './mac-projection-reference.mjs';
import {maskedFixture,asReference,velocityKeys,fieldError,circulation,addGradient} from './masked-projection-fixture.mjs';
// Actual shared-device WGSL only. CPU reference stays on the Node side.
export async function maskedProjectionGPUChecks(page,check,timed){
 const execute=async input=>page.evaluate(async input=>{const {projectMACGPU}=await import('/plugins/thermal/mac-projection-gpu.js');const r=await projectMACGPU({device:frameEngine.renderer.device},input);return {...r,u:Array.from(r.u),v:Array.from(r.v),w:Array.from(r.w),pressure:Array.from(r.pressure)};},input);
 const variants=[
  ['minimum',maskedFixture([3,3,3],{min:[1,1,1],max:[2,2,2]})],
  ['anisotropic',maskedFixture()],
  ['one-cell-shell',maskedFixture([8,6,4],{min:[1,1,1],max:[7,5,3]})],
  ['zero',circulation(maskedFixture(),0)],
  ['pure-gradient',addGradient(circulation(maskedFixture(),0))],
  ['circulation',circulation(maskedFixture())],
  ['gradient-circulation',addGradient(circulation(maskedFixture()))]
 ];
 for(const [name,f] of variants){const reference=projectMAC(asReference(f)),r=await timed('masked projection completed '+name,15000,()=>execute(f.input)),error=fieldError(r,reference);check(name+' masked GPU agrees with independent Float64 reference',error<3e-5,{error,metrics:r.metrics});
  check(name+' pressure sentinel and exact blocked faces',f.faces.every(e=>e.open||r[velocityKeys[e.axis]][e.index]===0)&&f.solid.every((solid,i)=>!solid||r.pressure[i]===0)&&/not physical pressure/.test(r.pressureConvention));
  check(name+' pressure gradients agree with independent reference',f.faces.every(e=>!e.open||Math.abs((r.pressure[e.right]-r.pressure[e.left])-(reference.pressure[e.right]-reference.pressure[e.left]))<.002));
  check(name+' returned physical divergence/energy gate and no retained state',r.metrics.maxDivergence<=r.metrics.maxDivergenceAllowance&&r.metrics.energyAfter<=r.metrics.energyBefore*(1+1e-4)&&r.metrics.retainedGPUBytes===0&&!r.sceneSolver,r.metrics);
  if(name==='circulation')check('circulation is not erased by pressure projection',fieldError(r,f.input)<1e-7&&r.metrics.energyAfter>0);
  if(name==='zero')check('zero field remains exactly zero',r.metrics.energyAfter===0&&r.metrics.maxDivergence===0);
 }
 const rejected=await page.evaluate(async input=>{const {projectMACGPU}=await import('/plugins/thermal/mac-projection-gpu.js'),codes=[];for(const change of [{maxIterations:1},{obstacle:{min:[0,1,1],max:[2,2,2]}},{obstacle:{min:[1.5,1,1],max:[2,2,2]}},{u:Array.from(input.u,(v,i)=>i===0?1:v)}])try{await projectMACGPU({device:frameEngine.renderer.device},{...input,...change});codes.push(null);}catch(e){codes.push(e.code);}return codes;},maskedFixture().input);
 check('nonconvergence and unsupported geometry/blocked velocities reject',JSON.stringify(rejected)===JSON.stringify(['NONCONVERGENCE','UNSUPPORTED_DOMAIN','INVALID_ARGUMENT','INVALID_BOUNDARY']),rejected);
}
