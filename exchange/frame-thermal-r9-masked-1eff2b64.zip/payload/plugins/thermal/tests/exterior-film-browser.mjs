import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {launch,ready} from '../../../tools/browser.mjs';
import {domainBoundaries,domainRequest,domainMaterials} from './native-domain-fixture.mjs';
import {savedFanSourceSnapshot} from './native-saved-fan-browser.mjs';
import {fixtureFluidOccurrence} from './native-fluid-fixture.mjs';
import {checkDefaultProbeFrame} from './native-probe-browser.mjs';
import {filmFaces,filmFixture,filmPhysics,filmExchange,filmTrajectory,filmProbe,exteriorFilmOracle} from './exterior-film-reference.mjs';
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const near=(a,b,tolerance=1e-10)=>Array.isArray(a)&&a.length===b.length&&a.every((v,i)=>Number.isFinite(v)&&Math.abs(v-b[i])<=tolerance);
const maxDifference=(a,b)=>a.length===b.length?Math.max(...a.map((v,i)=>Math.abs(v-b[i]))):Infinity;
const close=(a,b,scale=1)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=512*Number.EPSILON*Math.max(1,Math.abs(a),Math.abs(b),scale);
const components=[['u',80],['v',80],['w',80]],packedFan=[.25,0,0,0,.25,0,0,0,.25,-25,-12.5,-12.5],identityMatrix=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
const root=new URL('../../../',import.meta.url);
export const exteriorFilmSourceSnapshot=savedFanSourceSnapshot;
// A new isolated context, ordinary native authoring, and the shared real device.
// Observers retain actual identities only. Await gates hold genuine async work;
// no input/frame writes, solver replacement, CPU fallback or success injection.
export async function exteriorFilmBrowserChecks(parent,check,timed){
 const sources=await exteriorFilmSourceSnapshot();
 const context=await parent.context().browser().newContext({viewport:{width:1280,height:900},serviceWorkers:'block'}),page=await context.newPage(),errors=[],consoleErrors=[],evidence=[];
 page.on('pageerror',error=>errors.push(error.stack||String(error)));
 page.on('console',message=>{if(message.type()==='error')consoleErrors.push(message.text());});
 try{
  const catalogue=JSON.parse(await readFile(new URL('../../index.json',import.meta.url),'utf8'));
  check('exterior-film native domain candidate stays absent from public catalogue',!catalogue.includes('thermal/plugin.json'),catalogue);
  await page.route('**/plugins/index.json',route=>route.fulfill({json:[...catalogue,'thermal/plugin.json']}));
  const module=await readFile(new URL('../plugin.js',import.meta.url),'utf8'),activation='export async function activate(context) {',publication='result=await solve(job);current(job);',editor='context.editor.register({';
  for(const marker of [activation,publication,editor])if(module.split(marker).length!==2)throw Error('Exterior-film observer/await marker changed: '+marker);
  await page.route('**/plugins/thermal/plugin.js',route=>route.fulfill({contentType:'text/javascript',body:module.replace(activation,activation+'\nwindow.__exteriorFilmContext=context;').replace(editor,'context.editor.register(window.__exteriorFilmEditor={').replace(publication,'result=await solve(job);await window.__exteriorFilmGateAt?.("final");current(job);')}));
  await page.goto(parent.url());await ready(page);
  const call=(name,args={})=>page.evaluate(([name,args])=>frameAI.call(name,args),[name,args]);
  const objects=async()=> (await call('scene.inspect')).objects;
  const hardware=await page.evaluate(async()=>{
   const [{macProjectionWGSL},{macViscosityWGSL},{conductionWGSL}]=await Promise.all([import('/plugins/thermal/mac-projection-gpu.js'),import('/plugins/thermal/mac-viscosity-gpu.js'),import('/plugins/thermal/plugin.js')]);
   const device=frameEngine.renderer.device,info=device.adapterInfo;window.__exteriorFilmDevice=device;
   window.__exteriorFilmTemperatures=[];window.__exteriorFilmGPU=[];window.__exteriorFilmLost=null;window.__exteriorFilmOwned={live:0,peak:0,created:0,destroyed:0,unlabelled:0,unresolvedLabels:0,unrecognizedCallsites:[],byModule:{}};
   device.addEventListener('uncapturederror',event=>__exteriorFilmGPU.push(event.error.message));device.lost.then(info=>__exteriorFilmLost={reason:info.reason,message:info.message});device.pushErrorScope('validation');
   window.__exteriorFilmGateAt=async stage=>{const gate=window.__exteriorFilmGate;if(gate?.stage===stage&&!gate.entered&&++gate.hits===gate.target){gate.entered=true;await gate.promise;}};
   const allocationSources=new Set(['touching-classifier.js','plugin.js','mac-projection-gpu.js','mac-viscosity-gpu.js','mac-fan-gpu.js','temperature-advection-gpu.js'].map(name=>new URL('/plugins/thermal/'+name,location.href).href));
   const make=device.createBuffer.bind(device),shader=device.createShaderModule.bind(device),pipeline=device.createComputePipelineAsync.bind(device),modules=new WeakSet(),conductionModules=new WeakSet();window.__exteriorFilmConductionPipelines=0;
   device.createShaderModule=options=>{const result=shader(options);if(options.code===macProjectionWGSL||options.code===macViscosityWGSL)modules.add(result);if(options.code===conductionWGSL)conductionModules.add(result);return result;};
   device.createComputePipelineAsync=async options=>{if(modules.has(options.compute?.module))await __exteriorFilmGateAt('pipeline');const result=await pipeline(options);if(conductionModules.has(options.compute?.module)){__exteriorFilmConductionPipelines++;await __exteriorFilmGateAt('conduction');}return result;};
   device.createBuffer=options=>{
    // MAC/advection allocations have no labels. The immediate synchronous
    // source callsite identifies ownership, not transitive plugin callers or
    // every buffer on the shared device. Never rewrite production modules.
    const caller=(new Error().stack||'').split('\n').slice(1).map(line=>line.match(/(https?:\/\/[^\s)]+):\d+:\d+\)?$/)?.[1]).find(Boolean),path=caller?new URL(caller).pathname:null,stats=__exteriorFilmOwned;
    const buffer=make(options);if(!allocationSources.has(caller)){if(options.label?.startsWith('Thermal '))stats.unresolvedLabels++;if(path?.startsWith('/plugins/thermal/')&&!stats.unrecognizedCallsites.includes(caller))stats.unrecognizedCallsites.push(caller);return buffer;}
    stats.byModule[path]=(stats.byModule[path]||0)+1;if(!options.label)stats.unlabelled++;
    const destroy=buffer.destroy.bind(buffer),map=buffer.mapAsync.bind(buffer),range=buffer.getMappedRange.bind(buffer);let dead=false;
    buffer.getMappedRange=(...args)=>{const bytes=range(...args);if(options.label==='Thermal bounded temperature inspection'&&options.size===256)__exteriorFilmTemperatures.push(Array.from(new Float32Array(bytes),x=>x+273.15));return bytes;};stats.created++;stats.live+=options.size;stats.peak=Math.max(stats.peak,stats.live);
    buffer.destroy=()=>{if(!dead){dead=true;stats.destroyed++;stats.live-=options.size;}destroy();};
    buffer.mapAsync=async(...args)=>{await map(...args);if(options.label==='Thermal independent occurrence readback')await __exteriorFilmGateAt('classification');if(options.label==='Thermal bounded temperature inspection')await __exteriorFilmGateAt('heat');};return buffer;
   };
   return info?Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(key=>[key,info[key]])):null;
  });
  check('exterior-film native domain uses identifiable nonfallback hardware WebGPU',hardware&&Object.values(hardware).some(v=>typeof v==='string'&&v)&&!hardware.isFallbackAdapter&&!/swiftshader|llvmpipe|lavapipe|software/i.test(JSON.stringify(hardware)),hardware);
  const old=await objects();if(old.length)await call('scene.delete',{ids:old.filter(n=>!n.parent).map(n=>n.hash)});
  const owner=await timed('exterior-film native domain owner creation',10000,()=>call('plugins.create',{plugin:'thermal'}));
  const cmd=(operation,args={},id=owner.hash)=>call('plugins.command',{id,operation,args});
  const description=await call('plugins.describe',{plugin:'thermal'}),op=description.operations.find(op=>op.id==='solve-domain'),schema=op?.inputSchema;
  check('exterior-film native domain has strict discoverable canonical-role schema',op?.readOnly===false&&op.interruptible===true&&schema?.additionalProperties===false&&equal([...schema.required].sort(),['fanHash','fluidHash','dimensions','settings','stepCount','cumulativeDivergenceDriftBudgetK'].sort())&&schema.properties.settings.additionalProperties===false&&['cellSizeMM','domain','ownerWorld','size'].every(k=>!Object.hasOwn(schema.properties,k))&&['fanBox','fluidOccurrence'].every(k=>!Object.hasOwn(schema.properties.settings.properties,k)),description);
  check('old explicit-domain operations remain separate schemas',description.operations.find(op=>op.id==='solve-saved-fan')?.inputSchema.required.includes('cellSizeMM')&&description.operations.find(op=>op.id==='solve-scene')?.inputSchema.properties.settings.required.includes('fanBox'),description.operations);
  check('exterior-film native domain reuses bounded read-only native reads',['status','inspect','inspect-velocity','measure','fan-inputs'].every(id=>description.operations.find(op=>op.id===id)?.readOnly===true),description.operations);
  await call('scene.select',{ids:[owner.hash]});await page.locator('#tabAttributes').click();
  check('exterior-film native domain adds no Solve Attributes action',await page.locator('#attrContent [data-plugin-action-button^="solve"]').count()===0);
  const clearButton=page.locator('#attrContent [data-plugin-action-button="clear"]');
  check('exterior-film native domain uses stable disabled idle Clear action',await clearButton.count()===1&&await clearButton.isDisabled()&&(await clearButton.textContent())==='Clear');
  const ownerBefore=(await objects()).find(n=>n.hash===owner.hash),fan=await timed('exterior-film native domain native creation',10000,()=>cmd('create-fan'));
  const fanInputs=()=>cmd('fan-inputs',{},fan.hash),defaultFan=(await objects()).find(n=>n.hash===fan.hash),defaultInputs=await fanInputs();
  check('exterior-film native domain begins as selected native 25 mm child',defaultFan.selected&&defaultFan.parent===owner.hash&&defaultFan.params.Thermal===owner.hash&&equal(defaultFan.matrix,[.25,0,0,0,.25,0,0,0,.25,-25,-12.5,-12.5])&&equal(defaultInputs.fan.mapping.sizeMM,[25,25,25])&&equal(defaultInputs.fan.mapping.centerMM,[-25,-12.5,-12.5]),{defaultFan,defaultInputs});
  // Deliberately no selection repair: creation must await native selectOwner.
  await timed('native Fan immediate selected-child transform',1500,()=>call('transform.set',{channel:'position',axis:0,value:-24,coordinates:'world'}));
  const moved=(await objects()).find(n=>n.hash===fan.hash),ownerAfter=(await objects()).find(n=>n.hash===owner.hash);
  check('immediate Fan transform changes child local/world only',equal(moved.matrix,[.25,0,0,0,.25,0,0,0,.25,-24,-12.5,-12.5])&&near(moved.worldMatrix.slice(12,15),[-24,-12.5,-12.5])&&equal(ownerAfter.matrix,ownerBefore.matrix)&&equal(ownerAfter.worldMatrix,ownerBefore.worldMatrix),{moved,ownerBefore,ownerAfter});
  await call('edit.history',{action:'undo'});
  await call('scene.update',{id:fan.hash,params:{Direction:'Forward','Shutoff pressure':.02,'Free flow':.0001}});
  const assertFan=async label=>{const record=(await objects()).find(n=>n.hash===fan.hash),metadata=await fanInputs();check(label+' has native default box and exact physical mapping',equal(record.matrix,packedFan)&&metadata.fan.mapping.status==='supported-frame'&&equal(metadata.fan.mapping.centerMM,[-25,-12.5,-12.5])&&equal(metadata.fan.mapping.sizeMM,[25,25,25])&&!metadata.solverEligible&&!metadata.solverCoupled,{record,metadata});return metadata;};
  await assertFan('Authored domain Fan');
  check('sole domain is actual native 100 mm Thermal helper',near(ownerBefore.bounds.min,[-50,-50,-50])&&near(ownerBefore.bounds.max,[50,50,50])&&equal(ownerBefore.worldMatrix,identityMatrix)&&equal(Object.keys(ownerBefore.params).sort(),['Ambient','Initial']),ownerBefore);
  const groups=[],meshes=[];
  // Author SOLID first deliberately. Canonical fluidHash must resolve index 1,
  // rather than inheriting synthetic oracle order or guessing from material.
  await timed('exterior-film native domain actual two-cuboid material authoring',10000,async()=>{for(const i of [1,0]){
   const box=domainBoundaries()[i],group=await call('scene.create',{type:'group'}),mesh=await call('mesh.create',{vertices:Array.from(box.positions),indices:Array.from(box.indices),storage:'auto'});groups[i]=group.hash;meshes[i]=mesh.hash;
   await call('scene.update',{id:group.hash,parent:owner.hash});await call('scene.update',{id:mesh.hash,parent:group.hash});
   for(const tag of domainMaterials()[i])await call('tag.set',{ids:[group.hash],kind:tag.kind,enabled:true,params:tag.params});
  }});
  const probe=await timed('exterior-film native domain bounded Probe creation',2000,()=>cmd('create-probe'));
  checkDefaultProbeFrame(check,await objects(),probe.hash,owner.hash,'Exterior-film Probe');
  const probeOwnerBefore=(await objects()).find(n=>n.hash===owner.hash);
  await call('transform.set',{channel:'position',axis:1,value:1,coordinates:'world'});
  const movedProbe=(await objects()).find(n=>n.hash===probe.hash);
  check('immediate Probe transform changes selected child and preserves owner',near(movedProbe.worldMatrix.slice(12,15),[0,1,0])&&equal((await objects()).find(n=>n.hash===owner.hash).worldMatrix,probeOwnerBefore.worldMatrix),movedProbe);
  await call('edit.history',{action:'undo'});checkDefaultProbeFrame(check,await objects(),probe.hash,owner.hash,'Undo native-domain Probe');
  const initialCapture=await cmd('scene-inputs'),nativeMeshes=(await objects()).filter(n=>meshes.includes(n.hash));
  check('domain capture contains only actual buffer-backed 12-triangle cuboids with native parent records',initialCapture.totalOccurrences===2&&fixtureFluidOccurrence(initialCapture,meshes[0])===1&&nativeMeshes.length===2&&nativeMeshes.every(n=>n.mesh?.triangles===12&&n.mesh.storage==='buffer'&&n.parent===groups[meshes.indexOf(n.hash)]),{initialCapture,nativeMeshes});
  const args=async(steps=2,operation='solve-domain')=>{
   const r=domainRequest(steps);r.fanHash=fan.hash;r.fluidHash=meshes[0];
   if(operation!=='solve-domain'){delete r.fluidHash;r.cellSizeMM=r.dimensions.map(n=>100/n);r.settings.fluidOccurrence=fixtureFluidOccurrence(await cmd('scene-inputs'),meshes[0]);
    if(operation==='solve-scene'){delete r.fanHash;const f=(await objects()).find(n=>n.hash===fan.hash);r.settings.fanBox={centerMM:[-25,-12.5,-12.5],sizeMM:[25,25,25],shutoffPressure:f.params['Shutoff pressure'],freeFlow:f.params['Free flow'],direction:f.params.Direction==='Forward'?1:-1};}
   }return r;
  };
  const finish=async()=>{const until=performance.now()+15000;while(performance.now()<until){const state=await cmd('status');if(state.state!=='running')return state;await new Promise(resolve=>setTimeout(resolve,10));}throw Error('Exterior-film native job exceeded 15 s');};
  const resource=()=>page.evaluate(()=>({...__exteriorFilmOwned}));
  const clean=async label=>{const stats=await resource();check(label+' releases every tracked Thermal-owned buffer',stats.live===0&&stats.created===stats.destroyed&&stats.unresolvedLabels===0&&!stats.unrecognizedCallsites.length,stats);};
  const fields=async()=>{const result={temperature:(await cmd('inspect',{offset:0,count:64})).temperatures};for(const [component,count]of components)result[component]=(await cmd('inspect-velocity',{component,offset:0,count})).values;return result;};
  const noField=async label=>{for(const [operation,input,id]of [['inspect',{count:64},owner.hash],...components.map(([component,count])=>['inspect-velocity',{component,count},owner.hash]),['measure',{},probe.hash]]){const rejection=await page.evaluate(async({id,operation,args})=>{try{await frameAI.call('plugins.command',{id,operation,args});return null;}catch(error){return {code:error.code,message:error.message};}},{id,operation,args:input});check(label+' rejects '+operation+(input.component?' '+input.component:''),rejection?.code==='NO_RESULT',rejection);}};
  const solve=async(options={})=>{const variant=filmFixture(options),input=await args(variant.steps);input.settings.initialCelsius=[variant.initialKelvin-273.15];if(options.omit!==true)input.settings.thermalBoundary={kind:'exterior-film',faces:variant.faces};
   await page.evaluate(()=>{__exteriorFilmTemperatures=[];});return timed(`exterior film completed ${variant.steps}-step operation`,15000,async()=>{const start=await cmd('solve-domain',input),done=await finish(),temperatures=await page.evaluate(()=>__exteriorFilmTemperatures);check('film publishes only complete native duration',start.state==='running'&&done.state==='ready'&&done.duration?.completedSteps===variant.steps&&done.duration.completedTime===variant.steps*.01,{start,done});check('observer sees exactly one actual full conduction readback per completed step',temperatures.length===variant.steps&&temperatures.every(a=>a.length===64&&a.every(Number.isFinite)),{count:temperatures.length,steps:variant.steps});return {start,done,temperatures,input};});};
  const pause=(stage,target=1)=>page.evaluate(({stage,target})=>{let release;const promise=new Promise(resolve=>release=resolve);window.__exteriorFilmGate={stage,target,hits:0,promise,release,entered:false};},{stage,target});
  const waitGate=()=>page.waitForFunction(()=>window.__exteriorFilmGate?.entered,{},{timeout:15000});
  const resume=()=>page.evaluate(()=>{window.__exteriorFilmGate?.release();window.__exteriorFilmGate=null;});
  const unobserved=(operation,input={},name='__exteriorFilmPending')=>page.evaluate(({hash,operation,input,name})=>{window[name]=frameAI.call('plugins.command',{id:hash,operation,args:input});window[name].catch(()=>{});},{hash:owner.hash,operation,input,name});
  const selectProbe=async()=>{await call('scene.select',{ids:[probe.hash]});await page.locator('#tabAttributes').click();};
  const measureButton=page.locator('#attrContent [data-plugin-action-button="measure"]');
  const measuredLabel=async()=>{const measurement=await cmd('measure',{},probe.hash);await selectProbe();check('exterior-film native domain Probe is bounded physical sampling',Number.isFinite(measurement.temperature)&&measurement.cellsRead<=8&&measurement.interpolation==='perfect-contact-resistance-weighted'&&measurement.unit==='°C',measurement);return {measurement,label:await measureButton.textContent()};};
  const nativeFrames=()=>page.evaluate(hash=>{const c=__exteriorFilmContext,w=Array.from(c.document.world(hash)),snapshot=c.scene.capture(hash,[],['thermal_material','thermal_heater']);return {ownerWorld:w,ownerLocal:Array.from(c.document.local(hash)),lengthMM:[0,4,8].map(i=>100*Math.hypot(...w.slice(i,i+3))),determinant:w[0]*(w[5]*w[10]-w[6]*w[9])-w[4]*(w[1]*w[10]-w[2]*w[9])+w[8]*(w[1]*w[6]-w[2]*w[5]),sources:snapshot.meshes.map(m=>({hash:m.hash,matrix:Array.from(m.matrix),world:Array.from(c.document.world(m.hash)),triangles:m.triangleCount,storage:m.storage}))};},owner.hash);
  const beforeFrames=await call('diagnostics.frame',{frames:6});
  const boundarySchema=schema?.properties.settings.properties.thermalBoundary;
  check('explicit film schema has required kind and 1..6 strict whole local faces',boundarySchema?.additionalProperties===false&&equal([...boundarySchema.required].sort(),['faces','kind'])&&boundarySchema.properties.faces.minProperties===1&&boundarySchema.properties.faces.maxProperties===6&&boundarySchema.properties.faces.additionalProperties===false&&equal(Object.keys(boundarySchema.properties.faces.properties).sort(),[...filmFaces].sort())&&Object.values(boundarySchema.properties.faces.properties).every(s=>s.additionalProperties===false&&equal([...s.required].sort(),['ambientKelvin','hWPerM2K'])),boundarySchema);
  const setFixture=async variant=>{await call('scene.update',{id:fan.hash,params:{Direction:variant.direction===-1?'Reverse':'Forward','Shutoff pressure':variant.pressure??.02,'Free flow':.0001}});await call('tag.set',{ids:[groups[1]],kind:'thermal_heater',enabled:true,params:{Power:variant.power??.075}});};
  const compare=async(options,saved)=>{
   const variant=filmFixture(options),actual=await fields(),expected=exteriorFilmOracle(variant),trajectory=filmTrajectory(saved.temperatures,variant),d=saved.done.duration;
   const oracleErrors={temperatureK:maxDifference(actual.temperature.map(x=>x+273.15),Array.from(expected.temperature))};for(const [key]of components)oracleErrors[key]=maxDifference(actual[key],Array.from(expected[key]));
   check(options.name+' final T/u/v/w agree with independent Float64 physics',oracleErrors.temperatureK<=.0005&&components.every(([key])=>oracleErrors[key]<=.00002)&&equal(actual.temperature,saved.temperatures.at(-1).map(x=>x-273.15)),oracleErrors);
   const gross=Math.abs(trajectory.sourceEnergy)+trajectory.absoluteBoundaryEnergy;
   check(options.name+' signed global/face/region energy is reconstructed from actual per-step temperatures',close(d.boundaryEnergy,trajectory.boundaryEnergy)&&close(d.boundaryEnergyOutJ,trajectory.boundaryEnergy)&&close(d.absoluteBoundaryEnergyJ,trajectory.absoluteBoundaryEnergy)&&close(d.grossDriveEnergy,gross)&&filmFaces.every(f=>close(d.boundaryEnergyByFaceJ?.[f],trajectory.byFace[f]))&&close(d.fluid.boundaryEnergyOutJ,trajectory.regional[0])&&close(d.solid.boundaryEnergyOutJ,trajectory.regional[1])&&close(d.interfaceEnergyFluidToSolid,trajectory.interfaceEnergy)&&close(d.sourceEnergy,trajectory.sourceEnergy)&&close(d.thermalEnergyChange,trajectory.energyChange)&&close(d.thermalBalanceError,trajectory.balance)&&close(d.fluid.balanceError,trajectory.regionalBalance[0])&&close(d.solid.balanceError,trajectory.regionalBalance[1]),{trajectory,d});
   check(options.name+' independent endpoint equations and gross-drive cap hold',Math.abs(trajectory.balance)<=d.thermalBalanceAllowance&&Math.abs(trajectory.regionalBalance[0])<=d.fluid.balanceAllowance&&Math.abs(trajectory.regionalBalance[1])<=d.solid.balanceAllowance&&d.thermalBalanceAllowance<=.001*gross+1e-11&&Math.abs(d.mechanical.balanceError)<=d.mechanical.balanceAllowance&&d.temperatureAccuracyGuaranteeK===null&&d.netBoundaryEnergyResolved===(trajectory.boundaryEnergy===0?trajectory.absoluteBoundaryEnergy===0:Math.abs(trajectory.boundaryEnergy)>.001*trajectory.absoluteBoundaryEnergy),{trajectory,d});
   check(options.name+' energy agrees with separate Float64 trajectory',Math.abs(trajectory.boundaryEnergy-expected.trajectory.boundaryEnergy)<=.001*gross+1e-11&&filmFaces.every(f=>Math.abs(trajectory.byFace[f]-expected.trajectory.byFace[f])<=.001*gross+1e-11),{actual:trajectory,expected:expected.trajectory});
   check(options.name+' explicit bath metadata preserves sealed transient scope and bounded state',equal(saved.done.boundary,{kind:'exterior-film',faces:variant.faces})&&saved.done.authoring==='native-box-explicit-grid'&&saved.done.geometryCoupled&&!saved.done.sceneSolver&&!saved.done.generalSceneSolver&&saved.done.initialVelocity==='rest'&&near(saved.done.cellSize,variant.size.map(s=>s/4))&&saved.done.retainedGPUBytes===0&&saved.done.retainedHostFieldBytes===2432&&saved.done.maxStepWallMs<5000,saved.done);
   // Each face power is computed with its own adjacent material conductivity.
   // At near-wall points the Probe reports cell-centre reconstruction, not Ts.
   const probes=[],ownerWorld=(await nativeFrames()).ownerWorld;await call('scene.select',{ids:[probe.hash]});
   for(const point of options.pose?[[0,0,0]]:[[-12.5,-12.5,-12.5],[37.5,-12.5,-12.5],[49.9,-12.5,-12.5],[0,0,0]]){
    if(!options.pose){const world=point.map((_,a)=>ownerWorld[a]*point[0]+ownerWorld[a+4]*point[1]+ownerWorld[a+8]*point[2]+ownerWorld[a+12]);for(const [axis,value]of world.entries())await call('transform.set',{channel:'position',axis,value,coordinates:'world'});}
    const nativeProbe=(await objects()).find(n=>n.hash===probe.hash);check(options.name+' Probe is authored at the intended owner-local point',near(nativeProbe.matrix.slice(9,12),point,1e-8),{point,nativeProbe});
    const measured=await cmd('measure',{},probe.hash),predicted=filmProbe(expected.temperature,point);
    check(options.name+' bounded cell-centre Probe '+JSON.stringify(point),measured.cellsRead<=8&&measured.interpolation==='perfect-contact-resistance-weighted'&&measured.unit==='°C'&&Math.abs(measured.temperature-predicted)<=.0005,{point,measured,predicted});probes.push({point,measured,predicted});
   }
   if(!options.pose){check(options.name+' near-wall Probe is clamped cell-centre reconstruction',close(probes[1].measured.temperature,probes[2].measured.temperature),probes);const wall=expected.physics.films.find(e=>e.face==='xMax'&&e.i===23),bath=variant.faces.xMax;if(wall&&bath.hWPerM2K>0){const surface=wall.ambient+wall.g*(expected.temperature[23]-wall.ambient)/(bath.hWPerM2K*wall.area)-273.15;check(options.name+' near-wall Probe is not mislabeled as surface temperature',Math.abs(probes[2].measured.temperature-surface)>.01,{cellProbe:probes[2].measured.temperature,surface});}}
   await clean(options.name);return {variant,status:saved.done,oracleErrors,trajectory,expectedTrajectory:expected.trajectory,probes};
  };
  const variants=[
   {name:'cold-bath-10-step',steps:10,faces:{xMax:{hWPerM2K:.1,ambientKelvin:280}}},
   {name:'warm-bath-10-step',steps:10,faces:{xMax:{hWPerM2K:.1,ambientKelvin:320}}},
   {name:'opposing-baths',steps:2,faces:{xMin:{hWPerM2K:.1,ambientKelvin:280},xMax:{hWPerM2K:.2,ambientKelvin:320}}},
   {name:'mixed-material-faces',steps:2,faces:{xMax:{hWPerM2K:.1,ambientKelvin:280},yMax:{hWPerM2K:.15,ambientKelvin:320},zMin:{hWPerM2K:.2,ambientKelvin:280}}},
   {name:'negative-source-warm-bath',steps:2,power:-.075,faces:{xMax:{hWPerM2K:.1,ambientKelvin:320}}}
  ];
  for(const variant of variants){await setFixture(variant);const saved=await solve(variant),row=await compare(variant,saved);if(variant.name.startsWith('cold'))check('cold bath has outward positive exchange',row.trajectory.boundaryEnergy>0,row.trajectory);if(variant.name.startsWith('warm'))check('warm bath has outward negative exchange',row.trajectory.boundaryEnergy<0,row.trajectory);if(variant.name==='opposing-baths')check('opposing bath face signs survive integration',row.trajectory.byFace.xMin>0&&row.trajectory.byFace.xMax<0,row.trajectory);if(variant.steps===10){const finalTimesDuration=filmExchange(saved.temperatures.at(-1),variant).power*.1;check(variant.name+' uses actual step sum, not final power times duration',Math.abs(row.trajectory.boundaryEnergy-finalTimesDuration)>1e-7&&close(saved.done.duration.boundaryEnergyOutJ,row.trajectory.boundaryEnergy),{sum:row.trajectory.boundaryEnergy,finalTimesDuration});}evidence.push(row);}
  const base=filmFixture();await setFixture(base);
  const absent=await solve({steps:2,omit:true}),absentFields=await fields(),zeroFaces=Object.fromEntries(filmFaces.map((face,i)=>[face,{hWPerM2K:0,ambientKelvin:200+i*30}])),zero=await solve({steps:2,faces:zeroFaces}),zeroFields=await fields();
  check('explicit all-h0 is exact T/u/v/w adiabatic regression with no implicit Ambient face',absent.done.boundary==='adiabatic'&&equal(absentFields,zeroFields)&&equal(absent.temperatures,zero.temperatures)&&zero.done.duration.boundaryEnergyOutJ===0&&zero.done.duration.absoluteBoundaryEnergyJ===0&&filmFaces.every(f=>zero.done.duration.boundaryEnergyByFaceJ[f]===0),{absent:absent.done,zero:zero.done});await clean('zero film regression');

  // Native binary scaling/reflection retains exact source frames. The owner-local
  // xMax face stays xMax even when its world direction is negative.
  for(const pose of [{name:'anisotropic',size:[200,400,50]},{name:'reflected-anisotropic',scale:[-2,4,.5]}]){
   await cmd('clear');await call('scene.select',{ids:[owner.hash]});let edits=0;
   if(pose.scale){await call('animation.key',{id:owner.hash,path:'scale',frame:0,value:pose.scale,interpolation:'hard'});edits++;}else for(const [axis,value]of pose.size.entries()){await call('transform.set',{channel:'size',axis,value,coordinates:'object'});edits++;}
   const frames=await nativeFrames();check(pose.name+' authored exact source-relative native frames',near(frames.lengthMM,[200,400,50])&&frames.sources.every(s=>equal(s.matrix,identityMatrix))&&(!pose.scale||frames.determinant<0),frames);
   const variant={name:pose.name,pose:true,size:[.2,.4,.05],steps:1,faces:{xMax:{hWPerM2K:.1,ambientKelvin:280},yMin:{hWPerM2K:.15,ambientKelvin:320},zMax:{hWPerM2K:.2,ambientKelvin:280}}},saved=await solve(variant),row=await compare(variant,saved),physics=filmPhysics(variant);
   check(pose.name+' film area comes from anisotropic physical SI pitch',close(physics.films.filter(e=>e.face==='xMax').reduce((s,e)=>s+e.area,0),.4*.05)&&close(physics.films.filter(e=>e.face==='yMin').reduce((s,e)=>s+e.area,0),.2*.05)&&close(physics.films.filter(e=>e.face==='zMax').reduce((s,e)=>s+e.area,0),.2*.4),{areas:physics.films.map(({face,area})=>({face,area})),status:saved.done});
   check(pose.name+' fields/readbacks never rewrite native source transforms',equal(frames,await nativeFrames()),frames);evidence.push({...row,frames});await cmd('clear');for(let i=0;i<edits;i++)await call('edit.history',{action:'undo'});check(pose.name+' Undo restores original owner frame',equal((await nativeFrames()).ownerWorld,identityMatrix));
  }

  // Invalid nested data must be rejected before any predecessor interruption,
  // including descriptors that ordinary JSON serialization would conceal.
  await solve({...base,steps:2});const baseline=await fields(),predecessor=await cmd('status'),valid=await args(2);valid.settings.thermalBoundary={kind:'exterior-film',faces:base.faces};
  for(const bad of [null,{}, {kind:'exterior-film',faces:{}},{kind:'radiation',faces:base.faces},{kind:'exterior-film',faces:{xMax:{hWPerM2K:-1,ambientKelvin:280}}},{kind:'exterior-film',faces:{xMax:{hWPerM2K:.1,ambientKelvin:0}}},{kind:'exterior-film',faces:{xMax:{hWPerM2K:.1}}},{kind:'exterior-film',faces:{interface:{hWPerM2K:.1,ambientKelvin:280}}},{kind:'exterior-film',faces:base.faces,ambientKelvin:280}]){
   const input=structuredClone(valid);input.settings.thermalBoundary=bad;const rejection=await cmd('solve-domain',input).then(()=>null,e=>({code:e.code,message:e.message})),state=await cmd('status');check('invalid nested film preserves ready predecessor and exact fields',!!rejection&&state.state==='ready'&&state.job===predecessor.job&&equal(await fields(),baseline),{bad,rejection,state});
  }
  for(const kind of ['hidden','accessor','inherited','symbol','infinity']){
   const result=await page.evaluate(async({owner,valid,kind})=>{let getterCalls=0;const f=valid.settings.thermalBoundary.faces.xMax;
    if(kind==='hidden')Object.defineProperty(f,'extra',{value:1});if(kind==='accessor')Object.defineProperty(f,'hWPerM2K',{enumerable:true,get(){getterCalls++;return .1;}});if(kind==='inherited')Object.setPrototypeOf(f,{extra:1});if(kind==='symbol')f[Symbol('extra')]=1;if(kind==='infinity')f.hWPerM2K=Infinity;
    try{await frameAI.call('plugins.command',{id:owner,operation:'solve-domain',args:valid});return {rejected:false,getterCalls};}catch(e){return {rejected:true,getterCalls,code:e.code,message:e.message};}
   },{owner:owner.hash,valid,kind});const state=await cmd('status');check(kind+' nested boundary is rejected without executing getter or replacing field',result.rejected&&result.getterCalls===0&&state.job===predecessor.job&&state.state==='ready'&&equal(await fields(),baseline),result);
  }
  await pause('conduction');const active=await cmd('solve-domain',valid);await waitGate();const activeAllocations=await resource(),badActive=structuredClone(valid);badActive.settings.thermalBoundary.faces.xMax.hWPerM2K=-1;
  check('invalid nested film also preserves active native job',await cmd('solve-domain',badActive).then(()=>false,()=>true)&&(await cmd('status')).job===active.job&&(await resource()).created===activeAllocations.created);
  await noField('held active film');await call('scene.select',{ids:[owner.hash]});await page.locator('#tabAttributes').click();check('film uses native Stop action',await clearButton.isEnabled()&&(await clearButton.textContent())==='Stop');await clearButton.click();await resume();check('native Stop cancels film without publishing partial field',(await timed('film Stop drain',15000,finish)).state==='cancelled');await noField('film Stop');await clean('film Stop');

  // frameAI snapshots the nested request synchronously before queue work. Mutate
  // caller objects only; the observer never supplies replacement solver inputs.
  await pause('conduction');await page.evaluate(({owner,valid})=>{window.__exteriorFilmCaller=valid;window.__exteriorFilmQueued=frameAI.call('plugins.command',{id:owner,operation:'solve-domain',args:valid});valid.settings.thermalBoundary.faces.xMax.hWPerM2K=4;valid.settings.thermalBoundary.faces.xMax.ambientKelvin=500;valid.settings.thermalBoundary.faces.yMin={hWPerM2K:3,ambientKelvin:100};window.__exteriorFilmQueued.catch(()=>{});},{owner:owner.hash,valid});await waitGate();const queuedStart=await page.evaluate(()=>__exteriorFilmQueued);await page.evaluate(()=>{__exteriorFilmCaller.settings.thermalBoundary.faces.xMax.ambientKelvin=600;});await resume();const queuedDone=await timed('queued immutable film completion',15000,finish);
  check('queued and in-flight caller mutation cannot change explicit film snapshot',queuedDone.state==='ready'&&queuedDone.job===queuedStart.job&&equal(queuedDone.boundary,{kind:'exterior-film',faces:base.faces})&&maxDifference((await fields()).temperature,baseline.temperature)<=.0005,queuedDone);await clean('queued snapshot');

  // Hold the SECOND actual conduction readback: one step has truly completed,
  // but no duration field may be published. Stop/Clear/source/owner edits all
  // reuse the native controller and release every owned allocation.
  for(const action of ['cancel','clear','source','owner']){
   await page.evaluate(()=>{__exteriorFilmTemperatures=[];});await pause('heat',2);const r=structuredClone(valid);r.stepCount=3;await cmd('solve-domain',r);await waitGate();check('intermediate '+action+' suspends after one genuine completed step',await page.evaluate(()=>__exteriorFilmTemperatures.length)===1);await noField('intermediate '+action);const pipelines=await page.evaluate(()=>__exteriorFilmConductionPipelines);
   if(action==='source')await call('tag.set',{ids:[groups[1]],kind:'thermal_heater',enabled:true,params:{Power:.08}});
   else if(action==='owner'){await call('scene.select',{ids:[owner.hash]});await call('transform.set',{channel:'position',axis:0,value:1,coordinates:'world'});}
   else await unobserved(action);
   await resume();if(action==='cancel'||action==='clear')await timed('intermediate '+action+' work drain',15000,()=>page.evaluate(()=>__exteriorFilmPending));const done=await finish();
   check('intermediate '+action+' is atomic and schedules no third heat solve',done.state===(action==='clear'?'idle':action==='cancel'?'cancelled':'stale')&&await page.evaluate(()=>__exteriorFilmConductionPipelines)===pipelines,done);await noField('intermediate '+action);await clean('intermediate '+action);if(action==='source'||action==='owner')await call('edit.history',{action:'undo'});
  }
  await pause('conduction');const oldStart=await cmd('solve-domain',valid);await waitGate();const oldResources=await resource(),replacement=structuredClone(valid);replacement.settings.thermalBoundary.faces.xMax.ambientKelvin=320;const newStart=await cmd('solve-domain',replacement);
  check('film replacement waits for old native work before allocating',newStart.job!==oldStart.job&&newStart.state==='running'&&(await resource()).created===oldResources.created,{oldStart,newStart,oldResources,now:await resource()});await resume();const replaced=await timed('film replacement complete drain',15000,finish);check('only current replacement bath may publish',replaced.state==='ready'&&replaced.job===newStart.job&&replaced.boundary.faces.xMax.ambientKelvin===320,replaced);await clean('replacement');
  for(const kind of ['source','owner']){await solve(base);await measuredLabel();if(kind==='source')await call('tag.set',{ids:[groups[1]],kind:'thermal_heater',enabled:true,params:{Power:.08}});else{await call('scene.select',{ids:[owner.hash]});await call('transform.set',{channel:'position',axis:0,value:1,coordinates:'world'});}await selectProbe();const stale=await cmd('status');check('ready film '+kind+' edit retires result and cached Probe',stale.state==='stale'&&(await measureButton.textContent())==='Measure',stale);await noField('ready '+kind);await clean('ready '+kind);await call('edit.history',{action:'undo'});check(kind+' Undo never resurrects numeric film result',(await cmd('status')).state!=='ready');}
  const unresolved=structuredClone(valid);unresolved.settings.thermalBoundary.faces.xMax.hWPerM2K=1e-300;const unresolvedStart=await cmd('solve-domain',unresolved),unresolvedDone=await timed('unresolved nonzero film rejection',15000,finish);check('unresolved nonzero film rejects instead of becoming insulation or partial success',unresolvedStart.state==='running'&&unresolvedDone.state==='failed'&&unresolvedDone.error?.code==='NUMERICAL_RANGE',{unresolvedStart,unresolvedDone});await noField('unresolved film');await clean('unresolved film');
  await solve(base);await measuredLabel();await cmd('clear');check('Clear immediately removes selected film Probe label',(await measureButton.textContent())==='Measure');await noField('final Clear');await clean('final Clear');
  await call('view.set',{index:0,single:true,focus:owner.hash});await call('diagnostics.frame',{frames:6});const afterFrames=await call('diagnostics.frame',{frames:12});
  check('film fixture current CPU/GPU frame times remain bounded',afterFrames.timestampQueries&&afterFrames.frames.length===12&&afterFrames.frames.every(f=>Number.isFinite(f.cpuMs)&&Number.isFinite(f.gpuMs)&&f.cpuMs<50&&f.gpuMs<50),{beforeFrames,afterFrames});
  const gpu=await page.evaluate(async()=>({validation:(await frameEngine.renderer.device.popErrorScope())?.message||null,uncaptured:__exteriorFilmGPU,lost:__exteriorFilmLost,resources:__exteriorFilmOwned,sameDevice:frameEngine.renderer.device===__exteriorFilmDevice}));
  check('film native gate has no shader/device/page errors or owned buffer leak',gpu.sameDevice&&!gpu.validation&&!gpu.uncaptured.length&&!gpu.lost&&!errors.length&&!consoleErrors.length&&gpu.resources.live===0&&gpu.resources.created===gpu.resources.destroyed&&gpu.resources.unresolvedLabels===0&&!gpu.resources.unrecognizedCallsites.length,{gpu,errors,consoleErrors});
  check('film observer covers real unlabelled MAC/advection and heat resources',gpu.resources.unlabelled>0&&['touching-classifier.js','plugin.js','mac-projection-gpu.js','mac-viscosity-gpu.js','mac-fan-gpu.js','temperature-advection-gpu.js'].every(file=>gpu.resources.byModule['/plugins/thermal/'+file]>0),gpu.resources);
  const sourcesAfter=await exteriorFilmSourceSnapshot();check('all film runtime/oracle/harness sources are unchanged through hardware gate',equal(sources,sourcesAfter),{sources,sourcesAfter});
  return {hardware,beforeFrames,afterFrames,evidence,gpu,errors,consoleErrors,sources,sourcesAfter,missingGates:['Shared-renderer device destruction/loss is not deliberately injected; CPU lifecycle evidence does not qualify hardware loss.','Maximum grids, arbitrary geometry/rotations, complete application/stress/release qualification and animation physics remain separate.','Full-chain near-equilibrium nonzero films may be unresolvable in Float32. This gate claims no tiny-signal, huge-h or steady-cooling qualification.','Native-domain predecessor gate remains independently required and unchanged, including its failed assertions.']};
 }catch(error){error.exteriorFilmEvidence={sources,errors,consoleErrors,gpu:await page.evaluate(()=>({uncaptured:window.__exteriorFilmGPU||[],lost:window.__exteriorFilmLost||null,resources:window.__exteriorFilmOwned||null,gate:window.__exteriorFilmGate?{stage:__exteriorFilmGate.stage,entered:__exteriorFilmGate.entered}:null})).catch(()=>null)};throw error;}
 finally{await page.evaluate(()=>window.__exteriorFilmGate?.release()).catch(()=>{});await context.close();}
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const checks=[],timings=[],sources=await exteriorFilmSourceSnapshot();let session,result;
 const check=(name,pass,detail)=>{checks.push({name,pass:!!pass,detail});if(!pass)throw Error(name+': '+JSON.stringify(detail));};
 const timed=async(name,limit,fn)=>{const start=performance.now(),value=await fn(),ms=performance.now()-start;timings.push({name,ms,limit});check(name+' latency',ms<limit,{ms,limit});return value;};
 try{session=await launch({headless:process.argv.includes('--headless')});const evidence=await exteriorFilmBrowserChecks(session.page,check,timed);result={pass:true,hardwareVerified:true,checks,timings,evidence};}
 catch(error){result={pass:false,hardwareVerified:false,checks,timings,evidence:error.exteriorFilmEvidence||null,error:error.stack||String(error)};}
 finally{await session?.close();}
 result.sources=sources;result.sourcesAfter=await exteriorFilmSourceSnapshot();result.sourcesUnchanged=equal(sources,result.sourcesAfter);if(!result.sourcesUnchanged){result.pass=false;result.hardwareVerified=false;result.sourceError='Source bytes changed during the run; no hardware qualification applies.';}
 await mkdir(new URL('tests/results/',root),{recursive:true});await writeFile(new URL('tests/results/thermal-exterior-film.json',root),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;
}
