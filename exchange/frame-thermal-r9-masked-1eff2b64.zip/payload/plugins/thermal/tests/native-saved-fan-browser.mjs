import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {launch,ready} from '../../../tools/browser.mjs';
import {boundaries,request,classified} from './scene-conjugate-fixture.mjs';
import {sceneConjugateInputs} from '../scene-conjugate.js';
import {stepFanConjugate} from './fan-conjugate-reference.mjs';
import {fixtureFluidOccurrence} from './native-fluid-fixture.mjs';
import {checkDefaultProbeFrame} from './native-probe-browser.mjs';

const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const near=(a,b,tolerance=1e-10)=>Array.isArray(a)&&a.length===b.length&&a.every((v,i)=>Number.isFinite(v)&&Math.abs(v-b[i])<=tolerance);
const maxDifference=(a,b)=>a.length===b.length?Math.max(...a.map((v,i)=>Math.abs(v-b[i]))):Infinity;
const components=[['u',30],['v',32],['w',36]];
const packedFan=[2.5,0,0,0,2.5,0,0,0,5,-250,0,-250];
const worldFan=[2.5,0,0,0,0,2.5,0,0,0,0,5,0,-250,0,-250,1];
const root=new URL('../../../',import.meta.url);
export async function savedFanSourceSnapshot(){
 const paths=['index.html','plugins/index.json','tools/browser.mjs','package.json','package-lock.json'];
 const visit=async path=>{for(const entry of await readdir(new URL(path,root),{withFileTypes:true})){const next=path+'/'+entry.name;if(entry.isDirectory())await visit(next);else if(/\.(?:js|mjs|json|md|svg)$/.test(entry.name))paths.push(next);}};
 await visit('plugins/thermal');const result={};for(const path of paths.sort())result[path]=createHash('sha256').update(await readFile(new URL(path,root))).digest('hex');return result;
}

// A new isolated context, ordinary native authoring, and the shared real device.
// Observers retain actual identities only. Await gates hold genuine async work;
// no input/frame writes, solver replacement, CPU fallback or success injection.
export async function nativeSavedFanBrowserChecks(parent,check,timed){
 const sources=await savedFanSourceSnapshot();
 const context=await parent.context().browser().newContext({viewport:{width:1280,height:900},serviceWorkers:'block'}),page=await context.newPage(),errors=[],consoleErrors=[],evidence=[];
 page.on('pageerror',error=>errors.push(error.stack||String(error)));
 page.on('console',message=>{if(message.type()==='error')consoleErrors.push(message.text());});
 try{
  const catalogue=JSON.parse(await readFile(new URL('../../index.json',import.meta.url),'utf8'));
  check('saved Fan candidate stays absent from public catalogue',!catalogue.includes('thermal/plugin.json'),catalogue);
  await page.route('**/plugins/index.json',route=>route.fulfill({json:[...catalogue,'thermal/plugin.json']}));
  const module=await readFile(new URL('../plugin.js',import.meta.url),'utf8'),activation='export async function activate(context) {',publication='result=await solve(job);current(job);',editor='context.editor.register({';
  for(const marker of [activation,publication,editor])if(module.split(marker).length!==2)throw Error('Saved-Fan observer/await marker changed: '+marker);
  await page.route('**/plugins/thermal/plugin.js',route=>route.fulfill({contentType:'text/javascript',body:module.replace(activation,activation+'\nwindow.__savedFanContext=context;').replace(editor,'context.editor.register(window.__savedFanEditor={').replace(publication,'result=await solve(job);await window.__savedFanGateAt?.("final");current(job);')}));
  await page.goto(parent.url());await ready(page);
  const call=(name,args={})=>page.evaluate(([name,args])=>frameAI.call(name,args),[name,args]);
  const objects=async()=> (await call('scene.inspect')).objects;
  const hardware=await page.evaluate(async()=>{
   const [{macProjectionWGSL},{macViscosityWGSL},{conductionWGSL}]=await Promise.all([import('/plugins/thermal/mac-projection-gpu.js'),import('/plugins/thermal/mac-viscosity-gpu.js'),import('/plugins/thermal/plugin.js')]);
   const device=frameEngine.renderer.device,info=device.adapterInfo;
   window.__savedFanGPU=[];window.__savedFanLost=null;window.__savedFanOwned={live:0,peak:0,created:0,destroyed:0,unlabelled:0,unresolvedLabels:0,unrecognizedCallsites:[],byModule:{}};
   device.addEventListener('uncapturederror',event=>__savedFanGPU.push(event.error.message));device.lost.then(info=>__savedFanLost={reason:info.reason,message:info.message});device.pushErrorScope('validation');
   window.__savedFanGateAt=async stage=>{const gate=window.__savedFanGate;if(gate?.stage===stage&&!gate.entered){gate.entered=true;await gate.promise;}};
   const allocationSources=new Set(['touching-classifier.js','plugin.js','mac-projection-gpu.js','mac-viscosity-gpu.js','mac-fan-gpu.js','temperature-advection-gpu.js'].map(name=>new URL('/plugins/thermal/'+name,location.href).href));
   const make=device.createBuffer.bind(device),shader=device.createShaderModule.bind(device),pipeline=device.createComputePipelineAsync.bind(device),modules=new WeakSet(),conductionModules=new WeakSet();window.__savedFanConductionPipelines=0;
   device.createShaderModule=options=>{const result=shader(options);if(options.code===macProjectionWGSL||options.code===macViscosityWGSL)modules.add(result);if(options.code===conductionWGSL)conductionModules.add(result);return result;};
   device.createComputePipelineAsync=async options=>{if(modules.has(options.compute?.module))await __savedFanGateAt('pipeline');const result=await pipeline(options);if(conductionModules.has(options.compute?.module)){__savedFanConductionPipelines++;await __savedFanGateAt('conduction');}return result;};
   device.createBuffer=options=>{
    // MAC/advection allocations have no labels. The immediate synchronous
    // source callsite identifies ownership, not transitive plugin callers or
    // every buffer on the shared device. Never rewrite production modules.
    const caller=(new Error().stack||'').split('\n').slice(1).map(line=>line.match(/(https?:\/\/[^\s)]+):\d+:\d+\)?$/)?.[1]).find(Boolean),path=caller?new URL(caller).pathname:null,stats=__savedFanOwned;
    const buffer=make(options);if(!allocationSources.has(caller)){if(options.label?.startsWith('Thermal '))stats.unresolvedLabels++;if(path?.startsWith('/plugins/thermal/')&&!stats.unrecognizedCallsites.includes(caller))stats.unrecognizedCallsites.push(caller);return buffer;}
    stats.byModule[path]=(stats.byModule[path]||0)+1;if(!options.label)stats.unlabelled++;
    const destroy=buffer.destroy.bind(buffer),map=buffer.mapAsync.bind(buffer);let dead=false;stats.created++;stats.live+=options.size;stats.peak=Math.max(stats.peak,stats.live);
    buffer.destroy=()=>{if(!dead){dead=true;stats.destroyed++;stats.live-=options.size;}destroy();};
    buffer.mapAsync=async(...args)=>{await map(...args);if(options.label==='Thermal independent occurrence readback')await __savedFanGateAt('classification');if(options.label==='Thermal bounded temperature inspection')await __savedFanGateAt('heat');};return buffer;
   };
   return info?Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(key=>[key,info[key]])):null;
  });
  check('saved Fan uses identifiable nonfallback hardware WebGPU',hardware&&Object.values(hardware).some(v=>typeof v==='string'&&v)&&!hardware.isFallbackAdapter&&!/swiftshader|llvmpipe|lavapipe|software/i.test(JSON.stringify(hardware)),hardware);
  const old=await objects();if(old.length)await call('scene.delete',{ids:old.filter(n=>!n.parent).map(n=>n.hash)});
  const owner=await timed('saved Fan owner creation',10000,()=>call('plugins.create',{plugin:'thermal'}));
  const cmd=(operation,args={},id=owner.hash)=>call('plugins.command',{id,operation,args});
  const description=await call('plugins.describe',{plugin:'thermal'}),op=description.operations.find(op=>op.id==='solve-saved-fan'),schema=op?.inputSchema;
  check('saved Fan operation has strict discoverable explicit-domain schema',op?.readOnly===false&&op.interruptible===true&&schema?.additionalProperties===false&&['fanHash','dimensions','cellSizeMM','settings','stepCount','cumulativeDivergenceDriftBudgetK'].every(key=>schema.required.includes(key))&&schema.properties.settings.additionalProperties===false&&!Object.hasOwn(schema.properties.settings.properties,'fanBox'),description);
  check('saved Fan reuses bounded read-only native reads',['status','inspect','inspect-velocity','measure','fan-inputs'].every(id=>description.operations.find(op=>op.id===id)?.readOnly===true),description.operations);
  await call('scene.select',{ids:[owner.hash]});await page.locator('#tabAttributes').click();
  check('saved Fan adds no Solve Attributes action',await page.locator('#attrContent [data-plugin-action-button^="solve"]').count()===0);
  const clearButton=page.locator('#attrContent [data-plugin-action-button="clear"]');
  check('saved Fan uses stable disabled idle Clear action',await clearButton.count()===1&&await clearButton.isDisabled()&&(await clearButton.textContent())==='Clear');
  const ownerBefore=(await objects()).find(n=>n.hash===owner.hash),fan=await timed('saved Fan native creation',10000,()=>cmd('create-fan'));
  const fanInputs=()=>cmd('fan-inputs',{},fan.hash),defaultFan=(await objects()).find(n=>n.hash===fan.hash),defaultInputs=await fanInputs();
  check('saved Fan begins as selected native 25 mm child',defaultFan.selected&&defaultFan.parent===owner.hash&&defaultFan.params.Thermal===owner.hash&&equal(defaultFan.matrix,[.25,0,0,0,.25,0,0,0,.25,-25,-12.5,-12.5])&&equal(defaultInputs.fan.mapping.sizeMM,[25,25,25])&&equal(defaultInputs.fan.mapping.centerMM,[-25,-12.5,-12.5]),{defaultFan,defaultInputs});
  // Deliberately no selection repair: creation must await native selectOwner.
  await timed('saved Fan immediate native transform',1500,()=>call('transform.set',{channel:'position',axis:0,value:-250,coordinates:'world'}));
  const moved=(await objects()).find(n=>n.hash===fan.hash),ownerAfter=(await objects()).find(n=>n.hash===owner.hash);
  check('immediate transform updates Fan local/world/bounds, never Thermal owner',equal(moved.matrix,[.25,0,0,0,.25,0,0,0,.25,-250,-12.5,-12.5])&&near(moved.worldMatrix.slice(12,15),[-250,-12.5,-12.5])&&near(moved.bounds.min,[-262.5,-25,-25])&&near(moved.bounds.max,[-237.5,0,0])&&equal(ownerAfter.matrix,ownerBefore.matrix)&&equal(ownerAfter.worldMatrix,ownerBefore.worldMatrix),{moved,ownerBefore,ownerAfter});
  await timed('saved Fan supported native box authoring',10000,async()=>{
   for(const [axis,value]of [250,250,500].entries())await call('transform.set',{channel:'size',axis,value,coordinates:'object'});
   for(const [axis,value]of [-250,0,-250].entries())await call('transform.set',{channel:'position',axis,value,coordinates:'world'});
   await call('scene.update',{id:fan.hash,params:{Direction:'Forward','Shutoff pressure':2,'Free flow':.1}});
  });
  const assertFan=async label=>{const record=(await objects()).find(n=>n.hash===fan.hash),metadata=await fanInputs();check(label+' has actual packed local/world/bounds and exact native physical mapping',equal(record.matrix,packedFan)&&near(record.worldMatrix,worldFan)&&near(record.bounds.min,[-375,-125,-500])&&near(record.bounds.max,[-125,125,0])&&metadata.fan.mapping.status==='supported-frame'&&equal(metadata.fan.mapping.centerMM,[-250,0,-250])&&equal(metadata.fan.mapping.sizeMM,[250,250,500])&&!metadata.solverEligible&&!metadata.solverCoupled,{record,metadata});return metadata;};
  await assertFan('Authored saved Fan');
  const groups=[],meshes=[];
  await timed('saved Fan two-cuboid native material authoring',10000,async()=>{for(const [i,box]of boundaries().entries()){
   const group=await call('scene.create',{type:'group'}),mesh=await call('mesh.create',{vertices:Array.from(box.positions),indices:Array.from(box.indices),storage:'auto'});groups.push(group.hash);meshes.push(mesh.hash);
   await call('scene.update',{id:mesh.hash,parent:group.hash});await call('tag.set',{ids:[group.hash],kind:'thermal_material',enabled:true,params:{Conductivity:i?8:2,'Heat capacity':i?21:10}});
  }await call('tag.set',{ids:[groups[1]],kind:'thermal_heater',enabled:true,params:{Power:75}});});
  const probe=await timed('saved Fan bounded Probe creation',2000,()=>cmd('create-probe'));
  checkDefaultProbeFrame(check,await objects(),probe.hash,owner.hash,'Saved-Fan Probe');
  const initialCapture=await cmd('scene-inputs'),nativeMeshes=(await objects()).filter(n=>meshes.includes(n.hash));
  check('saved Fan and Probe are excluded from two real cuboid occurrences',initialCapture.totalOccurrences===2&&initialCapture.occurrences.every(o=>meshes.includes(o.hash))&&nativeMeshes.length===2&&nativeMeshes.every(n=>n.mesh?.triangles===12&&n.mesh.storage==='buffer'),{initialCapture,nativeMeshes});
  const args=async(steps=2,saved=true)=>{const capture=await cmd('scene-inputs'),r={...request(),stepCount:steps,cumulativeDivergenceDriftBudgetK:.001};r.settings.fluidOccurrence=fixtureFluidOccurrence(capture,meshes[0]);if(saved){delete r.settings.fanBox;r.fanHash=fan.hash;}return r;};
  const finish=async()=>{const until=performance.now()+15000;while(performance.now()<until){const state=await cmd('status');if(state.state!=='running')return state;await new Promise(resolve=>setTimeout(resolve,10));}throw Error('Saved-Fan native job exceeded 15 s');};
  const resource=()=>page.evaluate(()=>({...__savedFanOwned}));
  const clean=async label=>{const stats=await resource();check(label+' releases every tracked Thermal-owned buffer',stats.live===0&&stats.created===stats.destroyed&&stats.unresolvedLabels===0&&!stats.unrecognizedCallsites.length,stats);};
  const fields=async()=>{const result={temperature:(await cmd('inspect',{offset:0,count:24})).temperatures};for(const [component,count]of components)result[component]=(await cmd('inspect-velocity',{component,offset:0,count})).values;return result;};
  const noField=async label=>{for(const [operation,input,id]of [['inspect',{count:24},owner.hash],...components.map(([component,count])=>['inspect-velocity',{component,count},owner.hash]),['measure',{},probe.hash]]){const rejection=await page.evaluate(async({id,operation,args})=>{try{await frameAI.call('plugins.command',{id,operation,args});return null;}catch(error){return {code:error.code,message:error.message};}},{id,operation,args:input});check(label+' rejects '+operation+(input.component?' '+input.component:''),rejection?.code==='NO_RESULT',rejection);}};
  const solve=async(steps=1,input=null,operation='solve-saved-fan')=>{input??=await args(steps,operation==='solve-saved-fan');return timed(`${operation} completed ${steps}-step operation`,15000,async()=>{const began=performance.now(),start=await cmd(operation,input),done=await finish();check(operation+' returns running then publishes complete duration',start.state==='running'&&done.state==='ready'&&done.duration?.completedSteps===steps&&done.duration.completedTime===steps*.01,{start,done});return {start,done,wallMs:performance.now()-began};});};
  const pause=stage=>page.evaluate(stage=>{let release;const promise=new Promise(resolve=>release=resolve);window.__savedFanGate={stage,promise,release,entered:false};},stage);
  const waitGate=()=>page.waitForFunction(()=>window.__savedFanGate?.entered,{},{timeout:15000});
  const resume=()=>page.evaluate(()=>{window.__savedFanGate?.release();window.__savedFanGate=null;});
  const unobserved=(operation,input={},name='__savedFanPending')=>page.evaluate(({hash,operation,input,name})=>{window[name]=frameAI.call('plugins.command',{id:hash,operation,args:input});window[name].catch(()=>{});},{hash:owner.hash,operation,input,name});
  const rememberIdentity=()=>page.evaluate(({owner,fan})=>{const nodes=__savedFanContext.document.nodes;window.__savedFanIdentity={owner:nodes.find(n=>n.nativeHash===owner),fan:nodes.find(n=>n.nativeHash===fan)};if(!__savedFanIdentity.owner||!__savedFanIdentity.fan)throw Error('Missing observed native identities');},{owner:owner.hash,fan:fan.hash});
  const identity=()=>page.evaluate(({owner,fan})=>{const nodes=__savedFanContext.document.nodes,o=nodes.find(n=>n.nativeHash===owner),f=nodes.find(n=>n.nativeHash===fan);return {ownerPresent:!!o,fanPresent:!!f,ownerSame:o===__savedFanIdentity.owner,fanSame:f===__savedFanIdentity.fan,ownerHash:o?.nativeHash,fanHash:f?.nativeHash,ownerId:o?.id,fanId:f?.id};},{owner:owner.hash,fan:fan.hash});
  const selectProbe=async()=>{await call('scene.select',{ids:[probe.hash]});await page.locator('#tabAttributes').click();};
  const measureButton=page.locator('#attrContent [data-plugin-action-button="measure"]');
  const measuredLabel=async()=>{const measurement=await cmd('measure',{},probe.hash);await selectProbe();check('saved Fan Probe is bounded physical sampling',Number.isFinite(measurement.temperature)&&measurement.cellsRead<=8&&measurement.interpolation==='perfect-contact-resistance-weighted'&&measurement.unit==='°C',measurement);return {measurement,label:await measureButton.textContent()};};
  const beforeFrames=await call('diagnostics.frame',{frames:6});
  await call('scene.select',{ids:[owner.hash]});await page.locator('#tabAttributes').click();
  check('first saved Solve starts from stable disabled Clear action',await clearButton.isDisabled()&&(await clearButton.textContent())==='Clear');
  const firstInput=await args(10);await pause('pipeline');await cmd('solve-saved-fan',firstInput);await waitGate();
  check('first saved Solve changes idle Clear to Stop without reselecting owner',await clearButton.isEnabled()&&(await clearButton.textContent())==='Stop');
  await clearButton.click();await resume();check('idle-origin native action cancels first saved Solve',(await timed('first saved Solve native Stop drain',15000,finish)).state==='cancelled');await noField('first native Stop');await clean('first native Stop');
  await clearButton.click();check('same idle-origin action clears stopped saved job',(await cmd('status')).state==='idle'&&await clearButton.isDisabled());

  // Production stays GPU-only. This Float64 direct solver is a test oracle.
  for(const variant of [{name:'forward',direction:'Forward',pressure:2,steps:10},{name:'reverse',direction:'Reverse',pressure:2,steps:2},{name:'off',direction:'Forward',pressure:0,steps:1}]){
   await call('scene.update',{id:fan.hash,params:{Direction:variant.direction,'Shutoff pressure':variant.pressure,'Free flow':.1}});
   const metadata=await assertFan(variant.name),saved=await solve(variant.steps),actual=await fields();
   const explicit=await args(variant.steps,false);explicit.settings.fanBox.direction=variant.direction==='Forward'?1:-1;explicit.settings.fanBox.shutoffPressure=variant.pressure;
   // Only this independent synthetic oracle fixes left/right source order.
   const c=classified();c.settings={...explicit.settings,fluidOccurrence:0};const input=sceneConjugateInputs(c.source,c.classification,c.world,c.settings).input,{divergenceDriftBudgetK,boundary,...base}=input,{viscosity,...fluid}=input.fluid;
   let expected={...base,fluid,fan:{...input.fan,viscosity},boundary:{}};for(let i=0;i<variant.steps;i++){const next=stepFanConjugate(expected);expected={...expected,temperature:next.temperature,u:next.u,v:next.v,w:next.w};}
   const oracleErrors={temperatureK:maxDifference(actual.temperature.map(value=>value+273.15),Array.from(expected.temperature))};for(const [component]of components)oracleErrors[component]=maxDifference(actual[component],Array.from(expected[component]));
   check(variant.name+' actual T/u/v/w match independent Float64 duration oracle',actual.temperature.length===24&&actual.temperature.every(Number.isFinite)&&components.every(([key,count])=>actual[key].length===count&&actual[key].every(Number.isFinite))&&oracleErrors.temperatureK<=.0005&&components.every(([key])=>oracleErrors[key]<=.00002),oracleErrors);
   const d=saved.done.duration;
   check(variant.name+' preserves SI, source/energy diagnostics and retained-state limits',saved.done.authoring==='saved-fan-explicit-domain'&&saved.done.geometryCoupled&&!saved.done.sceneSolver&&!saved.done.generalSceneSolver&&equal(saved.done.cellSize,[.25,.25,.5])&&saved.done.boundary==='adiabatic'&&saved.done.retainedHostFieldBytes===976&&saved.done.retainedGPUBytes===0&&saved.done.maxStepWallMs<5000&&d.temperatureAccuracyGuaranteeK===null&&[saved.done.pressureRise,saved.done.correctedFlow,d.sourcePower,d.sourceEnergy,d.thermalEnergyChange,d.thermalBalanceError,d.thermalBalanceAllowance,d.mechanical.balanceError,d.mechanical.balanceAllowance,d.mechanical.midpointWork,d.fluid.balanceError,d.solid.balanceError].every(Number.isFinite)&&d.sourcePower===75&&Math.abs(d.sourceEnergy-75*.01*variant.steps)<1e-10&&Math.abs(d.thermalBalanceError)<=d.thermalBalanceAllowance&&Math.abs(d.mechanical.balanceError)<=d.mechanical.balanceAllowance&&Math.abs(d.fluid.balanceError)<=d.fluid.balanceAllowance&&Math.abs(d.solid.balanceError)<=d.solid.balanceAllowance&&d.boundaryEnergy===0,saved.done);
   check(variant.name+' honors actual native direction and pressure',metadata.fan.authored.params.Direction===variant.direction&&metadata.fan.authored.params['Shutoff pressure']===variant.pressure&&metadata.fan.authored.params['Free flow']===.1&&(variant.pressure===0?Math.abs(saved.done.correctedFlow)<1e-12:Math.sign(saved.done.correctedFlow)===explicit.settings.fanBox.direction),{metadata,status:saved.done});
   const measured=await measuredLabel();await call('scene.select',{ids:[owner.hash]});await selectProbe();check(variant.name+' selection preserves measured Probe label',/°C/.test(measured.label)&&(await measureButton.textContent())===measured.label,measured);
   const explicitSolve=await solve(variant.steps,explicit,'solve-scene'),comparison=await fields(),pathErrors={temperatureK:maxDifference(actual.temperature,comparison.temperature)};for(const [key]of components)pathErrors[key]=maxDifference(actual[key],comparison[key]);
   check(variant.name+' saved native input equals existing explicit numerical path',explicitSolve.done.authoring==='explicit-request'&&pathErrors.temperatureK<=.0005&&components.every(([key])=>pathErrors[key]<=.00002),pathErrors);
   await clean(variant.name);evidence.push({variant,saved,explicitSolve,oracleErrors,pathErrors,measured});
  }
  await call('scene.update',{id:fan.hash,params:{Direction:'Forward','Shutoff pressure':2}});

  // Invalid schema/preflight never cancels a valid predecessor. Invalid geometry
  // may honestly fail after acceptance/classification; it is tested separately.
  await solve();const baseline=await fields(),predecessor=await cmd('status');
  for(const [operation,input]of [['inspect',{count:257}],['inspect-velocity',{component:'u',count:257}]])check('saved field bounded read rejects '+operation+' overflow',await cmd(operation,input).then(()=>false,()=>true));
  const badFan=await cmd('create-fan');await call('scene.update',{id:badFan.hash,enabled:false});
  for(const change of [r=>delete r.fanHash,r=>r.fanHash='missing',r=>r.fanHash=owner.hash,r=>r.fanHash=badFan.hash,r=>r.settings.fanBox=request().settings.fanBox,r=>r.settings.direction=-1,r=>r.stepCount=11,r=>r.settings.timeStep=.2]){
   const input=await args();change(input);const rejected=await cmd('solve-saved-fan',input).then(()=>false,()=>true),state=await cmd('status');check('invalid saved request preserves ready predecessor and exact fields',rejected&&state.job===predecessor.job&&state.state==='ready'&&equal(await fields(),baseline),{input,state});
  }
  await call('scene.update',{id:badFan.hash,enabled:true});await call('scene.select',{ids:[badFan.hash]});await call('transform.set',{channel:'rotation',axis:2,value:30,coordinates:'object'});
  const rotatedMetadata=await cmd('fan-inputs',{},badFan.hash),rotatedArgs=await args();rotatedArgs.fanHash=badFan.hash;
  const rotatedRejected=await cmd('solve-saved-fan',rotatedArgs).then(()=>false,()=>true),afterRotated=await cmd('status');
  check('unsupported native rotated Fan rejects in preflight without replacing predecessor',rotatedMetadata.fan.mapping.status==='unsupported-frame'&&rotatedRejected&&afterRotated.state==='ready'&&afterRotated.job===predecessor.job&&equal(await fields(),baseline),{rotatedMetadata,afterRotated});
  await call('scene.delete',{ids:[badFan.hash]});
  const activeArgs=await args(10);await pause('pipeline');const active=await cmd('solve-saved-fan',activeArgs);await waitGate();const allocations=await resource();
  const badTime=await args(10);badTime.settings.timeStep=.02;const invalid=await cmd('solve-saved-fan',badTime).then(()=>false,()=>true);
  check('cross-field rejection preserves running predecessor before interruption',invalid&&(await cmd('status')).job===active.job&&(await cmd('status')).state==='running'&&(await resource()).created===allocations.created);
  await timed('saved Fan in-flight native API responsiveness',1500,async()=>{await cmd('status');await call('scene.select',{ids:[probe.hash]});await call('scene.select',{ids:[owner.hash]});});
  await page.locator('#tabAttributes').click();check('saved Fan running action exposes Stop',await clearButton.isEnabled()&&(await clearButton.textContent())==='Stop');
  await clearButton.click();await resume();check('saved Fan native Stop cancels without partial publication',(await timed('saved Fan native Stop drain',15000,finish)).state==='cancelled');await noField('Native Stop');await clean('Native Stop');
  await clearButton.click();check('same native action clears cancelled saved job',(await cmd('status')).state==='idle'&&await clearButton.isDisabled());

  // Physically invalid saved frames are authored via the actual native editor.
  for(const kind of ['default','off-grid','full-span']){
   await solve();const prior=(await cmd('status')).job;let target=fan.hash;
   if(kind==='default')target=(await cmd('create-fan')).hash;
   else{await call('scene.select',{ids:[fan.hash]});if(kind==='off-grid')await call('transform.set',{channel:'position',axis:0,value:-249,coordinates:'world'});else{for(const [axis,value]of [[1,750],[2,1000]])await call('transform.set',{channel:'size',axis,value,coordinates:'object'});await call('transform.set',{channel:'position',axis:2,value:0,coordinates:'world'});}}
   const input=await args();input.fanHash=target;const accepted=await cmd('solve-saved-fan',input),failed=await timed(kind+' saved Fan async mapping rejection',15000,finish);
   check(kind+' unsupported physical mapping fails honestly after acceptance',accepted.state==='running'&&accepted.job!==prior&&failed.state==='failed'&&!!failed.error?.code,{accepted,failed});await noField(kind);await clean(kind);
   if(kind==='default')await call('scene.delete',{ids:[target]});else{await call('scene.select',{ids:[fan.hash]});for(const [axis,value]of [250,250,500].entries())await call('transform.set',{channel:'size',axis,value,coordinates:'object'});for(const [axis,value]of [-250,0,-250].entries())await call('transform.set',{channel:'position',axis,value,coordinates:'world'});}await assertFan(kind+' restored');
  }

  const other=await call('plugins.create',{plugin:'thermal'});
  const edits=[
   ['direction',()=>call('scene.update',{id:fan.hash,params:{Direction:'Reverse'}}),()=>call('scene.update',{id:fan.hash,params:{Direction:'Forward'}})],
   ['pressure',()=>call('scene.update',{id:fan.hash,params:{'Shutoff pressure':0}}),()=>call('scene.update',{id:fan.hash,params:{'Shutoff pressure':2}})],
   ['free flow',()=>call('scene.update',{id:fan.hash,params:{'Free flow':.2}}),()=>call('scene.update',{id:fan.hash,params:{'Free flow':.1}})],
   ['reference',()=>call('scene.update',{id:fan.hash,params:{Thermal:other.hash}}),()=>call('scene.update',{id:fan.hash,params:{Thermal:owner.hash}})],
   ['enable',()=>call('scene.update',{id:fan.hash,enabled:false}),()=>call('scene.update',{id:fan.hash,enabled:true})],
   ['hierarchy',()=>call('scene.update',{id:fan.hash,parent:other.hash}),()=>call('scene.update',{id:fan.hash,parent:owner.hash})],
   ['transform',async()=>{await call('scene.select',{ids:[fan.hash]});await call('transform.set',{channel:'position',axis:0,value:-249,coordinates:'world'});},async()=>{await call('scene.select',{ids:[fan.hash]});await call('transform.set',{channel:'position',axis:0,value:-250,coordinates:'world'});}]
  ];
  for(const [name,edit,restore]of edits){await solve();await measuredLabel();await edit();const stale=await cmd('status');await selectProbe();check('actual native Fan '+name+' edit invalidates ready field and cached Probe',stale.state==='stale'&&(await measureButton.textContent())==='Measure',stale);await noField(name);await restore();check(name+' restoration never resurrects old result',(await cmd('status')).state!=='ready');await clean(name);}
  // Presentation edits and selection do not change physical provenance.
  await solve();const presentation=(await cmd('status')).job,{label}=await measuredLabel();await call('scene.update',{id:fan.hash,name:'Authored Fan',visible:false});await selectProbe();check('Fan name/visibility preserve ready job and cached Probe',(await cmd('status')).job===presentation&&(await cmd('status')).state==='ready'&&(await measureButton.textContent())===label);await call('scene.update',{id:fan.hash,visible:true});
  const ancestor=await call('scene.create',{type:'group'});await call('scene.update',{id:owner.hash,parent:ancestor.hash});
  for(const kind of ['enable','transform']){await solve();await measuredLabel();if(kind==='enable')await call('scene.update',{id:ancestor.hash,enabled:false});else{await call('scene.select',{ids:[ancestor.hash]});await call('transform.set',{channel:'position',axis:0,value:1,coordinates:'world'});}await selectProbe();check('native ancestor '+kind+' edit invalidates field and Probe',(await cmd('status')).state==='stale'&&(await measureButton.textContent())==='Measure');await noField('ancestor '+kind);if(kind==='enable')await call('scene.update',{id:ancestor.hash,enabled:true});else{await call('scene.select',{ids:[ancestor.hash]});await call('transform.set',{channel:'position',axis:0,value:0,coordinates:'world'});}}
  await call('scene.update',{id:owner.hash,parent:''});await call('scene.delete',{ids:[ancestor.hash]});await assertFan('Ancestry restored');

  // Existing explicit jobs must ignore every saved-Fan-only native edit.
  await solve(1,await args(1,false),'solve-scene');const explicitJob=(await cmd('status')).job,explicitFields=await fields();await rememberIdentity();
  for(const [name,edit,restore]of edits){await edit();const state=await cmd('status');check('explicit scene ignores saved Fan '+name+' edit',state.state==='ready'&&state.job===explicitJob&&state.authoring==='explicit-request'&&equal(await fields(),explicitFields),state);await restore();}
  await call('scene.select',{ids:[fan.hash]});await call('transform.set',{channel:'position',axis:0,value:-249,coordinates:'world'});await call('edit.history',{action:'undo'});const sameIdentity=await identity();
  check('native transform Undo preserves identities and explicit field',sameIdentity.ownerSame&&sameIdentity.fanSame&&(await cmd('status')).job===explicitJob&&(await cmd('status')).state==='ready'&&equal(await fields(),explicitFields),sameIdentity);await assertFan('Transform Undo');

  for(const stage of ['classification','pipeline','conduction','heat','final']){
   const input=await args(2);await pause(stage);await cmd('solve-saved-fan',input);await waitGate();const conductionPipelines=await page.evaluate(()=>__savedFanConductionPipelines);await noField('held '+stage);
   await call('scene.update',{id:fan.hash,params:{'Free flow':.2}});await resume();const stale=await timed('late Fan edit at '+stage+' drain',15000,finish);
   check('late native Fan edit at '+stage+' prevents atomic publication',stale.state==='stale',stale);if(stage==='conduction')check('late Fan edit stops immediately after genuine conduction pipeline await',await page.evaluate(()=>__savedFanConductionPipelines)===conductionPipelines);await noField('late '+stage);await clean('late '+stage);await call('scene.update',{id:fan.hash,params:{'Free flow':.1}});
  }
  for(const stage of ['classification','pipeline','conduction','heat','final']){
   const input=await args(2);await pause(stage);await cmd('solve-saved-fan',input);await waitGate();const conductionPipelines=await page.evaluate(()=>__savedFanConductionPipelines);await call('scene.select',{ids:[owner.hash]});await page.locator('#tabAttributes').click();await clearButton.click();await resume();const done=await timed('Stop at '+stage+' drain',15000,finish);check('Stop at '+stage+' publishes no candidate',done.state==='cancelled',done);if(stage==='conduction')check('Stop halts after genuine conduction pipeline await',await page.evaluate(()=>__savedFanConductionPipelines)===conductionPipelines);await noField('Stop '+stage);await clean('Stop '+stage);
  }
  for(const flag of ['author','output','render']){
   const input=await args();await pause('pipeline');await cmd('solve-saved-fan',input);await waitGate();
   await page.evaluate(flag=>{window.__savedFanBarrierDone=false;window.__savedFanBarrier=__savedFanEditor.flush({[flag]:true}).then(()=>__savedFanBarrierDone=true);},flag);
   await cmd('status');check(flag+' barrier waits for genuine active saved work',!await page.evaluate(()=>__savedFanBarrierDone));await unobserved('clear');await resume();await timed(flag+' Clear and work-tail drain',15000,()=>page.evaluate(async()=>{await __savedFanPending;await __savedFanBarrier;}));check(flag+' barrier drains retired work',(await cmd('status')).state==='idle'&&await page.evaluate(()=>__savedFanBarrierDone));await clean(flag);
  }
  for(const operation of ['cancel','clear']){
   const input=await args(),queued=await timed('queued saved Solve then '+operation,15000,()=>page.evaluate(async({owner,args,operation})=>{const solve=frameAI.call('plugins.command',{id:owner,operation:'solve-saved-fan',args}),stop=frameAI.call('plugins.command',{id:owner,operation,args:{}});return {start:await solve,end:await stop};},{owner:owner.hash,args:input,operation}));
   check('native API queue '+operation+' never publishes saved field',queued.end.state===(operation==='clear'?'idle':'cancelled'),queued);await noField('queued '+operation);await clean('queued '+operation);
  }
  for(const replacement of ['solve-saved-fan','solve-scene','solve-grid']){
   const firstArgs=await args(2),secondArgs=replacement==='solve-grid'?{dimensions:[2,1,1],cellSize:[1,1,1],conductivity:[1],boundary:{xMin:0,xMax:1}}:await args(1,replacement==='solve-saved-fan');await pause('pipeline');const first=await cmd('solve-saved-fan',firstArgs);await waitGate();const before=await resource(),second=await cmd(replacement,secondArgs);
   check(replacement+' replacement retains old work tail before allocation',second.state==='running'&&second.job!==first.job&&(await resource()).created===before.created,{first,second,before,after:await resource()});await resume();const done=await timed(replacement+' replacement completed drain',15000,finish);check(replacement+' replacement publishes only the fresh job',done.state==='ready'&&done.job===second.job&&(replacement==='solve-grid'?!done.geometryCoupled:done.duration.completedSteps===1),done);if(replacement==='solve-grid')await cmd('clear');await clean(replacement+' replacement');
  }
  await solve();await measuredLabel();await cmd('clear');check('Clear immediately removes selected saved Probe label',(await measureButton.textContent())==='Measure');await noField('Clear');

  // Real deletion/document restoration replaces JS nodes. Native frame Undo does
  // not; never use equal hashes or ordinary frame history as replacement proof.
  await solve();await rememberIdentity();const originalIdentity=await identity();await measuredLabel();
  await call('scene.delete',{ids:[owner.hash]});const absent=await identity();check('native deletion removes actual owner and Fan nodes',!absent.ownerPresent&&!absent.fanPresent,absent);
  await call('edit.history',{action:'undo'});const restored=await identity(),retired=await cmd('status');check('delete Undo restores hashes with new owner/Fan identities and no field',restored.ownerPresent&&restored.fanPresent&&!restored.ownerSame&&!restored.fanSame&&restored.ownerHash===owner.hash&&restored.fanHash===fan.hash&&restored.ownerId===originalIdentity.ownerId&&retired.state==='idle'&&retired.job===null,{originalIdentity,restored,retired});await noField('delete Undo');await selectProbe();check('delete Undo never restores numeric Probe label',(await measureButton.textContent())==='Measure');await solve();
  // The restored owner must retain the old pending tail even while its new
  // same-hash job is accepted, with no second allocation before old work drains.
  const heldArgs=await args(2);await pause('pipeline');const held=await cmd('solve-saved-fan',heldArgs);await waitGate();const heldResources=await resource();await rememberIdentity();await call('scene.delete',{ids:[owner.hash]});await call('edit.history',{action:'undo'});const replaced=await identity(),restart=await cmd('solve-saved-fan',await args(1));
  check('in-flight delete Undo requires new identity and drains before allocation',!replaced.ownerSame&&!replaced.fanSame&&restart.job!==held.job&&restart.state==='running'&&(await resource()).created===heldResources.created,{held,restart,replaced,heldResources,now:await resource()});
  await page.evaluate(()=>{window.__savedFanBarrierDone=false;window.__savedFanBarrier=__savedFanEditor.flush({render:true}).then(()=>__savedFanBarrierDone=true);});await cmd('status');check('restored owner render barrier includes retired job',!await page.evaluate(()=>__savedFanBarrierDone));await resume();await timed('delete Undo old/new saved work drain',15000,()=>page.evaluate(()=>__savedFanBarrier));const restarted=await finish();check('old completion cannot overwrite restored saved owner',restarted.state==='ready'&&restarted.job===restart.job&&restarted.duration.completedSteps===1,restarted);await clean('delete Undo replacement');
  const exported=await call('scene.export',{includeData:true}),beforeOpenFan=(await objects()).find(n=>n.hash===fan.hash),beforeOpenJob=(await cmd('status')).job;await rememberIdentity();await call('scene.open',{name:'thermal-native-saved-fan.hash',base64:exported.base64});
  const reopened=await identity(),openStatus=await cmd('status'),openObjects=await objects(),openFan=openObjects.find(n=>n.hash===fan.hash),openCapture=await cmd('scene-inputs'),fluidOccurrence=fixtureFluidOccurrence(openCapture,meshes[0]);
  check('HASH Open restores authoring with replacement identities, never runtime state',!reopened.ownerSame&&!reopened.fanSame&&reopened.ownerHash===owner.hash&&reopened.fanHash===fan.hash&&openStatus.state==='idle'&&openStatus.job===null&&equal(openFan.params,beforeOpenFan.params)&&equal(openFan.matrix,beforeOpenFan.matrix)&&openFan.params.Thermal===owner.hash,{reopened,openStatus,openFan});
  check('HASH Open explicitly resolves stable fluid hash in the current capture',openCapture.occurrences.filter(o=>o.hash===meshes[0]).length===1&&openCapture.occurrences.find(o=>o.occurrence===fluidOccurrence)?.hash===meshes[0],{initialCapture,openCapture,fluidHash:meshes[0],fluidOccurrence});checkDefaultProbeFrame(check,openObjects,probe.hash,owner.hash,'HASH saved-Fan Probe');await noField('HASH Open');
  await assertFan('HASH saved Fan');const fresh=await solve();check('HASH requires a fresh saved job',fresh.done.job!==beforeOpenJob&&fresh.done.authoring==='saved-fan-explicit-domain',fresh);await measuredLabel();await cmd('clear');await clean('final Clear');
  await call('view.set',{index:0,single:true,focus:owner.hash});await call('diagnostics.frame',{frames:6});const afterFrames=await call('diagnostics.frame',{frames:12});
  check('saved Fan fixture has bounded current CPU/GPU frame timings',afterFrames.timestampQueries&&afterFrames.frames.length===12&&afterFrames.frames.every(frame=>Number.isFinite(frame.cpuMs)&&Number.isFinite(frame.gpuMs)&&frame.cpuMs<50&&frame.gpuMs<50),{beforeFrames,afterFrames});
  const gpu=await page.evaluate(async()=>({validation:(await frameEngine.renderer.device.popErrorScope())?.message||null,uncaptured:__savedFanGPU,lost:__savedFanLost,resources:__savedFanOwned}));
  check('saved Fan completes without validation/device-loss/page errors or owned buffer leaks',!gpu.validation&&!gpu.uncaptured.length&&!gpu.lost&&!errors.length&&!consoleErrors.length&&gpu.resources.live===0&&gpu.resources.created===gpu.resources.destroyed&&gpu.resources.unresolvedLabels===0&&!gpu.resources.unrecognizedCallsites.length,{gpu,errors,consoleErrors});
  check('allocation observer covers unlabelled MAC/advection plus classification and conduction',gpu.resources.unlabelled>0&&['touching-classifier.js','plugin.js','mac-projection-gpu.js','mac-viscosity-gpu.js','mac-fan-gpu.js','temperature-advection-gpu.js'].every(file=>gpu.resources.byModule['/plugins/thermal/'+file]>0),gpu.resources);
  const sourcesAfter=await savedFanSourceSnapshot();check('saved Fan tested source bytes remain unchanged',equal(sources,sourcesAfter),{sources,sourcesAfter});
  return {hardware,beforeFrames,afterFrames,evidence,gpu,errors,consoleErrors,sources,sourcesAfter,missingGates:['Deliberate destruction/loss of the shared renderer device is not injected in this gate; native-device-loss CPU lifecycle tests are not hardware loss proof.','Maximum-grid duration, general geometry and complete application/stress/release qualification remain separate.']};
 }catch(error){error.savedFanEvidence={sources,errors,consoleErrors,gpu:await page.evaluate(()=>({uncaptured:window.__savedFanGPU||[],lost:window.__savedFanLost||null,resources:window.__savedFanOwned||null,gate:window.__savedFanGate?{stage:__savedFanGate.stage,entered:__savedFanGate.entered}:null})).catch(()=>null)};throw error;}
 finally{await page.evaluate(()=>window.__savedFanGate?.release()).catch(()=>{});await context.close();}
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const checks=[],timings=[],sources=await savedFanSourceSnapshot();let session,result;
 const check=(name,pass,detail)=>{checks.push({name,pass:!!pass,detail});if(!pass)throw Error(name+': '+JSON.stringify(detail));};
 const timed=async(name,limit,fn)=>{const start=performance.now(),value=await fn(),ms=performance.now()-start;timings.push({name,ms,limit});check(name+' latency',ms<limit,{ms,limit});return value;};
 try{session=await launch({headless:process.argv.includes('--headless')});const evidence=await nativeSavedFanBrowserChecks(session.page,check,timed);result={pass:true,hardwareVerified:true,checks,timings,evidence};}
 catch(error){result={pass:false,hardwareVerified:false,checks,timings,evidence:error.savedFanEvidence||null,error:error.stack||String(error)};}
 finally{await session?.close();}
 result.sources=sources;result.sourcesAfter=await savedFanSourceSnapshot();result.sourcesUnchanged=equal(sources,result.sourcesAfter);if(!result.sourcesUnchanged){result.pass=false;result.hardwareVerified=false;result.sourceError='Source bytes changed during the run; no hardware qualification applies.';}
 await mkdir(new URL('tests/results/',root),{recursive:true});await writeFile(new URL('tests/results/thermal-native-saved-fan.json',root),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;
}
