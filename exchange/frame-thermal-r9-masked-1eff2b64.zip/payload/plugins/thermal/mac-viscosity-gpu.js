// Internal GPU-only viscosity qualification. No scene, projection or CPU fallback.
const error=(code,message)=>Object.assign(new Error(message),{code});
const need=(condition,code,message)=>{if(!condition)throw error(code,message);};
const normal=x=>Number.isFinite(x)&&Math.abs(x)>=2**-1022;
export function assembleMACViscosity(input){
 const keys=['dimensions','size','u','v','w','density','viscosity','timeStep','tolerance','maxIterations'];
 need(input&&typeof input==='object'&&!Array.isArray(input)&&!('obstacle' in input)&&!Object.keys(input).some(k=>!keys.includes(k)),'INVALID_ARGUMENT','Explicit closed all-fluid MAC viscosity inputs required.');
 const {dimensions:d,size,density,viscosity,timeStep,tolerance=1e-4,maxIterations=20000}=input;
 need(Array.isArray(d)&&d.length===3&&Array.from(d).every(x=>Number.isInteger(x)&&x>=2&&x<=16)&&Array.isArray(size)&&size.length===3&&Array.from(size).every(x=>Number.isFinite(x)&&x>0)&&[density,viscosity,timeStep].every(x=>Number.isFinite(x)&&x>0)&&Number.isFinite(tolerance)&&tolerance>=1e-5&&tolerance<=1e-3&&Number.isInteger(maxIterations)&&maxIterations>=1&&maxIterations<=20000,'INVALID_ARGUMENT','Invalid bounded SI viscosity settings.');
 const h=size.map((x,a)=>x/d[a]),factor=viscosity/density*timeStep,coeff=h.map(x=>factor/(x*x)),massFactor=.5*density*h.reduce((a,b)=>a*b);
 need(h.every(normal)&&Math.max(...h)/Math.min(...h)<=10&&coeff.every(x=>Number.isFinite(x)&&x>=1e-6&&x<=100)&&normal(massFactor),'NUMERICAL_RANGE','Require normal cell mass, aspect ratio <=10 and dt*nu/h² in [1e-6,100].');
 const components=[];
 for(let axis=0;axis<3;axis++){
  const macShape=[...d];macShape[axis]++;const field=input[['u','v','w'][axis]],length=macShape.reduce((a,b)=>a*b);
  need((Array.isArray(field)||field instanceof Float32Array||field instanceof Float64Array)&&field.length===length&&Array.from(field).every(Number.isFinite),'INVALID_ARGUMENT','Dense finite MAC velocities required.');
  const shape=[...d];shape[axis]--;const n=shape.reduce((a,b)=>a*b),indices=new Uint32Array(n),original=new Float64Array(n),diagonal=new Float64Array(n).fill(1),edges=[],walls=[],id=p=>p[0]+shape[0]*(p[1]+shape[1]*p[2]);let scale=0;
  for(let z=0;z<macShape[2];z++)for(let y=0;y<macShape[1];y++)for(let x=0;x<macShape[0];x++){
   const p=[x,y,z],f=x+macShape[0]*(y+macShape[1]*z);if(p[axis]===0||p[axis]===d[axis]){need(field[f]===0,'INVALID_BOUNDARY','Outer normal velocities must be zero.');continue;}
   p[axis]--;const i=id(p);indices[i]=f;original[i]=field[f];scale=Math.max(scale,Math.abs(field[f]));
  }
  const rhs=new Float32Array(n);for(let i=0;i<n;i++){rhs[i]=scale===0?0:original[i]/scale;need(original[i]===0||(rhs[i]!==0&&Math.abs(rhs[i]*scale/original[i]-1)<1e-6),'NUMERICAL_RANGE','Component velocity dynamic range exceeds Float32.');}
  for(let i=0;i<n;i++){const p=[i%shape[0],Math.floor(i/shape[0])%shape[1],Math.floor(i/(shape[0]*shape[1]))];
   for(let a=0;a<3;a++)for(const sign of [-1,1]){const q=[...p];q[a]+=sign;if(q[a]<0||q[a]>=shape[a]){const c=coeff[a]*(a===axis?1:2);diagonal[i]+=c;walls.push([i,c]);}else if(sign===1){const j=id(q),c=coeff[a];edges.push([i,j,c]);diagonal[i]+=c;diagonal[j]+=c;}}
  }
  // Per-component energy scaling avoids one velocity component masking another.
  const energyScale=scale===0?0:massFactor*scale*scale;need(scale===0||normal(energyScale),'NUMERICAL_RANGE','Component kinetic energy scale is unrepresentable.');
  components.push({axis,shape,n,length,indices,original,scale,rhs,diagonal,edges,walls,energyScale});
 }
 return {dimensions:[...d],h,coeff,tolerance,maxIterations,components};
}
export function validateMACViscosity(plan,axis,values){
 const c=plan.components[axis];need(values instanceof Float32Array&&values.length===c.n&&Array.from(values).every(Number.isFinite),'NUMERICAL_RANGE','Finite Float32 GPU face field required.');
 const output=new Float64Array(c.length),x=new Float64Array(c.n),b=new Float64Array(c.n);let nonzero=false;
 for(let i=0;i<c.n;i++){
  const physical=values[i]*c.scale;need(Number.isFinite(physical)&&(values[i]===0||normal(physical)),'NUMERICAL_RANGE','Dimensional diffused velocity is unrepresentable.');output[c.indices[i]]=physical;nonzero ||= physical!==0;x[i]=c.scale===0?0:physical/c.scale;b[i]=c.scale===0?0:c.original[i]/c.scale;
 }
 need(c.scale===0||nonzero,'NUMERICAL_RANGE','Nonzero component vanished during diffusion.');
 const applied=Float64Array.from(x,(v,i)=>v*c.diagonal[i]);for(const [i,j,k]of c.edges){applied[i]-=k*x[j];applied[j]-=k*x[i];}
 let residual=0,before=0,after=0,step=0,loss=0;for(let i=0;i<c.n;i++){residual=Math.max(residual,Math.abs(applied[i]-b[i]));before+=b[i]*b[i];after+=x[i]*x[i];step+=(b[i]-x[i])**2;}
 need(Number.isFinite(residual)&&residual<=plan.tolerance,'NONCONVERGENCE','Actual dimensional velocity violates component-relative implicit residual.');
 for(const [i,j,k]of c.edges)loss+=2*k*(x[i]-x[j])**2;for(const [i,k]of c.walls)loss+=2*k*x[i]**2;
 // Exact BE identity defect = 2*x dot (b-A*x). Bound by the requested
 // per-face residual, never a large coefficient*velocity cancellation scale.
 const balance=before-after-step-loss,allowance=2*plan.tolerance*x.reduce((s,v)=>s+Math.abs(v),0)+128*Number.EPSILON*(before+after+step+loss);
 need(Number.isFinite(balance)&&Number.isFinite(allowance)&&Math.abs(balance)<=allowance&&after<=before*(1+1e-4),'NONCONVERGENCE','Returned viscosity energy balance failed.');
 const metrics={residual,energyBefore:before*c.energyScale,energyAfter:after*c.energyScale,stepLoss:step*c.energyScale,viscousLoss:loss*c.energyScale,energyError:balance*c.energyScale,energyAllowance:allowance*c.energyScale};
 need(Object.values(metrics).every(Number.isFinite)&&[[before,metrics.energyBefore],[after,metrics.energyAfter],[step,metrics.stepLoss],[loss,metrics.viscousLoss]].every(([a,b])=>a===0||normal(b)),'NUMERICAL_RANGE','Viscous energy diagnostics are unrepresentable.');
 return {output,metrics};
}
export const macViscosityWGSL=`
struct Config { dims:vec4<u32>, coeff:vec4<f32> }
@group(0) @binding(0) var<uniform> c:Config;
@group(0) @binding(1) var<storage,read> rhs:array<f32>;
@group(0) @binding(2) var<storage,read> velocity:array<f32>;
@group(0) @binding(3) var<storage,read_write> next:array<f32>;
@group(0) @binding(4) var<storage,read_write> metric:atomic<u32>;
fn row(i:u32)->vec2<f32>{
 let pos=vec3<u32>(i%c.dims.x,(i/c.dims.x)%c.dims.y,i/(c.dims.x*c.dims.y));let stride=vec3<u32>(1u,c.dims.x,c.dims.x*c.dims.y);var diagonal=1.;var sum=0.;
 for(var a=0u;a<3u;a++){let k=c.coeff[a];let wall=select(2.*k,k,a==c.dims.w);
 if(pos[a]>0u){diagonal+=k;sum+=k*velocity[i-stride[a]];}else{diagonal+=wall;}
 if(pos[a]+1u<c.dims[a]){diagonal+=k;sum+=k*velocity[i+stride[a]];}else{diagonal+=wall;}}
 return vec2<f32>(diagonal,sum);
}
@compute @workgroup_size(64) fn iterate(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&rhs)){return;}let r=row(i);next[i]=(rhs[i]+r.y)/r.x;}
@compute @workgroup_size(64) fn residual(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&rhs)){return;}let r=row(i);atomicMax(&metric,bitcast<u32>(abs(rhs[i]-(r.x*velocity[i]-r.y))));}
`;
async function checked(device,work){
 device.pushErrorScope('validation');device.pushErrorScope('out-of-memory');let result,failure;try{result=work();}catch(e){failure=e;}const pending=[device.popErrorScope(),device.popErrorScope()],errors=await Promise.all(pending);if(failure)throw failure;const e=errors.find(Boolean);if(e)throw error('GPU_ERROR',e.message);return result;
}
export async function diffuseMACGPU(context,input,{signal,check=()=>{}}={}){
 need(typeof check==='function'&&(!signal||(typeof signal.addEventListener==='function'&&typeof signal.removeEventListener==='function')),'INVALID_ARGUMENT','Invalid lifecycle guards.');
 const device=context?.device,owned=new Set();let disposed=false,liveBytes=0,peakGPUBytes=0,readbackBytes=0;
 const dispose=()=>{if(disposed)return;disposed=true;for(const b of owned)b.destroy();owned.clear();signal?.removeEventListener('abort',dispose);};
 const guard=()=>{need(!signal?.aborted,'CANCELLED','Viscosity cancelled.');need(!disposed,'RETIRED_RESULT','Viscosity retired.');need(context?.device===device,'STALE_JOB','Shared device changed.');check();};
 try{
  guard();const plan=assembleMACViscosity(input);need(device&&typeof device.createBuffer==='function','WEBGPU_REQUIRED','Borrowed shared device required.');signal?.addEventListener('abort',dispose,{once:true});guard();
  const U=GPUBufferUsage,make=(size,usage)=>{need(size<=device.limits.maxBufferSize&&(!(usage&U.STORAGE)||size<=device.limits.maxStorageBufferBindingSize),'GPU_LIMIT','Viscosity allocation exceeds device limits.');const b=device.createBuffer({size,usage});owned.add(b);liveBytes+=size;peakGPUBytes=Math.max(peakGPUBytes,liveBytes);return b;};
  const {module,layout,pipelineLayout}=await checked(device,()=>{const module=device.createShaderModule({code:macViscosityWGSL}),layout=device.createBindGroupLayout({entries:[{binding:0,visibility:GPUShaderStage.COMPUTE,buffer:{type:'uniform'}},...[1,2,3,4].map(binding=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:binding<=2?'read-only-storage':'storage'}}))]}),pipelineLayout=device.createPipelineLayout({bindGroupLayouts:[layout]});return {module,layout,pipelineLayout};});guard();
  const pipelines={};for(const entryPoint of ['iterate','residual']){pipelines[entryPoint]=await device.createComputePipelineAsync({layout:pipelineLayout,compute:{module,entryPoint}});guard();}
  const results=[],diagnostics=[];
  for(const c of plan.components){
   const resources=await checked(device,()=>{const storage=U.STORAGE|U.COPY_DST|U.COPY_SRC,uniform=make(32,U.UNIFORM|U.COPY_DST),rhs=make(c.n*4,storage),v=[make(c.n*4,storage),make(c.n*4,storage)],metric=make(4,storage),stage=make(c.n*4,U.MAP_READ|U.COPY_DST),config=new ArrayBuffer(32);new Uint32Array(config).set([...c.shape,c.axis]);new Float32Array(config,16).set([...plan.coeff,0]);device.queue.writeBuffer(uniform,0,config);device.queue.writeBuffer(rhs,0,c.rhs);return {uniform,rhs,v,metric,stage};});guard();
   const {uniform,rhs,v,metric,stage}=resources,groups=await checked(device,()=>v.map((b,i)=>device.createBindGroup({layout,entries:[uniform,rhs,b,v[1-i],metric].map((buffer,binding)=>({binding,resource:{buffer}}))})));guard();
   const read=async(buffer,count)=>{guard();await checked(device,()=>{const e=device.createCommandEncoder();e.copyBufferToBuffer(buffer,0,stage,0,count*4);device.queue.submit([e.finish()]);});guard();await stage.mapAsync(GPUMapMode.READ);try{guard();readbackBytes+=count*4;return new Float32Array(stage.getMappedRange(0,count*4).slice(0));}finally{stage.unmap();}};
   const dispatch=(encoder,name,current)=>{const pass=encoder.beginComputePass();pass.setPipeline(pipelines[name]);pass.setBindGroup(0,groups[current]);pass.dispatchWorkgroups(Math.ceil(c.n/64));pass.end();};
   let current=0,iterations=0,residual=Infinity;
   while(iterations<plan.maxIterations){guard();await checked(device,()=>{device.queue.writeBuffer(metric,0,new Uint32Array(1));const encoder=device.createCommandEncoder(),batch=Math.min(64,plan.maxIterations-iterations);for(let j=0;j<batch;j++){dispatch(encoder,'iterate',current);current=1-current;}iterations+=batch;dispatch(encoder,'residual',current);device.queue.submit([encoder.finish()]);});residual=(await read(metric,1))[0];need(Number.isFinite(residual),'NUMERICAL_RANGE','Nonfinite viscous iteration.');if(residual<=plan.tolerance*.25)break;}
   need(residual<=plan.tolerance*.25,'NONCONVERGENCE','Bounded GPU viscosity iteration exhausted.');
   const values=await read(v[current],c.n),validated=validateMACViscosity(plan,c.axis,values);guard();results.push(validated.output);diagnostics.push({...validated.metrics,iterations,gpuResidual:residual});
   for(const b of [uniform,rhs,...v,metric,stage]){b.destroy();owned.delete(b);}liveBytes=0;
  }
  guard();return {scope:'closed-all-fluid-mac-viscosity-gpu-qualification',sceneSolver:false,u:results[0],v:results[1],w:results[2],diagnostics,metrics:{peakGPUBytes,retainedGPUBytes:0,readbackBytes}};
 }catch(e){guard();throw e;}finally{dispose();}
}
