# Explicit exterior-film candidate (isolated; hardware unverified)

This follow-up adds a prescribed external heat bath on sealed no-slip exterior
walls. It reuses the existing conduction coefficients, buffers, WGSL, conjugate
timestep, native work tail and bounded duration pipeline. It does not add a second
solver, CPU production fallback, native authoring field, Solve button, catalogue
registration, ventilation, radiation, fan-work heating or steady cooling claim.
No actual user-model film coefficient, bath or wall selection is invented.

## Explicit request

The optional `settings.thermalBoundary` for the internal `solve-scene`,
`solve-saved-fan` and `solve-domain` candidates is:

```js
{kind:'exterior-film',faces:{xMax:{hWPerM2K:5,ambientKelvin:280}}}
```

These numbers are test fixtures, not recommended defaults. Select one to six whole
owner-local exterior faces from xMin/xMax/yMin/yMax/zMin/zMax. Every entry requires
finite h >= 0 W/(m² K) and an explicit 1..2000 K bath with the existing <=1e-4 K
Celsius upload conversion bound. Omitted faces are insulated. Explicit h=0 is
insulation and does not anchor a steady matrix. Its ambient is still validated.
Unknown keys, missing fields, symbols, inherited/hidden/accessor properties and
unsupported units/shapes reject. A film is not an interface condition or patch.

Absence preserves the old adiabatic scene behavior. Native Ambient does not create
an exterior film. Native owner-local face IDs are unchanged by world reflection.
The exact independently classified two touching cuboids, left fluid/right solid,
solid-only native Heater, partial grid-aligned local-X Fan, orthogonal physical
scale conversion, 2..16 axis counts, <=4096 cells, 1..10 steps and <=0.1 s remain.
No spatially stretched grid or arbitrary rotation/classifier tolerance is added.

The nested boundary is privately copied and frozen before awaits/interruption.
Saved-Fan/domain use the existing authentic frozen capture. Explicit solve-scene
now retains its frozen request in the interruption token and verifies the captured
owner identity, parameter/world signature and device before queued execution.
An implicit Initial changed while queued therefore rejects stale instead of
publishing the old temperature under a new owner stamp. Caller mutation never
changes h, bath or face selection in flight. Request replacement, source/native
changes, Stop/Clear, readback, device loss and publication retain existing guards.

## One operator, correct surface resistance

At each exterior cell-face incidence, with physical normal width delta, area A,
adjacent cell conductivity k, and h>0:

- `G = A / (delta/(2*k) + 1/h)` in W/K.
- `Qout = G*(Tcell - Tambient)` in W, outward positive.
- `Tsurface = Tambient + Qout/(h*A)` is the mathematical surface temperature.

The half-cell resistance is required; h*A alone is not the cell-centre-to-bath
conductance. Each corner receives its distinct exterior face contributions. A
transverse face spanning both regions uses the local material's conductivity at
each incidence. Interior reciprocal conductances and perfect contact are unchanged.
A warm bath yields negative outward power and heats the body. Nothing clamps it.

Core assembly has an internal optional `boundaryRobin` map with
`{hWPerM2K,ambientCelsius}`. It adds G to diagonal/boundaryG and G*TambientC to
RHS/boundaryGT, using the existing buffer layout and WGSL. It rejects any overlap
with temperature or flux, including zero conditions. Omitted legacy boundary still
uses Ambient on faces not covered by another explicit condition. Film adapters
always pass explicit empty temperature/flux maps, so omitted film faces cannot
silently become Dirichlet walls.

`boundaryRobin` is deliberately absent from the public `solve-grid` schema and
rejected by its direct preflight, including inherited properties. Generic
solveConductionGPU diagnostics alone are not film qualification. The core
assembler's steady Robin matrices are a test/analysis seam, not a supported
production steady-film operation. `solveLayeredHeatGPU` accepts the explicit film
object in its existing boundary parameter and validates every actual returned cell
before retaining a field. Its standalone guard uses the existing once-per-device
loss state, checks it across readback/metrics/inspection, and retires on loss
without attaching a persistent promise closure to each result. Its old x-end Dirichlet path is unchanged. Conjugate uses
the same film object or the existing `adiabatic` string. Fluid-only/forced-heat
contracts remain adiabatic and do not silently acquire exterior film support.

## Signed original-physics verification

The shared heat step checks the actual Kelvin field against
`C*(Tnew-Tadv)/dt + sum(Qinternal) + sum(Qout) - Psource = 0`.

It preserves the <=0.001 K per-cell residual and <=0.001 relative source-cell
power gate. Active nonzero film exchange also bounds residual by 0.001 times the
sum of absolute cell-face exchange. Material/source capacities and physical
products must remain finite normal values. Film G must remain normal Float32 with
relative upload error <=1e-6, resolve in the full uploaded diagonal within 1e-3,
and retain a nonzero initial drive within 1e-3 through the combined RHS/diagonal.
Source resolution is tested after film additions. Actual per-incidence original
exchange must remain resolved under a conservative marginal check of the actual
uploaded boundaryG/GT sums. This is a representability test, not a unique
attribution of a rounded sum to its faces. Aggregate uploaded
boundary accounting is checked separately. Tiny signals, large contrasts and
near-equilibrium cancellation may fail closed; h or temperatures are never clamped.

Source-free extrema include active bath temperatures. Global heat balance includes
signed exterior energy, uses a gross source/exchange drive cap and separately
reported Float64 summation allowance. Gross exchange sums absolute individual
cell-face powers before aggregation, so opposite signs within one face do not
cancel its scale. Fluid and solid balances include their own exterior exchange and
one shared interface power with opposite signs. Regional allowances derive from
actual local residual bounds; only fluid receives the old advection allowance.
Mechanical work is never included in thermal source or allowance.

The full chain uploads fluid temperature in Kelvin before the Celsius conduction
stage. An apparently uniform equilibrium can acquire a tiny conversion-level
exchange that is unresolvable relative to the intended zero drive and must reject.
Exactly representable layered-only equilibrium fixtures do not establish universal
full-chain equilibrium acceptance. Explicit h=0 runs the original adiabatic physics
checks, including its final net-source energy cap, and produces identical T/u/v/w.

Duration independently recomputes each completed field's exterior power and checks
its diagnostics before accepting the next step. It sums `dt*Qout` for every step,
face and region. It never uses endpoint power times total duration. Global and
regional endpoint balances include that sum. A failure publishes no partial field,
never retries a step and never offers continuation through a native result.

## Diagnostics and Probe

The native handle/status boundary is `adiabatic` or the immutable explicit film
object, not an unconditional adiabatic label. Per-step thermal conduction includes
`boundaryPowerOutW`, `boundaryEnergyOutJ`, `boundaryPowerByFaceW`,
`boundaryEnergyByFaceJ`, `absoluteBoundaryPowerW`, `absoluteBoundaryEnergyJ`, and
`netBoundaryPowerResolved`. Active-film regional diagnostics include their signed
boundary power and energy. Global `netDriveEnergyResolved` distinguishes a small
net source-minus-bath signal from its gross exchange scale.

Duration exposes `boundaryEnergyOutJ`, `boundaryEnergyByFaceJ`,
`absoluteBoundaryEnergyJ`, regional `boundaryEnergyOutJ`, `grossDriveEnergy` and
`netBoundaryEnergyResolved`. Existing `boundaryEnergy` is a signed outward-energy
alias, not an outlet or mechanical quantity. A net unresolved flag does not certify
the accuracy of cancelling exchanges, even when gross balance passes.

Probe is unchanged: bounded, current, cell-centre interpolation with the existing
resistance-aware internal interface rule. Outside the last centre it clamps to the
boundary-adjacent cell inside the domain. It does not report the wall surface
Tsurface or the ambient bath. Exterior points still reject. No new surface
reconstruction, fluid flow through the wall or external bath dynamics are modeled.

## Verification and limitations

Authored `tests/exterior-film.mjs` checks original-path h0 equality, heterogeneous
surface resistance, signed 1/10-step accounting, source/mechanical separation,
nested snapshots and queued native requests, preinterrupt rejection, corrupted
boundary diagnostics, layered actual-field checks and retained-buffer disposal,
unresolvable signals, and <=1000 ms six-face 16³ host planning. Independent review
and the actual-hardware browser gate are separate artifacts. Existing assertions
and acceptance tolerances are not weakened to fit films.

CPU reference and command-emulator success does not execute WGSL or qualify real
GPU rounding, shaders, native UI/Undo/HASH, rendering, frame timings, peak driver
memory or large-scene behavior. The new hardware harness must run on a genuine
adapter alongside full npm test/stress and the original native gates. No skipped
or blocked hardware gate is counted as passed. See the parent evidence report for
exact tested hashes, counts, timing and blocked-stage reasons. This local source is
not registered, published to GitHub/Pages, uploaded to Space, or installed on a
user computer by this task.
