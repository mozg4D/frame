## Isolated masked-projection follow-up

The existing MAC pressure path now supports one explicit strictly interior
whole-cell cuboid and one connected surrounding fluid component, using reciprocal
uploaded face masks in the same RHS/pressure/correction operator. This closes only
the narrow embedded-obstacle projection gap. Arbitrary occupancy, disconnected
components, masked viscosity/advection/fan/heat, native scene inference and full
solver integration remain unimplemented. The historical all-fluid stages below
retain their original contracts. See [MASKED-PROJECTION.md](MASKED-PROJECTION.md)
for gauge/normalization, solid pressure sentinels, strict numeric acceptance,
CPU/emulator evidence and the still-unrun actual-hardware gate.

# Exterior-film integration follow-up

The isolated exterior-film candidate implements the existing conduction seam,
strict explicit request, actual original heat equations and cumulative signed
exterior energy checks described in EXTERIOR-FILM.md. It adds no WGSL kernel,
second solver, native authoring field or public registration. Earlier adiabatic
stage descriptions below still apply when thermalBoundary is omitted. CPU proof
and emulator coverage do not complete the required actual-hardware boundary,
native job, full application and performance gates.

# Shared GPU and native scene integration: bounded plan

## What is already reusable

`plugin.js` already owns the production conduction machinery: `assembleConduction` creates reciprocal finite-volume conductances, per-cell transient capacity, signed source watts and thermal boundary accounting; `conductionWGSL` implements bounded damped-Jacobi iteration plus residual/energy reductions; `solveConductionGPU` borrows the supplied shared device, retains one temperature buffer, uses 32-byte metric readbacks and owns cancellation checks/resource cleanup. Do not copy these into a parallel thermal solver. Existing `probe.js`, exact scene identity stamps and scene pipeline guards remain reusable, but a scalar GPU result alone does not establish scene geometry or airflow.

The CPU MAC projection, viscosity, actuator, scalar advection and conjugate helpers are independent validation references, not production fallbacks. Their dense solves and synchronous loops are not suitable for native-scale runtime execution. No external CFD plugin is required or used.

## First real GPU path added

`layered-heat-gpu.js` is an internal explicit-grid adapter for the **conduction/source stage only**, using the existing shared-device solver. It maps two constant-property flat material slabs to per-cell conductivity and volumetric heat capacity, confines numeric W/m³ source input to the solid slab, and explicitly converts public Kelvin input to the existing Celsius numerical contract. Output bounded samples and temperature metrics are converted back to Kelvin. No velocities, advection, fan force, CPU solve, native tags or scene classification are silently invoked.

Scope: transient only, 2..128 cells per axis and at most 32768 cells; left fluid label/right solid label, full grid, positive constant properties, explicit SI extents, x-end Dirichlet or adiabatic boundaries. Input temperatures are 1..2000K with a <=1e-4K Float32 input quantization check. Nonzero heaters must survive Float32 RHS upload at relative 1e-3; source-only temperature must stay in range. This is an assembly representability gate, not a guarantee of final source-power accuracy. Final min/max and bounded samples must remain physically supported. Arbitrary steady heater accuracy and the CPU references' Float64 tolerances are not promised by this adapter.

`solveLayeredHeatGPU(context,input,{signal,check})` uses only `context.device`, rechecks device identity and caller-provided validity before/after async work, supports abort before/during/after solve, retires on stale/failed reads, and exposes no raw GPU buffer. `inspect` reads at most 256 temperatures. Bad read arguments do not retire an otherwise valid result. Caller must dispose abandoned fields and supply `check` when associating a field with mutable document state. There is no native registration or scene Solve action.

Hardware fixture in `tests/layered-gpu-checks.mjs` is wired into the existing plugin browser harness, after its non-software-adapter gate. It compares a closed solid-heater and Dirichlet interface case with the independent dense layered reference, validates Kelvin conversion, energy accounting, bounded retained buffer, malformed-read behavior, device staleness and post-publication abort. It invokes the real borrowed renderer device, never a software/CPU substitute. Until that fixture actually runs on hardware, the path is implemented but hardware-unverified.

## Initial budgets and acceptance gates

- Completed 32³ CPU assembly/upload-plan preparation: <1500ms in the focused test; coefficient/account/initial typed arrays are 104 bytes/cell, about 3.25MiB. Temporary JS field arrays are additional, so this is not peak heap measurement.
- Existing GPU allocation formula is approximately 56.5 bytes/cell plus 96 bytes, excluding driver/pipeline overhead: <2MiB at 32³. Retained temperature is 4 bytes/cell, 128KiB at 32³. Verify actual metrics rather than treating this estimate as available VRAM.
- Hardware fixture completed solve budget: 15s including compilation/dispatch/readback. Small-case field error <.02K and energy imbalance <.02W, residual must meet requested kernel criterion, retained field exactly 4N bytes. These are fixture gates, not a general accuracy specification.
- Hardware 32³ and larger completed-operation measurements, shader errors, device loss and UI responsiveness are still required. Do not claim GPU speedups or frame-time performance from CPU preparation timing.

## Exact remaining translation work

1. **Passive scalar GPU transport:** implement shared-flux/upwind updates, local multi-axis CFL/divergence reductions, range/energy checks and bounded output inspection. Prefer a face-flux pass plus cell divergence pass, so both cells use one face value. Keep Kelvin/Celsius conversion at explicit boundaries; avoid reupload/readback of whole fields between stages. Validate periodic test topology separately from native closed geometry. Compare against the current Fourier/energy reference and GPU Float32-specific error budgets.
2. **MAC GPU state and viscosity:** define three face-grid storage layouts and solid/active-face ownership, reuse device/submission/error-scope conventions, then implement implicit viscous operator and a robust convergent iterative solver. Current thermal scalar kernel cannot be claimed to handle MAC no-slip ghosts or vector diffusion unchanged.
3. **Pressure projection:** a dedicated masked pressure operator and per-component gauge/compatibility handling are needed. Preserve local roundoff budgets, actual pressure reconstruction and returned divergence checks. The scalar thermal kernel is anchored and positive-definite; unanchored pressure Poisson cannot be passed to it as if it were ordinary heat diffusion.
4. **Fan coupling:** represent the local-X sheet on valid fluid faces, measure corrected flux on GPU and converge the operating curve; retain closed-full-span zero-throughflow behavior and distinguish impulse work from physical heating. No per-cell multiplication of Q0. Validate forced time/space convergence and interface boundary behavior on hardware.
5. **Coupled temperature:** chain final valid face velocity to scalar transport, then the reusable heat kernel without CPU field roundtrips. Preserve scalar-ready local divergence, CFL, source-power and material-interface energy checks. Publish only after every stage passes, with cancellation/stale retirement spanning the whole job.

## Native scene path still missing

Existing Material/Heater tags, inherited provenance and exact per-occurrence transforms are available; exact touching-cuboid geometry avoids union loss. But there is no validated native fluid-domain marker, fluid property/heat-capacity authoring contract, fan P0/Q0 schema, boundary-condition authoring, or scene-to-fluid-face classifier. A Thermal helper box is not proof of a closed fluid volume. Do not infer these from generic tag presence or box size.

Start native integration only with an explicitly defined axis-aligned fluid chamber and one touching solid, complete-cell occupancy, exact interface and fan footprint. Validate no overlap/gap/partial cells, both material assignments, source provenance/coverage and the owner's scale-aware mm-to-SI conversion. Reuse exact scene stamps, owner/device guards, cancellation, bounded Probe reads and runtime-only ownership. Add native authoring/Undo/HASH fixtures and extension of Probe/section units only after the corresponding field exists. No catalogue entry, new public Solve, UI, publishing or shared-core changes belong to this isolated milestone.

## V23: bounded shared-device pressure projection qualification

`mac-projection-gpu.js` is an internal GPU-only closed all-fluid MAC projection.
It does not borrow the anchored conduction matrix: its Neumann pressure graph
has a nullspace, uses gauge-free damped Jacobi and only pressure differences.
Host assembly enumerates each internal face once. GPU kernels iterate pressure,
reduce maximum residual through positive-float atomic bits, and correct faces.
No external CFD, CPU solve fallback, native scene command, or resident flow API.

Contract: 2..16 cells per axis (4096 total), cell aspect ratio <=10, explicit
metres/seconds/kg/m³/m/s, zero outer normal velocity, no solids/open/periodic
boundaries. Constant density; no viscosity, fan, velocity advection or heat.
Velocities are normalized before Float32 upload, relative upload error <1e-6;
nonzero physical output/scale underflow is rejected. The pressure is a correction
in Pa with an unspecified gauge, not a steady pressure solution.

Stopping is bounded at 20,000 iterations, batches of 128, requested normalized
max-divergence tolerance 1e-5..1e-3 (default 1e-4). After convergence the actual
GPU face field and pressure are read back and independently checked on the host.
Each physical cell divergence must satisfy requested tolerance times initial
max divergence plus 64 Float32 eps times its own sum of absolute face fluxes.
The latter is a local arithmetic allowance, not a physical accuracy promise.
Pressure reconstruction, finite normal physical outputs and kinetic energy
nonincrease (relative allowance 1e-4) are required. Every failure rejects; Jacobi
stagnation is not silently reported as success.

This first qualification stage intentionally reads the bounded complete field:
4(N+E) final bytes plus 4 bytes per residual batch; E<=11520. It returns detached
CPU snapshots and destroys all GPU allocations before return, with zero retained
GPU bytes. GPU allocation upper bound 16N+24E+36 bytes (342,052 bytes at 16³).
This is not yet the zero-readback resident composition API needed by a production
flow timestep. Migrate the same checks to validated GPU reductions and retain
versioned buffers only after hardware accuracy and performance qualification.
Assembly budget: 16³ <1500ms. Hardware fixtures 2³/4x3x2/8x6x4 <15s each compare
against independent Float64 graph CG. Host command-emulator tests verify orchestration,
cleanup and fixtures only; they do not validate WGSL or hardware Float32 arithmetic.
Shared-device error scopes are opened/popped within synchronous turns, never held
across awaits. Caller check and AbortSignal revalidate after asynchronous work;
no shared device destruction. No claim of actual GPU execution until runners pass.

V23 correction: pressure-to-velocity reconstruction allowance depends only on
input velocity and actual pressure-difference correction, never absolute pressure
gauge. Float32 pressure inputs are represented exactly in host Float64; scaling
the subtraction allowance by |pLeft|+|pRight| could wrongly permit erasing an
exact circulation under an arbitrary constant pressure. Signed circulation tests
reject that field for gauges 0, +/-1e8 and 1e30 while accepting unchanged flow.

## V24: bounded shared-device implicit viscosity qualification

`mac-viscosity-gpu.js` implements backward Euler velocity diffusion, independently
of the pressure stage. No projection, advection, forcing, thermal coupling or
native scene operation is implied. Explicit constant density and dynamic viscosity
use SI; nu=viscosity/density. The scope is one closed all-fluid rectangular box,
2..16 cells per axis, aspect ratio <=10, dt*nu/h_axis² in [1e-6,100]. Solids,
open/periodic boundaries and other coefficient ranges reject explicitly.

Each MAC component solves its own interior normal faces. Interior neighbours have
symmetric dt*nu/h² coefficients; normal no-slip wall distance is h and contributes
one coefficient, tangential reflected half-cell walls contribute twice that.
The anchored SPD system is iterated by GPU Jacobi with bounded 64-iteration
batches, at most 20,000 iterations. A GPU atomic maximum tests its true uploaded
operator residual. This is a separate stencil from the singular pressure kernel.

Normalization is independent for u/v/w. Uploaded component values have relative
error <1e-6; physical scales and nonzero returned velocities/energies must be normal
Float64. After full bounded readback, the validator rescales the actual GPU field
and rebuilds the original SI operator residual, relative to that component's own
input maximum. Tolerance is 1e-5..1e-3, default 1e-4. No coefficient-magnitude
roundoff allowance can hide a bad residual. It verifies kinetic energy nonincrease (relative allowance 1e-4)
and the BE identity old-new = step loss + viscous loss. Energy identity tolerance
comes from 2*requestedResidual*sum(abs(returned normalized velocity)), plus Float64
summation allowance, not from an arbitrary physical scale. Nonconvergence rejects.

Sequential component allocation needs at most 16*3840+36 = 61,476 GPU bytes,
excluding pipelines/driver memory. All buffers are destroyed before return; returned
arrays are detached CPU snapshots, not live GPU fields. Final readback is 4*E bytes,
E<=11520, plus 4 bytes per residual batch. As with pressure, this intentionally
bounded qualification path precedes resident GPU composition and GPU-side final
physical checks. Assembly budget 16³ <1500ms; hardware fixtures 2³/4x3x2/8x6x4
<15s each. Float64 reference comparison, manufactured MAC sine eigenmode, no-slip
walls, per-component dynamic range, lifecycle and energy tests run on CPU. The
command emulator tests orchestration only, never WGSL/hardware correctness.

## V25: partial local-X GPU fan sheet qualification

`mac-fan-gpu.js` composes the shared-device pressure qualification stage with a
new GPU sheet-impulse kernel. The sequence is initial projection, unit-pressure
sheet projection to measure corrected mobility, a bounded scalar ideal-fan root,
GPU impulse, final projection and actual returned flow/work checks. The scalar
root uses no external CFD and is not a CPU fluid solver. All spatial solves and
the actual impulse use the borrowed device; no CPU fallback.

Same bounded all-fluid closed box as projection. The sheet is an internal integer
X face and rectangular half-open Y/Z cell ranges. Only partial sheets are supported;
full-span zero-mobility sheets reject explicitly rather than taking the CPU
reference's analytic shortcut. P0>=0 Pa, Q0>0 m³/s, direction +/-1; only the forward
sub-free-flow branch. Constant density, explicit dt, no viscosity, thermal coupling,
velocity advection, obstacle, open boundary, scene authoring or combined timestep.

The ideal curve is dp=P0*(1-(Q/Q0)^2). Root iteration uses corrected mobility, but
acceptance rechecks actual final Q and actual operating pressure with relative
1e-3 tolerance, not a shutoff-pressure denominator. The conservative conditioning
check 8*Float32_eps*P0/dp <=1e-3 rejects ill-conditioned near-free-flow outputs.
Projection uses its strictest current 1e-5 relative tolerance and local actual-field
divergence gates. Initial reverse/free-flow cases and unresolved mobility reject.

The impulse normalizes upload independently, checks every returned face against
the actual uploaded increment, and rejects unresolved/non-normal physical values.
Actual provisional kinetic energy minus initialized energy must agree with
midpoint provisional mechanical work to 1e-4 relative; all terms/scales must be
finite and nonzero work normal. Final projection cannot increase provisional
energy beyond its existing 1e-4 allowance. Midpoint impulse work is NOT shaft
power or fluid heating; projection energy removal remains separate. This stage
makes no steady-flow, convection, closed-box fan heat or full CFD claim.

Every asynchronous boundary checks abort/device/caller validity. All inputs are
snapshotted before asynchronous work. Nested projection and impulse buffers are
released on success/failure; detached result arrays retain zero GPU bytes. Impulse
allocation <=12*4352+48=52,272 bytes. Overall sequential GPU peak is the maximum
of that and bounded pressure allocation; three pressure passes plus one complete
U readback remain explicit qualification costs, not production resident performance.
Real shared-device fixtures cover mirrored 2x3x2 sheets against independent V14
Float64 reference, 30s budget each. Host tests include existing recirculation,
zero fan, actual curve/work rejection and nested cleanup. Emulator evidence does
not establish WGSL/hardware correctness; hardware gates remain required.
For P0=0 the inactive fan returns the initialized GPU projection unchanged, with
zero additional work and null (not measured) mobility. No redundant impulse upload
or second projection is allowed to create fictitious work on an existing flow.

## V26: shared-face passive thermal advection GPU qualification

`temperature-advection-gpu.js` implements first-order explicit upwind transport on
constant-property, equal-volume all-fluid cells. One GPU invocation computes each
shared oriented face flux exactly once; a second kernel gathers that same flux
with opposite signs into the two adjacent cells. There are no unordered floating
atomics or separate per-cell face reconstructions. Kelvin updates use enthalpy
transfer divided by the constant cell heat capacity, which algebraically cancels;
physical energies and transferred enthalpies remain independently validated.

Contract: 2..16 cells per axis, explicit SI size/density/specific heat/timeStep,
Kelvin 1..2000, explicit closed or periodic condition on each axis. Periodic
seams appear once and duplicate MAC endpoint velocities must match exactly.
Closed normal velocities are zero. No solids, sources, conduction, variable
capacity, fan/flow evolution, scene operation or GPU timestep composition.

Input local divergence must be within 64 Float64 eps times the local absolute
Courant sum; uploaded face values also pass a local Float32 roundoff check.
Outgoing multidimensional CFL must be <=0.9 before AND after upload. No automatic
subcycling. This strict incompressibility contract does NOT imply compatibility
with the current approximate GPU projection output. An independently validated
flux-consistent composition contract is still required before combining stages.

Float32 Courant upload relative error <1e-6, nonzero uploaded Courant normal.
Physical capacity, each input/returned cell energy and each nonzero original/
returned face enthalpy transfer must be finite normal Float64. This explicitly
rejects the V17 subnormal-capacity regression. Actual returned face fluxes must
match upwind donor products; returned Kelvin is independently reconstructed from
both original SI inputs and actual GPU fluxes. Local error/extrema allowance is
32 Float32 eps * maximum input Kelvin. Total returned physical energy error is
bounded by 8 Float32 eps * (input energy + twice absolute transfer). These are
explicit Float32 rounding budgets, not exact energy conservation or a guarantee
of long-time transport accuracy. Zero flow preserves the uploaded Float32 scalar,
not necessarily bit-identical original Float64 Kelvin. Numerical mixing is not heat.

No CPU solve fallback. Shared-device synchronous error scopes, input snapshots,
abort/caller/device checks and unconditional buffer disposal. Complete bounded
face/scalar readback is deliberate qualification overhead; no resident field API.
Peak buffers <=104*N =425,984 bytes at all-periodic 16³; final readback 4*(N+E),
E<=3*N, <=65,536 bytes. Zero retained GPU bytes. Host plan budget 16³ <1500ms.
Real-device periodic/closed fixtures have 15s budgets, compare independent V17fix
reference, CFL/energy and cleanup. CPU tests also cover analytic Fourier transport,
subnormal rejection, normal tiny density, wrong returned data and lifecycle.
Command-emulator tests do not validate WGSL execution or actual hardware.

## V27: explicit local projection-to-transport error contract

Strict V26 behaviour remains the default. Transport now accepts an opt-in
`divergenceDriftBudgetK` in (0,0.001] K **per step**. It recomputes every physical
cell's dimensionless divergence D=dt*div(u) from the actual dimensional velocities,
and separately from the uploaded face Courant values. BOTH must meet |D|<=1e-6
and Tmax*|D|<=the requested budget. No global average, kinetic energy, remote
circulation or component maximum can relax a local limit. Too-tight budgets reject;
the implementation never silently enlarges them or reprojects on CPU.

For a uniform-capacity finite-volume cell, the conservative update differs from
its incompressible advective-form counterpart by exactly -T_i*D_i. This is artificial
local compression/dilation caused by projection error, NOT simulated compressible
physics. The bound Tmax*|D_i| controls that per-step effect. Returned Kelvin is now
also checked against the independently reconstructed advective counterpart with
only this local allowance plus the existing Float32 arithmetic allowance. Extrema
use the same explicit local addition. Face consistency and global physical thermal
energy budgets are unchanged; divergence does not earn additional energy leakage.
The returned per-cell drift bounds and maximum expose the compromise separately
from `maxTemperatureErrorAllowance` (Float32 rounding, potentially larger).

`project-temperature-gpu.js` qualifies only initial GPU projection followed by one
passive scalar step with a required positive explicit drift budget. It snapshots
inputs, uses the strictest bounded projection tolerance (1e-5), then validates
ACTUAL returned velocities through transport assembly. It does not trust projection's
single max diagnostic. No viscosity/fan/advection-of-momentum/solid/source/heat
conduction, native scene, resident composition or general CFD claim. Cancellation,
caller/device staleness and all nested allocation cleanup remain enforced. Memory
peak is the maximum of the two sequential stages; zero retained GPU bytes.

This is NOT an unconditional multistep accuracy guarantee. A future duration API
must propagate numerical error, including each step's drift, Float32 rounding and
transport amplification; a per-step 0.001K budget must never be advertised as a
0.001K total-time error. Physical transport remains first-order upwind and has its
own numerical diffusion independent of this divergence budget.

Adversarial CPU tests cover signed uniform-field drift, globally cancelling local
violations, remote exact circulation, and Float32-induced divergence despite
original cancellation. Command tests compare the composed velocity to independent
Float64 projection and temperature to a separately constructed conservative update;
over-tight budget/cancel/stale reject cleanly. A real shared-device 4x3x2 fixture
is wired with a 30s budget. CPU/emulator passing does not establish GPU execution.

## V28: one-step viscous/fan/passive scalar GPU qualification

`forced-temperature-gpu.js` composes existing shared-device stages without new
CPU spatial solvers. Input is `{flow,fan,temperature,specificHeat,
divergenceDriftBudgetK}`. Flow is explicit SI closed-box MAC input including dynamic
viscosity; fan is the partial local-X sheet/ideal curve. No solids/conduction/source
fields are accepted. The positive per-step divergence budget is mandatory.

Ordering: initial projection; backward-Euler no-slip velocity diffusion;
fan's initialization projection of that viscous field; fan mobility/root and GPU
impulse/final projection; passive scalar advection with the final returned velocity
and the same dt. Fan is last in the mechanical sequence, so its operating curve
is checked against the actual velocity used for thermal transport. Scalar assembly
recomputes every local divergence/CFL/physical-energy gate; no later projection can
silently alter the fan operating point. `fanPressureCorrection` is only the fan
stage's final correction, NOT total physical pressure of the whole split.

This is an initialized first-order split with linear viscous flow and ideal forcing,
not momentum-advection Navier-Stokes or a monolithic Stokes/thermal solve. Temperature
is one-way passive: no buoyancy/temperature-dependent properties, fan heating or
viscous heat conversion. Kinetic losses and midpoint fan work are mechanical
bookkeeping; thermal energy retains its separate conservative transport budget.
No steady/duration accuracy guarantee, no native scene/classifier, no resident GPU
composition or publication. All inherited 16³, viscosity coefficient, partial fan,
regime/conditioning and per-cell drift limits apply; unsupported cases reject.

Actual stage energies are combined with independently validated BE step/viscous
losses and midpoint fan work. Combined balance allowance is viscous residual-derived
allowance + 1e-4*abs(fan work) + Float64 summation allowance. Each projection may
increase energy only within the existing 1e-4 relative numerical allowance, which
remains visible as a signed loss. Thermal conservation allowance is not expanded.

All source arrays/settings are snapshotted before the first asynchronous stage.
Caller, shared-device and AbortSignal checks are forwarded through every nested
stage. A late thermal budget failure rejects the whole step without mutating inputs
or publishing partial fields; every owned GPU buffer has already been retired or
is destroyed on failure. Peak GPU allocation is the maximum of sequential stage
peaks; returned snapshots retain zero GPU buffers. Full bounded readbacks remain
qualification overhead, not a production performance claim.

CPU tests compare mirrored and existing-circulation cases with the independent
V18 Float64 flow/passive reference; uniform temperature demonstrates that mechanical
work is not treated as heating. Zero fan/zero flow, unsupported fields, late strict
budget failure, and cancel/stale inside viscosity, impulse and scalar pipelines are
covered. Real-device mirrored 2x3x2 fixtures have 45s each budgets. Command emulation
is NOT WGSL execution or actual GPU evidence; hardware gates remain mandatory.

## V29: existing GPU conduction + signed fluid source after advection

`fluid-heat-gpu.js` reuses assembleConduction/solveConductionGPU, not another heat
kernel. It accepts explicit constant fluid rho/cp/k, SI dimensions/size/dt,
positive Kelvin field and signed volumetric `source` in W/m³ (one or N values).
Only `boundary: 'adiabatic'` is supported (also the default). Dirichlet, periodic,
flux, solid/contact and steady inputs reject. Grid <=16³, Kelvin 1..2000,
dt*k/(rho*cp*h²)<=100; all physical capacity/energies and nonzero source powers/
energies must be normal and finite. Caller supplies no native Heater attribution.

The adapter explicitly converts Kelvin to Celsius for the existing kernel and
back for the actual returned field. Float32 initial conversion error must be <=1e-4K;
each nonzero signed source must survive the Float32 RHS subtraction to relative
1e-3. Existing GPU iteration tolerance is 1e-5 Celsius. After bounded 256-cell
inspection chunks, an independent host check evaluates the original physical BE
storage + shared conductive outflow - source on actual Kelvin, <=0.001K equivalent
local residual. Every source-cell additionally requires residual <=1e-3*abs(its
source power), not conductivity*T or incident heat-flow scale. This deliberately
rejects ill-conditioned small sources even beside large conductive exchanges.
Signed cancelling source pairs cannot earn a large local residual allowance.

Adiabatic energy must change by dt*sum(source*volume), exactly once. No-source
rounding allowance is 8 Float32 eps times stored/source energy scale. With a nonzero
net source it is additionally capped at 1e-3*abs(net source energy); exact cancelling
sources use 1e-3*sum(abs(cell source energy)). Net source underflow rejects. These
are acceptance gates, not a promise every valid physical case is Float32-resolvable.
Zero-source diffusion also checks extrema. Finite positive returned cell energies
are checked independently of aggregate totals.

`forced-heat-gpu.js` performs V28 flow/passive advection first, then one backward
Euler heat/source substep with the same dt. Thermal balance is final-initial-source
with only the sum of advection and conduction budgets; source is never inserted
into advection or mechanical energy. Mechanical work/losses remain separate and do
not become heat. Velocity/fan operating flow is untouched by the heat stage. No
solids, general convection, temperature feedback, native scene or duration claim.

Both helpers preflight and snapshot heat/source configuration before async work,
then revalidate the actual advected field. Shared device/check/AbortSignal handling
surrounds every solve/inspection; retained conduction buffer is disposed on success,
late validation failure, cancellation or staleness. Full bounded readback remains
qualification overhead, zero retained GPU bytes. Peak is the sequential max of
existing stage peaks, including bounded inspection staging.

CPU/emulation tests use independent dense fluid heat and V18 split references:
uniform signed heating/cooling, nonuniform diffusion, cancelling sources, erased
source pair beside large conductive exchange, source once across the combined
step, unsupported boundaries/range, and heat-stage lifecycle. Real-device signed
2x3x2 fixtures have 45s budgets. Existing kernel emulation is not actual WGSL/GPU
execution; hardware gates remain mandatory.

## V30: flat perfect-contact fluid/solid GPU qualification

`conjugate-heat-gpu.js` composes the existing fluid flow/passive transport path with
V22 layered heat assembly and the existing GPU conduction solver. Explicit full
grid <=16³; left fluid chamber has f>=2 X cells, right solid slab >=1. Y/Z >=2.
The interface is flat, cell-aligned and perfect contact. Fluid rho/cp/k/viscosity
and solid rho/cp/k are constant within each region. All sizes are explicit metres;
this is not a scene geometry classifier or Material/Heater provenance bridge.

Full-domain MAC inputs must have EXACT zero normal velocity on the interface and
zero velocities inside the solid. The extracted fluid box uses local dimensions
[f,ny,nz] and corresponding physical width. Its interface is a no-slip closed wall
for the existing fluid viscosity/projection/fan stages. Fan sheet coordinates are
fluid-local and must remain partial/internal. Only fluid temperatures are advected;
solid temperatures are copied unchanged into the subsequent shared heat solve.
Returned fluid velocities are embedded into zeroed full-domain arrays and the
interface is rechecked. No flow through/within solid is manufactured.

Thermal stage uses reciprocal harmonic shared conductance
G=A/(h/(2*kFluid)+h/(2*kSolid)), distinct cell capacities, adiabatic outer walls and
solid-only signed source density (one or solid-cell-count values, X-fast within
the right slab). Source is absent from fluid advection and applied once in the
shared BE solve. Non-adiabatic boundaries, arbitrary obstacles/interfaces, contact
resistance, radiation, buoyancy/property feedback, native scene or full CFD claims
remain unsupported. Mechanical work/losses are not converted to heat.

Actual returned Kelvin is checked against original per-cell BE equations (<=.001K
equivalent residual), and each nonzero solid-source cell must resolve residual
relative to its own source power (1e-3). Normal cell/source energies, global
source-relative energy limits and source-free extrema remain enforced. Interface
power is computed once from actual adjacent temperatures/shared conductance and
reported with opposite regional signs. Fluid/solid energy changes independently
balance that exchange and the solid source, with allowances derived from the
per-cell residual bound plus Float64 summation. Combined initial-to-final energy
subtracts the solid source only once and combines fluid-advection/shared-heat budgets.

Inputs/materials/sources/fan settings are copied before asynchronous work. Nested
caller/device/abort checks and retained conduction buffer cleanup cover every exit;
no partial field is published. Full bounded snapshots/readbacks remain qualification
overhead, zero retained GPU buffers. No duration accuracy or hardware claim.

Independent V21 Float64 fan/conjugate reference checks signed heaters and returned
Kelvin. Tests cover harmonic contact, heater volume coverage, uniform equilibrium,
solid/interface velocity rejection, source once, regional exchange balances and
heat-stage cancellation/staleness/corrupted readback cleanup. Actual shared-device
4x3x2 signed-heater fixtures are wired with 45s budgets. Command emulation is not
WGSL execution or hardware evidence.

## V31: bounded native geometry/Material/Heater to conjugate step

The translation path now exists internally in `scene-conjugate.js`: independently
captured complete cuboids → exact X-interface classification → existing SI/tag
mapping → explicit fluid role and densities → local-X fan-box sheet → existing
conjugate GPU step → guarded runtime-only Celsius/velocity/Probe handle. No general
native Solve, catalogue entry, automatic fluid inference or CPU solver is added.

This resolves the narrow two-material geometry/source translation gap, not the
remaining native authoring contract. Fluid density/viscosity, solid density and fan
box are explicit internal request inputs, not invented tag defaults. Input starts
at rest for one step. Full-field host snapshots remain bounded qualification
overhead, not the final resident GPU flow design. A fan box selects a centre sheet
and has no fan-housing/solid-displacement model. Thermal helper extent is still not
the computational domain. Sections, interactive Fan object authoring, native
solver job ownership, time stepping and arbitrary geometry remain separate work.

New CPU coverage includes signed native watts, actual classified source volume,
physical frame conversion, explicit role/order, fan axis/coverage, independent
reference result, native Probe, async caller mutation, stale/cancel retirement,
copy isolation and a 4096-cell classification/mapping/preflight budget. Native
browser fixture authors meshes/tags/Probe through frameAI in a separate context
and invokes the real plugin bridge and actual GPU path, with signed reference
comparisons, frame timings, device identity, source hashes and error checks.
Hardware success is a mandatory gate before enabling a public scene operation.


## Native owner job milestone (isolated candidate)

`plugin.js` now owns the existing `scene-conjugate-duration.js` handle through an
explicit `solve-scene` request and the same one-job map as `solve-grid`. This is
native lifetime integration only: the 100 mm helper remains non-authoritative,
there is no native Fan or saved grid/duration, no Solve button, no section overlay
and no public catalogue entry. The exact two-buffer-cuboid, adiabatic finite
transient, left-fluid/right-solid, grid-aligned partial local-X sheet contract is
unchanged. General shapes/roles/boundaries reject; no steady cooling or CPU
fallback is claimed. Material/Heater values still come from native tags.

The request schema and cross-field preflight precede synchronous interruption.
One per-owner promise tail survives deletion/restore and drains before replacement
allocates. Active and retiring work is tracked separately from published results.
Generic plugin flush is intentionally nonblocking so frameAI can return running
jobs and status/selection remain responsive. Explicit author/output/render
barriers wait for active and retiring work; simulation flush never advances heat.
Queued Stop/Clear handles both the interrupted predecessor and the job immediately
preceding the queued handler. Only complete current duration state can publish.
Scalar source/exact transform stamps avoid retaining captured GPU buffers.

Native Attributes expose the existing Probe plus one persistent Clear action,
which the core changes to Stop while busy. Clear is disabled when idle and refreshes
Probe labels immediately; no custom panel or transient-request Solve action exists.
Probe dispatches to the exact owned scene handle for physical/contact sampling,
or to the original explicit-grid sampler for that job kind.

New CPU native-job.mjs coverage is command emulation/lifecycle only. The separate
native-job-browser.mjs harness uses actual frameAI/native controls and all real GPU
stages, with isolated asynchronous test gates, independent ten-step Float64 field
checks, source/final-race cancellation, repeat requests, Undo/HASH and owned-buffer
accounting. It is also included by the full Thermal browser suite. Hardware
execution of this changed native controller remains a new gate, regardless of
prior duration-module qualification. Full npm test/stress, native domain/Fan
ownership, sections and the remaining physical/performance requirements still
block public registration and live publication.
