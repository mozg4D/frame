import {snapshotExteriorFilm,plainData} from './exterior-film.js';
// Internal one-step scene qualification. Reuses exact geometry, native tag
// mapping and the real GPU solver; never registers a public Solve operation.
import {classifyTouchingSceneBoxes} from './touching-classifier.js';
import {sceneGridInputs} from './scene-grid.js';
import {sceneIdentityMatches,sharedThermalDeviceState} from './scene-identity.js';
import {assembleConjugateHeatGPU,stepConjugateHeatGPU} from './conjugate-heat-gpu.js';
import {assembleMACViscosity} from './mac-viscosity-gpu.js';
import {assembleMACFan} from './mac-fan-gpu.js';
import {sampleProbe} from './probe.js';
const error=(code,message)=>Object.assign(new Error(message),{code});
const need=(ok,code,message)=>{if(!ok)throw error(code,message);};
const I=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
const array=a=>Array.isArray(a)||a instanceof Float32Array||a instanceof Float64Array;
const vector=a=>Array.isArray(a)&&a.length===3&&Array.from(a).every(Number.isFinite);
const keys=['thermalBoundary','fluidOccurrence','fluidDensity','fluidViscosity','solidDensity','initialCelsius','timeStep','fanBox','divergenceDriftBudgetK'];

// Requires a trusted exact two-cuboid classification, not a bounds substitute.
export function sceneConjugateInputs(source,classification,ownerWorld,settings){
 need(settings&&typeof settings==='object'&&!Array.isArray(settings)&&!Object.keys(settings).some(k=>!keys.includes(k)),'INVALID_ARGUMENT','Explicit fluid role, physical properties and local-X fan box required.');
 settings=plainData(settings,keys);const thermalBoundary=settings.thermalBoundary===undefined?'adiabatic':snapshotExteriorFilm(settings.thermalBoundary);
 const {fluidOccurrence,fluidDensity,fluidViscosity,solidDensity,initialCelsius,timeStep,fanBox,divergenceDriftBudgetK}=settings;
 need([fluidDensity,fluidViscosity,solidDensity,timeStep].every(x=>Number.isFinite(x)&&x>0)&&Number.isFinite(divergenceDriftBudgetK)&&divergenceDriftBudgetK>0&&divergenceDriftBudgetK<=.001,'INVALID_ARGUMENT','Positive SI properties/time step and divergence budget <=0.001 K required.');
 const d=classification?.dimensions,contact=classification?.diagnostics?.contact;
 need(source?.meshes?.length===2&&Array.isArray(d)&&d.length===3&&Array.from(d).every(x=>Number.isInteger(x)&&x>=2&&x<=16)&&classification.diagnostics.classification==='two-touching-cuboids'&&classification.diagnostics.outside===0&&classification.diagnostics.partial===0&&contact?.model==='perfect-thermal-contact'&&contact.axis===0,'UNSUPPORTED_DOMAIN','Exact full-domain cuboids with a local-X perfect-contact interface are required.');
 const f=contact.lowerCell+1;
 need(Number.isInteger(f)&&f>=2&&f<d[0]&&[0,1].includes(contact.leftOccurrence)&&[0,1].includes(contact.rightOccurrence)&&contact.leftOccurrence!==contact.rightOccurrence&&fluidOccurrence===contact.leftOccurrence,'UNSUPPORTED_DOMAIN','The explicitly selected fluid must be the left chamber with at least two X cells.');
 need(Array.isArray(classification.completeOccurrences)&&classification.completeOccurrences.length===2&&classification.completeOccurrences.includes(0)&&classification.completeOccurrences.includes(1),'UNSUPPORTED_DOMAIN','Both full occurrences must be classified.');
 need(classification.occurrences instanceof Int32Array&&classification.occurrences.length===d.reduce((a,b)=>a*b)&&classification.occurrences.every((o,i)=>o===(i%d[0]<f?contact.leftOccurrence:contact.rightOccurrence)),'UNSUPPORTED_DOMAIN','Every cell must match the classified fluid/solid slab.');
 need(!source.meshes[fluidOccurrence].tags?.some(t=>t.kind==='thermal_heater'),'UNSUPPORTED_SOURCE','Heater must belong only to the complete solid, not the fluid or a shared ancestor.');
 const mapped=sceneGridInputs(source,classification,ownerWorld),n=mapped.grid.source.length;
 need(array(initialCelsius)&&[1,n].includes(initialCelsius.length)&&Array.from(initialCelsius).every(Number.isFinite),'INVALID_ARGUMENT','Initial Celsius must contain one value or one value per classified cell.');
 const temperature=Float64Array.from({length:n},(_,i)=>initialCelsius[initialCelsius.length===1?0:i]+273.15);
 need(fanBox&&typeof fanBox==='object'&&!Array.isArray(fanBox)&&!Object.keys(fanBox).some(k=>!['centerMM','sizeMM','shutoffPressure','freeFlow','direction'].includes(k))&&vector(fanBox.centerMM)&&vector(fanBox.sizeMM)&&fanBox.sizeMM.every(x=>x>0),'INVALID_ARGUMENT','Fan box must have finite owner-local millimetre center and positive size.');
 const h=classification.cellSizeMM,extent=d.map((x,a)=>x*h[a]),lo=fanBox.centerMM.map((x,a)=>x-fanBox.sizeMM[a]/2),hi=fanBox.centerMM.map((x,a)=>x+fanBox.sizeMM[a]/2);
 need(lo.every((x,a)=>Number.isFinite(x)&&x>=-extent[a]/2)&&hi.every((x,a)=>Number.isFinite(x)&&x<=-extent[a]/2+(a===0?f:d[a])*h[a]),'UNSUPPORTED_FAN','The entire fan box must lie inside the fluid chamber.');
 // One thin actuator sheet at the box centre, normal to owner-local X.
 // No tolerance/snap: partially covered cells or an off-grid sheet reject.
 const sheet={x:(fanBox.centerMM[0]+extent[0]/2)/h[0],y:[(lo[1]+extent[1]/2)/h[1],(hi[1]+extent[1]/2)/h[1]],z:[(lo[2]+extent[2]/2)/h[2],(hi[2]+extent[2]/2)/h[2]]};
 const material=(occurrence,density)=>{
  const m=source.meshes[occurrence].tags.find(t=>t.kind==='thermal_material').params,specificHeat=m['Heat capacity']/density;
  need(Number.isFinite(specificHeat)&&specificHeat>0&&Math.abs(density*specificHeat/m['Heat capacity']-1)<1e-12,'NUMERICAL_RANGE','Native volumetric heat capacity cannot be represented by the explicit density.');
  return {density,specificHeat,conductivity:m.Conductivity};
 };
 const solidSourceDensity=new Float64Array((d[0]-f)*d[1]*d[2]);
 for(let i=0;i<n;i++)if(i%d[0]>=f)solidSourceDensity[i%d[0]-f+(d[0]-f)*Math.floor(i/d[0])]=mapped.grid.source[i];
 const input={dimensions:[...d],size:d.map((x,a)=>x*mapped.grid.cellSize[a]),fluidCellsX:f,fluid:{...material(fluidOccurrence,fluidDensity),viscosity:fluidViscosity},solid:material(contact.rightOccurrence,solidDensity),temperature,solidSourceDensity,timeStep,fan:{sheet,shutoffPressure:fanBox.shutoffPressure,freeFlow:fanBox.freeFlow,direction:fanBox.direction},divergenceDriftBudgetK,boundary:thermalBoundary};
 for(let a=0;a<3;a++)input[['u','v','w'][a]]=new Float64Array(d.reduce((s,x,k)=>s*(x+Number(a===k)),1));
 // Validate all GPU-stage contracts before any solver allocation. No solver
 // substitution is permitted here; these are host assembly/range checks only.
 const plan=assembleConjugateHeatGPU(input);assembleMACViscosity(plan.step.flow);
 const {viscosity,...flow}=plan.step.flow;assembleMACFan({...flow,...input.fan});
 return {input,fieldFrame:mapped.fieldFrame,cellSize:[...mapped.grid.cellSize],heaters:mapped.heaters,contact:Object.freeze({kind:'perfect-thermal-contact',axis:0,lowerCell:f-1,conductivityLeft:input.fluid.conductivity,conductivityRight:input.solid.conductivity}),boundary:thermalBoundary,fan:{axis:'owner-local-X',sheet,centerMM:[...fanBox.centerMM],sizeMM:[...fanBox.sizeMM]},scope:'two-cuboid-conjugate-from-rest',sceneSolver:false};
}

// Classifier/timestep injection is test-only; production always uses the actual
// shared-device algorithms. current/mapInputs are trusted internal adapter hooks,
// never caller request keys. They preserve the same pipeline and handle lifecycle.
export function createSceneConjugatePipeline({classify=classifyTouchingSceneBoxes,stepGPU=stepConjugateHeatGPU,current=null,mapInputs=null,scope='two-cuboid-conjugate-from-rest'}={}){
 return async function stepScene(context,hash,request={}){
  need(request&&typeof request==='object'&&!Array.isArray(request)&&!Object.keys(request).some(k=>!['dimensions','cellSizeMM','settings','signal'].includes(k)),'INVALID_ARGUMENT','Explicit one-step scene request required.');
  request=plainData(request,['dimensions','cellSizeMM','settings','signal']);
  const {signal}=request;need(!signal||(typeof signal.addEventListener==='function'&&typeof signal.removeEventListener==='function'),'INVALID_ARGUMENT','Invalid cancellation signal.');
  const settingCopy=plainData(request.settings,keys);if(settingCopy.thermalBoundary!==undefined)settingCopy.thermalBoundary=snapshotExteriorFilm(settingCopy.thermalBoundary);
  const args=structuredClone({dimensions:request.dimensions,cellSizeMM:request.cellSizeMM,settings:settingCopy}),D=context.document,device=context.device,start=performance.now();
  // structuredClone preserves SharedArrayBuffer backing stores. Snapshot the
  // accepted typed temperature input explicitly before geometry can await.
  if(array(args.settings?.initialCelsius))args.settings.initialCelsius=Array.from(args.settings.initialCelsius);
  const owner=()=>D.nodes.find(n=>n.nativeHash===hash&&n.type==='thermal'),node=owner();
  need(node&&node.enabled!==false,'INVALID_OWNER','An enabled Thermal owner is required.');
  current?.();
  const stamp=n=>JSON.stringify([n.type,n.params,n.enabled,Array.from(D.world(n.nativeHash))]),ownerStamp=current?null:stamp(node);
  const deviceState=sharedThermalDeviceState(device);
  let source=null,result=null,retired=false;
  const dispose=()=>{retired=true;result=null;signal?.removeEventListener('abort',dispose);};
  const check=()=>{try{
   need(!signal?.aborted,'CANCELLED','Scene conjugate step cancelled.');need(!retired,'RETIRED_RESULT','Scene conjugate field retired.');need(!deviceState.lost,'DEVICE_LOST','Shared device lost.');
   need(context.device===device&&owner()===node&&(current||stamp(node)===ownerStamp),'STALE_JOB','Thermal owner or shared device changed.');
   if(current)current();else need(!source||sceneIdentityMatches(context,hash,source.signature,source.transformStamp),'STALE_JOB','Scene geometry or Thermal tags changed.');
  }catch(e){dispose();throw e;}};
  signal?.addEventListener('abort',dispose,{once:true});
  try{
   check();const classified=await classify(context,hash,{dimensions:args.dimensions,cellSizeMM:args.cellSizeMM,signal,...(current?{check:current}:{})});source=classified.source;check();
   const settings={...args.settings};if(settings.initialCelsius===undefined)settings.initialCelsius=[node.params.Initial];
   const mapped=mapInputs?mapInputs(source,classified.classification):sceneConjugateInputs(source,classified.classification,classified.classification.ownerWorld,settings);check();
   const count=mapped.input.temperature.length,dimensions=[...mapped.input.dimensions],fullLengths=['u','v','w'].map(k=>mapped.input[k].length);
   const pending=stepGPU(context,mapped.input,{signal,check});delete mapped.input;
   result=await pending;check();
   need(result?.temperatureUnit==='K'&&result.temperature instanceof Float64Array&&result.temperature.length===count&&result.temperature.every(x=>Number.isFinite(x)&&x>=1&&x<=2000),'INVALID_RESULT','Expected a complete validated Kelvin GPU field.');
   for(let a=0;a<3;a++)need(result[['u','v','w'][a]] instanceof Float64Array&&result[['u','v','w'][a]].length===fullLengths[a]&&result[['u','v','w'][a]].every(Number.isFinite),'INVALID_RESULT','Expected complete finite MAC velocity fields.');
   const totalWallMs=performance.now()-start,validateRead=(offset,n,length)=>need(Number.isInteger(offset)&&offset>=0&&Number.isInteger(n)&&n>=1&&n<=256&&offset+n<=length,'INVALID_ARGUMENT','Inspect at most 256 existing field values.');
   const inspect=async(offset=0,n=1)=>{check();validateRead(offset,n,count);return {offset,temperatures:Array.from(result.temperature.slice(offset,offset+n),x=>x-273.15),temperatureUnit:'°C'};};
   const sampleField={dimensions,cellSize:mapped.cellSize,fieldFrame:mapped.fieldFrame,contact:mapped.contact,inspect};
   return Object.freeze({scope,generalSceneSolver:false,temperatureUnit:'°C',initialVelocity:'rest',boundary:mapped.boundary??'adiabatic',dimensions:Object.freeze(dimensions),cellSize:Object.freeze(mapped.cellSize),fieldFrame:mapped.fieldFrame,contact:mapped.contact,
    get metrics(){check();return structuredClone({...result.metrics,totalWallMs,retainedHostFieldBytes:result.temperature.byteLength+result.u.byteLength+result.v.byteLength+result.w.byteLength,classification:classified.metrics});},
    get diagnostics(){check();return structuredClone({...(result.duration?{duration:result.duration}:{}),thermal:result.thermal,mechanical:result.mechanical,pressureRise:result.pressureRise,correctedFlow:result.correctedFlow,heaters:mapped.heaters,fan:mapped.fan});},
    inspect,dispose,
    async inspectVelocity(component,offset=0,n=1){check();need(['u','v','w'].includes(component),'INVALID_ARGUMENT','Expected u, v or w.');validateRead(offset,n,result[component].length);return {component,offset,values:Array.from(result[component].slice(offset,offset+n)),unit:'m/s',frame:'owner-orthonormal-axes',layout:'MAC-faces'};},
    async measureProbe(probeHash){
     check();const probe=D.nodes.find(n=>n.nativeHash===probeHash&&n.type==='thermal_probe');
     need(probe&&probe.enabled!==false&&probe.params.Thermal===hash,'INVALID_PROBE','Enabled Probe must reference this Thermal owner.');
     const probeStamp=stamp(probe),world=Array.from(D.world(probeHash)),probeCheck=()=>{check();need(D.nodes.includes(probe)&&stamp(probe)===probeStamp,'STALE_PROBE','Probe changed during sampling.');};
     return sampleProbe(sampleField,I,world.slice(12,15),probeCheck,mapped.fieldFrame.ownerWorld);
    }
   });
  }catch(e){dispose();throw e;}
 };
}
export const stepTouchingSceneConjugateGPU=createSceneConjugatePipeline();
