import {sharedThermalDeviceState} from './scene-identity.js';
// Internal production-path adapter. Explicit SI layered heat only, no scene Solve.
import {snapshotExteriorFilm,validateFilmHeat,plainData,boundaryDataProperty} from './exterior-film.js';
import {assembleConduction,solveConductionGPU} from './plugin.js';
const fail=(code,message)=>Object.assign(new Error(message),{code});
export function assembleLayeredHeatGPU(input){
 const keys=['dimensions','size','fluidCellsX','fluid','solid','temperature','solidSourceDensity','timeStep','boundary','tolerance','maxIterations'];
 if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!keys.includes(k)))throw fail('INVALID_ARGUMENT','Explicit layered heat input required.');
 boundaryDataProperty(input,'boundary');
 const {dimensions,size,fluidCellsX:f,fluid,solid,temperature,solidSourceDensity=[0],timeStep,boundary={}}=input;
 if(!Array.isArray(dimensions)||dimensions.length!==3||Array.from(dimensions).some(x=>!Number.isInteger(x)||x<2||x>128)||
 !Array.isArray(size)||size.length!==3||Array.from(size).some(x=>!Number.isFinite(x)||x<=0)||!Number.isInteger(f)||f<2||f>=dimensions[0]||!Number.isFinite(timeStep)||timeStep<=0)throw fail('INVALID_ARGUMENT','Finite SI grid, split and transient timeStep required.');
 const [nx,ny,nz]=dimensions,count=nx*ny*nz;if(count>32768)throw fail('GRID_LIMIT','Initial layered GPU adapter supports at most 32768 cells.');
 const copyArray=a=>Array.isArray(a)||a instanceof Float32Array||a instanceof Float64Array?Array.from(a):null;
 const kelvin=copyArray(temperature),sources=copyArray(solidSourceDensity);
 const validKelvin=x=>Number.isFinite(x)&&x>=1&&x<=2000&&Math.abs(Math.fround(x-273.15)+273.15-x)<=1e-4;
 if(!kelvin||kelvin.length!==count||kelvin.some(x=>!validKelvin(x))||!sources||![1,(nx-f)*ny*nz].includes(sources.length)||sources.some(x=>!Number.isFinite(x)))throw fail('INVALID_ARGUMENT','Dense Kelvin field (1..2000K) and solid-only finite W/m³ source required.');
 for(const m of [fluid,solid])if(!m||typeof m!=='object'||Array.isArray(m)||Object.keys(m).some(k=>!['density','specificHeat','conductivity'].includes(k))||['density','specificHeat','conductivity'].some(k=>!Number.isFinite(m[k])||m[k]<=0))throw fail('INVALID_ARGUMENT','Positive constant material properties required.');
 const boundaryData=plainData(boundary,['xMin','xMax','kind','faces']);
 const film=Object.hasOwn(boundaryData,'kind')||Object.hasOwn(boundaryData,'faces')?snapshotExteriorFilm(boundaryData):null;
 if(!film&&(!boundary||typeof boundary!=='object'||Array.isArray(boundary)||Object.keys(boundary).some(k=>!['xMin','xMax'].includes(k))||Object.values(boundary).some(x=>!validKelvin(x))))throw fail('INVALID_ARGUMENT','Only x-end Kelvin Dirichlet boundaries supported.');
 const k=new Array(count),cv=new Array(count),source=new Array(count).fill(0),cellSize=size.map((x,i)=>x/dimensions[i]),volume=cellSize.reduce((a,b)=>a*b);
 const normal=x=>Number.isFinite(x)&&Math.abs(x)>=2**-1022;
 for(let i=0;i<count;i++){
  const x=i%nx,m=x<f?fluid:solid;k[i]=m.conductivity;cv[i]=m.density*m.specificHeat;
  if(!normal(cv[i])||!normal(cv[i]*volume)||!normal(cv[i]*volume*kelvin[i])||!normal(cv[i]*volume/timeStep))throw fail('NUMERICAL_RANGE','Layered physical cell energy is unrepresentable.');
  if(x>=f){const si=(x-f)+(nx-f)*Math.floor(i/nx);source[i]=sources[sources.length===1?0:si];const delta=timeStep*source[i]/cv[i];
   if(!Number.isFinite(delta)||(source[i]!==0&&(!normal(delta)||!normal(source[i]*volume)))||kelvin[i]+delta<1||kelvin[i]+delta>2000)throw fail('NUMERICAL_RANGE','Solid source increment is unrepresentable or leaves the supported Kelvin range.');
  }
 }
 const grid=assembleConduction({dimensions:[...dimensions],cellSize,conductivity:k,heatCapacity:cv,source,initial:kelvin.map(x=>x-273.15),boundary:film?{}:Object.fromEntries(Object.entries(boundary).map(([k,v])=>[k,v-273.15])),...(film?{boundaryFlux:{},boundaryRobin:Object.fromEntries(Object.entries(film.faces).map(([face,v])=>[face,{hWPerM2K:v.hWPerM2K,ambientCelsius:v.ambientKelvin-273.15}]))}:{}),timeStep,...input.tolerance===undefined?{}:{tolerance:input.tolerance},...input.maxIterations===undefined?{}:{maxIterations:input.maxIterations}});
 // Do not silently erase a heater in the Float32 RHS upload. Relative accuracy
 // here is an assembly gate, NOT a promise about converged GPU source balance.
 for(let i=0;i<count;i++)if(source[i]!==0){const power=source[i]*volume,rhs=grid.coefficients[i*8+7],represented=Math.fround(rhs)-Math.fround(rhs-power);
  if(!Number.isFinite(represented)||Math.abs(represented/power-1)>1e-3)throw fail('NUMERICAL_RANGE','Solid heater is not resolved by the Float32 RHS.');
 }
 if(film){grid.thermalBoundary=film;grid.exteriorFilm=Object.freeze(grid.exteriorFilm.map(e=>Object.freeze({...e,ambientKelvin:film.faces[e.face].ambientKelvin})));grid.filmInitialKelvin=Float64Array.from(kelvin);grid.filmCapacities=Float64Array.from(cv,x=>x*volume);grid.filmSourcePower=Float64Array.from(source,x=>x*volume);}
 return grid;
}
export async function solveLayeredHeatGPU(context,input,{signal,check=()=>{}}={}){
 if(typeof check!=='function'||(signal&&(typeof signal.addEventListener!=='function'||typeof signal.removeEventListener!=='function')))throw fail('INVALID_ARGUMENT','Invalid lifecycle guards.');
 const device=context?.device,deviceState=sharedThermalDeviceState(device);let field=null,retired=false,abort;
 const retire=()=>{retired=true;field?.dispose();field=null;if(signal&&abort)signal.removeEventListener('abort',abort);};
 const guard=()=>{if(signal?.aborted)throw fail('CANCELLED','Layered heat cancelled.');if(retired)throw fail('RETIRED_RESULT','Layered heat retired.');if(deviceState.lost)throw fail('DEVICE_LOST','Shared GPU device was lost.');if(context?.device!==device)throw fail('STALE_JOB','Shared GPU device changed.');check();};
 try{
  guard();const grid=assembleLayeredHeatGPU(input);
  abort=()=>retire();signal?.addEventListener('abort',abort,{once:true});guard();
  field=await solveConductionGPU(device,grid,{check:guard});guard();
  let filmDiagnostics=null;
  if(grid.exteriorFilm?.some(e=>e.g>0)){const actual=new Float64Array(grid.count);for(let o=0;o<grid.count;o+=256){const r=await field.inspect(o,Math.min(256,grid.count-o));guard();actual.set(r.temperatures.map(t=>t+273.15),o);}const {residualBounds,cellPower,cellAbsolutePower,...checks}=validateFilmHeat(grid,grid.filmInitialKelvin,actual,grid.filmCapacities,grid.filmSourcePower);filmDiagnostics=checks;}
  const metrics=()=>({...field.metrics,minTemperature:field.metrics.minTemperature+273.15,maxTemperature:field.metrics.maxTemperature+273.15});
  if(!Number.isFinite(metrics().minTemperature)||metrics().minTemperature<1||metrics().maxTemperature>2000)throw fail('NONPHYSICAL_TEMPERATURE','GPU field is not positive Kelvin.');
  const fieldCount=grid.count;
  const assertCurrent=()=>{try{guard();}catch(e){retire();throw e;}};
  return Object.freeze({scope:'explicit-layered-conduction-gpu',sceneSolver:false,temperatureUnit:'K',dimensions:Object.freeze([...grid.dimensions]),
   get metrics(){assertCurrent();return {...metrics(),...(filmDiagnostics?{exteriorFilm:structuredClone(filmDiagnostics)}:{})};},
   async inspect(offset=0,count=1){assertCurrent();if(!Number.isInteger(offset)||offset<0||!Number.isInteger(count)||count<1||count>256||offset+count>fieldCount)throw fail('INVALID_ARGUMENT','Inspect at most 256 existing cells.');
    try{const r=await field.inspect(offset,count);assertCurrent();const temperatures=r.temperatures.map(x=>x+273.15);if(temperatures.some(x=>!Number.isFinite(x)||x<=0))throw fail('NONPHYSICAL_TEMPERATURE','Invalid Kelvin GPU sample.');return {offset,temperatures,temperatureUnit:'K'};}catch(e){retire();throw e;}
   },dispose:retire});
 }catch(e){retire();throw e;}
}
