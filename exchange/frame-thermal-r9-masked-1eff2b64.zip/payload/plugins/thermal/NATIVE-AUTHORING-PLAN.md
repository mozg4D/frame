# Historical proposals and current scope

The proposals below are not permission to add UI or native parameters. The isolated
`solve-domain` milestone now binds only the existing box/native frames and explicit
canonical fluid hash to the existing saved-Fan job. Grid, role references and
numerics remain API inputs. Its current contract is in NATIVE-DOMAIN-JOB.md.
Saved-Fan coupling was already added in NATIVE-SAVED-FAN-JOB.md. Native Solve,
persisted settings, boundary physics and the broader qualifications below remain
separate work; older statements below describe proposal-stage status.

# Next native authoring contract

The separate Fan authoring subset is now implemented in this isolated candidate;
see README.md, `native-fan.js`, and CORE-AUTHORING-BLOCKERS.md. Native domain/grid/
duration and saved-Fan solver coupling below remain proposals. Fan authoring is
not a completed native Solve release, and its required core reference copy/drop
and actual browser checks remain blocked/unverified.

The existing 100 mm helper and ordinary Frame transforms can express an
authoritative Thermal domain and a distinct Fan box without a new viewport API.
Static helper geometry is not a blocker. The remaining work is to bind those
native records to a narrow, validated physical contract and qualify it.

## Thermal domain and settings

- Make the Thermal owner's local `[-50,50]³` helper its actual domain. Its native
  world frame determines the physical pose and side lengths. Convert owner-local
  millimetres through the existing physical-frame mapping exactly once. Reject
  sheared, singular and projective frames; use existing orthogonal scale,
  rotation, reflection and translation support without changing world units.
- Author grid counts X/Y/Z as native integer parameters (2..16, at most 4096
  cells). Derive each local cell size as `100 / count` mm. Never retain both
  independently editable counts and cell sizes that can disagree with the box.
- Author positive Time step in seconds and integer Steps 1..10. Derived total
  time is their exact product, at most 0.1 s. Do not store a second editable
  Duration value. Initial remains the existing Celsius parameter and every Solve
  starts from Initial/rest. Ambient does not turn adiabatic walls into cooling.
- Add an explicit Fluid object reference to one canonical native buffer mesh.
  Resolve it to exactly one captured occurrence identity. Zero matches, multiple
  instances/occurrences, a group-only ambiguous reference, a solid reference or
  a reference outside the left chamber must reject. Do not infer the fluid from
  capture order, Material name, conductivity or creation order.
- Keep conductivity and volumetric heat capacity authoritative in the existing
  Material tags (W/(m K), J/(m³ K)); Heater remains signed total W on the complete
  solid only. The existing split also needs authored positive Fluid density
  (kg/m³), Fluid viscosity (Pa s) and Solid density (kg/m³). Generic initial
  defaults must not be described as air or another real substance. A future
  preset is separate work, not an invented role/property inference.
- The native controller must choose and document its cumulative local divergence
  acceptance budget, retaining the present <=0.001 K bound and tightening each
  step to budget/Steps. It is an acceptance limit, not temperature accuracy.
  Numerical expert settings need not become another panel.

Only the classified left-fluid/right-solid, complete full-face two-cuboid domain
is admissible. Procedural Cube/evaluated/paged inputs remain unsupported until
their actual source contract is separately qualified. Bounds never substitute
for geometry, and native transforms cannot silently snap contact or occupancy.

## Separate native Fan

The implemented authoring subset reports only frame metadata. Its exact mapping
currently requires a direct native child and verifies local/world composition,
which avoids inverse roundoff under common owner rotation and rejects evaluated
constraints. Other parent/reference arrangements remain editable but unsupported
for mapping. No saved Fan is passed to a solver yet. The broader qualifications
below still apply before that coupling is implemented.

- Declare a distinct `thermal_fan` native type and create it as a Thermal child
  through an ordinary document transaction. Store an explicit Thermal reference
  in its parameters; hierarchy alone must not silently reassign ownership.
- Reuse the 100 mm helper with native transforms for its box. Initial scope can
  require the exact owner-relative matrix to be positive diagonal scale plus
  translation, with zero off-diagonal terms. This gives an exact fan-local X
  axis coincident with owner-local X. Reject rotated, sheared, singular or
  uncertain relative frames; do not accept rounded near-axis alignment. Broader
  rotations would be a later geometry/force contract, not a tolerance tweak.
- Derive owner-local `centerMM` from the relative translation and `sizeMM` from
  100 mm times its diagonal scales. These values, not a second saved fan-box
  array, feed the existing sheet mapper. Require the entire box inside fluid,
  centre X plane and Y/Z footprint exactly on grid faces, and a partial internal
  sheet. Reject unsupported geometry rather than snap it.
- Author Shutoff pressure (Pa), Free flow (m³/s) and a forward/reverse choice
  along the fan's exact local X. These reuse the current fan curve. X thickness
  is containment/authoring extent only, not housing, solid displacement or
  force volume. Zero pressure disables forcing but does not change chamber walls.
- Resolve exactly one enabled Fan referencing the owner for the first contract.
  Multiple or missing fans need an explicit supported rule before Solve; do not
  silently select the first. A deliberate zero-pressure Fan is a valid fan-off
  fixture under the existing model.

## Aligned starting fixture and UI

A coherent default-grid proposal is `[4,4,4]`, so local cell pitch is exactly
25 mm. The demonstrated geometry must be two actual independently captured
12-triangle buffer cuboids occupying X `[-50,0]` and `[0,50]`, both with Y/Z
`[-50,50]`. Do not silently create/fill those materials when the user creates
Thermal. An optional explicit fixture-creation action could author them through
native transactions, subject to its own request and tests.

A Fan created for that fixture can use owner-local centre
`[-25,-12.5,-12.5]` mm and size `[25,25,25]` mm: local centre sheet X is the first
interior fluid face and its Y/Z footprint is one cell, not the full cross-section.
All coordinates are binary-exact multiples of 12.5 mm. These values are an
alignment proposal, not a guarantee the chosen material/flow/time configuration
passes the existing Float32 physical/numerical gates. Changing grid counts must
revalidate the unchanged native Fan rather than silently reposition it.

Use standard attributes/actions, native references, transforms and the existing
helper only. Group the three grid fields with the documented vector descriptor;
add no custom panel. A native Solve button becomes legitimate only after it reads
this authoritative document state. Keep the single Clear/Stop action and Probe.
Section visualization remains a separate required milestone, not represented by
the domain helper or a claimed result overlay.

## Required qualification before enabling native Solve

Test native field validation before mutation, exact unique role/Fan resolution,
unsupported shapes/frames/alignment, SI scale mapping, and independently checked
actual GPU fields. Cover transform edits, reparent/reference changes, copy,
Undo, HASH remapping, selection preservation, deletion/restore, job replacement,
Stop and final publication races. A native Fan/domain edit must retire the exact
owning field and Probe reading, while unrelated selection must not. Preserve the
same per-owner work tail and bounded resource/time budgets. Catalogue registration
and live release remain separate gates after hardware and full application checks.
