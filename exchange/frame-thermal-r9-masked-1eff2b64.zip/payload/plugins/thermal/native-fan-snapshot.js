// INTERNAL preparation only. No operation registration, solver, job, or UI.
// Do not pass the detached request to solve-scene and discard its Fan guards.
import {nativeFanMetadata,validateFanParameters} from './native-fan.js';
import {snapshotNativeSceneRequest} from './native-scene-request.js';
import {sceneConjugateInputs} from './scene-conjugate.js';
import {exactOccurrenceStamp,sharedThermalDeviceState} from './scene-identity.js';
import {THERMAL_TAGS} from './scene-inputs.js';
const fail=(code,message)=>{throw Object.assign(new Error(message),{code});};
const need=(ok,code,message)=>{if(!ok)fail(code,message);};
const captures=new WeakSet(),identities=new WeakMap();let nextIdentity=1;
function identity(object){let id=identities.get(object);if(!id){id=nextIdentity++;identities.set(object,id);}return id;}
const freeze=value=>{if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value);}return value;};
// No rounding, and no JSON null/undefined or signed-zero identity collisions.
const exact=value=>value===undefined?['undefined']:value===null?['null']:typeof value==='number'?['number',Object.is(value,-0)?'-0':String(value)]:Array.isArray(value)?['array',value.map(exact)]:typeof value==='object'?['object',Object.entries(value).sort(([a],[b])=>a<b?-1:a>b?1:0).map(([k,v])=>[k,exact(v)])]:[typeof value,value];
const affine=value=>value?.length===16&&Array.from(value).every(Number.isFinite)&&value[3]===0&&value[7]===0&&value[11]===0&&value[15]===1;
const equal=(a,b)=>Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((x,i)=>Object.is(x,b[i]));

function scalarParameters(params,required){
 need(params&&typeof params==='object'&&[Object.prototype,null].includes(Object.getPrototypeOf(params)),'INVALID_ARGUMENT','Native parameters must be a plain bounded scalar record.');
 const keys=Reflect.ownKeys(params),descriptors=Object.getOwnPropertyDescriptors(params);
 need(keys.length<=64&&keys.every(key=>typeof key==='string'&&key.length<=128&&descriptors[key].enumerable&&Object.hasOwn(descriptors[key],'value'))&&required.every(key=>Object.hasOwn(descriptors,key)),'INVALID_ARGUMENT','Native parameters must be own enumerable scalar data, including every required field.');
 const entries=keys.map(key=>[key,descriptors[key].value]);
 need(entries.every(([,value])=>typeof value==='number'&&Number.isFinite(value)||typeof value==='boolean'||typeof value==='string'&&value.length<=4096),'INVALID_ARGUMENT','Native parameters must be bounded finite scalar values.');
 return Object.fromEntries(entries);
}

function authoring(context,ownerHash,fanHash,binding){
 const D=context?.document,nodes=D?.nodes;
 need(typeof ownerHash==='string'&&ownerHash.length>0&&typeof fanHash==='string'&&fanHash.length>0&&Array.isArray(nodes),'INVALID_ARGUMENT','Explicit canonical Thermal and Fan hashes are required.');
 const byHash=new Map(),byId=new Map();
 // Build fresh lookup maps on EVERY guard. A null marks duplicate identities;
 // unlike one-element arrays this avoids 2*N transient allocations per guard.
 for(const node of nodes){const hash=node.nativeHash,id=node.id;if(typeof hash==='string'&&hash)byHash.set(hash,byHash.has(hash)?null:node);if(typeof id==='string'&&id)byId.set(id,byId.has(id)?null:node);}
 const resolve=(map,key,code)=>{const node=map.get(key);need(node,code,'Native identity must resolve to exactly one current object.');return node;};
 // The domain path may capture any native source. Validate the complete parent
 // graph before capture/world evaluators, with no saved epoch or topology cache.
 if(binding){
  const depths=new Map();
  for(const n of nodes){
   need(typeof n.nativeHash==='string'&&n.nativeHash&&typeof n.id==='string'&&n.id&&resolve(byHash,n.nativeHash,'UNSUPPORTED_HIERARCHY')===n&&resolve(byId,n.id,'UNSUPPORTED_HIERARCHY')===n,'UNSUPPORTED_HIERARCHY','Native topology needs unique canonical and session identities.');
   need(n.parent==null||typeof n.parent==='string'&&n.parent.length>0,'UNSUPPORTED_HIERARCHY','Invalid native parent identity.');
  }
  for(const start of nodes){if(start.parent==null||depths.has(start))continue;const path=[],seen=new Set();let n=start;
   while(n.parent!=null&&!depths.has(n)){
    need(!seen.has(n)&&path.length<256,'UNSUPPORTED_HIERARCHY','Cyclic or excessive native ancestry.');seen.add(n);path.push(n);n=resolve(byId,n.parent,'UNSUPPORTED_HIERARCHY');
   }
   let depth=n.parent==null?1:depths.get(n);for(const n of path.reverse()){need(++depth<=256,'UNSUPPORTED_HIERARCHY','Native ancestry exceeds 256 levels.');depths.set(n,depth);}
  }
  need(resolve(byHash,binding.fluidHash,'INVALID_FLUID').type==='mesh','INVALID_FLUID','Fluid must name a canonical native polygon mesh, not a group, generator or instance.');
 }
 const owner=resolve(byHash,ownerHash,'INVALID_OWNER'),fan=resolve(byHash,fanHash,'INVALID_FAN');
 need(owner.type==='thermal'&&fan.type==='thermal_fan','INVALID_ARGUMENT','Explicit Thermal owner and native Fan types are required.');
 const ownerParams=scalarParameters(owner.params,['Initial','Ambient']),fanParams=scalarParameters(fan.params,['Thermal','Shutoff pressure','Free flow','Direction']);
 need(['Initial','Ambient'].every(key=>typeof ownerParams[key]==='number'&&ownerParams[key]>=-273.15),'INVALID_ARGUMENT','Valid Initial and Ambient temperatures are required.');
 validateFanParameters(D,fanParams);
 need(fan.params.Thermal===ownerHash,'INVALID_FAN','Fan must explicitly reference the requested Thermal owner; hierarchy cannot assign ownership.');
 const ancestry=start=>{const ancestors=[],seen=new Set();let node=start;
 while(node){
  need(!seen.has(node)&&ancestors.length<256,'UNSUPPORTED_HIERARCHY','Cyclic or more than 256-level Fan ancestry is unsupported.');seen.add(node);
  need(typeof node.nativeHash==='string'&&node.nativeHash&&typeof node.id==='string'&&node.id&&resolve(byHash,node.nativeHash,'UNSUPPORTED_HIERARCHY')===node&&resolve(byId,node.id,'UNSUPPORTED_HIERARCHY')===node,'UNSUPPORTED_HIERARCHY','Every ancestor needs unambiguous native and session identities.');
  need(typeof node.type==='string'&&node.type.length>0&&node.type.length<=128,'UNSUPPORTED_HIERARCHY','Ancestor type must be a bounded native type string.');
  need(node.enabled===undefined||typeof node.enabled==='boolean','UNSUPPORTED_HIERARCHY','Unknown native enabled state.');
  need(node.enabled!==false,'DISABLED','The Fan, owner and every ancestor must be enabled for internal preparation.');
  ancestors.push(node);
  need(node.parent===undefined||node.parent===null||typeof node.parent==='string'&&node.parent.length>0,'UNSUPPORTED_HIERARCHY','Unsupported native parent identity.');
  node=node.parent==null?null:resolve(byId,node.parent,'UNSUPPORTED_HIERARCHY');
 }
 return ancestors;};
 const ancestors=ancestry(fan);
 need(ancestors[1]===owner,'UNSUPPORTED_FAN_FRAME','Fan must be a direct child of its explicitly referenced Thermal owner.');
 // Validate the COMPLETE topology before a native evaluator can walk it.
 const frames=nodes=>{const chain=nodes.map(node=>{
  const local=Array.from(D.local(node.nativeHash)||[]),world=Array.from(D.world(node.nativeHash)||[]);
  need(affine(local)&&affine(world),'UNSUPPORTED_FAN_FRAME','Every relevant native local/world frame must be finite affine.');
  return {identity:identity(node),hash:node.nativeHash,id:node.id,type:node.type,parent:node.parent,enabled:node.enabled,local,world,...(node===owner?{params:ownerParams}:node===fan?{params:fanParams}:{})};
 });
 if(binding)for(let i=0;i<chain.length;i++){
  const expected=i+1<chain.length?Array.from(context.math.mul(chain[i+1].world,chain[i].local)):chain[i].local;
  need(expected.every((x,k)=>x===chain[i].world[k]),'UNSUPPORTED_DOMAIN_FRAME','Native world frame must exactly match its local/ancestor composition; evaluated constraints are unsupported.');
 }
 return chain;};
 const chain=frames(ancestors);
 const metadata=nativeFanMetadata(context,fan);
 need(metadata.profile.status==='valid'&&metadata.mapping.status==='supported-frame','UNSUPPORTED_FAN_FRAME','Fan requires the existing exact positive-diagonal owner-local frame mapping.');
 const device=context.device;need(device&&(typeof device==='object'||typeof device==='function'),'INVALID_DEVICE','Existing shared device identity is required; no device is created.');
 need(!sharedThermalDeviceState(device).lost,'DEVICE_LOST','Shared device is lost.');
 return {owner,fan,metadata,chain,deviceIdentity:identity(device),...(binding?{sourceChain:hash=>{const node=resolve(byHash,hash,'INVALID_FLUID');need(node.type==='mesh','UNSUPPORTED_GEOMETRY','Both domain sources must be canonical native polygon meshes, not groups, generators or instances.');return frames(ancestry(node));}}:{})};
}
function sceneStamp(context,ownerHash,binding,state){
 // Borrow during this call only. Never retain capture resources or wrappers.
 const source=context.scene.capture(ownerHash,[],THERMAL_TAGS);
 need(source.device===context.device&&typeof source.signature==='string','STALE_JOB','Scene capture must belong to the current shared device.');
 need(source.meshes?.length===2,'UNSUPPORTED_GEOMETRY','Exactly two explicit captured occurrences are required.');
 let domain;
 if(binding){
  const matches=source.meshes.flatMap((mesh,i)=>mesh.hash===binding.fluidHash?[i]:[]);
  need(matches.length===1,'INVALID_FLUID','Fluid hash must resolve to exactly one captured occurrence.');
  need(new Set(source.meshes.map(m=>m.hash)).size===2,'UNSUPPORTED_GEOMETRY','Repeated/instanced source occurrences are unsupported.');
  const chains=source.meshes.map(mesh=>{
   const chain=state.sourceChain(mesh.hash),relative=Array.from(context.math.mul(context.math.inv(state.chain[1].world),chain[0].world));
   need(relative.every((x,i)=>x===mesh.matrix[i]),'UNSUPPORTED_DOMAIN_FRAME','Captured occurrence must match its canonical native world frame exactly.');return chain;
  });
  domain={fluidHash:binding.fluidHash,fluidOccurrence:matches[0],chains};
 }
 return {signature:source.signature,transformStamp:exactOccurrenceStamp(source),...(domain?{domain}:{})};
}
const token=(state,source)=>JSON.stringify(exact([state.deviceIdentity,state.chain,source]));

// Request has the existing explicit domain/fluid/numerics/duration shape with
// settings.fanBox omitted. Native Fan parameters/pose are the ONLY fan source.
export function captureNativeFanRequest(context,ownerHash,fanHash,request,binding=null){
 const started=performance.now();
 need(request&&typeof request==='object'&&!Array.isArray(request)&&request.settings&&typeof request.settings==='object'&&!Array.isArray(request.settings)&&!Object.hasOwn(request.settings,'fanBox'),'INVALID_ARGUMENT','Saved-Fan preparation forbids an explicit fanBox, including an identical one.');
 const state=authoring(context,ownerHash,fanHash,binding),{centerMM,sizeMM,direction}=state.metadata.mapping,params=state.fan.params;
 let source=binding?sceneStamp(context,ownerHash,binding,state):null;
 if(binding)request={...request,cellSizeMM:request.dimensions.map(n=>100/n),settings:{...request.settings,fluidOccurrence:source.domain.fluidOccurrence}};
 const explicit=snapshotNativeSceneRequest({...request,settings:{...request.settings,fanBox:{centerMM,sizeMM,direction,shutoffPressure:params['Shutoff pressure'],freeFlow:params['Free flow']}}},state.owner.params.Initial);
 source??=sceneStamp(context,ownerHash);
 const result=freeze({stage:'native-fan-request-snapshot',ownerHash,fanHash,...(binding?{domain:{fluidHash:binding.fluidHash,localMinMM:[-50,-50,-50],localMaxMM:[50,50,50]}}:{}),request:explicit,source,ownerWorld:state.chain[1].world,token:token(state,source),metrics:{wallMs:performance.now()-started},executed:false});
 captures.add(result);return result;
}

// An on-use guard, not an event subscription or automatic retirement monitor.
// Use before/after every later asynchronous operation and final publication.
export function assertNativeFanRequestCurrent(context,snapshot){
 need(snapshot&&captures.has(snapshot),'INVALID_ARGUMENT','Expected an authentic immutable internal Fan snapshot.');
 try{
  const state=authoring(context,snapshot.ownerHash,snapshot.fanHash,snapshot.domain),source=sceneStamp(context,snapshot.ownerHash,snapshot.domain,state);
  need(token(state,source)===snapshot.token,'STALE_JOB','Native Fan, owner, hierarchy, source or shared device changed.');
 }catch(error){if(error.code==='DEVICE_LOST')throw error;fail('STALE_JOB','Native Fan snapshot is no longer current: '+error.message);}
}

// Trusted existing classifier output only. This does not classify geometry or
// run numerics. Reuse all exact geometry/SI/source/sheet/curve assembly gates.
export function nativeFanSceneInputs(context,snapshot,source,classification){
 const started=performance.now();assertNativeFanRequestCurrent(context,snapshot);
 need(source?.signature===snapshot.source.signature&&source.transformStamp===snapshot.source.transformStamp&&classification?.signature===snapshot.source.signature&&classification.transformStamp===snapshot.source.transformStamp&&equal(classification.ownerWorld,snapshot.ownerWorld)&&equal(classification.dimensions,snapshot.request.dimensions)&&equal(classification.cellSizeMM,snapshot.request.cellSizeMM),'STALE_CLASSIFICATION','Classification must exactly match this captured source, owner frame and explicit grid.');
 const mapped=sceneConjugateInputs(source,classification,snapshot.ownerWorld,snapshot.request.settings);
 assertNativeFanRequestCurrent(context,snapshot);
 return {...mapped,nativeFan:{ownerHash:snapshot.ownerHash,fanHash:snapshot.fanHash,token:snapshot.token},duration:{stepCount:snapshot.request.stepCount,cumulativeDivergenceDriftBudgetK:snapshot.request.cumulativeDivergenceDriftBudgetK},metrics:{wallMs:performance.now()-started},executed:false};
}
