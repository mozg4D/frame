// Internal native-job integration only. Domain/role/duration stay explicit.
import {nativeSceneSchema,validateNativeSceneLimits,snapshotNativeRequest} from './native-scene-request.js';
import {captureNativeFanRequest,assertNativeFanRequestCurrent,nativeFanSceneInputs} from './native-fan-snapshot.js';
import {createSceneConjugateDurationPipeline} from './scene-conjugate-duration.js';
const settings=structuredClone(nativeSceneSchema.properties.settings);
delete settings.properties.fanBox;settings.required=settings.required.filter(k=>k!=='fanBox');
export const nativeSavedFanSchema={...structuredClone(nativeSceneSchema),properties:{...structuredClone(nativeSceneSchema.properties),settings,fanHash:{type:'string',minLength:1,maxLength:256}},required:[...nativeSceneSchema.required,'fanHash']};
const invalid=()=>{throw Object.assign(Error('Expected a plain saved-Fan request with explicit fanHash and domain/fluid/grid/duration, without fan overrides.'),{code:'INVALID_ARGUMENT'});};
// Reject accessors, inherited fields, sparse arrays, symbols and other hidden
// caller data before touching native state or interrupting a predecessor.
export function preflightNativeSavedFan(context,hash,args){
 const {fanHash,...request}=snapshotNativeRequest(args,nativeSavedFanSchema);
 return captureNativeFanRequest(context,hash,fanHash,request);
}
export function advanceNativeSavedFanGPU(context,snapshot,{signal}={}){
 return createSceneConjugateDurationPipeline({
  current:()=>assertNativeFanRequestCurrent(context,snapshot),
  mapInputs:(source,classification)=>nativeFanSceneInputs(context,snapshot,source,classification)
 })(context,snapshot.ownerHash,{...snapshot.request,signal});
}

// Native-box variant reuses the identical immutable Fan capture and GPU factory.
export const nativeDomainSchema=structuredClone(nativeSavedFanSchema);
delete nativeDomainSchema.properties.cellSizeMM;
nativeDomainSchema.required=nativeDomainSchema.required.filter(k=>k!=='cellSizeMM');
delete nativeDomainSchema.properties.settings.properties.fluidOccurrence;
nativeDomainSchema.properties.settings.required=nativeDomainSchema.properties.settings.required.filter(k=>k!=='fluidOccurrence');
nativeDomainSchema.properties.fluidHash={type:'string',minLength:1,maxLength:256};nativeDomainSchema.required.push('fluidHash');
export function preflightNativeDomain(context,hash,args){
 const {fanHash,fluidHash,...request}=snapshotNativeRequest(args,nativeDomainSchema);
 validateNativeSceneLimits(request);
 if(request.dimensions.some(n=>n*(100/n)!==100))throw Object.assign(Error('Derived cells must exactly represent the native 100 mm box; this grid count is unsupported.'),{code:'INVALID_ARGUMENT'});
 return captureNativeFanRequest(context,hash,fanHash,request,{fluidHash});
}
