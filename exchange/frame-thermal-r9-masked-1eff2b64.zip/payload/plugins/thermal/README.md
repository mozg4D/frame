# Isolated interior-obstacle projection follow-up

The existing shared-device pressure projection now has a bounded optional single
strictly interior whole-cell cuboid mask. It enforces exact impermeable faces and
reuses one reciprocal GPU graph operator, with independent returned physical
pressure/velocity checks. This is projection only, not obstacle no-slip, advection,
Fan/heat/native coupling or a completed solver. No catalogue/UI/live release is
added. [MASKED-PROJECTION.md](MASKED-PROJECTION.md) defines the explicit contract,
nonphysical solid pressure sentinels, ownership and pending hardware gates.

# Explicit exterior-film follow-up (isolated)

The optional explicit exterior-film request now reuses the existing GPU heat
operator and native bounded duration jobs, with signed per-cell/region/global
heat-bath accounting and immutable request snapshots. No automatic cooling, new
authoring/UI, solver, public registration or hardware qualification is implied.
[EXTERIOR-FILM.md](EXTERIOR-FILM.md) is the current boundary contract; the stages
below describe earlier adiabatic milestones and remain unchanged when omitted.

# Native Thermal box candidate

The isolated `solve-domain` operation now derives its domain from the ordinary
native Thermal `[-50,50]³` mm box and native transforms. It uses explicit canonical
fluid/Fan hashes and explicit grid/numerical arguments, with the same classifier,
saved-Fan snapshot, GPU duration pipeline and native jobs. No saved settings, Solve
UI, new physics, public registration or release is added. See
[NATIVE-DOMAIN-JOB.md](NATIVE-DOMAIN-JOB.md) for the exact admissibility, lifecycle
and separate CPU/hardware qualification limits.

# Saved-Fan asynchronous native job candidate

The distinct unregistered `solve-saved-fan` operation now consumes an explicitly
named native Fan with explicit domain/fluid/grid/duration inputs through the same
owner job map and existing duration solver. `solve-scene` remains independent of
saved Fans. The sections below describe the previous independently qualified
stages; the current integration contract and qualification limits are in
[NATIVE-SAVED-FAN-JOB.md](NATIVE-SAVED-FAN-JOB.md). Metadata-only `fan-inputs` and
creation results are not eligibility certificates. No public catalogue/Solve UI or
release is enabled.

# Thermal: numerical conduction foundation

This is the first independently testable numerical stage, **not a finished scene-driven Thermal solver**. It solves a supplied 3D Cartesian conduction grid on Frame's existing WebGPU device. It does not voxelize scene geometry or solve thermal tags. No scene `Solve` attribute action is exposed, and status explicitly returns `sceneSolver: false`. An isolated, unregistered `solve-scene` API candidate now gives the restricted duration pipeline native job ownership; see the final section. It is not a general or live Thermal release.

The native Thermal object, icon, Ambient and Initial attributes use ordinary Frame authoring, selection, transforms, Undo and HASH. The 100 mm helper box is the authoritative owner-local domain only for the isolated `solve-domain` candidate. It is **not a visualization or extent of the explicit numerical grid**, and old `solve-scene`/`solve-saved-fan` requests still define their own domains. There is no result overlay in this stage. The plugin stays lazy and independent of CFD/Aero and every other solver.

## Implemented physics

- Isotropic Fourier conduction with positive, spatially varying conductivity.
- Cell-centred 3D finite volumes on an orthogonal grid, including anisotropic cell dimensions.
- Reciprocal face conductance from the harmonic mean of neighbouring conductivities. Internal heat flux cancels pairwise.
- Fixed-temperature outer faces at the physical boundary, half a cell from the first cell centre.
- Prescribed signed inward heat flux on outer faces, normalized by physical face area. Faces omitted from both explicit boundary maps are insulated.
- Volumetric sources and sinks; total power is source density times physical cell volume.
- Steady solve, or one backward-Euler transient step with volumetric heat capacity.
- Native independent jobs, cancellation, stale-result rejection, bounded temperature inspection, resource retirement, and runtime-only field ownership.

The equation for each cell is `sum(Gij * (Ti - Tj)) + boundaryFlux + C / dt * (Ti - Tinitial) = source * volume`. The transient term is absent in steady mode. Celsius temperature differences are identical to kelvin differences. No radiation calculation uses Celsius here.

The initial value is the numerical starting guess in steady mode and the previous physical temperature in transient mode. An entirely insulated steady grid is rejected because its absolute temperature is not unique. Positive conductivity makes the rectangular grid connected. A transient grid can be insulated because its positive heat capacity anchors the next state.

The GPU uses damped Jacobi iterations, explicit shared-device binding limits, and batches of at most 64 iterations. A GPU reduction reads only 32 bytes per residual check. `residualK` is maximum absolute equation residual divided by that cell's diagonal; it is a backward-error indicator, **not a bound on total temperature or geometric discretization error**. A limit, non-finite result, cancellation, or stale input does not publish success. Float32 can stagnate below a requested tolerance. No CPU solver silently substitutes for an unavailable GPU.

## Numerical API

Discover with `plugins.describe {plugin: 'thermal'}`. Then use `plugins.command` with the Thermal owner ID.

`solve-grid` inputs:

| Field | Meaning |
| --- | --- |
| dimensions | Required `[nx, ny, nz]`, positive integers |
| cellSize | Required `[dx, dy, dz]`, **metres**, not Frame millimetres |
| conductivity | Required one-element or per-cell array, W/(m K), positive |
| heatCapacity | One-element or per-cell array, J/(m³ K), positive; default 1,000,000 |
| source | One-element or per-cell array, W/m³; default zero; signed |
| initial | One-element or per-cell array, °C; default owner's Initial |
| boundary | Object with optional xMin/xMax/yMin/yMax/zMin/zMax temperatures in °C |
| boundaryFlux | Optional object with xMin/xMax/yMin/yMax/zMin/zMax heat flux densities, W/m²; positive enters the domain, negative leaves |
| timeStep | Optional positive seconds; presence selects one transient step |
| tolerance | Numerical API-only residual threshold in K, default 0.0001 |
| maxIterations | Numerical API-only limit, default 20,000 |

Absent `boundary` fixes faces without a `boundaryFlux` entry to the owner's Ambient. Explicit `{}` leaves faces without a flux entry insulated. A face cannot prescribe both temperature and heat flux, including a zero flux. Flux alone does not anchor a steady domain; a fixed-temperature face or transient step is still required. Per-cell arrays use `x + nx * (y + ny * z)`. Array lengths must be exactly one or the cell count; values are validated before replacing any existing job. This stage supports at most 262,144 cells and 256 along any axis. These are explicit input/work limits for this foundation, not automatic quality or an estimate of available VRAM.

Example: a 100 mm long slab, 10 cells along X, faces at 0 and 100 °C, other faces insulated:

```js
await frameAI.call('plugins.command', {
  id: thermalHash, operation: 'solve-grid', args: {
    dimensions: [10, 1, 1], cellSize: [0.01, 0.01, 0.01],
    conductivity: [2], initial: [50], boundary: {xMin: 0, xMax: 100}
  }
});
```

The operation returns a job immediately. Poll `status` for `ready`, then call `inspect {offset: 0, count: 10}`. Expected cell-centre temperatures are 5, 15, …, 95 °C. `inspect` reads at most 256 cells. `cancel` interrupts scheduling and drains current work. `clear` releases the numerical field. Do not mistake `ready` for a solve of scene geometry: `sceneSolver` remains false.

Boundary power includes prescribed heat flux with outward-positive sign, so net outward boundary power plus stored power equals volumetric source power. Prescribed inward flux is not counted again as volumetric source power.

Status reports numerical iterations, completed wall time, min/max temperature, source/boundary/storage power, energy imbalance, tracked peak/retained GPU buffer bytes, and actual readback bytes. Allocation accounting excludes the driver, pipeline compilation, and Frame's own resources. It does not claim to know free VRAM. A completed field retains only one Float32 temperature buffer; transient assembly/scratch is released. The source grid and field are not written to HASH. Copy/reload starts without numerical state. Owner changes retire a field; unrelated camera movement does not.

## Verification

`node --test plugins/thermal/tests/numerics.mjs` checks assembly against an independent Float64 shared-face resistance model and pivoted dense solver, analytical slabs and layered materials, source normalization, signed boundary-flux slab gradients and transient energy, energy conservation, transient heating/diffusion, validation, immutability, ownership-facing API and a 32³ assembly latency budget. This is CPU/reference verification, not proof that WGSL executes correctly.

`node plugins/thermal/tests/run.mjs --headless` runs the actual WGSL using hardware WebGPU, compares all fields with independent numerical references, measures completed-operation budgets and GPU buffer/readback accounting, rejects nonconvergence, and checks native job/validation/copy/HASH/UI behavior. It rejects software adapters. During isolated development the harness injects only the catalogue response, without changing repository files. Once registered by the integrator, standard/stress discover `tests/index.mjs` normally.

Required release gates also include `npm test` and `npm run test:stress`. A missing GPU is an unmet release gate, never a skipped passing test.

## Next stages

1. Native Material/Heater tag parameters and scene-to-grid coupling, validated occupancy and physical transforms/units, plus rendered temperature sections. Probe inspection of explicit grids is implemented below.
2. Temperature-dependent power and properties, contacts, scene Heat flux tags and native Curves/animation.
3. Material transport, independent fluid motion and natural/forced convection, Fan, radiation and phase change.
4. Adaptive spatial/temporal resolution and geometry convergence tests, thin-wall handling, solver acceleration and cached scene reuse.

No convection, radiation, fan, material flow, phase change, geometry field, animation solve, thermal contact object, or engineering temperature-accuracy certification is claimed by this stage.

## Native Probe

A Thermal object's **Probe** action creates an ordinary child Probe with a `Thermal` object reference. Its small 2 mm helper marks the sample point; native transform controls move it, and ordinary selection, Undo and HASH own its authoring. Multiple Probes and independent Thermal owners are supported. A Probe's **Measure** action samples the current converged explicit grid and replaces its label with the measured Celsius temperature. Pressing it again repeats the measurement. There is no debug panel, persisted numerical result, history curve or automatic physical time integration.

New Probe initialization uses the actual core's packed `creationFrame`, built
with `context.math.I()` and `pack()`. The existing shared `[-50,50]³` box has
native local scale `[.02,.02,.02]` and origin `[0,0,0]`, giving a 2 mm cube in
parent coordinates. World dimensions follow ordinary parent scaling. Standalone
creation uses the same frame but leaves Thermal unassigned. Core consumes the
initializer once; later edits, Undo and HASH remain authoritative. This corrects
the old `n.transform` assignment, which never initialized the actual native matrix
and left a 100 mm helper. Existing authored frames are not migrated or reset.
The sampled world origin and all sampling/physics code are unchanged.

`node --test plugins/thermal/tests/native-probe.mjs` executes actual extracted core
creation, synchronization, record installation and math against the shipped hook.
It checks real helper edges, parent-local and standalone defaults, old-defect
reproduction, one-shot consumption, later edits and 32 creations below 1500 ms.
`node plugins/thermal/tests/native-probe-browser.mjs --headless` is a focused,
fresh-context hardware gate for native matrix/bounds, UI creation, standalone and
transformed-parent creation, repeated sync, transform Undo/Redo, edited HASH
frames, 32 creations below 10000 ms and measured CPU/GPU frames below 50 ms.
The full Thermal suite includes this gate and strengthens its existing Probe
creation/HASH checks without relaxing numerical, label or stale-field checks.
See [exact correction and verification scope](NATIVE-PROBE-SIZE-FIX.md).

### Creation completion and native selection

Both `create-probe` and `create-fan` are asynchronous authoring operations. They
keep creation, explicit Thermal reference and ordinary Attributes selection in
one native transaction, then await `context.editor.selectOwner(childHash)` before
returning the unchanged result shape. The existing core helper synchronizes the
native transform engine; `document.select` alone changes only UI selection.
This fixes immediate-after-create edits moving the owner while the child's row
was selected. No manual reselection or alternative pose is required.

The helper adds no Undo checkpoint. `frameAI` already awaits operation results,
so a queued transform waits for the selected child. No serialized API is called
from the operation itself. A helper rejection propagates rather than reporting
success or retrying creation; the already committed child remains undoable.
The core selection queue's existing GPU-error handling is unchanged.

`node --test plugins/thermal/tests/native-selection.mjs` exercises the actual
extracted bridge, native selection queue, serialized API queue, native transforms
and frame capture/restoration. Tests cover both child types, delayed selection,
endpoint rejection, one checkpoint, repeated creation, prior-child preservation,
newer-selection ordering, component display modes, API-tail completion
and 32 completed creation/selection/transform operations below 1500 ms. These are
CPU source contracts, not full browser Undo/HASH or rendering qualification.
The Probe and Fan browser gates now require immediate Attributes and queued API
edits to change the child local/world frame without changing its owner, followed
by strict Undo/Redo checks. No `scene.select` repair is inserted into that path.
See [selection diagnosis and exact runtime change](NATIVE-SELECTION-FIX.md).

The explicit grid is centred on its Thermal owner. Grid dimensions times cell sizes define its extent in metres; the Probe world origin is transformed into the owner's local frame and converted from Frame millimetres to metres. The author's existing 100 mm Thermal helper is still a placeholder, not the grid extent. Owner transforms position the explicit numerical coordinate frame; scaling the owner does not reassemble physics with different metre cell sizes. The solver is still not coupled to scene meshes; tag authoring and inspection are separate from explicit-grid physics.

`plugins.command {id: probeHash, operation: 'measure'}` reads at most eight scalar temperatures and returns `temperature`, `unit`, `localMetres`, `cellsRead` and `interpolation`. Sampling is trilinear between cell centres; within the exterior half cells it clamps to the nearest cell centre. It does not reconstruct the prescribed face temperature and is not an accuracy certificate. A point outside the grid rejects instead of silently clamping to the domain. Missing/cleared/nonconverged fields reject. Changes to the Probe, source owner, shared device or job during readback reject the whole measurement. Cached readings are runtime-only and become unavailable on authoring changes, field retirement or restore.

Run `node --test plugins/thermal/tests/numerics.mjs plugins/thermal/tests/probe.mjs` for CPU/reference checks. The hardware harness also tests native creation, repeated measurement, field clearing, HASH references and the real attribute button; those checks require Chromium and a hardware WebGPU adapter.

## Native scene tag authoring (bridge dependency)

Requires the shared parameterized-tag bridge. Native inheritable `thermal_material` (Thermal Material) and `thermal_heater` (Heater) tags use ordinary tag attributes, `tag.set`, Undo, copy, HASH and parameter animation. `solve-grid` continues to use explicit supplied arrays, not tags. Animation changes authoring only, not physical time.

Material Conductivity is W/(m K); volumetric Heat capacity is J/(m³ K). Both have an authoring floor of 1e-12, not a physical accuracy guarantee. Defaults 1 and 1,000,000 are generic placeholders, not a named substance. Heater Power is signed total watts: positive heating, negative cooling, default zero.

`scene-inputs {offset?, count?}` returns at most 256 captured occurrences (default 64), effective tags and original source/UID provenance. Pages capture fresh state; avoid authoring changes between pages. Untagged occurrences remain visible. Nearest whole tags override ancestors, and instance ancestry takes priority under the shared bridge. One inherited Heater may appear on several occurrences: do not add its watts once per occurrence. No total power, occupied volume, density or geometry buffers are returned. `sceneSolver`, `geometryClassified` and `powerNormalized` are false.

Bounds are not occupancy and are not used. No coordinate conversion is needed for these material scalars or watts. Future geometry coupling must convert Frame millimetres to metres exactly once, classify closed physical volumes, resolve overlaps/contacts and define inherited/instanced Heater normalization. The helper box remains a placeholder.

Flow is requested but its parameters, direction frame and transport law are absent from recovered user messages. No misleading marker or invented velocity semantics are introduced. Material presets need a supported expansion contract and property model. Flow, presets, temperature-dependent power/properties, fan, contacts, convection, radiation, sections and Curves remain later stages. No scene Solve action is added.

Run `node --test plugins/thermal/tests/scene-inputs.mjs` for bridge declaration validation, bounded resource-free projection, signed Heater provenance, invalid values and latency. Native browser checks cover inherited capture, atomic rejection, Undo and timing. Hardware and aggregate checks remain required for release.

The original planning conversation is https://chatgpt.com/c/6aedd745-3c88-83ea-8b59-7504437d4984. Its visible user messages specify independent internal CFD, a box plus multiple sections, Fan direction along local X, Material/Heater/Flow tags and Probe/Curves. The saved assistant messages, including the final written specification, were unavailable during this implementation; these missing details are not treated as approved numerical models.

## Aggregate geometry inspection and capture cost

`inspect-geometry` uses the exact shared snapshot and `prepareVolume` with nested-union, checks current source/device after asynchronous preparation and releases derived buffers on success, failure or stale completion. It reports aggregate boundary counts and limited allocation/readback metrics. Cancellation and owner retirement abort in-flight preparation. It does not retain the boundary or expose a result overlay. This is not material-volume classification: union removes internal interfaces and cannot assign per-material occupancy or normalize inherited heaters. Owner-local coordinates also do not establish physical volume under owner scaling. No thermal mesh/grid conversion is implemented.

`scene-inputs` bounds only its response, not capture work. Frozen `capture` and `signature` traverse every occurrence, resolve tags/accuracy and serialize full-scene signatures. Thermal cannot safely restrict this work under the existing contract, and caching without a cheap authoritative revision would risk stale authoring. The response now reports `captureScope: 'whole-scene'` and completed capture/wall milliseconds. True bounded traversal requires a shared paged capture/revision API and must preserve occurrence ordering, inheritance and current-source checks.

`tests/capture-performance.mjs` exercises extracted shipped snapshot traversal and tag resolution for 10,000 occurrences (100M declared triangles) plus a page projection, with a 2 s CPU budget. Geometry resources, matrix math and accuracy providers are fixture stubs; this is not a rendered heavy-scene test or measured GPU performance. Hardware browser checks now include aggregate geometry inspection with a 15 s completed-operation budget but remain a release gate until executed successfully. `tests/geometry.mjs` covers stale/cancel/failure disposal with a mocked shared preparer, not real polygon preparation.

## Internal classified-grid adapter (not a user-facing solve)

`scene-grid.js` exports `sceneGridInputs(snapshot, classification, ownerWorld)`. This is an internal contract for a future geometry classifier, not an operation registered in the application. Nothing calls it from scene Solve and it cannot classify triangles. The classification must identify the exact snapshot signature and owner frame, supply three grid dimensions, owner-local cell sizes in millimetres and one Int32 occurrence index per complete cell in x-fastest order. The caller must establish full-cell occupancy, resolve material overlap and report fully covered occurrences; the adapter cannot verify those geometric claims. Sparse numeric arrays and nonzero Heater power that underflows to zero density or per-cell watts reject before returning a grid. Reconstructed per-definition watts must match the requested total within relative 1e-12 (no absolute tolerance floor), rejecting large subnormal rounding losses as well. It rejects void/unresolved indices, missing material, duplicate effective tags, clipped/unrepresented heaters and stale frame/signature inputs. Air/void and partial cells require a later model.

The adapter maps effective native Material conductivity and volumetric capacity into per-cell arrays and groups Heater watts by `(source, uid)`. One inherited definition's signed power is distributed over all its classified cells exactly once. Every occurrence carrying that Heater must be declared fully covered and have cells, otherwise the adapter rejects instead of concentrating an entire clipped source into the remaining cells. Shared provenance across instances means shared total watts under this internal contract; independent instance power requires distinct native tag definitions. A future scene workflow must expose/confirm this interpretation, not silently substitute per-instance power.

Owner-local millimetres are converted to physical metres once, multiplying each axis by the corresponding owner-world column length. Orthogonal rotation, translation, reflection and nonuniform scale are supported; singular/projective/sheared frames reject (orthogonality tolerance 1e-10). Physical cell volume then normalizes source density in W/m³. Snapshot occurrence transforms belong to the preceding classifier and are not applied twice here.

The returned `grid` has dimensions, physical cell sizes, conductivity, capacity and source arrays suitable for `assembleConduction`; it deliberately omits boundary, initial temperature and time-step decisions. Assembly still owns Float32 representability and numerical validation. It also returns coordinate metadata and per-definition power/volume accounting, never a solved field. The existing explicit-grid Probe convention must not be reused blindly for these physically scaled cells. The internal assembler and physical Probe mapping below now preserve this distinction. No public/native Solve job invokes this classifier; the restricted internal pipeline below connects the stages for further validation.

`tests/scene-grid.mjs` covers inherited and independent signed heaters, heterogeneous materials, exact SI conversion with affine orthogonal scale, resolution-independent power, incomplete/stale/invalid rejection, a closed transient energy balance against the independent Float64 solver, and complete 32³ mapping-plus-assembly latency under 1 s. These are analytic classified fixtures, not validated scene voxelization.

## Physical-field Probe integration

Internal `assembleSceneConduction` combines classified material/source inputs with boundary/initial/time settings while forbidding replacements of classified geometry/material arrays. It attaches an immutable `physical-owner` frame. GPU solve captures a defensive immutable copy before asynchronous work and retains it on the returned field. No new scene Solve command is exposed.

Probe sampling dispatches by the field metadata. Explicit-grid fields retain the existing owner-local convention. Physical scene fields project world millimetres onto the saved normalized owner axes, then convert to physical metres exactly once. Thus orthogonal nonuniform scale and reflections match the physical cell dimensions produced by the scene adapter. The current owner-world frame must exactly match the saved frame before any read, and normal job/Probe checks still guard asynchronous readbacks. Missing/stale owner metadata rejects; there is no fallback to the wrong convention. Trilinear weights and the eight-scalar read bound are unchanged. Reported `localMetres` means physical distance along saved owner axes for physical fields.

Source-power diagnostics use Neumaier compensated Float64 summation to avoid accumulated rounding drift across large grids. The adapter's relative 1e-12 check concerns each Heater's reconstruction from uniform per-cell power; it is not a GPU temperature or energy-imbalance accuracy guarantee. GPU reduction remains Float32.

CPU tests cover 250,000-cell signed source accounting, scaled/rotated/reflected physical Probe sampling, exterior/missing/stale frames, interrupted readbacks, immutable metadata and bounded sampling latency. Actual WGSL result propagation and native UI require hardware verification and remain unverified in this environment.

Physical Probe face checks admit floating-point projection roundoff using an axis-specific tolerance of 32 machine epsilons times the magnitudes involved in world-origin subtraction, normalized-axis projection and unit conversion. Only coordinates within that numerical band are clamped to the physical face. This is not geometry uncertainty or an engineering accuracy tolerance. If the band exceeds 1e-7 of the corresponding cell size, sampling rejects with `PRECISION_LIMIT` rather than accepting a materially exterior point. Regression sweeps cover all faces/corners over 1,000 rotations plus the reported translated/nonuniform/reflected frame, and exterior offsets of 1e-6 mm reject. Neumaier summation additionally preserves small signed diagnostic residuals between cancelling large source terms; it does not make the Float32 solver exact.

## Restricted classifier path: one evaluated cuboid

Internal `classifySceneBox(context, owner, {dimensions, cellSizeMM, signal})` now provides the first bounded bridge from actual shared prepared geometry to classified cells. It is not registered as an AI operation, catalogue item or Solve button. It captures exactly one occurrence with Thermal Material, rejects more than 4096 source triangles, requires an orthogonal valid physical owner frame, calls shared `prepareVolume`, and reads back only a prepared twelve-triangle boundary (at most 4096 vertices). Shared preparation's own costs are additional to the readback metrics. Cancellation/stale source, frame and device checks surround asynchronous work. Every staging buffer and prepared boundary is released on success or failure.

The CPU classifier does not trust the bounding box as geometry: it checks actual triangle indices and finite used vertices, all eight cuboid corners, exactly two triangles per axis-aligned rectangular face, opposite-corner shared diagonals, and paired consistently oriented edges. This restricted surface is provably the represented rectangular box; bevels, rotated boxes relative to owner, interior vertices, duplicate/open/nonmanifold faces and other shapes reject. Overall winding reversal and seam vertex duplication are supported. This is a deliberately narrow algorithm, not a general mesh voxelizer. Shared topology preparation is not claimed to certify arbitrary self-intersection-free material domains.

Cells are centred on the Thermal owner and classified by exact represented-coordinate interval containment: 0 is a complete material cell, -1 exterior, -2 intersected/partial. No epsilon inflates solids, no partial cell is silently assigned, and bounds are used only after triangle recognition. Complete Heater coverage is reported only when the entire box is inside the domain with no partial cells. The existing scene adapter rejects exterior/partial cells and incomplete heaters instead of generating a fake rectangular fill. All coordinates here are owner-local millimetres; physical scaling remains in `assembleSceneConduction`.

The return contains a resource-free source tag descriptor, classification and bounded readback/timing metrics. That descriptor is not a shared capture and must never be passed to `prepareVolume`; it only accompanies this classification into the internal SI-grid adapter. The caller must revalidate the saved source signature and owner frame before submitting a subsequent solver job. GPU resources and CPU triangle buffers are not retained in the result. Classification refers to the evaluated Float32 boundary, not certified underlying authored curves or source-approximation error. A future workflow still needs source-accuracy policy, native domain/boundary controls and hardware validation.

`tests/box-classifier.mjs` checks real triangle recognition, same-bounds malformed/non-box shapes, winding/seams, partial/void/clipped cells, Heater integration, sparse/limit checks and 32³ completed-operation budget of 1 s. Mock shared-device tests exercise current/stale/cancelled/failed readback disposal and reject multiple materials before preparation. Real shared preparation/readback hardware execution remains unverified. General materials, contact interfaces, fluid domain/transport and independent internal CFD are not implemented by this restricted path.

## Internal end-to-end restricted pipeline

`solveSceneConduction(context, ownerHash, {dimensions, cellSizeMM, conditions?, signal?})` now connects the actual internal stages: scene capture, shared prepared boundary readback, restricted cuboid classification, SI assembly, the existing shared-device WGSL solver, and native Probe-reference sampling. It is an exported internal function only. No plugin command, catalogue registration, button or user-visible mock workflow is added.

Supported domains must fully coincide with one captured material cuboid: no exterior, partial or clipped cells, additional scene occurrences, arbitrary geometry or material interfaces. Unsupported cases reject explicitly before numerical solve. Conditions may specify initial/boundary/flux/time/convergence controls, never replace classified geometry/material/source. Missing initial and boundary settings use the owner's Initial/Ambient; explicit empty boundary retains insulation. Input arrays/conditions are copied before asynchronous work.

A successful handle provides bounded `inspect`, `measureProbe(probeHash)`, numerical/classification metrics and idempotent `dispose`. Probe must be enabled and reference the exact Thermal owner. Sampling uses immutable physical owner metadata. Geometry/tag signatures, owner identity/parameters/frame and shared device are checked through solve and before/after reads. Stale/failure retires the field; AbortSignal cancellation disposes immediately, including after publication. A changed Probe rejects its measurement without retiring an otherwise current field. Invalid inspection arguments likewise preserve a current field. Explicit disposal releases the owned numerical result and unregisters the abort listener. Consumers must still call dispose when abandoning a handle; authoring invalidation is checked on use, not by a background monitor. No HASH or Undo state is modified.

The field owns no retained mesh snapshot or classification arrays. Published metrics report completed-operation wall time, not the field's age. Classification metrics are additional to shared preparation; numerical memory/readback accounting remains owned by the GPU solver. The production default has no CPU fallback. `createScenePipeline` exposes dependency injection solely for internal tests; the test dense solver remains under tests and is never imported into runtime.

CPU integration tests run the real classifier and SI assembly with a mocked shared-device readback and an independent dense linear-solver algorithm applied to assembled coefficients. An analytical slab checks absolute temperatures through native Probe reference sampling. Tests also cover scaled defaults, unsupported domains, invalid replacement controls, stale/cancel/failure ownership, Probe movement, request mutation and a 100-completed-pipeline-plus-Probe budget of 2 s. These tests verify orchestration and CPU mathematics; they do not demonstrate real GPU prepareVolume, WGSL execution, native UI operation or general scene simulation. Hardware verification remains required before exposure or release. CFD, natural/forced convection, Fan and transport remain absent.

## Two independent cuboids: first multi-material contact path

Internal `classifyTouchingSceneBoxes` and `solveTouchingSceneConduction` add a separate bounded scope for exactly two captured occurrences. This path never calls `prepareVolume`/union: each native occurrence's positions/indices are borrowed and read independently, preserving both material identities and the shared face. Only buffer-backed, COPY_SRC-capable geometry is accepted, with exactly twelve triangles and at most 4096 vertices per occurrence. Paged/texture sources, undersized buffers, additional bodies and missing materials reject before readback. Native buffers are never destroyed; staging buffers are released on all paths. Source/device/owner checks surround asynchronous copies. Results retain only resource-free tags and classification, not meshes.

Relative transforms must be axis permutations with signed power-of-two scales, exactly Float32-representable coefficients, and translations whose vertex sums are exact in both Float64 arithmetic and Float32 storage. This intentionally rejects many otherwise geometrically reasonable transforms: rounding must not collapse a real gap into a false contact. The physical Thermal owner frame retains its earlier orthogonal scale/rotation support. No epsilon closes gaps or merges faces.

Each transformed boundary passes the full independent cuboid triangle/edge validation. The two boxes must meet on exactly one complete matching rectangular face and exactly fill the centred grid. Gaps, overlaps, partial-face contacts, clipped solids and cell-cutting interfaces reject explicitly. Occurrence order does not decide spatial material ownership. Both complete occurrence IDs flow into the SI adapter, so inherited Heater totals are normalized once across their combined classified volume.

The model is **perfect thermal contact**, with zero additional interface resistance. Shared-face conductance uses the existing reciprocal half-cell resistance formula `G = A / (h/(2*kLeft) + h/(2*kRight))`. No separate fluid layer, contact-pressure model, finite contact resistance or radiation is inferred. Physical owner scaling changes face area and normal distance in SI. An analytical two-layer slab with k=2/8 W/(m K), two 10 mm cells per material and faces 0/100 °C has cell-centre temperatures 20, 60, 85, 95 °C and interface temperature 80 °C.

Ordinary linear interpolation would give a wrong interface temperature of 72.5 °C for that slab. The two-material handle therefore carries explicit perfect-contact metadata. Probe interpolation normal to that one face is piecewise resistance-weighted, using the harmonic-face temperature; tangential interpolation remains trilinear and total reads remain at most eight. The returned interpolation label is `perfect-contact-resistance-weighted`. Existing explicit-grid and single-material fields are unchanged. This is a restricted reconstruction for one full-face, constant-material interface, not a general gradient/temperature accuracy certificate.

Tests cover analytical slab temperatures and reciprocal conductance along all three axes, area/distance scaling, Heater normalization, occurrence-order invariance, unsupported geometry/transforms/storage, no-union readback ownership and stale/cancel cleanup. A complete two-material pipeline→Probe test uses a test-only dense solver, not GPU execution. Additional 32³ classification+assembly and 10,000 contact-weight budgets measure completed CPU work. Boundary staging/host-byte metrics exclude the shared scene buffers, grid arrays, driver and JS runtime. Hardware readback/WGSL and native UI remain unverified. No public Solve command or UI is registered; independent internal CFD is still absent.

## Exact relative-frame invalidation

Core snapshot signatures quantize relative matrices to 1e-9, which is insufficient for exact contact topology. Thermal now supplements that signature with a scalar stamp containing occurrence order/hash/solid and every finite matrix component without quantization. The stamp is a JSON string of scalar values, not a retained mesh snapshot or GPU resource. Both classifiers carry it into classification/source metadata; SI assembly rejects mismatched stamps. Geometry inspection, asynchronous readback, solving and field reads recapture current source metadata and compare both the normal signature and exact transform stamp.

A regression executes extracted shipped `pluginSnapshot`: moving a source by 2^-35 mm while incrementing version and frameRevision together leaves its normal signature unchanged, but changes Thermal's stamp. Additional tests reject that movement during readback and retire an already-published two-material field before Probe reads. This correction requires full scene recapture at guard points because the current bridge exposes no cheap unrounded transform token. It does not retain borrowed resources, but has whole-scene capture cost. A 10,000-guard CPU fixture budget includes shipped snapshot traversal with fixture matrix/accuracy providers, not rendering/GPU performance.

## Independent airflow investigation (test-only)

`AIRFLOW-DESIGN.md` defines the bounded rectangular-duct fan reference and the route to an internal staggered-grid flow solver. `tests/airflow-reference.mjs` is an analytical control problem only, never a runtime CPU substitute. It does not change conduction, expose Fan authoring, compute scene velocity or implement convection. Run `node --test plugins/thermal/tests/airflow.mjs` for the reference checks.

`tests/stokes-reference.mjs` adds a symmetry-reduced developed-duct MAC-grid CPU reference, with numerical cross-section velocities, prescribed pressure, conservation checks and analytical grid convergence. It is not a general Stokes pressure-coupling solver. Run `node --test plugins/thermal/tests/stokes.mjs`; see AIRFLOW-DESIGN.md for limits.

`tests/fan-stokes-reference.mjs` couples the ideal fan curve to measured discrete MAC duct resistance and verifies the actual returned flow/pressure and fluid regimes. It remains a developed-channel CPU control problem without an interior fan interface or general CFD solve. Run `node --test plugins/thermal/tests/fan-stokes.mjs`.

`tests/mac-projection-reference.mjs` implements a bounded closed-domain 3D MAC pressure-projection CPU reference with solid-cell obstacles and per-component gauges. It is an incompressibility substep, not a complete Stokes/CFD solver. Run `node --test plugins/thermal/tests/mac-projection.mjs`; AIRFLOW-DESIGN.md lists the boundary and physics exclusions.

`tests/mac-viscosity-reference.mjs` adds backward-Euler MAC velocity diffusion with no-slip outer/partition walls. Supported fluid components must be rectangular chambers; arbitrary embedded obstacles reject explicitly. This is a test-only viscous substep, not a coupled Stokes integrator. Run `node --test plugins/thermal/tests/mac-viscosity.mjs`.

`tests/mac-step-reference.mjs` composes initialized projection, implicit viscosity and final projection as a first-order split CPU timestep. It reports stage energy changes and only a projection pressure correction; it is not an exact coupled Stokes solver. `tests/mac-step.mjs` verifies temporal refinement against a separate dense constrained-Stokes reference. AIRFLOW-DESIGN.md also specifies the future local-X fan actuator and its missing boundary/energy gates; actuator forcing is not implemented.

`tests/mac-fan-reference.mjs` implements a restricted local-X ideal fan sheet impulse with corrected-flow pressure-curve coupling in an obstacle-free closed box. It reports midpoint provisional work separately from projection loss; this is not physical shaft heating or sustained duct throughput. Full-span sheets produce pressure balance without invented flow. See AIRFLOW-DESIGN.md and `tests/mac-fan.mjs`.

`tests/mac-fan-step-reference.mjs` combines viscosity/projection followed by the fan impulse so the final returned flow satisfies the fan curve. It reports separate corrections and split-energy accounting, with fan-off/vanishing-viscosity/full-span limits tested in `tests/mac-fan-step.mjs`. It is an obstacle-free closed-box CPU reference, not a monolithic fan-flow solver or thermal convection.

`tests/mac-forced-duration.mjs` quantifies forced temporal refinement and steady bias against an independently assembled dense coupled Stokes/fan system. See AIRFLOW-DESIGN.md for measured errors and the distinction between split bookkeeping and physical energy balance. `TEMPERATURE-ADVECTION-DESIGN.md` specifies the future conservative shared-flux/CFL/energy validation plan; scalar advection is not implemented.

`tests/temperature-advection-reference.mjs` implements test-only conservative passive Kelvin transport with shared enthalpy fluxes, closed/explicit-periodic topology and outgoing CFL≤0.9. Solids, sources and conduction coupling are explicitly unsupported. `tests/temperature-advection.mjs` checks energy, extrema, local divergence and analytic translation; see TEMPERATURE-ADVECTION-DESIGN.md for measured first-order numerical mixing and limits.

`tests/flow-temperature-step-reference.mjs` adds a test-only one-way flow→passive-temperature split with a scalar-ready divergence check, final fan-curve recheck, same-dt CFL enforcement and separate thermal/flow energy diagnostics. `tests/flow-temperature-step.mjs` verifies analytic limits and temporal convergence against independent dense flow/face transport. Solid/source/conduction coupling remains explicitly unsupported.

`tests/fluid-heat-reference.mjs` adds ≤512-cell constant-property implicit conduction and signed explicit fluid source input after passive transport. Closed adiabatic all-fluid scope only; no Material/Heater tag or solid-interface integration. Tests cover cosine decay, heating/cooling, source energy, timestep/range guards and modal convergence. See TEMPERATURE-ADVECTION-DESIGN.md for split ordering and limits.

`tests/conjugate-layer-reference.mjs` adds a ≤256-cell flat fluid/solid perfect-contact heat reference: fluid-only conservative advection, reciprocal shared-face conduction and separate material heat capacities. `tests/conjugate-layer.mjs` checks analytic layered resistance, region energy exchange and closed equilibrium. It does not integrate fan/obstacle flow or scene tags. See CONJUGATE-HEAT-DESIGN.md for boundaries and unsupported models.

`solidSourceDensity` in the layered reference now supports signed solid-only W/m³ input. `tests/fan-conjugate-reference.mjs` runs fan/viscous flow exclusively on the left fluid subgrid, then one fluid-advection/shared-conduction/source step; the solid and interface stay impermeable. `tests/fan-conjugate.mjs` checks analytic heater heat paths, quadratic solid profiles, region/global energy and fan-off/one-way limits. No native source tags or arbitrary obstacle flow are integrated.

## Internal shared-GPU layered heat adapter

`layered-heat-gpu.js` provides a bounded explicit-SI transient layered conduction/source path on the borrowed shared device, reusing the existing conduction kernel. Kelvin input/output is converted explicitly; no flow/advection/scene solving is implied. `tests/layered-gpu-checks.mjs` adds real-hardware fixtures to the existing harness; those gates must run before claiming GPU verification. GPU-INTEGRATION-PLAN.md records reusable kernels, exact missing native contracts and performance budgets.

Internal `mac-projection-gpu.js` qualifies bounded all-fluid closed-box pressure
projection on the borrowed GPU. It has strict Float32/local divergence gates,
no CPU fallback, no scene command and no hardware validation yet. Full bounded
readback is intentional at this stage; see GPU-INTEGRATION-PLAN.md before reuse.

`mac-viscosity-gpu.js` adds internal bounded closed-box implicit viscosity
qualification, with no-slip MAC walls, per-component actual-field residual and
energy checks. It is separate from projection and has no scene/timestep API.
Hardware execution remains unverified; see GPU-INTEGRATION-PLAN.md.

`mac-fan-gpu.js` qualifies a partial internal local-X ideal fan sheet using GPU
pressure projections and an actual GPU impulse. Corrected flow, operating-pressure
conditioning and midpoint mechanical work are validated. Full-span sheets and
scene/thermal/timestep integration remain unsupported; hardware is unverified.

`temperature-advection-gpu.js` qualifies bounded all-fluid passive Kelvin advection
with shared upwind face fluxes and conservative gather, explicit closed/periodic
boundaries, CFL and actual returned-field/energy gates. Strict divergence-free
input is required; no combined GPU flow/heat or scene claim. Hardware unverified.

V27 adds explicit opt-in local divergence drift budgets (<=0.001K/step and
|dt*div(u)|<=1e-6 per cell before/after upload) and a one-step projection/passive
transport qualification wrapper. Strict transport remains default. Local artificial
compression error is reported separately from Float32 error; no duration accuracy
or complete CFD/scene claim. See GPU-INTEGRATION-PLAN.md.

`forced-temperature-gpu.js` qualifies one initialized viscosity→fan/projection→
passive transport step with explicit local drift budget and separate mechanical/
thermal bookkeeping. It has no solids, conduction, momentum advection, heat feedback
or scene API. No real GPU execution or duration accuracy is claimed.

V29 adds `fluid-heat-gpu.js` and `forced-heat-gpu.js`: existing GPU conduction kernel,
explicit Kelvin conversion, adiabatic constant-fluid conduction and signed source
once after passive advection. Returned physical BE/source/energy gates reject
unresolved sources. No solids, other thermal boundaries or scene claim; hardware
execution remains unverified.

`conjugate-heat-gpu.js` qualifies an explicit flat left-fluid/right-solid domain:
fluid-confined fan/viscosity/advection followed by V22 shared perfect-contact heat
assembly with solid heater once. Actual local/global/regional energy checks and
zero interface/solid velocity are required. Adiabatic only, no native scene or
actual GPU execution claim.

## V31: native geometry and tag bridge to one conjugate GPU step

`scene-conjugate.js` connects the existing exact two-cuboid classifier and native
Material/Heater SI mapper to `stepConjugateHeatGPU`. It is internal qualification,
not a registered scene command or a completed Thermal release. There is no new
UI, catalogue entry, external CFD dependency, or CPU production fallback.

`stepTouchingSceneConjugateGPU(context, thermalHash, request)` accepts explicit
`dimensions` (2..16 per axis), `cellSizeMM` (owner-local millimetres), `settings`
and an optional `signal`. The exact complete cuboids must share a full local-X
face. `settings.fluidOccurrence` must explicitly identify the left captured
occurrence with at least two X cells; material tags alone never imply fluid.
The right cuboid is the solid. Other interfaces, arbitrary shapes, uncertain
cells, holes, overlaps, and additional scene occurrences reject.

Settings require `fluidDensity` and `solidDensity` in kg/m³, `fluidViscosity` in
Pa s, `timeStep` in seconds and `divergenceDriftBudgetK` (0..0.001 exclusive at
zero). Native Material conductivity and volumetric heat capacity are authoritative;
specific heat is derived from the explicitly supplied density and checked.
`initialCelsius` is one value or one per full-domain cell, defaulting to the
owner's Initial. Kelvin conversion occurs explicitly at the GPU contract.
Outer walls are adiabatic; owner Ambient is not silently imposed. Every call
starts at rest and runs ONE timestep, not a continuation or duration simulation.

Heater watts are normalized by existing provenance-aware `sceneGridInputs`, over
the complete classified solid volume. Any Heater on the fluid, including a shared
inherited Heater or zero-valued tag, rejects rather than being reassigned to the
solid. Source sign and power are preserved and the source enters only the existing
conjugate heat stage. Owner scale, rotation, reflection and translation use the
existing physical frame conversion exactly once.

`settings.fanBox` has owner-local `centerMM` and positive `sizeMM`, plus
`shutoffPressure` (Pa), `freeFlow` (m³/s), and `direction` (+1 or -1 along owner-local
X). The entire box must be inside fluid. Its centre X plane and Y/Z footprint
must be exactly aligned to grid faces; no snapping is performed. Physics uses
one thin actuator sheet at the box centre. X thickness is a containment/authoring
extent, NOT a volumetric body force, fan housing, or aerodynamic thickness model.
A full-span sheet remains unsupported by this bounded GPU stage.

The returned runtime-only handle has bounded Celsius `inspect`, bounded
`inspectVelocity(component,offset,count)` in m/s along orthonormal owner axes,
resistance-aware native `measureProbe`, detached diagnostics, and idempotent
`dispose`. Source signature plus exact transforms, owner identity/parameters/world
frame, shared device, abort and Probe changes are checked before/after asynchronous
work. No partial field is published. Bounded full-field host snapshots remain
qualification overhead; retained GPU bytes are zero. Host field bytes are reported
separately from metadata, temporary arrays and browser memory. Runtime fields never
enter Undo/HASH or native plugin job storage.

Focused command: `node --test plugins/thermal/tests/scene-conjugate.mjs`.
Hardware command: `node plugins/thermal/tests/scene-conjugate-browser.mjs --headless`.
The latter creates a fresh isolated browser context, authors two real native
buffer meshes with inherited tags and Probe via frameAI, observes the actual
plugin bridge through a test-only activation route, and runs the production
classifier/timestep. Signed heat and both fan directions are compared with an
independent Float64 reference; native Heater edits must retire the result.
It records the actual renderer device identity, frame timing, source hashes,
completed-operation budgets and GPU errors. It is also called by Thermal's normal
browser suite. CPU injection tests do not establish hardware validation.

### Native helper shader return regression

The helper is lines-only: its surface shader always discards the fragment.
WGSL still requires an explicit vec4f return in this non-void helper function;
`discard; return vec4f(0.0);` preserves the no-surface contract while satisfying
shader compilation. The regression captures the actual descriptor from activate,
including unchanged line geometry, bounds and settings. This source-level test is
not a substitute for the native browser/GPU compile-and-render check.

### Probe reading lifetime across editor selection

Native documentChanged also runs for selection-only renders. It now revalidates
cached Probe readings instead of clearing them unconditionally. The display keeps
its last measured Celsius value only while the exact ready source job/result,
shared device, Thermal owner identity/settings/world frame and Probe
identity/reference/enabled/world frame remain current. Changed or removed records
are pruned; undoing a Probe move does not resurrect a previously invalidated
reading. Clear, replacement/failed solve and restored native identities invalidate
old readings. A new measure still clears its previous display before asynchronous
sampling and retains all after-read guards.

These native cached readings belong to the explicit-grid API, which does not
consume arbitrary scene geometry. Internal geometry/conjugate scene fields retain
their independent exact source-signature guards unchanged. Geometry inspection
cancellation is also unchanged. The real browser test that selects a measured
Probe and requires its numeric Measure label remains strict. The dedicated
probe-reading-lifecycle.mjs suite executes the shipped native controller with a
test-only numerical result and covers selection versus substantive invalidation.

### Internal bounded conjugate duration (hardware qualification pending)

`scene-conjugate-duration.js` exports
`advanceTouchingSceneConjugateGPU(context, ownerHash, request)`. It reuses the
one-step native capture/map/Probe/result-lifetime wrapper and the existing
`stepConjugateHeatGPU` chain. It does not register a native job, Solve command,
object, UI, catalogue entry or another physics solver. The existing scene shape,
local-X fan, solid-only Heater and adiabatic boundary restrictions still apply.

The request has the one-step dimensions, cellSizeMM, settings and optional signal,
plus required integer `stepCount` (1 through 10) and explicit
`cumulativeDivergenceDriftBudgetK` (positive, at most 0.001 K). Total physical time
is exactly `stepCount * settings.timeStep`, positive and at most 0.1 seconds.
There is no rounded duration, adaptive final step or implicit restart/resume.
Each new scene job starts once from Initial/rest. Within that job the actual
validated T/u/v/w is passed to the next GPU timestep. Low-level
`advanceConjugateHeatGPU` can accept an explicitly supplied initial field for
qualification; native handles do not expose continuation/resume.

The per-step local divergence allowance is tightened to the smaller of the
requested step budget and cumulative budget divided by step count. Every actual
local original/uploaded-velocity drift is accumulated. Both per-cell accumulated
drift and the more conservative sum of per-step maxima are bounded. This accounts
for transport of earlier local errors; it is still a consistency allowance, not
a proven long-time numerical error estimate. Existing per-step CFL, source,
regional/interface, energy, mechanical and range rejection remain unchanged.

The final diagnostics.duration reports completed steps/time, signed source watts
and joules, actual total thermal energy change/error/allowance, accumulated
reciprocal interface transfer and regional balances, and separate mechanical work,
loss and kinetic endpoints. Source heat must equal watts times completed duration.
For nonzero net source, cumulative thermal energy allowance is also capped at
0.1% of net source energy, plus explicit Float64 bookkeeping roundoff. Mechanical
work is never added to heat. Equation residual consistency sums and transport
consistency sums are labelled as such. `temperatureAccuracyGuaranteeK` is null:
neither 0.001 K per step nor their sum certifies duration accuracy. Small heating,
extreme flow or a too-tight drift budget can legitimately reject as unresolved.

Settings and source fields are snapshotted before asynchronous work. The scene is
captured/classified once. Owner/source/exact transforms/device/loss/cancellation
are checked across each stage and final publication. Between steps a task-queue
yield permits Stop and source edits to run. A failed or cancelled job returns no
partial field, partial time or partial heat ledger; a fresh job must start over.
Disposal retires the completed handle, including Probe/velocity reads. The driver
holds only current and candidate full states, no playback history; numerical
stage scratch, caller-owned inputs and classification metadata are separate.
A module-level per-device loss subscription is shared by jobs, outside job lexical
scopes, so a pending device-loss promise cannot retain disposed scene/source state.
Per-step wall times are bounded to ten scalar entries. Final retained host field
bytes remain T/u/v/w only (976 bytes for the 24-cell fixture); this is not a claim
of resident-GPU speed or of total browser/peak scratch memory.

CPU command-emulator checks run the shipped GPU orchestration but are NOT hardware
qualification. Independent Float64 comparison at 1/2/10 steps, both heater signs
and fan signs, gives the existing reference signals. The emulator can resolve the
10-step fan redistribution (~0.00225 K) but the 2-step ~0.0000096 K signal rounds
away. Same-duration timestep refinement .02 s x 5 versus .01 s x 10 differs by
~0.00828 K in the independent reference. This is a measured temporal-discretization
effect, not an implementation tolerance to hide under a per-step accuracy claim.

Commands:
- `node --test plugins/thermal/tests/scene-conjugate-duration.mjs`
- `node plugins/thermal/tests/duration-browser-fixtures.mjs --headless`
- `node plugins/thermal/tests/run.mjs --headless` (includes duration hardware checks)

The actual shared-device harness has a whole-duration fixture reference gate of
0.0005 K and velocity discrepancy of 0.00002 m/s. The 24-cell completed job budget
is 15 seconds (including cold compilation), each step at most 5 seconds, and the
maximum timer gap below 2 seconds. Actual GPU steps are also wrapped in test-only
hooks that abort or edit a native Heater after step 1 or 2, requiring no published
handle or later step and clean scopes. These budgets must not be loosened to hide a
failed hardware run. Maximum 16x16x16 GPU duration, device-loss/responsiveness and
full application integration/performance still require qualification. The
4096-cell host-only injected-equilibrium timing is solely a bounded-lifecycle
check, not that missing GPU gate. No public or live release is enabled.


## Native job ownership candidate (not registered for release)

The isolated `solve-scene` operation now puts the existing exact two-cuboid
conjugate duration pipeline in Thermal's existing native owner job map. There is
one current result per Thermal owner, shared with `solve-grid`; starting either
replaces the other. The catalogue remains unchanged and unregistered. This stage
adds neither a second physics solver nor another scene model. Domain extent,
grid/duration settings and the numerical Fan box remain explicit request inputs;
the separate saved Fan authoring below is deliberately not consumed. The Thermal
100 mm helper is still a placeholder. No Solve
attribute button is provided, and no transient last request is replayed by UI.

`plugins.command {id: thermalHash, operation: 'solve-scene', args}` accepts:

- `dimensions`: three integers 2..16; `cellSizeMM`: three positive owner-local
  millimetre lengths. The centred grid must exactly cover the classified domain.
- `stepCount`: 1..10; `cumulativeDivergenceDriftBudgetK`: (0, 0.001] K.
- `settings`: `fluidOccurrence` (explicit captured occurrence index 0 or 1),
  positive SI `fluidDensity`, `fluidViscosity`, `solidDensity`, `timeStep`, and
  `divergenceDriftBudgetK` in (0, 0.001] K. `initialCelsius` is optional, one value
  or exactly one per grid cell; otherwise the current owner's Initial is used.
  Supported Kelvin range is 1..2000. Total time is `stepCount * timeStep <= 0.1 s`.
- `settings.fanBox`: `centerMM`, positive `sizeMM`, nonnegative `shutoffPressure`
  in Pa, positive `freeFlow` in m³/s and `direction` +1 or -1 along owner-local X.

The role is explicit, never inferred from a Material tag. This API still requires
exactly two complete captured COPY_SRC buffer-backed twelve-triangle cuboids, a
full local-X contact, at least two left-fluid X cells and a right solid. Existing
restricted exact relative transforms apply. A native procedural Cube is not
silently converted to supported geometry. Additional shapes, unresolved overlap,
partial cells, alternative roles and boundary models reject. Material and solid
Heater tags use the existing physical/provenance mapping. All outer walls are
adiabatic. Each solve starts from rest and Initial, never from a previous result.
A Heater in this closed model adds energy indefinitely; this is not steady cooling.
The fan is the existing grid-aligned partial centre sheet, not a housing or volume
force. No sections, buoyancy, momentum advection, radiation or general CFD claim
is added. There is no CPU production fallback.

### Queue, cancellation and publication

Frame validates the operation schema before its synchronous interrupt hook.
Thermal also validates cross-field request limits before interrupting an existing
job. Invalid syntax/scalars/lengths/total duration therefore preserve the current
job. Geometry/material/classification and numerical acceptance checks occur in
the new asynchronous job; an accepted request that later fails does not restore
its predecessor. Inputs are copied before asynchronous work.

The interrupt hook stops scheduling before Frame's global command queue settles.
The queued handler also targets the job immediately preceding it in execution
order, so rapid Solve → Stop/Clear and running Solve → replacement → Stop/Clear
cannot accidentally act only on an older captured job. A per-owner work tail
survives removal of the visible job record, deletion and same-hash restoration.
A replacement waits for that tail before any new GPU work. The global pending
set covers active and retiring promises for explicit completion barriers.
Only scalar source signatures/exact transform stamps and native owner identity
are retained by job bookkeeping, not captured geometry/GPU wrappers.

The field publishes atomically after the entire duration and the last current
check. Failure, cancellation, source edits, owner edits/replacement, deletion,
shared-device changes or loss publish no partial duration or field. Geometry and
exact relative transforms are checked even when core rounded signatures agree.
Undo/HASH restore authoring, not derived fields. Copy owns independent idle state.
Selection/camera changes alone preserve the field and a current Probe reading.

### Native controls, status and flush semantics

Native Attributes keep Probe and one stable Clear action. Clear is disabled when
idle. The same native action becomes Stop while running, then Clear when ready,
cancelled, stale or failed, using the core's existing busy/cancel support. It is
present from idle so no re-selection is needed. Clear refreshes the selected Probe
label immediately. No panel or custom DOM is added.

`solve-grid`, `solve-scene`, `cancel`, `clear` and `create-probe` are not readOnly.
`status`, `inspect`, `inspect-velocity` and `measure` are readOnly authoring
operations; they may retire stale runtime resources. `status` reports `job`,
`state`, `error`, bounded dimensions/cell sizes/resource metrics and, for the
scene candidate, `stage: 'two-cuboid-conjugate-duration'`, `geometryCoupled: true`,
`authoring: 'explicit-request'`, `boundary: 'adiabatic'`, `initialVelocity: 'rest'`,
completed `duration` balances and fan pressure/flow. `sceneSolver` and
`generalSceneSolver` remain false to avoid advertising a general scene solver.
No per-cell field arrays appear in status. `inspect-velocity` requires `component`
u/v/w and optional offset/count (at most 256), returning m/s in the owner's
physical orthonormal axes. Explicit-grid jobs reject this velocity operation.

Generic `flush()` no longer waits for numerical work. Because Frame calls generic
flush before and after every API command, Solve now actually returns while its
background job runs, and status/selection can observe it. Explicit
`flush({author:true})`, `flush({output:true})` and `flush({render:true})` drain
active and retired work present at the barrier. Cancel and Clear themselves drain
the work they stop. `flush({simulation:true})` does not start or advance Thermal,
and generic navigation does not create timesteps. Callers must poll status with
a bounded deadline before inspecting a result; a returned `running` snapshot is
not a completion assertion. Existing numerical tests now use explicit completion
barriers while retaining their original field, energy and Probe assertions.

Probe samples exactly its referenced owner's current job/result. Restricted scene
jobs dispatch to the existing physical-frame, resistance-aware Probe method;
explicit grids retain their original convention. After asynchronous measurement,
source/job/Probe identity and parameters are checked again. Replacing a field,
clearing it, or changing the Probe invalidates cached labels without resurrecting
older readings.

### Verification and remaining authoring work

`node --test plugins/thermal/tests/native-job.mjs` exercises the shipped native
controller and GPU orchestration through a test-only CPU command emulator. It
covers shared job ownership, nonblocking generic flush, explicit barriers,
repeated/queued requests, Stop during classification/pipeline/heat readback,
selection versus substantive edits, deletion/restore, final-resolution race,
Probe ownership, bounded resources and latency. This is not WGSL/hardware proof.

`node plugins/thermal/tests/native-job-browser.mjs --headless` uses a fresh browser
context, actual frameAI commands, native tags/transforms/Undo/HASH and real GPU
stages. Test-only hooks pause asynchronous stages and the final publication point;
they do not substitute numerical results. It requires identifiable non-software
hardware, checks the entire native ten-step field against the independent Float64
reference, tests Stop/Clear without reselecting, source/final races, queue/barrier
semantics and records source hashes/GPU errors/frame timing. It is included in the
full Thermal browser suite. It must be executed successfully on actual hardware
before this native integration is qualified; prior lower-level hardware reports
do not certify this changed controller. No browser result is claimed here.

Authoritative native domain/grid/duration settings, hardware qualification of the saved-Fan solver
coupling and complete native reference copy/drop semantics, rendered
sections, broader geometry and maximum-grid duration qualification remain open.
Public catalogue registration and live publication remain blocked on these
requirements and complete application checks.

## Separate native Fan authoring candidate

`thermal_fan` is a separate ordinary native object. The Thermal **Fan** action
(`create-fan`) creates one child in one document transaction, explicitly sets its
Thermal reference to that owner, and selects its ordinary Attributes. Standalone
`plugins.create {plugin:'thermal', type:'thermal_fan'}` leaves it unassigned. No
loading-time object, inferred owner, custom panel, extra scene model or numerical
state is created. Creation and inspection remain authoring-only within this isolated, unregistered
candidate. The separate solve-saved-fan operation is documented above.

The box is exactly the existing helper's local `[-50,50]³` under the object's
ordinary native transform. Position, rotation and scale are the sole saved pose
and dimensions. New Fans start at owner-local `[-25,-12.5,-12.5]` mm with scale
`[.25,.25,.25]`, a 25 mm cube. This is only a convenient aligned starting pose for
the proposed 100 mm/4³ fixture, not a domain, material or grid eligibility claim.
Thermal's own helper is still a placeholder, not an authoritative scene domain.
Native arbitrary rotations, shear, reflections, parenting and references remain
editable even when the restricted physical mapping rejects them.

Fields are Thermal (native reference), Shutoff pressure (nonnegative Pa), Free
flow (positive m³/s), and Direction (Forward/Reverse along the Fan's local X).
The default zero pressure is deliberate fan-off authoring. Free flow's generic
0.1 default is not a measured fan specification or material preset. Positive
subnormal values can be authored; this does not promise numerical admissibility.
API parameter validation rejects wrong types, nonfinite values, invalid reference
targets and nonpositive free flow before mutation. Historical native reference drop defects were fixed in the inherited R6 core;
see CORE-AUTHORING-BLOCKERS.md and the later R6 reference/selection gate evidence.

### Native default-frame correction

The Fan creation hook now initializes `creationFrame` with the core's packed
native affine matrix, built with `context.math.I()` and `context.math.pack()`.
The previous `n.transform` assignment only changed obsolete fallback UI values;
actual native synchronization ignored it and created a 100 mm box at the origin.
The 25 mm/offset starting convention above is unchanged. The initializer is
consumed once and removed by core synchronization; later native edits remain
authoritative. All solver behavior is unchanged. The later, separate Probe
initializer correction is documented in the Native Probe section above.

`native-creation-fixture.mjs` extracts and executes the current core's create,
plugin document bridge, visibility sync, native sync, record installation and
frame/math readers. It replaces the former test fixture's invented conversion
from `n.transform` to native matrices. The focused CPU regression explicitly
reproduces the old 100 mm/origin defect, rejects it as the expected Fan default,
and checks standalone creation, parent-local composition, one-shot consumption,
repeated synchronization, and preservation of later native edits. Its 32 complete
source-extracted creation/sync operations must finish within 1500 ms. This is a
CPU source contract, not browser/rendering/Undo/HASH hardware qualification.
See [the exact default-frame diagnosis and remaining gates](NATIVE-FAN-DEFAULTS-FIX.md).

### Presentation and read-only inspection

The shared native box supplies ordinary picking, bounds, transforms and visibility.
Use the existing local transform X gizmo to read its axis; Forward/Reverse supplies
the sign. Core currently has one viewport descriptor per plugin and no per-type
static line selector. No Fan arrow is drawn on Thermal/Probe, no custom renderer
or duplicate plugin is introduced, and no new GPU resources are owned here.

`fan-inputs {}` accepts a Thermal owner or an individual Fan. It does no geometry
capture/readback/GPU work, stores no authoritative cache, and returns detached
bounded metadata:

- Selection reports `unique`, `missing`, `multiple` or `unresolved-owner` by
  explicit Thermal reference and each Fan's **direct** enabled flag. Hidden Fans
  still count. An owner target only includes a Fan record when this selection is
  unique; an individual Fan target always inspects that specific record.
- Owner resolution, curve profile and frame mapping have independent statuses.
  A disabled owner is explicitly reported. Ancestor enabled semantics are
  `not-qualified`; direct-enabled uniqueness is not effective physical activation.
- `directionLocal` is signed ±X. `normalizedWorldAxis` is its normalized actual
  world-space direction, including reflection and native rotation, or null when
  the frame cannot provide one. `box` reports the 100 mm local helper size and
  finite world edge lengths/centre when representable.
- `mapping.status:'supported-frame'` requires the Fan to be a direct native child
  of its explicitly referenced owner. It reads `document.local` and verifies the
  evaluated world matrix exactly equals `math.mul(ownerWorld,local)`, rejecting
  mismatched evaluated constraints. This avoids inverse roundoff under common
  owner rotation. The relative matrix must be exactly positive diagonal scale
  plus translation, with no tolerance or snapping. Owner physical-frame validation
  reuses `copyPhysicalFrame`. Other hierarchy arrangements are valid authoring but
  unsupported mapping. No hierarchy inference changes the reference.
- Mapping derives owner-local `centerMM` and `sizeMM` only from that frame. It
  **does not** validate fluid role, box containment, grid-face alignment, partial
  internal-sheet extent, ancestor state or numerical/GPU acceptance. The response
  and mapping always say `solverEligible:false`, with `solverCoupled:false` at
  the response level. A supported frame alone is never a valid solver input.

Material/Heater tags remain independent and authoritative on actual captured
geometry. A Fan helper is not a solid, source mesh, housing or force volume; no
tag or material is automatically attached. X thickness is authoring extent only.
`solve-scene` still accepts its existing explicit numeric `settings.fanBox` and
does not read saved Fans. Consequently Fan edits, disabling, reparenting and
removal do not retire or alter an explicit-request field. Actual source/tag/owner
changes retain the existing invalidation checks. The distinct solve-saved-fan operation now adds its own complete ownership and
invalidation contract without mixing those two fan inputs; see
NATIVE-SAVED-FAN-JOB.md.

### Persistence gates and verification

Parameters and transforms use native Undo/HASH only. Earlier source inspection
identified two generic core defects (fixed in the inherited R6 core): ordinary copying does not remap plugin reference
parameters, and native object-reference drop stores session IDs while bypassing
plugin validation. See [exact core reference blockers](CORE-AUTHORING-BLOCKERS.md).
No plugin workaround is introduced; the original failure gates remain to detect regressions.

`node --test plugins/thermal/tests/native-fan.mjs` covers the shipped native hooks,
actual extracted core creation/synchronization/record installation and affine
math, strict validation, signed direction, exact
common owner rotation/reflection/scaling, unsupported transforms, detached finite
metadata, ambiguity/disabled semantics, helper/source separation and unchanged
explicit-request ownership. Its 1000 inspections of a 10000-record native document
have a 1500 ms CPU budget. These are not real editor/GPU tests.

`node plugins/thermal/tests/native-fan-browser.mjs --headless` is the actual
fresh-context frameAI/native UI/hardware harness. It checks the Fan Attributes
button, native transforms and Undo/Redo, live reference changes and actual
reference drag/drop, wrong-type rejection, helper geometry exclusion, native
source invalidation, HASH Open/Merge, Duplicate and clipboard remapping. Mandatory
budgets are 1500 ms for ordinary completed edits, 3000 ms for 100 API inspections,
10000 ms for 32 native Fan creations, and each measured CPU/GPU frame below 50 ms.
It records exact source hashes and requires real timestamp-query frame timings.
It is included in Thermal's full browser suite. Known failing reference assertions
are not skipped. A future successful run must include the corrected core bytes.

This cloud copy has no pinned Playwright Chromium executable. Standard and stress
commands stop at launch after their 64 pre-browser assertions; browser checks, rendering,
actual Undo/HASH/copy/drop and GPU timing are **not verified** here. No browser
fallback, software adapter, Windows/user-scene execution, package or publication is
performed by this authoring task. Full application/stress and large-scene gates
remain necessary in addition to the focused CPU tests.
