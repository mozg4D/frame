import {sharedThermalDeviceState} from './scene-identity.js';
// Internal bounded GPU projection qualification path, not a scene solver.
const error=(code,message)=>Object.assign(new Error(message),{code});
const need=(ok,code,message)=>{if(!ok)throw error(code,message);};
export function assembleMACProjection(input){
 const allowed=['dimensions','size','u','v','w','density','timeStep','tolerance','maxIterations','obstacle'];
 need(input&&typeof input==='object'&&!Array.isArray(input)&&!Object.keys(input).some(k=>!allowed.includes(k)),'INVALID_ARGUMENT','Explicit bounded closed MAC grid required.');
 const {dimensions:d,size,density,timeStep,tolerance=1e-4,maxIterations=20000}=input;
 need(Array.isArray(d)&&d.length===3&&Array.from(d).every(x=>Number.isInteger(x)&&x>=2&&x<=16)&&Array.isArray(size)&&size.length===3&&Array.from(size).every(x=>Number.isFinite(x)&&x>0)&&Number.isFinite(density)&&density>0&&Number.isFinite(timeStep)&&timeStep>0&&Number.isFinite(tolerance)&&tolerance>=1e-5&&tolerance<=1e-3&&Number.isInteger(maxIterations)&&maxIterations>=1&&maxIterations<=20000,'INVALID_ARGUMENT','Invalid bounded MAC settings.');
 const n=d.reduce((a,b)=>a*b),h=size.map((s,a)=>s/d[a]),hmin=Math.min(...h),inv=h.map(x=>Math.fround(hmin/x));
 need(inv.every(x=>x>=.1&&x<=1),'UNSUPPORTED_DOMAIN','Cell aspect ratio must be at most ten.');
 // Only one exact, whole-cell, strictly interior cuboid is supported. This is
 // explicit numerical geometry, never a native mesh classifier or a cut cell.
 let obstacle=null;const solid=new Uint8Array(n),faceMasks=new Uint32Array(n);
 const property=Object.getOwnPropertyDescriptor(input,'obstacle');
 need(!('obstacle' in input)||(property?.enumerable&&Object.hasOwn(property,'value')),'INVALID_ARGUMENT','Obstacle must be an own enumerable data field.');
 if(property){
  const o=property.value;
  need(o&&typeof o==='object'&&[Object.prototype,null].includes(Object.getPrototypeOf(o))&&Reflect.ownKeys(o).length===2&&Reflect.ownKeys(o).every(k=>['min','max'].includes(k)),'INVALID_ARGUMENT','One exact whole-cell cuboid min/max pair required.');
  obstacle={};for(const k of ['min','max']){
   const field=Object.getOwnPropertyDescriptor(o,k);need(field?.enumerable&&Object.hasOwn(field,'value'),'INVALID_ARGUMENT','Obstacle bounds must be plain data.');const a=field.value;
   need(Array.isArray(a)&&a.length===3&&Reflect.ownKeys(a).length===4,'INVALID_ARGUMENT','Dense exact three-index obstacle bounds required.');
   obstacle[k]=[0,1,2].map(i=>{const v=Object.getOwnPropertyDescriptor(a,String(i));need(v?.enumerable&&Object.hasOwn(v,'value')&&Number.isInteger(v.value),'INVALID_ARGUMENT','Integer obstacle bounds must be plain data.');return v.value;});
  }
  need(obstacle.min.every((v,a)=>v>=1&&v<obstacle.max[a]&&obstacle.max[a]<=d[a]-1),'UNSUPPORTED_DOMAIN','Obstacle must be nonempty and strictly interior with a fluid-cell shell.');
  for(let z=obstacle.min[2];z<obstacle.max[2];z++)for(let y=obstacle.min[1];y<obstacle.max[1];y++)for(let x=obstacle.min[0];x<obstacle.max[0];x++)solid[x+d[0]*(y+d[1]*z)]=1;
 }
 const fields=['u','v','w'].map((k,a)=>{const shape=[...d];shape[a]++;const v=input[k];need((Array.isArray(v)||v instanceof Float32Array||v instanceof Float64Array)&&v.length===shape.reduce((x,y)=>x*y)&&Array.from(v).every(Number.isFinite),'INVALID_ARGUMENT','Dense finite MAC velocities required.');return Float64Array.from(v);});
 let speed=0;for(const f of fields)for(const v of f)speed=Math.max(speed,Math.abs(v));if(speed===0)speed=1;
 const edges=[],rows=new Float32Array(n),id=p=>p[0]+d[0]*(p[1]+d[1]*p[2]);
 for(let a=0;a<3;a++){const shape=[...d];shape[a]++;for(let z=0;z<shape[2];z++)for(let y=0;y<shape[1];y++)for(let x=0;x<shape[0];x++){
  const p=[x,y,z],f=x+shape[0]*(y+shape[1]*z),v=fields[a][f];
  if(p[a]===0||p[a]===d[a]){need(v===0,'INVALID_BOUNDARY','Outer normal velocities must be zero.');continue;}
  const right=id(p);p[a]--;const left=id(p);
  if(solid[left]||solid[right]){need(v===0,'INVALID_BOUNDARY','Every solid-adjacent normal velocity must be zero.');continue;}
  const q=Math.fround(v/speed);
  need(v===0||(q!==0&&Math.abs(q*speed/v-1)<1e-6),'NUMERICAL_RANGE','Velocity dynamic range exceeds Float32 contract.');
  need(!obstacle||q===0||Math.abs(q)>=2**-126,'NUMERICAL_RANGE','Masked normalized velocities must be normal Float32 values.');
  edges.push({left,right,axis:a,index:f,inv:inv[a],q});faceMasks[left]|=1<<(2*a+1);faceMasks[right]|=1<<(2*a);
 }}
 const fluidCount=n-solid.reduce((a,b)=>a+b,0);
 if(obstacle){
  // Check the generated graph, not merely the cuboid's promised topology.
  const reached=new Uint8Array(n),queue=[0],stride=[1,d[0],d[0]*d[1]];reached[0]=1;
  for(let j=0;j<queue.length;j++){const i=queue[j];for(let a=0;a<3;a++)for(let side=0;side<2;side++)if(faceMasks[i]&(1<<(2*a+side))){const k=i+(side?1:-1)*stride[a];need(!solid[k]&&(faceMasks[k]&(1<<(2*a+1-side))),'UNSUPPORTED_DOMAIN','Nonreciprocal fluid face.');if(!reached[k]){reached[k]=1;queue.push(k);}}}
  need(fluidCount>=2&&queue.length===fluidCount,'UNSUPPORTED_DOMAIN','One connected fluid component required.');
 }
 // Assemble from the exact uploaded face data; never independently round cell RHS.
 const rhs64=new Float64Array(n);for(const e of edges){const q=e.q*e.inv;rhs64[e.left]-=q;rhs64[e.right]+=q;}
 rows.set(rhs64);let rhsNorm=0;for(const x of rhs64)rhsNorm=Math.max(rhsNorm,Math.abs(x));
 if(obstacle){let sum=0;for(const x of rows)sum+=x;need(Math.abs(sum)<=fluidCount*tolerance*rhsNorm*.25,'NUMERICAL_RANGE','Rounded pressure RHS is incompatible with the closed fluid graph.');}
 const pressureScale=density*hmin*speed/timeStep,divergenceScale=speed/hmin,energyScale=.5*density*h.reduce((a,b)=>a*b)*speed*speed;
 need([pressureScale,divergenceScale,energyScale].every(x=>Number.isFinite(x)&&x>=2**-1022),'NUMERICAL_RANGE','Physical scales are unrepresentable.');
 return {dimensions:[...d],n,h,obstacle,solid,faceMasks,fluidCount,inv,trueInv:h.map(x=>hmin/x),fields,edges,rhs:rows,rhsNorm,speed,pressureScale,divergenceScale,energyScale,tolerance,maxIterations};
}
export const macProjectionWGSL=`
struct Config { dims:vec4<u32>, inv:vec4<f32> }
@group(0) @binding(0) var<uniform> c:Config;
@group(0) @binding(1) var<storage,read> rhs:array<f32>;
@group(0) @binding(2) var<storage,read> p:array<f32>;
@group(0) @binding(3) var<storage,read_write> next:array<f32>;
@group(0) @binding(4) var<storage,read> edges:array<vec4<f32>>;
@group(0) @binding(5) var<storage,read_write> velocityOut:array<f32>;
@group(0) @binding(6) var<storage,read_write> metric:atomic<u32>;
@group(0) @binding(7) var<storage,read> faceMasks:array<u32>;
fn sums(i:u32)->vec2<f32>{
 let stride=vec3<u32>(1u,c.dims.x,c.dims.x*c.dims.y);var diag=0.;var sum=0.;
 for(var a=0u;a<3u;a++){let w=c.inv[a]*c.inv[a];if((faceMasks[i]&(1u<<(2u*a)))!=0u){diag+=w;sum+=w*p[i-stride[a]];}if((faceMasks[i]&(1u<<(2u*a+1u)))!=0u){diag+=w;sum+=w*p[i+stride[a]];}}
 return vec2<f32>(diag,sum);
}
@compute @workgroup_size(64) fn iterate(@builtin(global_invocation_id) gid:vec3<u32>){
 let i=gid.x;if(i>=arrayLength(&rhs)){return;}let s=sums(i);if(s.x==0.){next[i]=0.;return;}
 // Gauge-free damped Jacobi. Only pressure differences are physical.
 next[i]=p[i]+0.6666666667*((rhs[i]+s.y)/s.x-p[i]);
}
@compute @workgroup_size(64) fn residual(@builtin(global_invocation_id) gid:vec3<u32>){
 let i=gid.x;if(i>=arrayLength(&rhs)){return;}let s=sums(i);if(s.x==0.){return;}let r=abs(rhs[i]-(s.x*p[i]-s.y));atomicMax(&metric,bitcast<u32>(r));
}
@compute @workgroup_size(64) fn correct(@builtin(global_invocation_id) gid:vec3<u32>){
 let i=gid.x;if(i>=arrayLength(&edges)){return;}let e=edges[i];velocityOut[i]=e.w-(p[u32(e.y)]-p[u32(e.x)])*e.z;
}`;
// Independently validate actual GPU values, including local divergence, energy,
// pressure reconstruction and finiteness. This bounded full readback is deliberate.
export function validateMACProjection(plan,pressure,velocity){
 const {n,edges,rhsNorm,tolerance,energyScale}=plan;
 need(pressure.length===n&&velocity.length===edges.length&&Array.from(pressure).every(Number.isFinite)&&Array.from(velocity).every(Number.isFinite),'NUMERICAL_RANGE','Invalid GPU result.');
 if(plan.obstacle)for(let i=0;i<n;i++)need(!plan.solid[i]||pressure[i]===0,'NUMERICAL_RANGE','Solid pressure slots must stay zero.');
 const div=new Float64Array(n),local=new Float64Array(n);let before=0,after=0;
 for(let j=0;j<edges.length;j++){const e=edges[j],v=velocity[j],correction=(pressure[e.right]-pressure[e.left])*e.inv,reconstructed=e.q-correction;
  // Input pressures are exact Float32 values represented in Float64 here.
  // Subtraction/multiplication error scales with the actual correction, not
  // either pressure magnitude: an arbitrary gauge must not weaken this gate.
  const roundoff=32*2**-23*(Math.abs(e.q)+Math.abs(correction));
  need(Math.abs(v-reconstructed)<=roundoff,'NUMERICAL_RANGE','Returned velocity does not match pressure correction.');
  const flux=v*plan.trueInv[e.axis];div[e.left]+=flux;div[e.right]-=flux;local[e.left]+=Math.abs(flux);local[e.right]+=Math.abs(flux);before+=e.q*e.q;after+=v*v;
 }
 let maxDivergence=0,maxAllowance=0;
 for(let i=0;i<n;i++){const allowance=tolerance*rhsNorm+64*2**-23*local[i];need(Math.abs(div[i])<=allowance,'NONCONVERGENCE','Returned GPU field violates local divergence budget.');maxDivergence=Math.max(maxDivergence,Math.abs(div[i]));maxAllowance=Math.max(maxAllowance,allowance);}
 const energyBefore=before*energyScale,energyAfter=after*energyScale;
 need(Number.isFinite(energyBefore)&&Number.isFinite(energyAfter)&&(before===0||energyBefore>=2**-1022)&&(after===0||energyAfter>=2**-1022),'NUMERICAL_RANGE','Kinetic energy is unrepresentable.');
 need(energyAfter<=energyBefore*(1+1e-4),'NONCONVERGENCE','Projection increased kinetic energy.');
 return {energyBefore,energyAfter,maxDivergence:maxDivergence*plan.divergenceScale,maxDivergenceAllowance:maxAllowance*plan.divergenceScale};
}
export function validateMaskedPhysicalProjection(plan,pressure,fields){
 need(plan.obstacle&&pressure.length===plan.n&&fields.length===3,'INVALID_ARGUMENT','Masked projection result required.');
 const div=new Float64Array(plan.n),reconstructedDiv=new Float64Array(plan.n),local=new Float64Array(plan.n),reconstructedLocal=new Float64Array(plan.n);
 for(const e of plan.edges){
  const q=plan.fields[e.axis][e.index]/plan.speed,actual=fields[e.axis][e.index]/plan.speed;
  // Returned SI pressure, original SI input and physical h. The solid zero
  // slots are not a gauge anchor for the connected fluid pressure field.
  const correction=(pressure[e.right]-pressure[e.left])/plan.pressureScale*plan.trueInv[e.axis],reconstructed=q-correction;
  const allowance=32*2**-23*(Math.abs(q)+Math.abs(correction));
  need(Number.isFinite(actual)&&Number.isFinite(reconstructed)&&Math.abs(actual-reconstructed)<=allowance,'NUMERICAL_RANGE','Physical pressure does not reconstruct the original velocity correction.');
  for(const [v,d,l] of [[actual,div,local],[reconstructed,reconstructedDiv,reconstructedLocal]]){const flux=v*plan.trueInv[e.axis];d[e.left]+=flux;d[e.right]-=flux;l[e.left]+=Math.abs(flux);l[e.right]+=Math.abs(flux);}
 }
 for(let i=0;i<plan.n;i++)for(const [d,l] of [[div,local],[reconstructedDiv,reconstructedLocal]])need(Math.abs(d[i])<=plan.tolerance*plan.rhsNorm+64*2**-23*l[i],'NONCONVERGENCE','Actual physical pressure/velocity violates the original local divergence budget.');
 // All absent faces, including solid-solid interior faces, remain exactly zero.
 const open=fields.map(f=>new Uint8Array(f.length));for(const e of plan.edges)open[e.axis][e.index]=1;
 for(let a=0;a<3;a++){need(fields[a].length===plan.fields[a].length,'NUMERICAL_RANGE','Invalid returned MAC shape.');for(let i=0;i<fields[a].length;i++)need(Number.isFinite(fields[a][i])&&(open[a][i]||fields[a][i]===0),'NUMERICAL_RANGE','Returned blocked velocity must be exactly zero.');}
 for(let i=0;i<plan.n;i++)need(Number.isFinite(pressure[i])&&(!plan.solid[i]||pressure[i]===0),'NUMERICAL_RANGE','Invalid physical pressure.');
}

async function checked(device,work){
 device.pushErrorScope('validation');device.pushErrorScope('out-of-memory');let value,failure;try{value=work();}catch(e){failure=e;}
 const pending=[device.popErrorScope(),device.popErrorScope()];const errors=await Promise.all(pending);if(failure)throw failure;const problem=errors.find(Boolean);if(problem)throw error('GPU_ERROR',problem.message);return value;
}
export async function projectMACGPU(context,input,{signal,check=()=>{}}={}){
 need(typeof check==='function'&&(!signal||(typeof signal.addEventListener==='function'&&typeof signal.removeEventListener==='function')),'INVALID_ARGUMENT','Invalid lifecycle guards.');
 const device=context?.device,deviceState=sharedThermalDeviceState(device),owned=[];let disposed=false;
 const guard=()=>{need(!signal?.aborted,'CANCELLED','Projection cancelled.');need(!deviceState.lost,'DEVICE_LOST','Shared GPU device was lost.');need(!disposed,'RETIRED_RESULT','Projection retired.');need(context?.device===device,'STALE_JOB','Shared device changed.');check();};
 const dispose=()=>{if(disposed)return;disposed=true;for(const b of owned)b.destroy();owned.length=0;signal?.removeEventListener('abort',dispose);};
 try{
  guard();const plan=assembleMACProjection(input);need(device&&typeof device.createBuffer==='function','WEBGPU_REQUIRED','Borrowed shared GPU device required.');
  need(device.limits.maxStorageBuffersPerShaderStage===undefined||device.limits.maxStorageBuffersPerShaderStage>=7,'GPU_LIMIT','Projection requires seven storage bindings.');
  signal?.addEventListener('abort',dispose,{once:true});guard();
  const U=GPUBufferUsage,make=(size,usage)=>{need(size<=device.limits.maxBufferSize&&(!(usage&U.STORAGE)||size<=device.limits.maxStorageBufferBindingSize),'GPU_LIMIT','Projection allocation exceeds device limits.');const b=device.createBuffer({size,usage});owned.push(b);return b;};
  const resources=await checked(device,()=>{const storage=U.STORAGE|U.COPY_DST|U.COPY_SRC,uniform=make(32,U.UNIFORM|U.COPY_DST),rhs=make(plan.n*4,storage),p=[make(plan.n*4,storage),make(plan.n*4,storage)],edge=make(plan.edges.length*16,storage),out=make(plan.edges.length*4,storage),metric=make(4,storage),masks=make(plan.n*4,storage),stage=make(Math.max(plan.n,plan.edges.length)*4,U.MAP_READ|U.COPY_DST);
  const config=new ArrayBuffer(32);new Uint32Array(config).set([...plan.dimensions,0]);new Float32Array(config,16).set([...plan.inv,0]);device.queue.writeBuffer(uniform,0,config);device.queue.writeBuffer(rhs,0,plan.rhs);device.queue.writeBuffer(masks,0,plan.faceMasks);device.queue.writeBuffer(edge,0,Float32Array.from(plan.edges.flatMap(e=>[e.left,e.right,e.inv,e.q])));
  const module=device.createShaderModule({code:macProjectionWGSL}),layout=device.createBindGroupLayout({entries:[{binding:0,visibility:GPUShaderStage.COMPUTE,buffer:{type:'uniform'}},...[1,2,3,4,5,6,7].map(binding=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:[1,2,4,7].includes(binding)?'read-only-storage':'storage'}}))]}),pipelineLayout=device.createPipelineLayout({bindGroupLayouts:[layout]});return {uniform,rhs,p,edge,out,metric,masks,stage,module,layout,pipelineLayout};});guard();
  const {uniform,rhs,p,edge,out,metric,masks,stage,module,layout,pipelineLayout}=resources,pipelines={};
  for(const entryPoint of ['iterate','residual','correct']){pipelines[entryPoint]=await device.createComputePipelineAsync({layout:pipelineLayout,compute:{module,entryPoint}});guard();}
  const groups=await checked(device,()=>p.map((b,i)=>device.createBindGroup({layout,entries:[uniform,rhs,b,p[1-i],edge,out,metric,masks].map((buffer,binding)=>({binding,resource:{buffer}}))})));guard();
  const read=async(buffer,count)=>{guard();await checked(device,()=>{const enc=device.createCommandEncoder();enc.copyBufferToBuffer(buffer,0,stage,0,count*4);device.queue.submit([enc.finish()]);});guard();await stage.mapAsync(GPUMapMode.READ);try{guard();return new Float32Array(stage.getMappedRange(0,count*4).slice(0));}finally{stage.unmap();}};
  const dispatch=(enc,name,group,count)=>{const pass=enc.beginComputePass();pass.setPipeline(pipelines[name]);pass.setBindGroup(0,groups[group]);pass.dispatchWorkgroups(Math.ceil(count/64));pass.end();};
  let current=0,iterations=0,residual=Infinity;
  // Fixed bounded batches. Conservative stopping is followed by a separate true-field check.
  while(iterations<plan.maxIterations){guard();await checked(device,()=>{device.queue.writeBuffer(metric,0,new Uint32Array(1));const enc=device.createCommandEncoder(),batch=Math.min(128,plan.maxIterations-iterations);
   for(let j=0;j<batch;j++){dispatch(enc,'iterate',current,plan.n);current=1-current;}iterations+=batch;dispatch(enc,'residual',current,plan.n);device.queue.submit([enc.finish()]);});residual=(await read(metric,1))[0];need(Number.isFinite(residual),'NUMERICAL_RANGE','Nonfinite pressure iteration.');if(residual<=plan.tolerance*plan.rhsNorm*.25)break;
  }
  need(residual<=plan.tolerance*plan.rhsNorm*.25,'NONCONVERGENCE','Bounded GPU pressure iteration exhausted.');
  await checked(device,()=>{const enc=device.createCommandEncoder();dispatch(enc,'correct',current,plan.edges.length);device.queue.submit([enc.finish()]);});const pressure=await read(p[current],plan.n),velocity=await read(out,plan.edges.length),metrics=validateMACProjection(plan,pressure,velocity);guard();
  const fields=plan.fields.map(a=>new Float64Array(a.length));for(let j=0;j<plan.edges.length;j++){const e=plan.edges[j];const physical=velocity[j]*plan.speed;need(Number.isFinite(physical)&&(velocity[j]===0||Math.abs(physical)>=2**-1022),'NUMERICAL_RANGE','Returned physical velocity is unrepresentable.');fields[e.axis][e.index]=physical;}
  const physicalPressure=Float64Array.from(pressure,x=>x*plan.pressureScale);need(Array.from(physicalPressure).every((x,i)=>Number.isFinite(x)&&(pressure[i]===0||Math.abs(x)>=2**-1022)),'NUMERICAL_RANGE','Pressure is unrepresentable.');
  if(plan.obstacle)validateMaskedPhysicalProjection(plan,physicalPressure,fields);
  return {scope:plan.obstacle?'closed-interior-cuboid-mac-gpu-qualification':'closed-all-fluid-mac-gpu-qualification',sceneSolver:false,...plan.obstacle?{obstacle:{min:[...plan.obstacle.min],max:[...plan.obstacle.max]},fluidCellCount:plan.fluidCount,pressureConvention:'Fluid additive gauge; solid slots are zero storage only, not physical pressure.'}:{},u:fields[0],v:fields[1],w:fields[2],pressure:physicalPressure,metrics:{...metrics,iterations,residual:residual*plan.divergenceScale,peakGPUBytes:32+16*plan.n+20*plan.edges.length+4+4*Math.max(plan.n,plan.edges.length),retainedGPUBytes:0}};
 }catch(e){guard();throw e;}finally{dispose();}
}
