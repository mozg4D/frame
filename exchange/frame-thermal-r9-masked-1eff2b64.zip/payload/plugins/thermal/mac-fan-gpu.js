// Internal partial-sheet GPU fan qualification. No scene or thermal coupling.
import {assembleMACProjection,projectMACGPU} from './mac-projection-gpu.js';
const error=(code,message)=>Object.assign(new Error(message),{code});
const need=(ok,code,message)=>{if(!ok)throw error(code,message);};
const normal=x=>Number.isFinite(x)&&Math.abs(x)>=2**-1022;
const keys=['u','v','w'];
export function assembleMACFan(input){
 const allowed=['dimensions','size','u','v','w','density','timeStep','sheet','shutoffPressure','freeFlow','direction'];
 need(input&&typeof input==='object'&&!Array.isArray(input)&&!('obstacle' in input)&&!Object.keys(input).some(k=>!allowed.includes(k)),'INVALID_ARGUMENT','Explicit partial-sheet fan required.');
 const {sheet,shutoffPressure:P0,freeFlow:Q0,direction,...rest}=input;
 const base={...rest,tolerance:1e-5},grid=assembleMACProjection(base),[nx,ny,nz]=grid.dimensions;
 need(Number.isFinite(P0)&&P0>=0&&normal(Q0)&&Q0>0&&[1,-1].includes(direction)&&sheet&&typeof sheet==='object'&&!Object.keys(sheet).some(k=>!['x','y','z'].includes(k))&&Number.isInteger(sheet.x)&&sheet.x>=1&&sheet.x<nx&&['y','z'].every((k,a)=>Array.isArray(sheet[k])&&sheet[k].length===2&&Array.from(sheet[k]).every(Number.isInteger)&&sheet[k][0]>=0&&sheet[k][1]<=[ny,nz][a]&&sheet[k][0]<sheet[k][1]),'INVALID_ARGUMENT','Invalid fan curve or cell-aligned internal sheet.');
 need(!(sheet.y[0]===0&&sheet.y[1]===ny&&sheet.z[0]===0&&sheet.z[1]===nz),'UNSUPPORTED_DOMAIN','Full-span zero-mobility sheet is not supported by this GPU qualification.');
 const area=grid.h[1]*grid.h[2],impulse=input.timeStep/(input.density*grid.h[0]),faces=[];
 need(normal(area)&&normal(impulse),'NUMERICAL_RANGE','Unrepresentable actuator SI scales.');
 for(let z=sheet.z[0];z<sheet.z[1];z++)for(let y=sheet.y[0];y<sheet.y[1];y++)faces.push(sheet.x+(nx+1)*(y+ny*z));
 // Own immutable inputs across all asynchronous GPU stages.
 for(let a=0;a<3;a++)base[keys[a]]=grid.fields[a];base.dimensions=[...grid.dimensions];base.size=[...input.size];
 return {base,sheet:{x:sheet.x,y:[...sheet.y],z:[...sheet.z]},P0,Q0,direction,area,impulse,faces,volume:grid.h.reduce((a,b)=>a*b)};
}
function flux(plan,u){let sum=0;for(const i of plan.faces)sum+=plan.direction*u[i]*plan.area;need(Number.isFinite(sum),'NUMERICAL_RANGE','Fan flux is unrepresentable.');return sum;}
function energy(plan,fields){let sum=0;for(const k of keys)for(const x of fields[k]){const term=.5*plan.base.density*plan.volume*x*x;need(x===0||normal(term),'NUMERICAL_RANGE','Kinetic energy term is unrepresentable.');sum+=term;}need(Number.isFinite(sum),'NUMERICAL_RANGE','Kinetic energy overflows.');return sum;}
export function solveMACFanCurve(plan,qBase,mobility){
 need(Number.isFinite(qBase)&&qBase>=0&&qBase<plan.Q0,'UNSUPPORTED_REGIME','Reverse/free-flow branch unsupported.');need(normal(mobility)&&mobility>0,'NUMERICAL_RANGE','Unresolved positive projected mobility.');
 let lo=0,hi=plan.P0;for(let i=0;i<100;i++){const p=lo+(hi-lo)/2,q=qBase+mobility*p,f=q/plan.Q0;need(Number.isFinite(f),'NUMERICAL_RANGE','Fan root overflow.');if(p>plan.P0*(1-f)*(1+f))hi=p;else lo=p;}
 return lo+(hi-lo)/2;
}
export function validateMACFan(plan,initial,provisional,final,pressure){
 const flow=flux(plan,final.u),fraction=flow/plan.Q0,curve=plan.P0*(1-fraction)*(1+fraction);
 need(Number.isFinite(flow)&&flow>=0&&fraction<1,'UNSUPPORTED_REGIME','Actual corrected flow is outside supported fan branch.');
 if(plan.P0>0)need(normal(pressure)&&pressure>0&&Number.isFinite(curve)&&Math.abs(curve/pressure-1)<=1e-3&&8*2**-23*(plan.P0/pressure)<=1e-3,'NUMERICAL_RANGE','Actual projected flow does not resolve operating fan pressure to 1e-3.');
 const before=energy(plan,initial),afterImpulse=energy(plan,provisional),afterProjection=energy(plan,final);let work=0;
 for(const i of plan.faces)work+=plan.base.timeStep*plan.direction*pressure*plan.area*(initial.u[i]/2+provisional.u[i]/2);
 const gain=afterImpulse-before,scale=Math.max(Math.abs(work),Math.abs(gain));
 need([work,gain,scale].every(Number.isFinite)&&(plan.P0===0||normal(work))&&Math.abs(gain-work)<=1e-4*scale&&afterProjection<=afterImpulse*(1+1e-4),'NUMERICAL_RANGE','Actual impulse midpoint work/energy cannot be resolved.');
 return {pressureRise:plan.direction*pressure,correctedFlow:plan.direction*flow,midpointWork:work,energy:{initialized:before,afterImpulse,afterProjection},fanCurveRelativeError:pressure===0?0:Math.abs(curve/pressure-1)};
}
export const macFanImpulseWGSL=`
struct Config { dims:vec4<u32>, bounds:vec4<u32> }
@group(0) @binding(0) var<uniform> c:Config;
@group(0) @binding(1) var<uniform> increment:vec4<f32>;
@group(0) @binding(2) var<storage,read> original:array<f32>;
@group(0) @binding(3) var<storage,read_write> result:array<f32>;
@compute @workgroup_size(64) fn impulse(@builtin(global_invocation_id) gid:vec3<u32>){
 let i=gid.x;if(i>=arrayLength(&original)){return;}let x=i%c.dims.x;let y=(i/c.dims.x)%c.dims.y;let z=i/(c.dims.x*c.dims.y);var value=original[i];
 if(x==c.dims.w&&y>=c.bounds.x&&y<c.bounds.y&&z>=c.bounds.z&&z<c.bounds.w){value+=increment.x;}result[i]=value;
}`;
async function checked(device,work){device.pushErrorScope('validation');device.pushErrorScope('out-of-memory');let value,failure;try{value=work();}catch(e){failure=e;}const pending=[device.popErrorScope(),device.popErrorScope()],errors=await Promise.all(pending);if(failure)throw failure;const e=errors.find(Boolean);if(e)throw error('GPU_ERROR',e.message);return value;}
async function applyImpulseGPU(device,plan,initial,pressure,guard,owned){
 const delta=plan.direction*plan.impulse*pressure;need(Number.isFinite(delta)&&(pressure===0||normal(delta)),'NUMERICAL_RANGE','Fan impulse overflows/underflows.');let scale=Math.abs(delta);for(const x of initial.u)scale=Math.max(scale,Math.abs(x));if(scale===0)scale=1;
 const uploaded=Float32Array.from(initial.u,x=>x/scale),increment=Math.fround(delta/scale);
 for(let i=0;i<uploaded.length;i++)need(initial.u[i]===0||(uploaded[i]!==0&&Math.abs(uploaded[i]*scale/initial.u[i]-1)<1e-6),'NUMERICAL_RANGE','Fan impulse input dynamic range exceeds Float32.');
 need(delta===0||(increment!==0&&Math.abs(increment*scale/delta-1)<1e-6),'NUMERICAL_RANGE','Fan increment is unresolved in Float32.');
 const U=GPUBufferUsage,make=(size,usage)=>{need(size<=device.limits.maxBufferSize&&(!(usage&U.STORAGE)||size<=device.limits.maxStorageBufferBindingSize),'GPU_LIMIT','Fan allocation exceeds shared device limits.');const b=device.createBuffer({size,usage});owned.add(b);return b;},n=uploaded.length;
 const resources=await checked(device,()=>{const config=make(32,U.UNIFORM|U.COPY_DST),deltaBuffer=make(16,U.UNIFORM|U.COPY_DST),source=make(4*n,U.STORAGE|U.COPY_DST),output=make(4*n,U.STORAGE|U.COPY_SRC),stage=make(4*n,U.MAP_READ|U.COPY_DST);device.queue.writeBuffer(config,0,new Uint32Array([plan.base.dimensions[0]+1,plan.base.dimensions[1],plan.base.dimensions[2],plan.sheet.x,...plan.sheet.y,...plan.sheet.z]));device.queue.writeBuffer(deltaBuffer,0,new Float32Array([increment,0,0,0]));device.queue.writeBuffer(source,0,uploaded);const module=device.createShaderModule({code:macFanImpulseWGSL}),layout=device.createBindGroupLayout({entries:[0,1,2,3].map(binding=>({binding,visibility:GPUShaderStage.COMPUTE,buffer:{type:binding<2?'uniform':binding===2?'read-only-storage':'storage'}}))}),pipelineLayout=device.createPipelineLayout({bindGroupLayouts:[layout]});return {config,deltaBuffer,source,output,stage,module,layout,pipelineLayout};});guard();
 const {config,deltaBuffer,source,output,stage,module,layout,pipelineLayout}=resources,pipeline=await device.createComputePipelineAsync({layout:pipelineLayout,compute:{module,entryPoint:'impulse'}});guard();
 await checked(device,()=>{const group=device.createBindGroup({layout,entries:[config,deltaBuffer,source,output].map((buffer,binding)=>({binding,resource:{buffer}}))}),encoder=device.createCommandEncoder(),pass=encoder.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,group);pass.dispatchWorkgroups(Math.ceil(n/64));pass.end();encoder.copyBufferToBuffer(output,0,stage,0,n*4);device.queue.submit([encoder.finish()]);});guard();await stage.mapAsync(GPUMapMode.READ);let values;try{guard();values=new Float32Array(stage.getMappedRange().slice(0));}finally{stage.unmap();}
 const faceSet=new Set(plan.faces),u=new Float64Array(n);for(let i=0;i<n;i++){const expected=uploaded[i]+(faceSet.has(i)?increment:0),v=values[i];need(Number.isFinite(v)&&Math.abs(v-expected)<=4*2**-23*(Math.abs(uploaded[i])+(faceSet.has(i)?Math.abs(increment):0)),'NUMERICAL_RANGE','Actual GPU fan impulse is inconsistent.');u[i]=v*scale;need(v===0||normal(u[i]),'NUMERICAL_RANGE','Dimensional impulse underflows.');}
 for(const b of [config,deltaBuffer,source,output,stage]){b.destroy();owned.delete(b);}return {fields:{u,v:initial.v.slice(),w:initial.w.slice()},peakGPUBytes:12*n+48,readbackBytes:4*n};
}
export async function actuateMACFanGPU(context,input,{signal,check=()=>{}}={}){
 need(typeof check==='function'&&(!signal||(typeof signal.addEventListener==='function'&&typeof signal.removeEventListener==='function')),'INVALID_ARGUMENT','Invalid lifecycle guards.');
 const device=context?.device,owned=new Set();let disposed=false;
 const dispose=()=>{if(disposed)return;disposed=true;for(const b of owned)b.destroy();owned.clear();signal?.removeEventListener('abort',dispose);};
 const guard=()=>{need(!signal?.aborted,'CANCELLED','Fan cancelled.');need(!disposed,'RETIRED_RESULT','Fan retired.');need(context?.device===device,'STALE_JOB','Shared device changed.');check();};
 try{
  guard();const plan=assembleMACFan(input);need(device&&typeof device.createBuffer==='function','WEBGPU_REQUIRED','Borrowed shared GPU device required.');signal?.addEventListener('abort',dispose,{once:true});guard();
  const run=fields=>projectMACGPU(context,{...plan.base,...fields},{signal,check:guard}),initial=await run({});guard();
  const qBase=flux(plan,initial.u);need(qBase>=0&&qBase<plan.Q0,'UNSUPPORTED_REGIME','Initial reverse/free-flow branch unsupported.');
  // An inactive fan is exactly the initialized GPU field; do not round it
  // through another upload or invent nonzero work/mobility diagnostics.
  if(plan.P0===0){const initialized=energy(plan,initial);guard();return {scope:'closed-partial-sheet-mac-fan-gpu-qualification',sceneSolver:false,u:initial.u,v:initial.v,w:initial.w,pressureCorrection:new Float64Array(plan.base.dimensions.reduce((a,b)=>a*b)),correctedMobility:null,inactive:true,pressureRise:0,correctedFlow:plan.direction*qBase,midpointWork:0,fanCurveRelativeError:0,energy:{input:energy(plan,plan.base),initialized,afterImpulse:initialized,afterProjection:initialized},metrics:{...initial.metrics,impulseReadbackBytes:0}};}
  const unitU=new Float64Array(initial.u.length);for(const i of plan.faces)unitU[i]=plan.direction*plan.impulse;
  const unit=await run({u:unitU,v:new Float64Array(initial.v.length),w:new Float64Array(initial.w.length)});guard();
  const mobility=flux(plan,unit.u),pressure=solveMACFanCurve(plan,qBase,mobility),impulse=await applyImpulseGPU(device,plan,initial,pressure,guard,owned);guard();
  const final=await run(impulse.fields);guard();const diagnostics=validateMACFan(plan,initial,impulse.fields,final,pressure);
  return {scope:'closed-partial-sheet-mac-fan-gpu-qualification',sceneSolver:false,u:final.u,v:final.v,w:final.w,pressureCorrection:final.pressure,correctedMobility:mobility,...diagnostics,energy:{input:energy(plan,plan.base),...diagnostics.energy},metrics:{peakGPUBytes:Math.max(initial.metrics.peakGPUBytes,unit.metrics.peakGPUBytes,final.metrics.peakGPUBytes,impulse.peakGPUBytes),retainedGPUBytes:0,impulseReadbackBytes:impulse.readbackBytes,maxDivergence:final.metrics.maxDivergence,maxDivergenceAllowance:final.metrics.maxDivergenceAllowance}};
 }catch(e){guard();throw e;}finally{dispose();}
}
