import {snapshotExteriorFilm,boundaryDataProperty,validateFilmHeat,exteriorFaces} from './exterior-film.js';
// Explicit flat fluid/solid perfect-contact qualification, not native scene Solve.
import {assembleLayeredHeatGPU} from './layered-heat-gpu.js';
import {solveConductionGPU} from './plugin.js';
import {stepForcedTemperatureGPU} from './forced-temperature-gpu.js';
const error=(code,message)=>Object.assign(new Error(message),{code});
const need=(ok,code,message)=>{if(!ok)throw error(code,message);};
const normal=x=>Number.isFinite(x)&&Math.abs(x)>=2**-1022;
const sum=a=>{let s=0,c=0;for(const x of a){const t=s+x;c+=Math.abs(s)>=Math.abs(x)?s-t+x:x-t+s;s=t;}return s+c;};
export function assembleConjugateHeatGPU(input){
 const allowed=['dimensions','size','fluidCellsX','fluid','solid','temperature','solidSourceDensity','timeStep','u','v','w','fan','divergenceDriftBudgetK','boundary'];
 need(input&&typeof input==='object'&&!Array.isArray(input)&&!('obstacle' in input)&&!Object.keys(input).some(k=>!allowed.includes(k)),'INVALID_ARGUMENT','Explicit flat fluid/solid domain required.');
 boundaryDataProperty(input,'boundary');
 const {dimensions:d,size,fluidCellsX:f,fluid,solid,timeStep,boundary='adiabatic'}=input;
 need(Array.isArray(d)&&d.length===3&&Array.from(d).every(x=>Number.isInteger(x)&&x>=2&&x<=16)&&Number.isInteger(f)&&f>=2&&f<d[0],'INVALID_ARGUMENT','Bounded full grid and nonempty right solid slab required.');
 const thermalBoundary=boundary==='adiabatic'?'adiabatic':snapshotExteriorFilm(boundary);
 need(fluid&&typeof fluid==='object'&&!Array.isArray(fluid)&&!Object.keys(fluid).some(k=>!['density','specificHeat','conductivity','viscosity'].includes(k))&&Number.isFinite(fluid.viscosity)&&fluid.viscosity>0,'INVALID_ARGUMENT','Constant fluid properties including viscosity required.');
 const {viscosity,...fluidHeat}=fluid,source=Array.from(input.solidSourceDensity??[0]),temperature=Array.from(input.temperature??[]);
 const heat={dimensions:[...d],size:Array.isArray(size)?[...size]:size,fluidCellsX:f,fluid:fluidHeat,solid:{...solid},temperature,solidSourceDensity:source,timeStep,boundary:thermalBoundary==='adiabatic'?{}:thermalBoundary,tolerance:1e-5};
 const grid=assembleLayeredHeatGPU(heat),[nx,ny,nz]=d,fluidDimensions=[f,ny,nz],fluidSize=[grid.cellSize[0]*f,size[1],size[2]],fluidTemperature=new Float64Array(f*ny*nz),fields=[],fullLengths=[];
 for(let z=0;z<nz;z++)for(let y=0;y<ny;y++)for(let x=0;x<f;x++)fluidTemperature[x+f*(y+ny*z)]=temperature[x+nx*(y+ny*z)];
 for(let axis=0;axis<3;axis++){
  const shape=[...d];shape[axis]++;const localShape=[...fluidDimensions];localShape[axis]++;const length=shape.reduce((a,b)=>a*b),values=input[['u','v','w'][axis]];
  need((Array.isArray(values)||values instanceof Float32Array||values instanceof Float64Array)&&values.length===length&&Array.from(values).every(Number.isFinite),'INVALID_ARGUMENT','Full-grid finite MAC arrays required.');
  const local=new Float64Array(localShape.reduce((a,b)=>a*b));fullLengths.push(length);
  for(let z=0;z<shape[2];z++)for(let y=0;y<shape[1];y++)for(let x=0;x<shape[0];x++){
   const i=x+shape[0]*(y+shape[1]*z),solidOrInterface=x>=f;
   if(solidOrInterface)need(values[i]===0,'INVALID_BOUNDARY','Velocity on the fluid-solid interface and inside solid must be zero.');
   if(x<localShape[0])local[x+localShape[0]*(y+localShape[1]*z)]=values[i];
  }
  fields.push(local);
 }
 const fan=input.fan;need(fan&&typeof fan==='object'&&!Array.isArray(fan)&&!Object.keys(fan).some(k=>!['sheet','shutoffPressure','freeFlow','direction'].includes(k))&&fan.sheet,'INVALID_ARGUMENT','Explicit partial fluid-local fan required.');
 const fanCopy={...fan,sheet:{...fan.sheet,y:Array.from(fan.sheet.y??[]),z:Array.from(fan.sheet.z??[])}};
 const step={flow:{dimensions:fluidDimensions,size:fluidSize,density:fluid.density,viscosity,timeStep,u:fields[0],v:fields[1],w:fields[2]},fan:fanCopy,temperature:fluidTemperature,specificHeat:fluid.specificHeat,divergenceDriftBudgetK:input.divergenceDriftBudgetK};
 const capacities=Float64Array.from({length:grid.count},(_,i)=>(i%nx<f?fluid.density*fluid.specificHeat:solid.density*solid.specificHeat)*grid.volume),power=new Float64Array(grid.count);
 for(let i=0;i<grid.count;i++){need(normal(capacities[i])&&normal(capacities[i]*temperature[i]),'NUMERICAL_RANGE','Unrepresentable cell energy.');if(i%nx>=f){const si=(i%nx-f)+(nx-f)*Math.floor(i/nx),s=source[source.length===1?0:si];power[i]=s*grid.volume;need(s===0||(normal(power[i])&&normal(power[i]*timeStep)),'NUMERICAL_RANGE','Unrepresentable solid source power/energy.');}}
 return {heat,grid,step,capacities,power,fullLengths,thermalBoundary};
}
export function validateConjugateHeatGPU(plan,initial,temperature){
 const {grid,capacities,power}=plan,n=grid.count,dt=grid.timeStep,nx=grid.dimensions[0],f=plan.heat.fluidCellsX;
 need(initial instanceof Float64Array&&temperature instanceof Float64Array&&initial.length===n&&temperature.length===n&&initial.every((x,i)=>Number.isFinite(x)&&x>=1&&x<=2000&&normal(capacities[i]*x))&&temperature.every((x,i)=>Number.isFinite(x)&&x>=1&&x<=2000&&normal(capacities[i]*x)),'NUMERICAL_RANGE','Invalid actual Kelvin/energy fields.');
 if(grid.exteriorFilm?.some(e=>e.g>0))return validateConjugateFilm(plan,initial,temperature);
 const strides=[1,nx,nx*grid.dimensions[1]];let maxResidualK=0,interfacePower=0;
 for(let i=0;i<n;i++){
  const storage=capacities[i]*(temperature[i]-initial[i])/dt;let outflow=0;
  for(let a=0;a<3;a++)for(let side=0;side<2;side++){const g=grid.coefficients[i*8+a*2+side];if(g){const j=i+(side?1:-1)*strides[a],q=g*(temperature[i]-temperature[j]);outflow+=q;if(a===0&&side===1&&i%nx===f-1)interfacePower+=q;}}
  const residual=storage+outflow-power[i],residualK=Math.abs(residual)*dt/capacities[i];maxResidualK=Math.max(maxResidualK,residualK);
  need(Number.isFinite(residualK)&&residualK<=1e-3,'NONCONVERGENCE','Actual conjugate field violates original BE equation.');
  if(power[i]!==0)need(Math.abs(residual)<=1e-3*Math.abs(power[i]),'NUMERICAL_RANGE','Solid source-cell residual is unresolved relative to source power.');
 }
 const before=sum(Array.from(initial,(x,i)=>x*capacities[i])),after=sum(Array.from(temperature,(x,i)=>x*capacities[i])),sourcePower=sum(power),sourceEnergy=dt*sourcePower,absoluteSourceEnergy=sum(Array.from(power,x=>Math.abs(x*dt))),energyError=after-before-sourceEnergy;
 need(sourcePower===0||(normal(sourcePower)&&normal(sourceEnergy)),'NUMERICAL_RANGE','Net solid source underflows.');
 let energyAllowance=8*2**-23*(before+absoluteSourceEnergy);if(sourceEnergy!==0)energyAllowance=Math.min(energyAllowance,1e-3*Math.abs(sourceEnergy));else if(absoluteSourceEnergy>0)energyAllowance=Math.min(energyAllowance,1e-3*absoluteSourceEnergy);
 need([before,after,sourcePower,sourceEnergy,energyError,energyAllowance,interfacePower].every(Number.isFinite)&&Math.abs(energyError)<=energyAllowance,'NUMERICAL_RANGE','Conjugate thermal energy balance is unresolved.');
 if(power.every(x=>x===0)){const lo=Math.min(...initial),hi=Math.max(...initial);need(temperature.every(x=>x>=lo-1e-3&&x<=hi+1e-3),'NUMERICAL_RANGE','Source-free conjugate diffusion violates extrema.');}
 const regions=[];for(const fluid of [true,false]){const selected=Array.from({length:n},(_,i)=>i).filter(i=>(i%nx<f)===fluid),regionBefore=sum(selected.map(i=>initial[i]*capacities[i])),regionAfter=sum(selected.map(i=>temperature[i]*capacities[i])),error=regionAfter-regionBefore+(fluid?1:-1)*dt*interfacePower-(fluid?0:sourceEnergy),allowance=1e-3*sum(selected.map(i=>capacities[i]))+128*Number.EPSILON*(regionBefore+regionAfter+Math.abs(dt*interfacePower)+Math.abs(sourceEnergy));need([regionBefore,regionAfter,error,allowance].every(Number.isFinite)&&Math.abs(error)<=allowance,'NUMERICAL_RANGE','Interface regional energy balance failed.');regions.push({energyBefore:regionBefore,energyAfter:regionAfter,balanceError:error,balanceAllowance:allowance});}
 return {energyBefore:before,energyAfter:after,sourcePower,sourceEnergy,energyError,energyAllowance,maxResidualK,fluid:grid.thermalBoundary?{...regions[0],boundaryPowerOutW:0,boundaryEnergyOutJ:0}:regions[0],solid:grid.thermalBoundary?{...regions[1],boundaryPowerOutW:0,boundaryEnergyOutJ:0}:regions[1],interfacePowerFluidToSolid:interfacePower,interfacePowerSolidToFluid:-interfacePower,boundaryEnergy:0,...(grid.thermalBoundary?{boundaryPowerOutW:0,absoluteBoundaryPowerW:0,boundaryEnergyOutJ:0,absoluteBoundaryEnergyJ:0,boundaryPowerByFaceW:Object.fromEntries(exteriorFaces.map(k=>[k,0])),boundaryEnergyByFaceJ:Object.fromEntries(exteriorFaces.map(k=>[k,0])),grossDriveEnergy:absoluteSourceEnergy,netBoundaryPowerResolved:true}: {})};
}
function validateConjugateFilm(plan,initial,temperature){
 const {grid,capacities,power}=plan,nx=grid.dimensions[0],f=plan.heat.fluidCellsX,dt=grid.timeStep,v=validateFilmHeat(grid,initial,temperature,capacities,power);
 let interfacePower=0;for(let i=0;i<grid.count;i++)if(i%nx===f-1)interfacePower+=grid.coefficients[i*8+1]*(temperature[i]-temperature[i+1]);
 const regions=[true,false].map(fluid=>{const indices=Array.from({length:grid.count},(_,i)=>i).filter(i=>(i%nx<f)===fluid),before=sum(indices.map(i=>initial[i]*capacities[i])),after=sum(indices.map(i=>temperature[i]*capacities[i])),boundaryPowerOutW=sum(indices.map(i=>v.cellPower[i])),boundaryEnergyOutJ=dt*boundaryPowerOutW,balanceError=after-before+(fluid?1:-1)*dt*interfacePower+boundaryEnergyOutJ-(fluid?0:v.sourceEnergy),balanceAllowance=dt*sum(indices.map(i=>v.residualBounds[i]))+128*Number.EPSILON*(before+after+Math.abs(dt*interfacePower)+Math.abs(v.sourceEnergy)+dt*sum(indices.map(i=>v.cellAbsolutePower[i])));
  need([before,after,boundaryPowerOutW,boundaryEnergyOutJ,balanceError,balanceAllowance].every(Number.isFinite)&&Math.abs(balanceError)<=balanceAllowance,'NUMERICAL_RANGE','Exterior film regional energy balance failed.');return {energyBefore:before,energyAfter:after,boundaryPowerOutW,boundaryEnergyOutJ,balanceError,balanceAllowance};});
 const {cellPower,cellAbsolutePower,residualBounds,...metrics}=v;return {...metrics,fluid:regions[0],solid:regions[1],interfacePowerFluidToSolid:interfacePower,interfacePowerSolidToFluid:-interfacePower,boundaryEnergy:v.boundaryEnergyOutJ};
}
export async function stepConjugateHeatGPU(context,input,{signal,check=()=>{}}={}){
 need(typeof check==='function'&&(!signal||(typeof signal.addEventListener==='function'&&typeof signal.removeEventListener==='function')),'INVALID_ARGUMENT','Invalid lifecycle guards.');
 const device=context?.device;let field=null;const retire=()=>{field?.dispose();field=null;},guard=()=>{need(!signal?.aborted,'CANCELLED','Conjugate step cancelled.');need(context?.device===device,'STALE_JOB','Shared device changed.');check();};
 try{
  guard();const plan=assembleConjugateHeatGPU(input),[nx,ny,nz]=plan.grid.dimensions,f=plan.heat.fluidCellsX;signal?.addEventListener('abort',retire,{once:true});
  const fluid=await stepForcedTemperatureGPU(context,plan.step,{signal,check:guard});guard();
  const advected=Float64Array.from(plan.heat.temperature);for(let z=0;z<nz;z++)for(let y=0;y<ny;y++)for(let x=0;x<f;x++)advected[x+nx*(y+ny*z)]=fluid.temperature[x+f*(y+ny*z)];
  // Only fluid cells were advected. Sources appear once, in this shared solve.
  const grid=assembleLayeredHeatGPU({...plan.heat,temperature:advected});guard();field=await solveConductionGPU(device,grid,{check:guard});guard();
  const temperature=new Float64Array(grid.count);for(let offset=0;offset<grid.count;offset+=256){const sample=await field.inspect(offset,Math.min(256,grid.count-offset));guard();temperature.set(sample.temperatures.map(x=>x+273.15),offset);}
  const conduction=validateConjugateHeatGPU({...plan,grid},advected,temperature),initialEnergy=sum(plan.heat.temperature.map((x,i)=>x*plan.capacities[i])),finalEnergy=conduction.energyAfter,balanceError=finalEnergy-initialEnergy-conduction.sourceEnergy+(conduction.boundaryEnergyOutJ??0),balanceAllowance=fluid.thermal.energyAllowance+conduction.energyAllowance;
  need([initialEnergy,finalEnergy,balanceError,balanceAllowance].every(Number.isFinite)&&Math.abs(balanceError)<=balanceAllowance,'NUMERICAL_RANGE','Combined conjugate energy accounting failed.');
  const output=plan.fullLengths.map(n=>new Float64Array(n));for(let axis=0;axis<3;axis++){const fullShape=[nx,ny,nz],shape=[f,ny,nz];fullShape[axis]++;shape[axis]++;const values=fluid[['u','v','w'][axis]];for(let z=0;z<shape[2];z++)for(let y=0;y<shape[1];y++)for(let x=0;x<shape[0];x++){const value=values[x+shape[0]*(y+shape[1]*z)];need(x<f||value===0,'INVALID_BOUNDARY','Returned velocity crossed the fluid-solid interface.');output[axis][x+fullShape[0]*(y+fullShape[1]*z)]=value;}}
  guard();return {scope:'flat-conjugate-fan-heat-gpu-qualification',sceneSolver:false,temperatureUnit:'K',u:output[0],v:output[1],w:output[2],temperature,mechanical:fluid.mechanical,pressureRise:fluid.pressureRise,correctedFlow:fluid.correctedFlow,thermal:{advection:fluid.thermal,conduction,initialEnergy,finalEnergy,sourceEnergy:conduction.sourceEnergy,...(conduction.boundaryEnergyOutJ===undefined?{}:{boundaryEnergyOutJ:conduction.boundaryEnergyOutJ}),balanceError,balanceAllowance},metrics:{peakGPUBytes:Math.max(fluid.metrics.peakGPUBytes,field.metrics.peakGPUBytes,grid.count*4+Math.min(grid.count,256)*4),retainedGPUBytes:0}};
 }catch(e){guard();throw e;}finally{retire();signal?.removeEventListener('abort',retire);}
}
