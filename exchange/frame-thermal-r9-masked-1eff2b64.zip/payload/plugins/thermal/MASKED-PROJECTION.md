# Isolated interior-cuboid pressure projection

This candidate extends `mac-projection-gpu.js`, the existing borrowed-device MAC
projection, for one explicit embedded whole-cell cuboid. It is **projection only**,
not a complete fluid solver, a native geometry classifier or an obstacle-aware
Thermal solve. It adds no native command, saved property, catalogue entry, UI or
live release. The frozen R9 exterior-film candidate and the published Docs release
are not modified. Hardware qualification of this candidate remains pending.

## Explicit domain and face ownership

The old all-fluid input remains valid when `obstacle` is absent. The optional
internal input is `obstacle: {min: [ix, iy, iz], max: [jx, jy, jz]}`. Bounds are
integer **cell indices**, not metres or millimetres, with half-open ownership:
`min[a] <= cell[a] < max[a]`. Both arrays and descriptor must be dense plain data;
inherited, accessor, hidden, unknown and symbol geometry fields reject.

Each axis requires `1 <= min[a] < max[a] <= dimensions[a]-1`. Thus an obstacle
requires at least 3 cells on every axis and leaves a complete one-cell fluid shell.
The existing maximum is 16³ cells, and existing cell aspect ratio is at most 10.
Only one nonempty strictly interior axis-aligned cuboid is accepted. Wall-touching,
partial/cut cells, multiple obstacles, arbitrary binary masks, rotations, disconnected
fluid regions and mesh/native inference are unsupported. The generated fluid graph
is explicitly checked for reciprocal faces and a single connected component.

MAC arrays retain their ordinary dense shapes: u=(nx+1)ny nz,
v=nx(ny+1)nz and w=nx ny(nz+1), X fastest. Every outer normal face, solid-fluid
interface face and face inside solid must already be **exactly zero**. Invalid
values reject; the input is never silently clamped. Only faces with two fluid
neighbours become active edges. Both output solid/interface velocities remain
exactly zero because only active edges are scattered into zero-filled output.
This is impermeability/no penetration. It makes **no tangential no-slip claim**.

## One operator, pressure gauge and normalization

The existing shared-device Jacobi and velocity correction kernels are reused.
Each active face has one edge, one uploaded velocity and two reciprocal incident
mask bits. Binding 7 stores one Uint32 six-bit mask per cell: bits 2a and 2a+1
open the negative and positive neighbour on axis a. The pressure diagonal and
neighbour sum include exactly these faces, as do RHS assembly, correction,
returned divergence and kinetic-energy checks. No edge touching solid contributes.
Solid rows have zero diagonal/RHS and are skipped in residual/iteration, with
explicit zero assignment rather than division by zero.

Pressure is unanchored on the connected fluid component. Only its differences
are physical. Damped Jacobi starts at zero but does not promise zero-mean pressure.
Solid pressure slots are **zero storage sentinels, not physical pressure inside
the obstacle**, nor anchors for fluid pressure. The masked result identifies this
in `pressureConvention`, returns the snapshotted obstacle and fluidCellCount, and
has scope `closed-interior-cuboid-mac-gpu-qualification`; `sceneSolver` is false.
The old all-fluid result scope remains unchanged.

Normalization is unchanged: speed=max|input face velocity| (1 only for an exact
zero field), hmin=min(dx,dy,dz), uploaded inv=f32(hmin/h), q=f32(u/speed).
The pressure scale is rho*hmin*speed/dt; divergence scale is speed/hmin;
kinetic-energy scale per active face is 0.5*rho*dx*dy*dz*speed². Each active face
has the full equal-cell dual volume. Boundary/solid faces have no kinetic-energy
unknown. Masked nonzero q must be normal Float32 (at least 2^-126), preserving
the existing relative upload error gate. Normalized subnormal face inputs reject; effects below the stated Float32
arithmetic/divergence budgets are not guaranteed resolved.

RHS is negative divergence assembled from the exact uploaded face q and inv,
then rounded once per cell. Masked input screens the resulting sum for closed-graph
compatibility: |sum(rhs)| <= fluidCellCount * tolerance * rhsNorm * 0.25. It never
fixes compatibility by subtracting an undisclosed mean or anchoring/omitting a
fluid row. This compatibility screen is necessary, not a convergence guarantee.
Iteration still must meet its actual residual target within maxIterations.

## Actual returned-field acceptance

The old tests and gates remain: finite values, pressure-difference reconstruction,
per-cell physical divergence using hmin/h, and energy nonincrease up to 1e-4
relative arithmetic allowance. The correction roundoff depends on actual input
and correction, not pressure magnitude, so a large pressure gauge cannot erase
solenoidal flow. Gradient, circulation and gradient-plus-circulation tests exercise
that distinction, and independent tests inspect projection orthogonality.

A cell divergence allowance is tolerance*rhsNorm plus 64*2^-23 times that cell's
sum of absolute returned normalized face fluxes. The first term is a **global
requested floor** for this one connected component, not a cell-relative/region
accuracy guarantee. It is not a time-integration or engineering accuracy bound.
Masked outputs additionally reconstruct the correction from returned SI pressure,
original SI input velocity and unrounded physical spacing, then independently
check both reconstructed and actual SI velocity divergence against the same
local budget. Corrupted/uncertain/underflowing outputs reject, not publish.

## Ownership and isolation from other stages

All source arrays, obstacle bounds and physical scales are captured synchronously
before the first await. Shared-device identity, caller currentness, cancellation
and actual device-loss state are checked at asynchronous boundaries. The existing
`scene-identity.js` device-loss tracker is reused: one subscription per shared
device, no pending per-operation loss closure. All buffers and abort listeners are
released on success and failure. No GPU state is retained in the returned result.
The bounded full-field host readback remains qualification overhead, not a final
resident GPU simulation architecture.

With N dense cells and E open faces, exact owned buffer bytes are
36 + 16N + 20E + 4*max(N,E), including the larger of pressure/edge readback needs.
Seven storage bindings are required; unsupported devices reject. No software
adapter or CPU production fallback is supplied.

`project-temperature-gpu.js` now explicitly rejects obstacle flow. Fan, viscosity and rectangular conjugate preflights explicitly reject
own, hidden or inherited obstacle data before it can be discarded by input
spreads; their numerical compositions remain unchanged. Existing left-fluid/right-solid chamber heat, film, Fan and native
pipelines do not receive this masked field. Obstacle velocity advection, viscous
wall conditions, Fan placement/work, thermal transport/conduction coupling,
multiple regions, component-wise gauges, native classifiers and scene duration
integration remain separate unimplemented work.

## Verification and pending gates

`node --test plugins/thermal/tests/mac-projection-gpu.mjs
plugins/thermal/tests/masked-projection-gpu.mjs` covers old all-fluid assertions,
independent solid-mask Float64 reference fields/pressure gradients, independent
face enumeration and operator identity, analytic fields, exact blocked faces,
strict geometry, mutable-source snapshots, nonconvergence, cancel/stale/replace/
loss/readback/allocation errors, corruption, Float32 underflow, exact resource
accounting, shared-listener reuse and GC retention. Budgets apply to completed
operations, not merely dispatch: <=5 s for small nonzero cases, <=10 s for the
16³ zero-flow one-cell shell, and <=1.5 s for maximum assembly. These CPU command
emulator timings are **not GPU timings or WGSL proof**.

`node plugins/thermal/tests/masked-projection-browser.mjs` is the prepared focused
hardware gate. It uses a fresh isolated browser context and the actual Frame
shared device, rejects software adapters, preserves all previous all-fluid
hardware comparisons, and checks masked actual fields, blocked faces, pressure
gradients, analytic/no-flow/nonconverged cases, source mutation, async cancellation,
staleness, device replacement guards, resource cleanup and source hashes. Its
per-operation hardware budget is 15 s and measured owned-buffer peak must stay
within 14,436 bytes for this focused fixture set. Observers/await gates never replace kernel
arithmetic or inject success. It is not run without the coordinator's GO.
The full Thermal harness also includes masked field checks, without registration.

No current hardware pass, standard `npm test`, stress or large-scene pass is
claimed. Aggregate/hardware gates remain blocked pending permitted focused
hardware qualification and safe execution approval. No Unite, heavy standard/
stress, or user-scene workloads were run for this isolated milestone. R9's own
hardware status remains pending and cannot inherit this projection-only gate.
