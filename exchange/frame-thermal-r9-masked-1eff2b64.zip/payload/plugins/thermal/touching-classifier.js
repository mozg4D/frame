import {exactOccurrenceStamp,sceneIdentityMatches} from './scene-identity.js';
// Preserve interfaces: independently validate/read two native occurrences; never union them.
import {classifyBoxTriangles} from './box-classifier.js';
import {copyPhysicalFrame} from './probe.js';
import {THERMAL_TAGS} from './scene-inputs.js';
const fail=(code,message)=>Object.assign(new Error(message),{code});
const exactTransformRows=matrix=>{
  if(!Array.isArray(matrix)||matrix.length!==16||Array.from(matrix).some(v=>!Number.isFinite(v)||Math.fround(v)!==v)||matrix[3]!==0||matrix[7]!==0||matrix[11]!==0||matrix[15]!==1)throw fail('UNSUPPORTED_TRANSFORM','Expected exact Float32 affine transform and bounded native vertices.');
  const rows=[],columns=new Set();
  for(let a=0;a<3;a++){
    const active=[0,1,2].filter(c=>matrix[c*4+a]!==0);if(active.length!==1||columns.has(active[0]))throw fail('UNSUPPORTED_TRANSFORM','Only axis permutations and signed binary scales are supported.');
    const column=active[0],scale=matrix[column*4+a],power=2**Math.round(Math.log2(Math.abs(scale)));
    if(Math.abs(scale)!==power)throw fail('UNSUPPORTED_TRANSFORM','Relative scales must be exact signed powers of two.');columns.add(column);rows.push({column,scale});
  }
  return rows;
};
export function transformCuboidExactly(positions,matrix) {
  if(!(positions instanceof Float32Array)||positions.length%3||positions.length>4096*3)throw fail('UNSUPPORTED_TRANSFORM','Expected bounded Float32 vertex storage.');
  const rows=exactTransformRows(matrix),out=new Float32Array(positions.length);
  for(let i=0;i<positions.length;i+=3)for(let a=0;a<3;a++){
    const {column,scale}=rows[a],x=positions[i+column],product=x*scale,translation=matrix[12+a],sum=product+translation,b=sum-product,roundoff=(product-(sum-b))+(translation-b);
    if(!Number.isFinite(x)||!Number.isFinite(sum)||product/scale!==x||roundoff!==0||Math.fround(sum)!==sum)throw fail('UNSUPPORTED_TRANSFORM','Transform rounding could change contact topology.');
    out[i+a]=sum;
  }
  return out;
}
export function classifyTouchingCuboids(boundaries,dimensions,cellSizeMM) {
  if(!Array.isArray(boundaries)||boundaries.length!==2)throw fail('UNSUPPORTED_GEOMETRY','Exactly two independent cuboids are required.');
  const parts=boundaries.map(b=>classifyBoxTriangles(b.positions,b.indices,dimensions,cellSizeMM)),a=parts[0].diagnostics.boundsMM,b=parts[1].diagnostics.boundsMM;
  const axes=[0,1,2].filter(axis=>(a.max[axis]===b.min[axis]||b.max[axis]===a.min[axis])&&[0,1,2].filter(k=>k!==axis).every(k=>a.min[k]===b.min[k]&&a.max[k]===b.max[k]));
  if(axes.length!==1)throw fail('UNSUPPORTED_CONTACT','Cuboids must meet on exactly one complete matching face, without gaps or overlap.');
  if(parts.some(p=>p.diagnostics.partial||p.completeOccurrences.length!==1))throw fail('UNSUPPORTED_DOMAIN','Both complete cuboids and their interface must align with the cell grid.');
  const occurrences=new Int32Array(parts[0].occurrences.length);let outside=0;
  for(let i=0;i<occurrences.length;i++){
    const first=parts[0].occurrences[i]===0,second=parts[1].occurrences[i]===0;
    if(first&&second)throw fail('UNSUPPORTED_CONTACT','Material cells overlap.');
    occurrences[i]=first?0:second?1:-1;if(!first&&!second)outside++;
  }
  if(outside)throw fail('UNSUPPORTED_DOMAIN','The grid must exactly cover the two-cuboid assembly.');
  const axis=axes[0],other=[0,1,2].filter(k=>k!==axis),areaMM2=other.reduce((area,k)=>area*(a.max[k]-a.min[k]),1);
  const coordinateMM=a.max[axis]===b.min[axis]?a.max[axis]:b.max[axis],faceIndex=coordinateMM/cellSizeMM[axis]+dimensions[axis]/2;
  if(!Number.isInteger(faceIndex)||faceIndex<1||faceIndex>=dimensions[axis])throw fail('UNSUPPORTED_CONTACT','Contact plane must map exactly to an interior grid face.');
  return {dimensions:[...dimensions],cellSizeMM:[...cellSizeMM],occurrences,completeOccurrences:[0,1],diagnostics:{inside:occurrences.length,outside:0,partial:0,classification:'two-touching-cuboids',reference:'independently-captured-Float32-boundaries',contact:{model:'perfect-thermal-contact',axis,coordinateMM,lowerCell:faceIndex-1,leftOccurrence:a.max[axis]===b.min[axis]?0:1,rightOccurrence:a.max[axis]===b.min[axis]?1:0,areaMM2},sceneSolver:false}};
}
export async function classifyTouchingSceneBoxes(context,hash,{dimensions,cellSizeMM,signal,check:externalCheck}={}) {
  externalCheck?.();
  const start=performance.now(),snapshot=context.scene.capture(hash,[],THERMAL_TAGS),ownerWorld=copyPhysicalFrame({kind:'physical-owner',ownerWorld:Array.from(context.document.world(hash))}).ownerWorld,transformStamp=exactOccurrenceStamp(snapshot);
  const check=()=>{if(signal?.aborted)throw fail('CANCELLED','Two-material classification cancelled.');externalCheck?.();const world=Array.from(context.document.world(hash));if(context.device!==snapshot.device||!sceneIdentityMatches(context,hash,snapshot.signature,transformStamp)||world.length!==16||world.some((v,i)=>v!==ownerWorld[i]))throw fail('STALE_CLASSIFICATION','Scene, tags, device or owner frame changed.');};
  check();if(snapshot.meshes.length!==2)throw fail('UNSUPPORTED_GEOMETRY','Exactly two captured occurrences are required.');
  // Complete descriptor validation precedes any allocation or source readback.
  for(const mesh of snapshot.meshes){
    if(mesh.storage!=='buffer'||!mesh.positions||!mesh.indices||!(mesh.positions.usage&GPUBufferUsage.COPY_SRC)||!(mesh.indices.usage&GPUBufferUsage.COPY_SRC))throw fail('UNSUPPORTED_GEOMETRY','Only COPY_SRC buffer-backed occurrences are supported; texture/paged sources are not.');
    if(!Number.isInteger(mesh.vertexCount)||mesh.vertexCount<8||mesh.vertexCount>4096||mesh.triangleCount!==12)throw fail('GEOMETRY_LIMIT','Each occurrence must contain twelve triangles and at most 4096 vertices.');
    if(!Number.isSafeInteger(mesh.positions.size)||mesh.positions.size<mesh.vertexCount*12||!Number.isSafeInteger(mesh.indices.size)||mesh.indices.size<144)throw fail('INVALID_GEOMETRY','Source buffers are smaller than their declared geometry.');
    exactTransformRows(mesh.matrix);
    if(!mesh.tags?.some(t=>t.kind==='thermal_material'))throw fail('INVALID_CLASSIFICATION','Both occurrences need Thermal Material tags.');
    // Validate the grid without inventing a geometry fixture or touching GPU memory.
    if(!Array.isArray(dimensions)||dimensions.length!==3||Array.from(dimensions).some(n=>!Number.isInteger(n)||n<1||n>256)||dimensions.reduce((a,b)=>a*b,1)>262144||!Array.isArray(cellSizeMM)||cellSizeMM.length!==3||Array.from(cellSizeMM).some(v=>!Number.isFinite(v)||v<=0))throw fail('INVALID_ARGUMENT','Invalid classified grid.');
  }
  let readbackBytes=0,peakStagingBytes=0,transientBoundaryBytes=0,peakBoundaryHostBytes=0;
  const read=async(source,bytes)=>{check();const d=context.device;if(bytes>d.limits.maxBufferSize)throw fail('GPU_LIMIT','Readback exceeds device limit.');const staging=d.createBuffer({label:'Thermal independent occurrence readback',size:bytes,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});peakStagingBytes=Math.max(peakStagingBytes,bytes);let mapped=false;
    try{const e=d.createCommandEncoder();e.copyBufferToBuffer(source,0,staging,0,bytes);d.queue.submit([e.finish()]);await staging.mapAsync(GPUMapMode.READ);mapped=true;check();const data=staging.getMappedRange().slice(0);readbackBytes+=bytes;return data;}finally{if(mapped)staging.unmap();staging.destroy();}
  };
  const boundaries=[];
  for(const mesh of snapshot.meshes){
    const local=new Float32Array(await read(mesh.positions,mesh.vertexCount*12)),indices=new Uint32Array(await read(mesh.indices,144)),positions=transformCuboidExactly(local,mesh.matrix);check();
    peakBoundaryHostBytes=Math.max(peakBoundaryHostBytes,transientBoundaryBytes+local.byteLength+positions.byteLength+indices.byteLength);
    transientBoundaryBytes+=positions.byteLength+indices.byteLength;boundaries.push({positions,indices});
  }
  const classification=classifyTouchingCuboids(boundaries,dimensions,cellSizeMM);check();
  return {source:{signature:snapshot.signature,transformStamp,meshes:snapshot.meshes.map(mesh=>({tags:mesh.tags.map(t=>({kind:t.kind,uid:t.uid,source:t.source,params:{...t.params}}))}))},classification:{...classification,signature:snapshot.signature,transformStamp,ownerWorld},metrics:{wallMs:performance.now()-start,readbackBytes,peakStagingBytes,retainedBoundaryBytes:0,transientBoundaryBytes,peakBoundaryHostBytes},sceneSolver:false};
}
