# Native Thermal box job candidate

This isolated, unregistered milestone adds `solve-domain`. It binds the existing
native Thermal box to the same saved-Fan duration pipeline and job controller.
It adds no solver, UI action, native parameter fields, persistent role/grid/time
settings, geometry cache, CPU production fallback, or heat-rejection boundary.
Core, plugin catalogue, manifest fields and GPU kernels are unchanged.

## Request and physical contract

`plugins.command {id: thermalHash, operation: 'solve-domain', args}` requires:

- `fanHash`: the canonical native Fan hash, explicitly referencing this Thermal.
- `fluidHash`: the canonical native polygon mesh hash for the left chamber.
- `dimensions`: three integers in 2..16, at most 4096 cells.
- `settings`: positive `fluidDensity` and `solidDensity` in kg/m³,
  `fluidViscosity` in Pa s, positive `timeStep` in seconds, and
  `divergenceDriftBudgetK` in (0, 0.001]. Optional `initialCelsius` contains one
  value or one per cell in x-fastest order; otherwise native Initial is used.
- `stepCount`: 1..10, with `stepCount * timeStep <= 0.1` seconds.
- `cumulativeDivergenceDriftBudgetK`: explicit acceptance budget in (0, 0.001].

The sole owner-local domain is the ordinary helper box `[-50,50]³` mm.
`cellSizeMM` is derived as `100 / dimensions[axis]` and cannot be supplied.
Caller domain/pose/size overrides, `fluidOccurrence`, `fanBox`, fan parameters,
roles inferred from material properties, and unspecified extra fields reject.
The native Fan alone supplies its actual box, pressure, free flow and direction.
Grid/time/physical properties and the two canonical role references remain API
arguments, not saved Thermal parameters. This is not a native Solve UI release.

Native owner and ancestor local/world transforms determine physical pose and
axis lengths. Existing orthogonal translation/rotation/nonuniform scale/reflection
mapping converts local millimetres to metres once. Source-volume normalization
continues to preserve the native Heater's total signed watts. Shear, singular or
projective frames and evaluated world frames inconsistent with exact native
local/parent composition reject. This metadata support does not make every pose
admissible to the stricter actual-geometry classifier.

Exactly two complete actual COPY_SRC buffer-backed twelve-triangle cuboids must
cover the domain with full local-X contact. The left fluid must have at least two
X cells. Native Material tags supply conductivity and volumetric heat capacity;
Heater may apply only to the complete solid. Triangle validity, independent
contact, occupancy, relative transforms and source normalization use the existing
classifier and scene mapper. The helper's bounds never substitute for triangles.
Groups, instances, generators, missing or repeated canonical sources reject.
Canonical role resolution requires both one native mesh node and exactly one
current capture entry. Every new solve resolves the fluid occurrence again,
including after HASH order changes. A capture reorder during a job retires it.
The core's current ordinary replica owner hashes and mesh-type gate justify this
narrow rejection; this is not a general replica/procedural provenance certificate.

The actual core capture computes `inverse(ownerWorld) * sourceWorld`. An arbitrary
common rotation can introduce tiny off-axis or non-Float32 residues even when a
native child local frame is identity. The unchanged exact classifier rejects those
residues. No local-frame substitution, coordinate snapping or tolerance widening
is used. The existing large-world-origin versus physical-cell precision gate
can also reject Probe sampling; orthogonal frame metadata alone is not full pose
admissibility. Exact representability also matters for counts: `11 * (100 / 11)` is
`100.00000000000001`, so `solve-domain` rejects that count in pure preflight,
before native reads or predecessor interruption. This exactly derived extent
check neither rounds the cells nor widens the unchanged classifier.
Other counts can fail contact or Fan alignment. The schema's range is not a
promise that every grid/material/time-step configuration is admissible.

A small aligned fixture uses `[4,4,4]`, actual triangles in X `[-50,0]` and
`[0,50]`, both with Y/Z `[-50,50]`, and the unchanged native default 25 mm Fan at
`[-25,-12.5,-12.5]`. This gives centre sheet X=1 and Y/Z footprint [1,2] in grid
coordinates. The Fan must fit the fluid and remain an exact partial local-X
internal sheet. Thickness is containment only, not a force volume or housing.
Numerical test values in `tests/native-domain-fixture.mjs` are explicit test
inputs, not air/material presets or promises that arbitrary inputs converge.

Outer walls remain adiabatic, flow starts at rest, and the complete duration
starts from explicit request `initialCelsius` or native Initial when omitted.
There is no heat sink, ventilation, fan-work-to-heat term,
radiation, steady cooling claim, continuation or temperature accuracy guarantee.
Zero boundary heat loss is a model condition, not a demonstrated cooling effect.

## Validation and lifecycle

The same strict snapshot code rejects unknown/inherited/hidden/accessor/symbol
fields, sparse/decorated arrays and invalid scalars before native interruption.
Cross-field limits, exact represented 100 mm extents and native
owner/Fan/role/topology authoring must pass before a
predecessor is stopped. Unsupported triangle/contact/sheet/numerical physics can
fail later inside an accepted asynchronous job after the predecessor is retired.
No promise to preserve that predecessor is made for asynchronous proof failures.

The immutable snapshot is carried through the native interrupt token, so queued
caller mutation cannot alter it. It contains only scalar/array authoring stamps,
not scene/GPU wrappers. It records owner/Fan identities, native local/world frames,
parameters, relevant ancestry, both canonical source identities and ancestry,
canonical fluid hash/current index, source signature/exact transforms, and shared
device identity. The domain path validates the entire native parent topology
before any native evaluator or capture. It additionally proves each relevant
world frame equals its local/ancestor composition and each captured relative
frame equals the canonical native world correspondence.

Every existing nested asynchronous guard runs the full currentness check, as do
publication, ready status, bounded temperature/velocity reads, Probe sampling and
cached Probe labels. Lookup/depth maps are rebuilt within each check; they are not
cached scene state or epochs. Same-hash new-object Undo/HASH identities, edits,
reparenting, disable, deletion/restore, source reorder and device loss retire
results. Selection/name/presentation changes alone preserve valid fields when the
actual capture is unchanged. Stale Probe labels clear through existing paths.

`solve-domain`, `solve-saved-fan`, `solve-scene` and `solve-grid` share the existing
jobs/readings/workTails controller. Replacement drains retired work before new GPU
allocation. Clear/Stop, queued replacement, deletion/restoration and viewport
retirement retain the same drain ownership and atomic-publication rules. Native
Probe/Fan creation still awaits the real editor selection queue. R7's individual
conduction-await checks remain unchanged. No additional numerical buffers, solver
or runtime CPU mirror are introduced.

`status.authoring` is `native-box-explicit-grid` for this path.
`geometryCoupled` is true; `sceneSolver` and `generalSceneSolver` remain false.
`solve-saved-fan` keeps its explicit domain/fluidOccurrence contract, and
`solve-scene` continues to ignore native Fans. No domain inspection operation or
second editable domain state is added.

## Qualification and remaining work

`node --test plugins/thermal/tests/native-domain-job.mjs` exercises the shipped
controller, classifier and numerical orchestration through the test-only CPU GPU
command emulator. It uses source-extracted actual native creation/frame/record/
selection/restore machinery and the actual core capture matrix calculation.
Geometry buffers, UI/GPU endpoints and history/checkpoint storage are adapters;
these CPU tests do not prove browser rendering, full Undo stacks or HASH I/O.
They compare all T/u/v/w and bounded Probe values against a separate Float64 oracle
and exactly matched old operation inputs, and cover strict requests, identities,
geometry, transforms, interruption, cleanup and completed-operation budgets with
10,000 unrelated document nodes and full nested guard cadence.

The focused browser gate must use actual `frameAI`, native authoring/transforms,
real imported triangle meshes, Undo/HASH and identifiable hardware WebGPU. Missing
pinned Chromium or GPU access is blocked, never passed or replaced by software.
The full Thermal CPU suite, independent review/retention, required `npm test` and
`npm run test:stress`, real-hardware gates and source hashes must be reported
separately. A pass from an earlier R6/R7 source cannot qualify this candidate.

Persisted role/grid/numerical authoring, native Solve UI, a separately validated
heat-rejection boundary, section visualization, general geometry and wider/max-grid
hardware qualification remain future work. Local preparation here does not register
the plugin, publish main/Pages, upload files, or qualify a live release.
