# Saved-Fan asynchronous native job candidate

This isolated, unregistered candidate joins the reviewed native Fan snapshot
adapter to the existing Thermal asynchronous job and two-cuboid duration pipeline.
It adds no solver, scene model, continuation, CPU production fallback, UI Solve
action or saved-domain settings. Core and catalogue bytes are unchanged.

## Operation and physical contract

`plugins.command {id: thermalHash, operation: 'solve-saved-fan', args}` takes
`fanHash` plus the existing `solve-scene` dimensions, cellSizeMM, settings,
stepCount and cumulativeDivergenceDriftBudgetK. `settings.fanBox` is forbidden,
even if identical to the saved Fan. Other fan/property overrides also reject.
The native Fan is the sole source of box, pressure, free flow and signed local-X
direction. No unique-Fan inference is performed; the canonical Fan hash is
explicit even if several Fans reference the owner.

All existing physical limits remain: exactly two actual complete COPY_SRC
buffer-backed twelve-triangle touching cuboids, full local-X contact, explicit
left fluid occurrence with at least two X cells, solid-only Heater, exact relative
geometry frames, adiabatic outer walls, rest/Initial start, 1..10 steps and at
most 0.1 seconds. Material/Heater provenance and actual independent triangles
are classified by the existing classifier. SI lengths are converted once by
existing scene mapping. Native Fan pressure/free flow remain Pa and m³/s.
The Fan must have the adapter's exact supported direct-child positive-diagonal
owner-relative frame, explicit reference and all-enabled unambiguous ancestry.
Its centre sheet and partial footprint must be exactly grid-aligned inside fluid;
there is no snapping, role inference, force volume or housing interpretation.

The convenient default 25 mm Fan is not eligible automatically. It does not match
the older metre-scale fixture. Author its actual native transform for the chosen
explicit grid and verify mapping; do not override it in the numerical request.

`solve-scene` retains its existing explicit numeric fanBox contract and ignores
saved Fan objects. Its operation body is unchanged. Fan edits/disable/reparent/
removal do not retire an explicit-request field. `fan-inputs` remains detached
metadata inspection: its solverCoupled/solverEligible false flags describe that
inspection's lack of physical certification, not a claim that no separately
validated operation can consume a Fan. `create-fan` creates authoring only; its
return value is not a solve or eligibility result.

## Validation, ownership and asynchronous boundaries

The strict schema rejects unknown, inherited, hidden, accessor and symbol fields,
sparse or decorated arrays and nonfinite/out-of-range scalars before interruption.
Cross-field numerical limits and native authoring/reference/topology/frame checks
also precede interruption. The immutable capture is carried in the interrupt token
across Frame's native command queue; caller mutation cannot change accepted input.
The queued handler revalidates that original capture. Direct handler use preflights
independently. Unsupported physical geometry, role or grid/sheet classification may
fail later in the accepted asynchronous job, after the predecessor is retired.
There is no promise to preserve a predecessor after all unsupported geometry.

The same jobs/readings/pending/workTails controller owns grid, explicit scene and
saved-Fan jobs. Replacement drains retiring work before any new GPU allocation.
Cancel/Clear stop scheduling immediately and drain. Generic flush stays nonblocking;
author/output/render barriers include active and retired work. Owner deletion,
Undo/HASH same-hash replacement and viewport retirement retain drain ownership.
There is never a published partial duration, and no automatic restart or retry.

Minimal internal factory hooks pass the existing saved guard into the classifier,
scene pipeline and existing duration/GPU chain and map classified input through
nativeFanSceneInputs. The classifier checks the external guard before its initial
capture/world evaluator and before every readback continuation; the pipeline and
native reads check it before owner evaluators. Complete topology validation thus
precedes native world evaluation even after an unnotified cycle is introduced.
The guard covers owner/Fan identity, canonical reference, exact local/world frames,
ancestry enablement/reparenting, native parameters, source signature/exact occurrence
transforms and shared-device identity/loss. Selection/name/presentation-only changes
preserve valid results when captured geometry is unchanged.

The reused conduction path also checks after each individual asynchronous pipeline
creation, between error-scope completion and mapping, and before/after retained
field inspection awaits, with unconditional staging cleanup on new guard throws.
No equations or GPU kernels change.

No event epoch, microtask ticket, cached scene or sampled guard cadence is used.
Every existing nested asynchronous guard reaches a full saved-Fan check. Redundant
standalone owner/source checks in the scene/native owner path are replaced only
where that same full adapter check already proves them; cancellation/device checks
remain immediate. Ready status, bounded temperature/velocity reads, Probe measures
and cached Probe labels revalidate. A final native current check gates publication
independently of the pipeline's own last check. A result disposed at a final race
cannot enter the owner's job map.

Status uses `authoring: 'saved-fan-explicit-domain'`; geometryCoupled is true,
sceneSolver and generalSceneSolver remain false. Explicit scene uses
`authoring: 'explicit-request'`. No arrays are added to status. Existing bounded
reads, physical Probe sampling and T/u/v/w ownership/accounting remain unchanged.

## Qualification

`node --test plugins/thermal/tests/native-saved-fan-job.mjs` runs the shipped
controller, classifier and GPU orchestration using a test-only CPU command emulator.
It is not WGSL/hardware proof. It covers strict preflight, mutable queued inputs,
forward/reverse/off equality to explicit inputs and independent Float64 T/u/v/w,
unsupported mapping, late edits, cancellation/drain/replace/retire, same-hash
replacement, device loss, bounded reads/labels and completed-operation budgets.
The original 23-test adapter suite retains all numerical/currentness assertions;
its former global "no runtime import" assertion now tests the explicit operation's
detachment and complete runtime assets with an unregistered catalogue, because
native integration is this milestone's intended change.

The focused browser harness and full Thermal suite must run on identifiable native
hardware with exact source hashes. Missing pinned Chromium is blocked, not passed.
Full `npm test` and `npm run test:stress`, maximum-grid duration, whole-application
integration and release qualification remain separate. No main/live/Windows/OBS
changes or library upload are part of this local gate preparation.
