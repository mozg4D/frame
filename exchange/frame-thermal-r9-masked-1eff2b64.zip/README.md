# Thermal R6 to frozen R9 plus masked projection

This source-only packet reconstructs the exact 483-file frozen candidate. It uses 22 replacements and 22 new files from the verified 461-file Thermal R6 source. It is not the unrelated Docs R6 release. It does not change main, publish a website, install software, launch a browser or authorize hardware execution.

Verify the independently supplied archive SHA-256 before extraction. Run the applier from the extracted packet directory. Use the existing Thermal R6 source as BASE and a NEW separate sibling directory as NEW_TARGET. Do not apply over any prior source or evidence directory.

    node apply.mjs --check BASE
    node apply.mjs --apply BASE NEW_TARGET
    node apply.mjs --verify-target NEW_TARGET

Stop immediately if any command exits nonzero. Preserve incomplete output and its error. Never edit an expected hash, remove a check, replace the runner, bypass a helper, or reuse an old target to obtain a pass.

The applier checks the complete base source inventory, every source hash, every payload, the exact delta set and complete target inventory. It refuses unknown source files except the six explicitly enumerated infrastructure/historical-output roots. Those roots are never copied. It refuses unsafe paths, source symlinks, changed payloads, overlapping/existing outputs and deletions. It rechecks the unchanged base after copying. Only the exact 483 source files are reconstructed; no node_modules, private reports or private user scene files are transferred in this packet. Unchanged source fixtures already present in the verified base remain part of the exact target inventory.

The base is Thermal native-selection R6 with unchanged core SHA-256 a8e82c4e8986a57b5b4b0d72539c5bbe60dbbfb8c6671e588492bedb4a77eba0. The candidate freeze SHA-256 is d67e7f490a22b588c4e6431356890ee1e5aab721ace43b8bdd8c4fd49d65583c. The masked runtime SHA-256 is eecd61543f51073eec6b492b7481dcd285315332e8bfc612c68fb16109c0518e. The manifest binds all source identities.

A smaller pressure-only overlay was rejected because the new caller guard in conjugate-heat-gpu.js belongs to the R9 exterior-film implementation, and the masked CPU fixture imports it. No guard is omitted or spliced into a different implementation. The exact target therefore contains R7/R8/R9 changes as well as masked projection. Their inclusion does not qualify them.

## Qualification stages

First, from NEW_TARGET, without starting a browser:

    node --test plugins/thermal/tests/mac-projection-gpu.mjs plugins/thermal/tests/masked-projection-gpu.mjs

The command emulator and Float64 oracle are test-only. CPU success is not real GPU evidence.

Only after source review, a separate hardware execution GO, scheduling with other GPU work, and the required laboratory OBS/printing safeguards, use the supported existing browser launcher and already installed pinned dependencies:

    node plugins/thermal/tests/masked-projection-browser.mjs --headless

The focused gate retains the complete old all-fluid projection assertions, adds independent masked geometry/pressure/velocity checks and actual-device lifecycle/resource checks, and records exact before/after source hashes. It must use the identifiable actual nonfallback shared GPU device. Do not install software, substitute a software adapter or modify tools/browser.mjs. Preserve tests/results/thermal-masked-projection.json and logs outside the candidate after the run.

The focused gate only covers pressure projection for one explicit strictly interior whole-cell cuboid and one connected fluid component. Solid pressure slots are nonphysical zero sentinels. Impermeability is not tangential no-slip. It does not qualify obstacle viscosity, fan, advection, heat, native geometry inference, scene solving, R9 film or aggregate application behavior.

The unchanged legacy full Thermal R6 regression requires a separately reviewed, source-bound harness that runs on this exact composed target. Candidate plugins/thermal/tests/run.mjs is now the larger R9 suite; do not relabel it as the old R6 476-check gate or replace candidate tests/index.mjs with old bytes. Broader R9, standard/stress and large-scene gates remain separate pending work. Old R6 Probe/Fan/full PASS results apply only to their historical exact source and are not inherited by this candidate.
