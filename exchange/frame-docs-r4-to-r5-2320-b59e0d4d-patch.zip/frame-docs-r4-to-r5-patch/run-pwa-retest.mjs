// PWA-only bounded retest. This is not the full nine-stage qualification.
import{readFile,lstat,rename,writeFile}from'node:fs/promises';import{resolve,join,dirname}from'node:path';import{fileURLToPath,pathToFileURL}from'node:url';import{createHash}from'node:crypto';
const bundle=dirname(fileURLToPath(import.meta.url)),sha=b=>createHash('sha256').update(b).digest('hex');
const args=process.argv.slice(2),rootArg=args.find(a=>!a.startsWith('--'));if(!rootArg||args.some(a=>a!==rootArg&&a!=='--headless'))throw Error('Usage: node run-pwa-retest.mjs R5_FOLDER [--headless]');
const root=resolve(rootArg),manifest=JSON.parse(await readFile(join(bundle,'PATCH-MANIFEST.json'))),raw=await readFile(join(root,'DOCS-GATE-INVENTORY.json'));
if(sha(raw)!==manifest.targetInventorySHA256)throw Error('Not the exact R5 inventory');const inventory=JSON.parse(raw);
for(const path of ['tests/docs-gate-inventory.mjs','tests/docs-integrated-browser-gate.mjs'])if(sha(await readFile(join(root,path)))!==inventory.files[path])throw Error('Gate source differs: '+path);
const aggregate=join(root,'DOCS-INTEGRATED-BROWSER-RESULT.json'),result=join(root,'DOCS-R5-PWA-GATE-RESULT.json');
for(const path of [aggregate,result]){try{await lstat(path);throw Error('Preserve existing report before retest: '+path);}catch(e){if(e.code!=='ENOENT')throw e;}}
const{verify}=await import(pathToFileURL(join(root,'tests/docs-gate-inventory.mjs')));const before=await verify(root);
const{runGate}=await import(pathToFileURL(join(root,'tests/docs-integrated-browser-gate.mjs')));const report=await runGate({root,steps:['docs-pwa-browser.mjs']});
// Keep any failure and the child report. Do not leave a one-step PASS named as a full run.
report.scope='R5 PWA-only retest: one stage, not the nine-stage focused browser gate';report.remaining='Native remote-history and live-page update still require execution; historical earlier-source passes do not certify R5.';
try{report.wrapperSourcesAfter=await verify(root,before);}catch(e){report.pass=false;report.wrapperError=e.message;}
await rename(aggregate,result);await writeFile(result,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({pass:report.pass,scope:report.scope,result,steps:report.steps,error:report.error||report.wrapperError},null,2));process.exitCode=report.pass?0:1;
