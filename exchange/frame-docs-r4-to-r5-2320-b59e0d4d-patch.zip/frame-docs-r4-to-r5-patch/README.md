# Exact R4 to R5 Docs icon correction

Small strict patch from verified 182-source R4 inventory to a NEW sibling R5 directory. The applier never edits R4, copies node_modules, installs dependencies, executes project code or launches a browser. It refuses an existing destination, verifies every source before/after, permits no removals and applies only two exact version substitutions to index.html. R4 Windows failure/diagnostic bytes remain preserved there, not copied as cloud originals.

If ad hoc diagnostics were saved in inventoried R4 paths, the checker must reject that tree. Preserve it untouched and reconstruct a fresh R4 using the verified original R3 archive and previous approved R3-to-R4 patch. Never delete failed reports, relax checks or regenerate inventory.

Verify this ZIP SHA-256 supplied separately. PowerShell from the extracted patch folder; set $R4 to the exact frozen R4 source, $R5 to a NEW sibling directory:

    node .\apply-docs-r5.mjs --check $R4
    if ($LASTEXITCODE -ne 0) { throw 'R4 preflight failed' }
    node .\apply-docs-r5.mjs --apply $R4 $R5
    if ($LASTEXITCODE -ne 0) { throw 'Patch failed; preserve incomplete output' }
    node "$R5\tests\docs-final-cpu-gate.mjs"
    if ($LASTEXITCODE -ne 0) { throw 'R5 CPU gate failed' }

Only with the authorized Windows browser environment ready and its existing Playwright/Chromium installation resolvable from the NEW R5 folder:

    node .\run-pwa-retest.mjs $R5 --headless
    if ($LASTEXITCODE -ne 0) { throw 'STOP: PWA retest failed' }

PWA retest runs one child with the unchanged five-minute outer bound and 30-second popup assertion, plus exact source checks. It writes DOCS-R5-PWA-GATE-RESULT.json, not a nine-stage PASS. Missing dependency means stop, no installation or software-GPU fallback. Forced termination leaves descendant cleanup uncertain. Preserve child reports before any later rerun.

After PWA passes, the coordinator decides when to run the unchanged full focused nine-stage gate:

    node "$R5\tests\docs-integrated-browser-gate.mjs" --headless

R4 offline functional checks passed but implicit /favicon.ico retrieval caused console FAIL. R5 declares the already cached SVG icon. No console filtering, assertion weakening, timeout change or SW routing expansion. R5 browser qualification remains UNRUN until reported on its own exact source.

No full standard/stress, unrelated Unite, printer/CNC operations, user scenes/media, main/live edits, upload or publication. Actual OS IME, installed-PWA launch and broader release qualification remain separate. No general atomic-deployment or rollback claim.
