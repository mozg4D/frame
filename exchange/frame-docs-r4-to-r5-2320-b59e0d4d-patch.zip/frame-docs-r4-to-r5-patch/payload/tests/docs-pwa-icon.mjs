// Actual worker install/fetch handlers, CPU icon fixtures only; no browser evidence.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
const root=new URL('../',import.meta.url),link='<link rel="icon" href="./frame-icon-v4.svg" type="image/svg+xml">';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
function explicitIcon(html){assert.equal(html.split(link).length-1,1,'Docs must declare the exact existing main SVG icon link');}
async function iconWorker(source,index,icon,scope){
 const handlers={},stored=new Map(),network=[];let online=true,installed=false,task;
 const key=request=>{const url=new URL(typeof request==='string'?request:request.url);url.hash='';return url.href;};
 const cache={put:async(request,response)=>stored.set(key(request),response.clone()),match:async request=>stored.get(key(request))?.clone()};
 vm.runInNewContext(source,{URL,Response,self:{registration:{scope},location:{origin:new URL(scope).origin},addEventListener:(name,handler)=>handlers[name]=handler,skipWaiting:async()=>{installed=true;}},caches:{open:async()=>cache},fetch:async request=>{
  const url=typeof request==='string'?request:request.url;network.push(url);if(!online)throw Error('Offline icon fixture request');
  const path=new URL(url).pathname.slice(new URL(scope).pathname.length);
  // The icon and shell use exact bytes; unrelated installation assets are stubs.
  return new Response(path==='index.html'?index:path==='frame-icon-v4.svg'?icon:path==='plugins/index.json'?'[]':'asset',{headers:{'Content-Type':path==='frame-icon-v4.svg'?'image/svg+xml':path==='index.html'?'text/html; charset=utf-8':'application/octet-stream'}});
 }});
 handlers.install({waitUntil:promise=>task=promise});await task;assert.equal(installed,true);online=false;network.length=0;
 return {stored,network,async request(url){const request=new Request(url);Object.defineProperty(request,'destination',{value:'image'});let result;handlers.fetch({request,respondWith:promise=>{assert.equal(result,undefined);result=Promise.resolve(promise);}});if(!result)return {handled:false};const response=await result;return {handled:true,status:response.status,mime:response.headers.get('Content-Type'),sha256:hash(new Uint8Array(await response.arrayBuffer()))};}};
}
export async function iconChecks(){
 const [html,before,index,source,icon]=await Promise.all([
  readFile(new URL('documentation.html',root),'utf8'),readFile(new URL('qualification/pwa-icon/before/documentation.html',root),'utf8'),readFile(new URL('index.html',root),'utf8'),readFile(new URL('frame-sw.js',root),'utf8'),readFile(new URL('frame-icon-v4.svg',root))
 ]),checks=[],timings=[];
 assert.equal(hash(before),'a209f163762bea7fc323e92919103544e78d80821982f9a739478dc552992cc7','Pinned original Docs without an icon');
 assert.throws(()=>explicitIcon(before),/Docs must declare/,'Original missing-icon source must fail the new regression');
 explicitIcon(html);assert.equal(index.split(link).length-1,1,'Reuse the exact existing main icon');assert.equal(html.replace(link,''),before,'Only the explicit existing icon link changes Docs HTML');
 assert.equal(hash(icon),'292052cfbe59a891d1e70ca0907445a29efe146683e402dfca81336d4b3bf733','Existing SVG asset remains unchanged');
 checks.push('Pinned original fails explicit-icon requirement; current Docs adds only the exact existing main SVG link');
 assert.match(source,/"frame-icon-v4\.svg"/,'Existing worker precaches the icon');
 for(const server of ['tools/browser.mjs','tests/pwa.mjs'])assert.match(await readFile(new URL(server,root),'utf8'),/'\.svg':'image\/svg\+xml'/,'Existing '+server+' SVG MIME');
 checks.push('Existing SVG is already in CORE and both existing test servers declare image/svg+xml');
 for(const scope of ['https://frame.test/','https://frame.test/frame/']){
  const fixture=await iconWorker(source,index,icon,scope),url=new URL('./frame-icon-v4.svg',new URL('documentation.html#handshake-token',scope)).href;
  assert.equal(url,new URL('frame-icon-v4.svg',scope).href,'Relative icon remains inside the registration scope');assert.ok(fixture.stored.has(url),'Actual install handler stages icon');
  for(const suffix of ['','#icon'])assert.deepEqual(await fixture.request(url+suffix),{handled:true,status:200,mime:'image/svg+xml',sha256:hash(icon)},'Exact offline cached SVG bytes and MIME');
  for(const fallback of new Set([new URL('/favicon.ico',scope).href,new URL('favicon.ico',scope).href]))assert.equal((await fixture.request(fallback)).handled,false,'No generic favicon routing');
  assert.equal((await fixture.request(url+'?other=1')).handled,false,'No broad query normalization');
  const started=performance.now(),iterations=100;for(let i=0;i<iterations;i++)assert.equal((await fixture.request(url)).sha256,hash(icon));
  const elapsedMs=performance.now()-started,budgetMs=1000;assert.ok(elapsedMs<budgetMs,'100 completed cached icon responses exceeded 1000 ms');assert.equal(fixture.network.length,0,'Offline icon responses require zero network requests');
  timings.push({scope,iterations,elapsedMs,budgetMs});checks.push('Actual install/fetch handlers serve exact cached SVG under '+new URL(scope).pathname+' with no fallback/query route or offline network');
 }
 return {checks,timings,documentationSHA256:hash(html),beforeDocumentationSHA256:hash(before),workerSHA256:hash(source),iconSHA256:hash(icon)};
}
if(process.argv[1]===fileURLToPath(import.meta.url))console.log(JSON.stringify({pass:true,qualification:'Actual worker icon install/fetch CPU fixtures; unrelated installation assets stubbed; no browser run',...await iconChecks()},null,2));
