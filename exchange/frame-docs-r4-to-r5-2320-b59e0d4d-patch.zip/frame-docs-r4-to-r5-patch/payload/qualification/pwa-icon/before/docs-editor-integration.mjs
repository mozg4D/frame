import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {createHash} from 'node:crypto';
const hash=s=>createHash('sha256').update(s).digest('hex');let core=await readFile(new URL('../index.html',import.meta.url),'utf8');
// R4 exact stamp reversal before the unchanged R3 proof.
assert.equal(hash(core),'50270bd8c3097cfb6c39f1e5b1adb5c0c5a27f153027e491f4c2f635f6f31a29','Frozen R4 index');
assert.equal(core.split('2026 07 nov 23:03').length-1,2);core=core.replaceAll('2026 07 nov 23:03','2026 07 nov 22:08');
// Final qualification: undo only the explicit stamp and exact reviewed barrier.
assert.equal(hash(core),'c4dd55f425708ea0ac1f3bae0345db3f4b4084e797f7e6b2ad9f492c0b4402e3','Frozen final index');
assert.equal(core.split('2026 07 nov 22:08').length-1,2,'Only title/meta use release stamp');
core=core.replaceAll('2026 07 nov 22:08','2026 06 nov 16:47');
const reverseBytes=await readFile(new URL('../qualification/save-barrier/INDEX-REVERSE.json',import.meta.url));
assert.equal(hash(reverseBytes),'b0785810ac43843adb47d7d2b7856bc858cf866e8d98554a6aebb98063504033','Frozen reverse proof');
const reverse=JSON.parse(reverseBytes);assert.equal(hash(core),reverse.afterSHA256,'Exact reviewed barrier index before reversal');
const lines=core.split('\n');for(const h of [...reverse.hunks].reverse()){assert.deepEqual(lines.slice(h.afterStart,h.afterStart+h.after.length),h.after,'Exact reverse hunk');lines.splice(h.afterStart,h.after.length,...h.before);}core=lines.join('\n');
assert.equal(hash(core),reverse.beforeSHA256,'Barrier reverses exactly');assert.equal(reverse.beforeSHA256,'ce96a9fffb9bf9e1a7b47346816c41bd816a03e4bec44130870b9c8d152b5745');
let worker=await readFile(new URL('../frame-sw.js',import.meta.url),'utf8');assert.equal(hash(worker),'c761a1c6b4acfeba47d90159004cb18b74f60d37914fd0c314bc39687d975724','Frozen R4 worker');assert.equal(worker.split('2026 07 nov 23:03').length-1,1);worker=worker.replaceAll('2026 07 nov 23:03','2026 07 nov 22:08');assert.equal(hash(worker),'6bc5e8980c9c267d9118754cddf309a2563e801eee22380cd81aef35eb6ab5d2','Exact reviewed semantic worker');assert.equal(worker.split("url.hash='';").length-1,1);worker=worker.replace("url.hash='';",'');assert.equal(hash(worker),'8a7479df4744389287ebb79142c08784fcbfe0387cd04a13c42eb970b51267d0','Frozen final worker');assert.equal(hash(worker.replaceAll('2026 07 nov 22:08','2026 07 nov 21:28')),'41770dad667e74df52e0c98c5a015b3dfbc03ce41ce8dafc4cbe8f14abf48c86','Only explicit stamp overrides reviewed PWA worker');
const button='\n<button type="button" class="tbtn" id="btnDocs" title="Scene Documentation" hidden>Docs</button>',hook="\n      import('./core/documentation-window.mjs').then(({installDocumentationWindow})=>installDocumentationWindow({button:$('btnDocs'),api:window.frameAI,read:()=>docs.get()})).catch(fileOperationError);";
for(const addition of [button,hook]){assert.equal(core.split(addition).length,2);core=core.replace(addition,'');}
assert.equal(core.split("['btnNew','btnOpen','btnSave','btnDownload','btnShare','btnHelp','btnDocs','btnBrowser']").length,2);
core=core.replace("['btnNew','btnOpen','btnSave','btnDownload','btnShare','btnHelp','btnDocs','btnBrowser']","['btnNew','btnOpen','btnSave','btnDownload','btnShare','btnHelp','btnBrowser']");
assert.equal(hash(core),'dc71a654ab8d5406244be074ba49d25b3df8e8034542c7bcd93ac03be33d62dc');
const expected={'core/documentation-editor.mjs':'afc2e507ee43077bb9657db577d7cf2cce92c8dc44d98e32918cd473d9200709','core/documentation-sync.mjs':'a75d992fd4340756a250597780b901e8dfff56b4976f51e32a496602fc643606','core/documentation-window.mjs':'f264ab7969015dd9eaf5209a34373b9a83d5f369153055b40d32724231aa1580','documentation.html':'a209f163762bea7fc323e92919103544e78d80821982f9a739478dc552992cc7'};
for(const [file,sha] of Object.entries(expected))assert.equal(hash(await readFile(new URL('../'+file,import.meta.url))),sha,file);
console.log(JSON.stringify({pass:true,checks:8,scope:'Exact R4 stamp and temporary URL hash normalization reverse to R3; exact final stamp and reviewed barrier reversed to ce96; inherited three editor additions then reverse to dc71; exact reviewed final Docs runtime and PWA worker'}));
