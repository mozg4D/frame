// Offline source-only patcher. Never modifies the r5 input, installs dependencies,
// executes project code, launches a browser, or accepts an existing destination.
import {readFile,readdir,lstat,mkdir,writeFile,realpath} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,join,dirname,basename,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
const bundle=dirname(fileURLToPath(import.meta.url)),sha=b=>createHash('sha256').update(b).digest('hex');
const BASE='a0baca9e5312423212490aee7c6ecc5239321f4f9c60a2a75278a355d2456312';
const directories=new Set(['core','plugins','kernels','textures','models','tools','tests','qualification']);
const rootFile=name=>/\.(html|js|mjs|json|webmanifest|png|ico|svg)$/.test(name)&&name!=='DOCS-GATE-INVENTORY.json'&&!/^DOCS.*RESULT\.json$/.test(name);
function safe(path){if(typeof path!=='string'||!path||path.includes('\\')||path.startsWith('/')||path.includes(':')||path.split('/').some(p=>!p||p==='.'||p==='..'))throw Error('Unsafe patch path');return path;}
async function exists(path){try{await lstat(path);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
async function regular(path){const stat=await lstat(path);if(!stat.isFile()||stat.isSymbolicLink())throw Error('Expected an ordinary source file: '+path);return readFile(path);}
async function inventory(root){const out={};async function walk(relative){for(const item of(await readdir(join(root,relative),{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){const path=relative?relative+'/'+item.name:item.name;if(path==='tests/results'||item.name==='node_modules'||item.name==='.git')continue;if(item.isSymbolicLink())throw Error('Unexpected source symlink: '+path);if(item.isDirectory()){if(relative||directories.has(item.name))await walk(path);}else if(item.isFile()&&(relative||rootFile(item.name)))out[path]=sha(await readFile(join(root,path)));}}await walk('');return out;}
function sameFiles(actual,expected,label){for(const path of new Set([...Object.keys(actual),...Object.keys(expected)]))if(actual[path]!==expected[path])throw Error(label+': '+path);}
async function main(){
 const [mode,sourceArg,destinationArg,...extra]=process.argv.slice(2);if(!['--check','--apply'].includes(mode)||!sourceArg||extra.length||(mode==='--check'&&destinationArg)||(mode==='--apply'&&!destinationArg))throw Error('Usage: node apply-docs-r5-sync.mjs --check R5_FAILED_FOLDER | --apply R5_FAILED_FOLDER NEW_R5_SYNC_FOLDER');
 const sourceInput=resolve(sourceArg);if(!(await lstat(sourceInput)).isDirectory()||(await lstat(sourceInput)).isSymbolicLink())throw Error('Input must be an ordinary r5 directory');const source=await realpath(sourceInput);
 const destination=destinationArg?resolve(destinationArg):null;
 if(destination){if(destination===source||destination.startsWith(source+sep)||source.startsWith(destination+sep))throw Error('Destination must be a new separate sibling directory');if(await exists(destination))throw Error('Destination already exists; nothing was changed');const parent=await realpath(dirname(destination));const canonicalDestination=join(parent,basename(destination));const key=p=>process.platform==='win32'?p.toLowerCase():p;const a=key(source),b=key(canonicalDestination);if(a===b||b.startsWith(a+sep)||a.startsWith(b+sep))throw Error('Destination resolves inside or around input');}
 const manifest=JSON.parse(await regular(join(bundle,'PATCH-MANIFEST.json')));if(manifest.format!==1||manifest.baseInventorySHA256!==BASE)throw Error('Unexpected patch format or predecessor');
 const script=await regular(fileURLToPath(import.meta.url));if(sha(script)!==manifest.toolSHA256)throw Error('Patch tool checksum mismatch');
 const baseRaw=await regular(join(bundle,safe(manifest.baseInventoryFile)));if(sha(baseRaw)!==BASE)throw Error('Bundled r5 inventory checksum mismatch');
 const base=JSON.parse(baseRaw);if(base.version!==1||!base.files||Object.keys(base.files).length!==192)throw Error('Invalid r5 source inventory');
 const currentRaw=await regular(join(source,'DOCS-GATE-INVENTORY.json'));if(sha(currentRaw)!==BASE)throw Error('Input is not the exact frozen failed-test r5 inventory');sameFiles(await inventory(source),base.files,'Input source differs from frozen failed-test r5');
 const originals={};for(const [path,want] of Object.entries({...base.files,...manifest.baseExtraFiles})){safe(path);const bytes=await regular(join(source,path));if(sha(bytes)!==want)throw Error('Original file checksum mismatch: '+path);originals[path]=bytes;}
 originals['DOCS-GATE-INVENTORY.json']=currentRaw;
 const outputs=new Map(Object.entries(originals)),changed=new Set();
 for(const change of manifest.changes){
  const path=safe(change.path);if(changed.has(path))throw Error('Duplicate change: '+path);changed.add(path);
  const before=originals[path];if(change.beforeSHA256===null){if(before||await exists(join(source,path)))throw Error('Unexpected existing addition: '+path);}else if(!before||sha(before)!==change.beforeSHA256)throw Error('Wrong original change bytes: '+path);
  let bytes;
  if(change.kind==='replace-utf8'){
   if(!before||!Array.isArray(change.replacements))throw Error('Invalid exact text patch: '+path);let text=before.toString('utf8');if(!Buffer.from(text,'utf8').equals(before))throw Error('Source is not exact UTF-8');
   for(const replacement of change.replacements){if(typeof replacement.from!=='string'||!replacement.from||typeof replacement.to!=='string'||!Number.isSafeInteger(replacement.count)||replacement.count<1)throw Error('Invalid text replacement');if(text.split(replacement.from).length-1!==replacement.count)throw Error('Exact replacement count mismatch: '+path);text=text.split(replacement.from).join(replacement.to);}bytes=Buffer.from(text,'utf8');
  }else if(change.kind==='file'){bytes=await regular(join(bundle,safe(change.payload)));}else throw Error('Unsupported patch operation');
  if(sha(bytes)!==change.afterSHA256)throw Error('Replacement payload checksum mismatch: '+path);outputs.set(path,bytes);
 }
 const targetRaw=outputs.get('DOCS-GATE-INVENTORY.json');if(!targetRaw||sha(targetRaw)!==manifest.targetInventorySHA256)throw Error('Target source inventory mismatch');const target=JSON.parse(targetRaw);if(target.version!==1||!target.files)throw Error('Invalid target inventory');
 for(const [path,want] of Object.entries(target.files)){safe(path);if(!outputs.has(path)||sha(outputs.get(path))!==want)throw Error('Target source cannot be reconstructed: '+path);}
 for(const path of Object.keys(base.files))if(!(path in target.files))throw Error('Source removal is not permitted: '+path);
 const extras=manifest.targetExtraFiles||{};for(const [path,bytes] of outputs)if(path!=='DOCS-GATE-INVENTORY.json'&&!(path in target.files)&&extras[path]!==sha(bytes))throw Error('Unexpected output outside target inventory: '+path);
 for(const [path,want] of Object.entries(extras))if(!outputs.has(path)||sha(outputs.get(path))!==want)throw Error('Target extra checksum mismatch: '+path);
 const baseCheck=async()=>{if(sha(await regular(join(source,'DOCS-GATE-INVENTORY.json')))!==BASE)throw Error('Input inventory changed during operation');sameFiles(await inventory(source),base.files,'Input drifted during operation');for(const [path,want] of Object.entries(manifest.baseExtraFiles))if(sha(await regular(join(source,path)))!==want)throw Error('Input extra drifted: '+path);};
 await baseCheck();
 if(mode==='--check')return {pass:true,mode:'check only; no files written',baseInventorySHA256:BASE,targetInventorySHA256:manifest.targetInventorySHA256,changes:changed.size,targetSourceFiles:Object.keys(target.files).length};
 await mkdir(destination);try{
  for(const [path,bytes] of outputs){await mkdir(dirname(join(destination,path)),{recursive:true});await writeFile(join(destination,path),bytes,{flag:'wx'});}
  sameFiles(await inventory(destination),target.files,'Applied source differs from target');if(sha(await regular(join(destination,'DOCS-GATE-INVENTORY.json')))!==manifest.targetInventorySHA256)throw Error('Applied target inventory differs');for(const [path,want] of Object.entries(extras))if(sha(await regular(join(destination,path)))!==want)throw Error('Applied extra differs: '+path);await baseCheck();
 }catch(error){error.message+='; input was not modified. Destination is incomplete: preserve it for diagnosis and do not run it.';throw error;}
 return {pass:true,mode:'applied into new directory; original preserved',destination,baseInventorySHA256:BASE,targetInventorySHA256:manifest.targetInventorySHA256,changes:changed.size,targetSourceFiles:Object.keys(target.files).length,dependencies:'Not copied or installed. Reuse only the already authorized existing browser setup.',reports:'Original R5 reports remain in the original directory; no historical result is relabelled as a synchronous-fixture pass.'};
}
try{console.log(JSON.stringify(await main(),null,2));}catch(error){console.error(JSON.stringify({pass:false,error:error.message},null,2));process.exitCode=1;}
