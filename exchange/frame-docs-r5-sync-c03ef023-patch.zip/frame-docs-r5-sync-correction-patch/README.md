# R5 synchronous-predicate test correction

Test-only overlay from failed corrected inventory a0baca9e… (192 sources). All runtime/index/SW/Docs bytes and version 2026 07 nov 23:20 remain identical to R5. The prior async-predicate CPU model did not reproduce the installed Playwright poller. Previous CPU PASS and Windows FAIL evidence remain historical and unchanged, not reclassified as current qualification.

Inherited R5 source/layer/package maps are intentionally unchanged historical provenance. The new source inventory and exact overlay bind the current tests. No runtime/provenance scaffolding, timing relaxation or error filtering is added by packaging.

Verify the ZIP SHA-256 supplied separately. From this patch folder set $Failed to the exact failed corrected source (a0baca…), and $Fixed to a NEW sibling destination:

    node .\apply-docs-r5-sync.mjs --check $Failed
    if ($LASTEXITCODE -ne 0) { throw 'Input preflight failed' }
    node .\apply-docs-r5-sync.mjs --apply $Failed $Fixed
    if ($LASTEXITCODE -ne 0) { throw 'Patch failed; preserve incomplete output' }
    node "$Fixed\tests\docs-final-cpu-gate.mjs"
    if ($LASTEXITCODE -ne 0) { throw 'CPU16 failed' }

Only after authorization, using existing resolvable Playwright/Chromium: first run the tiny actual-poller about:blank smoke (no Frame or WebGPU), then the unchanged sequential full nine-stage hardware gate. Stop on any failure:

    node "$Fixed\tests\file-controls-predicate-smoke.mjs"
    if ($LASTEXITCODE -ne 0) { throw 'STOP: blank poller contract failed' }
    node "$Fixed\tests\docs-integrated-browser-gate.mjs" --headless
    if ($LASTEXITCODE -ne 0) { throw 'STOP: focused browser gate failed' }

No browser runs, dependency installation or copying node_modules by the applier. It verifies all source before/after, refuses existing output and leaves original reports untouched. If ad hoc diagnostics polluted inventoried paths, preserve that tree and reconstruct the exact base from its previously verified patch chain. Never delete failures, relax checks or regenerate baseline inventory.

The full runner checks source around every child, stops on failure and keeps its existing five-minute child limit. Forced termination leaves descendant cleanup uncertain. Preserve reports before later reruns. No standard/stress, unrelated Unite, printer/CNC work, user scenes/media, main/live changes, uploads or publication. OS IME and broader release qualification remain separate.
