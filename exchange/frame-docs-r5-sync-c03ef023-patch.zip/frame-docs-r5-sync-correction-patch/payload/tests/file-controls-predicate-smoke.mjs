// Isolated about:blank check of the exact recent-Open helper. No Frame page,
// scene import, WebGPU workload, browser download, or existing user context.
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {chromium} from 'playwright';
const require=createRequire(import.meta.url),source=await readFile(new URL('./file-controls.mjs',import.meta.url),'utf8');
const start=source.indexOf('open=async name=>{'),end=source.indexOf('\n try{',start);assert.ok(start>=0&&end>start);
const helper=source.slice(start+5,end).trim().replace(/;$/,''),sha=x=>createHash('sha256').update(x).digest('hex');
const checks=[],unexpected=[];let browser;
const bounded=(promise,label)=>{let timer;return Promise.race([promise,new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('Smoke deadline: '+label)),5000))]).finally(()=>clearTimeout(timer));};
async function setup(){
 const context=await browser.newContext({viewport:{width:1280,height:900},serviceWorkers:'block'}),page=await context.newPage();page.setDefaultTimeout(3000);
 page.on('pageerror',error=>unexpected.push(error.stack||error.message));page.on('console',message=>{if(message.type()==='error')unexpected.push(message.text());});
 await page.goto('about:blank');
 await page.setContent('<div id="app"><button id="btnOpen">Open</button><button role="menuitem">selected.hash</button><div id="obInner"><div class="ob-row">Old row</div></div></div><div id="frame-engine-canvas" data-ready="true"></div>');
 await page.evaluate(()=>{
  window.__writes=Promise.resolve();window.__writeReads=0;window.__clicked=false;window.__inspectCount=0;
  Object.defineProperty(window,'recentFileWrites',{configurable:true,get(){__writeReads++;return __writes;},set(value){__writes=value;}});
  window.recentFilesReady=Promise.resolve();window.recentFileNames=['selected.hash'];window.frameEngine={idle:true};
  window.frameAI={call:async name=>{if(name!=='scene.inspect')throw Error('Unexpected smoke API call');if(!frameEngine.idle)throw Object.assign(Error('Finish the native file operation first'),{code:'BUSY'});__inspectCount++;return {objects:[{name:'New row'}]};}};
  document.querySelector('[role="menuitem"]').onclick=()=>{__clicked=true;};
 });
 return {page,context};
}
function runHelper(page,text=helper){
 let state='pending',error;let before;let entered;const waiting=new Promise(resolve=>entered=resolve);
 // Forward the exact function to real Playwright; never invoke/await it here.
 const observedPage=new Proxy(page,{get(target,key){if(key==='waitForFunction')return (fn,arg,options)=>{before=arg.before;const result=target.waitForFunction(fn,arg,options);entered();return result;};const value=Reflect.get(target,key);return typeof value==='function'?value.bind(target):value;}});
 const open=new Function('page','call','persist','return ('+text+');')(observedPage,(name,args)=>page.evaluate(([name,args])=>frameAI.call(name,args),[name,args]),()=>page.evaluate(async()=>{await recentFilesReady;await recentFileWrites;}));
 const task=open('selected.hash');task.then(()=>state='fulfilled',e=>{state='rejected';error=e.message;});
 return {task,waiting,get state(){return state;},get error(){return error;},get before(){return before;}};
}
async function check(name,fn){const started=performance.now();try{const detail=await fn();checks.push({name,pass:true,elapsedMs:performance.now()-started,detail});}catch(error){checks.push({name,pass:false,elapsedMs:performance.now()-started,error:error.stack});throw error;}}
let failure;
try{
 browser=await chromium.launch({headless:true,channel:'chromium',executablePath:process.env.FRAME_BROWSER||undefined,timeout:15000});
 await check('Exact synchronous helper stays pending across old idle, early row and pending persistence',async()=>{
  const {page,context}=await setup();try{
   const run=runHelper(page);await bounded(run.waiting,'waiter entry');
   await page.waitForFunction(()=>__clicked&&__writeReads>=3);assert.equal(run.state,'pending');assert.equal(await page.evaluate(()=>__inspectCount),0);
   const reads=await page.evaluate(()=>{frameEngine.idle=false;document.querySelector('#app').inert=true;document.querySelector('#frame-engine-canvas').dataset.ready='loading';document.querySelector('.ob-row').textContent='New row';return __writeReads;});
   await page.waitForFunction(reads=>__writeReads>=reads+2,reads);assert.equal(run.state,'pending');assert.equal(await page.evaluate(()=>__inspectCount),0);
   await page.evaluate(()=>{frameEngine.idle=true;document.querySelector('#app').inert=false;document.querySelector('#frame-engine-canvas').dataset.ready='true';recentFileWrites=new Promise(resolve=>window.__resolveWrites=resolve);});
   await page.waitForFunction(before=>before.observed===recentFileWrites&&!before.settled,run.before);assert.equal(run.state,'pending');assert.equal(await page.evaluate(()=>__inspectCount),0);
   await page.evaluate(()=>__resolveWrites());await bounded(run.task,'completed helper');assert.equal(run.state,'fulfilled');assert.equal(await page.evaluate(()=>__inspectCount),1);
   return {oldIdleHeld:true,earlyRowHeld:true,persistenceHeld:true,inspectCalls:1,returnedHandleMustBeTrue:true};
  }finally{await context.close();}
 });
 await check('Exact helper rejects caught persistence error without inspecting',async()=>{
  const {page,context}=await setup();try{
   const run=runHelper(page);await bounded(run.waiting,'waiter entry');await page.waitForFunction(()=>__writeReads>=3);
   await page.evaluate(()=>{recentFileWrites=new Promise((_,reject)=>window.__rejectWrites=reject).catch(error=>{document.querySelector('#frame-engine-canvas').dataset.operationError=error.message;});});
   await page.waitForFunction(before=>before.observed===recentFileWrites&&!before.settled,run.before);assert.equal(run.state,'pending');await page.evaluate(()=>__rejectWrites(Error('smoke persistence failure')));
   await assert.rejects(bounded(run.task,'storage error'),/smoke persistence failure/);assert.equal(await page.evaluate(()=>__inspectCount),0);return {error:run.error,inspectCalls:0};
  }finally{await context.close();}
 });
 await check('Exact returned-handle guard catches an accidental async predicate',async()=>{
  const {page,context}=await setup();try{
   const mutant=helper.replace('page.waitForFunction(({before,name})=>{','page.waitForFunction(async({before,name})=>{');assert.notEqual(mutant,helper);
   const run=runHelper(page,mutant);await assert.rejects(bounded(run.task,'async predicate guard'),/completion predicate returned a non-true result/);assert.equal(await page.evaluate(()=>__inspectCount),0);return {error:run.error,inspectCalls:0};
  }finally{await context.close();}
 });
}catch(error){failure=error.stack||String(error);}finally{await browser?.close();}
const report={pass:!failure&&!unexpected.length&&checks.length===3&&checks.every(c=>c.pass),scope:'Real existing Playwright and Chromium on isolated about:blank only; exact helper with synthetic completion signals. No Frame/GPU qualification.',playwrightVersion:require('playwright/package.json').version,fileControlsSHA256:sha(source),helperSHA256:sha(helper),checks,unexpected,...failure?{error:failure}:{}};
await mkdir(new URL('./results/',import.meta.url),{recursive:true});await writeFile(new URL('./results/file-controls-predicate-smoke.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));if(!report.pass)process.exitCode=1;
