// CPU-only contract proof. Verbatim runtime functions; stubbed DOM/GPU/decode dependencies.
// No browser/GPU. Report creation is self-contained on a clean source-only package.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root=new URL('../',import.meta.url);
const html=await readFile(new URL('index.html',root),'utf8');
const sha=x=>createHash('sha256').update(x).digest('hex');
const pieces={};
function extract(name,start,end){const a=html.indexOf(start),b=html.indexOf(end,a+start.length);assert.ok(a>=0&&b>a,name);pieces[name]={startLine:html.slice(0,a).split('\n').length,sha256:sha(html.slice(a,b)),source:html.slice(a,b)};return pieces[name].source;}
const native=extract('nativeIO','    function nativeIOStart(label){','    async function nativeReadGPU');
const load=extract('loadHash','    async function loadHash(file,name=file.name','    async function newFile()');
const event=extract('nativeSceneEvent','    function nativeSceneEvent(name){','    function nativeSceneStats(name){');
const queue=extract('enqueueAndNativeTask','      let documentationWindow=null;','      const fail=');
const call=extract('call','      async function call(name,args={},bridgeGuard=null)','\n');
const placeholder=extract('openScenePlaceholder','async function openScenePlaceholder(name)','\n');
const open=extract('openSceneFile','async function openSceneFile(file','\n');
const remember=extract('rememberSceneFile','function rememberSceneFile(source','\n');
const persist=extract('persistRecentFiles','function persistRecentFiles(){','\n');
const fileDispatch=extract('loadFileDispatch','      loadFile:(file,options)=>','\n').trim().replace(/,$/,'');
const idle=extract('idle','      get idle(){','\n').trim().replace(/,$/,'');
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const watchdog=(promise,label)=>{let timer;return Promise.race([promise,new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('Bounded proof timed out: '+label)),2000))]).finally(()=>clearTimeout(timer));};
const results=[];
function env({priorRows=true,holdSource=false}={}){
 const events=[],gates={source:deferred(),draw:deferred(),gpu:deferred(),persist:deferred()},reached={source:deferred(),draw:deferred(),gpu:deferred(),persist:deferred()};
 const app={inert:false},button={disabled:false},canvas={dataset:{ready:'true'}},status={hidden:true},elements=new Map([['app',app],['frame-engine-read',button],['frame-engine-canvas',canvas],['dV',{}]]);
 let progress=null;
 const record=(kind,extra={})=>events.push({kind,...snap(),...extra});
 const snap=()=>({rows:c.rows.map(x=>x.name),idle:c.api.idle,inert:app.inert,buttonDisabled:button.disabled,ready:canvas.dataset.ready,progress:!!progress,operationError:canvas.dataset.operationError||null,remembered:c.remembered,sceneEventCount:c.sceneEventCount});
 const file=new File(['synthetic payload is not decoded'],'selected.hash');
 const c={performance,setTimeout,Map,Set,Promise,Uint32Array,JSON,Blob,console,events,rows:priorRows?[{name:'old row'}]:[],remembered:0,sceneEventCount:0,
 nativeIOBusy:false,selectionBusy:false,editDrag:null,gizmoSession:null,coreNumeric:null,editFinishing:false,undoBusy:false,button,canvas,status,hoverCursor:{inside:false},scene:{meshes:[],records:new Map()},sceneFrameDirty:false,displayUnitIndex:2,rescaleUnitIndex:2,units:['m','cm','mm'],selectionScope:null,objectSelection:[],componentPivot:null,metaUndo:[],metaRedo:[],selectionSignature:'',lastImportReport:null,
 objectActionQueue:Promise.resolve(),clipboardSerial:Promise.resolve(),selectionQueue:Promise.resolve(),editSerial:Promise.resolve(),appearanceQueue:Promise.resolve(),replicaQueue:Promise.resolve(),animationSerial:Promise.resolve(),tail:Promise.resolve(),sequence:0,
 splineMaterialOrigins:new Map(),polygonTools:{soft:true},frameSoloIds:null,appearanceSignature:'',FrameHash:{K:{parameters:'params'}},
 recentFilesReady:Promise.resolve(),recentSceneFiles:new Map(),recentFileCompanions:new Map(),recentFileNames:['selected.hash'],recentFileWrites:Promise.resolve(),sceneFileName:'old.hash',sceneFileHandle:null,
 FramePlugins:{ready:Promise.resolve()},FrameSpline:{flush:async()=>{}},docs:{get:()=>({version:'fixture:0'})},settle:async()=>{},tools:new Map(),validate:()=>{},json:x=>x,stop:()=>{},
 fail:(code,message)=>{throw Object.assign(Error(message),{code});},CustomEvent:class{constructor(type,init){this.type=type;this.detail=init.detail;}},
 fileOperationError:e=>{canvas.dataset.operationError=e.message;record('operation-error',{message:e.message});},
 document:{getElementById:id=>id==='frame-file-progress'?progress:elements.get(id),createElement:()=>({setAttribute(){},remove(){progress=null;}})},
 $:id=>id==='btnSolo'?{classList:{remove(){}},ariaPressed:false}:elements.get(id),
 nativeDecodePlan:async()=>({objects:[{hash:'new-hash',name:'new row',flags:3,type:0}],meshes:0,appearance:{ids:[]},records:new Map(),camera:[],importReport:{}}),
 nativeObjects:()=>[{hash:'new-hash',name:'new row',flags:3,type:0}],appearanceLibrary:()=>[],nativeSceneStats:()=>{},
 getRenderer:async()=>({device:{queue:{writeBuffer(){},onSubmittedWorkDone(){record('gpu-wait');reached.gpu.resolve();return gates.gpu.promise;}}}}),
 sceneFromMeshes:(_gpu,meshes)=>({meshes,records:new Map(),triangleCount:0}),
 draw:()=>{record('draw-wait');reached.draw.resolve();return gates.draw.promise;},
 window:{dispatchEvent:e=>{if(e.type==='frame-engine-scene'){c.rows=e.detail.objects;c.sceneEventCount++;record('scene-event',{name:e.detail.name});}else record(e.type,e.detail);}}
 };
 c.recentFilesDB=Promise.resolve({transaction(){const tx={objectStore:()=>({put(){c.remembered++;record('persist-wait');reached.persist.resolve();}})};gates.persist.promise.then(()=>tx.oncomplete(),error=>{tx.error=error;tx.onerror();});return tx;}});
 elements.set('frame-engine-host',{append(el){progress=el;record('native-start');}});
 for(const name of ['touchActivity','frameSyncMaterials','endPolygonTool','clearSplineDisplays','clearEdits','checkSession','disposeScene','clearFeatureDraws','clearPickGroups','installNativeRecords','uploadPolygonSets','resetView','applyNativeCamera','setVisibility','disposeMesh','trimRecentFiles'])c[name]=()=>{};
 c.api={ready:Promise.resolve()};c.window.FrameSpline=c.FrameSpline;
 const source=holdSource?{name:file.name,getFile:()=>{record('source-wait');reached.source.resolve();return gates.source.promise;}}:file;
 c.recentSceneFiles.set(file.name,source);
 vm.createContext(c);vm.runInContext(native+load+event+queue+call+placeholder+open+remember+persist+'\nObject.defineProperty(api,"idle",Object.getOwnPropertyDescriptor({'+idle+'},"idle"));api.loadFile=({'+fileDispatch+'}).loadFile;',c);
 c.window.frameEngine=c.api;c.frameEngine=c.api;
 c.tools.set('scene.inspect',{inputSchema:{},annotations:{readOnlyHint:true},run:()=>{record('inspect-run');return {objects:c.rows};}});
 return {c,events,gates,reached,snap,file,record};
}
async function test(name,fn){const started=performance.now();try{const detail=await fn();results.push({name,pass:true,elapsedMs:performance.now()-started,detail});}catch(error){results.push({name,pass:false,error:error.stack});}}
await test('New scene rows are observable while real loadHash still holds native IO, even with no old row',async()=>{
 const e=env({priorRows:false}),{c,gates,reached}=e;
 const selected=c.openScenePlaceholder('selected.hash');await watchdog(reached.draw.promise,'draw');
 assert.deepEqual(c.rows.map(x=>x.name),['new row']);assert.equal(c.api.idle,false);assert.equal(c.nativeIOBusy,true);assert.equal(c.canvas.dataset.ready,'loading');
 await assert.rejects(c.call('scene.inspect'),x=>x.code==='BUSY'&&x.message==='Finish the native file operation first');
 assert.equal(e.events.some(x=>x.kind==='frame-ai-call'),false,'Eager rejection is before command start event');
 e.record('expected-busy-after-row');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');assert.equal(c.nativeIOBusy,true);e.record('gpu-still-pending');
 gates.gpu.resolve();await watchdog(reached.persist.promise,'persistence');assert.equal(c.nativeIOBusy,false);assert.equal(c.api.idle,true);gates.persist.resolve();await watchdog(selected,'selected open');
 const result=await c.call('scene.inspect');assert.equal(result.objects[0].name,'new row');assert.equal(c.canvas.dataset.operationError,undefined);
 return {events:e.events};
});
await test('Old row plus old idle is true while current handle getFile has not admitted any native load',async()=>{
 const e=env({holdSource:true}),{c,gates,reached}=e,oldWrite=c.recentFileWrites;
 const selected=c.openScenePlaceholder('selected.hash');await watchdog(reached.source.promise,'source');
 assert.equal(c.api.idle,true);assert.equal(c.canvas.dataset.ready,'true');assert.equal(c.rows[0].name,'old row');assert.equal(c.sceneEventCount,0);assert.equal(c.recentFileWrites,oldWrite);e.record('false-old-idle-row');
 gates.source.resolve(e.file);await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persistence');
 assert.notEqual(c.recentFileWrites,oldWrite);assert.equal(c.nativeIOBusy,false);assert.equal(c.sceneEventCount,1);gates.persist.resolve();await watchdog(selected,'selected open');
 return {events:e.events};
});
await test('Post-scene idle observation admits one inspect behind native persistence instead of bypassing queue',async()=>{
 const e=env(),{c,gates,reached}=e,oldWrite=c.recentFileWrites;const selected=c.openScenePlaceholder('selected.hash');
 await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persistence');
 assert.ok(c.sceneEventCount===1&&c.api.idle&&!c.document.getElementById('app').inert&&c.canvas.dataset.ready==='true'&&!c.document.getElementById('frame-file-progress'));assert.notEqual(c.recentFileWrites,oldWrite);
 const inspection=c.call('scene.inspect');await Promise.resolve();assert.equal(e.events.some(x=>x.kind==='inspect-run'),false,'Native tail still owns persistence');gates.persist.resolve();
 const [,result]=await watchdog(Promise.all([selected,inspection]),'native completion + inspect');assert.equal(result.objects[0].name,'new row');
 return {events:e.events};
});
await test('Failed GPU completion cannot pass event plus idle: error and loading state remain explicit',async()=>{
 const e=env(),{c,gates,reached}=e,oldWrite=c.recentFileWrites;const selected=c.openScenePlaceholder('selected.hash');
 await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.reject(Error('injected GPU completion failure'));await watchdog(selected,'failed open');
 assert.equal(c.sceneEventCount,1);assert.equal(c.api.idle,true);assert.equal(c.canvas.dataset.ready,'loading');assert.equal(c.canvas.dataset.operationError,'injected GPU completion failure');assert.equal(c.recentFileWrites,oldWrite);assert.equal(c.remembered,0);
 return {events:e.events};
});
await test('Persistence failure sets operationError despite changed promise and healthy engine; success observer must fail',async()=>{
 const e=env(),{c,gates,reached}=e,oldWrite=c.recentFileWrites;const selected=c.openScenePlaceholder('selected.hash');
 await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persistence');
 const replacement=c.recentFileWrites;assert.notEqual(replacement,oldWrite);assert.equal(c.api.idle,true);assert.equal(c.canvas.dataset.ready,'true');
 gates.persist.reject(Error('injected IndexedDB write failure'));await watchdog(replacement,'caught persistence failure');await watchdog(selected,'selected open failure');
 assert.equal(c.canvas.dataset.operationError,'injected IndexedDB write failure');assert.equal(c.api.idle,true);assert.equal(c.recentFileNames[0],'selected.hash');
 return {events:e.events,note:'Actual persistRecentFiles catches the storage rejection. Awaiting the changed promise alone is NOT a success assertion; operationError must be checked after await.'};
});
// Execute the exact current UI helper against controlled, verbatim runtime functions.
const fixture=await readFile(new URL('tests/file-controls.mjs',root),'utf8');
const helperStart=fixture.indexOf('open=async name=>{'),helperEnd=fixture.indexOf('\n try{',helperStart);
assert.ok(helperStart>=0&&helperEnd>helperStart);const helper=fixture.slice(helperStart+'open='.length,helperEnd).trim().replace(/;$/,'');
// Verbatim Playwright 1.64.1 injected callback; bundle SHA-256 829521b67ed7be90c7d6d6098ff39f2241562d47e4ad7ccab13710924a56001d.
const playwrightPoller="(injected, { expression: expression3, isFunction: isFunction3, polling, arg: arg3 }) => {\n            let evaledExpression;\n            const predicate = () => {\n              let result3 = evaledExpression ?? globalThis.eval(expression3);\n              if (isFunction3 === true) {\n                evaledExpression = result3;\n                result3 = result3(arg3);\n              } else if (isFunction3 === false) {\n                result3 = result3;\n              } else {\n                if (typeof result3 === \"function\") {\n                  evaledExpression = result3;\n                  result3 = result3(arg3);\n                }\n              }\n              return result3;\n            };\n            let fulfill;\n            let reject;\n            let aborted = false;\n            const result2 = new Promise((f, r) => {\n              fulfill = f;\n              reject = r;\n            });\n            const next = () => {\n              if (aborted)\n                return;\n              try {\n                const success = predicate();\n                if (success) {\n                  fulfill(success);\n                  return;\n                }\n                if (typeof polling !== \"number\")\n                  injected.utils.builtins.requestAnimationFrame(next);\n                else\n                  injected.utils.builtins.setTimeout(next, polling);\n              } catch (e) {\n                reject(e);\n              }\n            };\n            next();\n            return { result: result2, abort: () => aborted = true };\n          }";
assert.equal(sha(playwrightPoller),"9c4696114ecb039144a3d0c7d7ee1227b606a78105a0762b99d0b850a090e9b0");
const oldAsyncHelper="async name=>{\n  // One selected Open runs in this isolated fixture. Its new persistence\n  // promise is installed only after the awaited native load has completed.\n  const before=await page.evaluateHandle(()=>({writes:recentFileWrites}));\n  try{\n   await page.mouse.move(20,450);await page.locator('#btnOpen').hover();await page.getByRole('menuitem',{name,exact:true}).click();\n   await page.waitForFunction(async({before,name})=>{\n    const canvas=document.querySelector('#frame-engine-canvas');if(canvas?.dataset.operationError)throw Error(canvas.dataset.operationError);\n    const writes=recentFileWrites;if(writes===before.writes)return false;\n    await writes;\n    if(canvas?.dataset.operationError)throw Error(canvas.dataset.operationError);\n    return frameEngine.idle&&canvas?.dataset.ready==='true'&&!document.querySelector('#app').inert&&!document.querySelector('#frame-file-progress')&&recentFileNames[0]===name;\n   },{before,name},{timeout:3000});\n   await page.locator('#obInner .ob-row').first().waitFor();await call('scene.inspect');await persist();\n   await page.evaluate(()=>{const error=document.querySelector('#frame-engine-canvas')?.dataset.operationError;if(error)throw Error(error);});\n  }finally{await before.dispose();}\n }";
function helperEnv(options={},source=helper){
 const e=env(options),{c}=e,waiting=deferred(),callRequested=deferred(),scheduled=[];let disposed=false,completedDisposed=false,nativeTask,poller,probeCount=0,waitSettled=false,waitValue,waitError,beforeValue,predicateKind;
 c.document.querySelector=selector=>selector==='#frame-engine-canvas'?c.canvas:selector==='#app'?c.document.getElementById('app'):selector==='#frame-file-progress'?c.document.getElementById('frame-file-progress'):null;
 const evaluate=(fn,arg)=>{c.__fixtureArgument=arg;return vm.runInContext('('+fn.toString()+')(__fixtureArgument)',c);};
 const page={mouse:{move:async()=>{}},getByRole:()=>({click:async()=>{nativeTask=c.openScenePlaceholder('selected.hash');if(options.clickWaitForNative)await e.reached.draw.promise;}}),locator:selector=>({hover:async()=>{},first(){return this;},waitFor:async()=>{assert.equal(selector,'#obInner .ob-row');assert.ok(c.rows.length,'Original row assertion remains');}}),
 evaluateHandle:async fn=>({value:beforeValue=await evaluate(fn),dispose:async()=>{disposed=true;}}),evaluate:async(fn,arg)=>evaluate(fn,arg),
 waitForFunction:(fn,input,options)=>{
  assert.equal(options.timeout,3000,'Native completion deadline remains 3 seconds');predicateKind=fn.constructor.name;
  c.__pollingInjected={utils:{builtins:{requestAnimationFrame:fn=>scheduled.push(fn),setTimeout:fn=>scheduled.push(fn)}}};
  c.__pollingOptions={expression:fn.toString(),isFunction:true,polling:undefined,arg:{...input,before:input.before.value}};
  poller=vm.runInContext('('+playwrightPoller+')(__pollingInjected,__pollingOptions)',c);waiting.resolve();
  return poller.result.then(value=>{waitSettled=true;waitValue=value;return {jsonValue:async()=>value,dispose:async()=>{completedDisposed=true;}};},error=>{waitSettled=true;waitError=error.message;throw error;});
 }};
 const openHelper=new Function('page','call','persist','return ('+source+');')(page,(name,args)=>{callRequested.resolve();return c.call(name,args);},async()=>{await c.recentFilesReady;await c.recentFileWrites;});
 const task=openHelper('selected.hash');task.catch(()=>{});
 const probe=async()=>{await waiting.promise;const next=scheduled.shift();if(next){probeCount++;next();}for(let i=0;i<8;i++)await Promise.resolve();return {settled:waitSettled,value:waitValue,error:waitError,scheduled:scheduled.length};};
 return {...e,waiting,callRequested,task,probe,get before(){return beforeValue;},get disposed(){return disposed;},get completedDisposed(){return completedDisposed;},get nativeTask(){return nativeTask;},get probeCount(){return probeCount;},get predicateKind(){return predicateKind;}};
}
await test('Actual helper rejects old idle/row and early new row, then awaits persistence before one inspect',async()=>{
 const e=helperEnv({holdSource:true}),{c,gates,reached}=e;await watchdog(reached.source.promise,'source');await watchdog(e.waiting.promise,'observer');
 assert.equal((await e.probe()).settled,false,'Old idle and old row do not complete the real poller');assert.equal(e.predicateKind,'Function');assert.equal(e.events.some(x=>x.kind==='inspect-run'),false);
 gates.source.resolve(e.file);await watchdog(reached.draw.promise,'draw');assert.equal((await e.probe()).settled,false,'Early row remains pending');
 gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');assert.equal((await e.probe()).settled,false);gates.gpu.resolve();await watchdog(reached.persist.promise,'persist');
 assert.equal((await e.probe()).settled,false,'Changed promise still pending is not completion');const observed=e.before.observed;assert.equal(observed,c.recentFileWrites);assert.equal(e.before.settled,false);
 assert.equal((await e.probe()).settled,false);assert.equal(e.before.observed,observed,'Subsequent polls reuse the same observed promise');assert.equal(e.events.some(x=>x.kind==='inspect-run'),false);
 gates.persist.resolve();await c.recentFileWrites;const final=await e.probe();assert.equal(final.settled,true);assert.equal(final.value,true);await watchdog(e.task,'helper');assert.equal(e.events.filter(x=>x.kind==='inspect-run').length,1);assert.equal(e.disposed,true);assert.equal(e.completedDisposed,true);return {events:e.events,probes:e.probeCount,predicateKind:e.predicateKind};
});
await test('Actual helper fails storage rejection even though persistRecentFiles catches it',async()=>{
 const e=helperEnv(),{c,gates,reached}=e;await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persist');
 assert.equal((await e.probe()).settled,false);gates.persist.reject(Error('storage failure'));await c.recentFileWrites;assert.equal((await e.probe()).error,'storage failure');await assert.rejects(e.task,/storage failure/);assert.equal(e.events.some(x=>x.kind==='inspect-run'),false);assert.equal(e.disposed,true);return {events:e.events};
});
await test('Actual helper fails native load error instead of accepting released idle or an existing row',async()=>{
 const e=helperEnv(),{gates,reached}=e;await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.reject(Error('GPU completion failure'));await watchdog(e.nativeTask,'native error');
 assert.equal((await e.probe()).error,'GPU completion failure');await assert.rejects(e.task,/GPU completion failure/);assert.equal(e.events.some(x=>x.kind==='inspect-run'),false);assert.equal(e.disposed,true);return {events:e.events};
});
await test('Actual helper detects native final-settle error after a normal queued inspect can recover',async()=>{
 const e=helperEnv(),{c,gates,reached}=e,finalSettle=deferred(),atFinalSettle=deferred();let settles=0;c.settle=async()=>{if(++settles===2){atFinalSettle.resolve();await finalSettle.promise;}};
 await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persist');
 assert.equal((await e.probe()).settled,false);gates.persist.resolve();await watchdog(atFinalSettle.promise,'final settle');await c.recentFileWrites;assert.equal((await e.probe()).value,true);await watchdog(e.callRequested.promise,'inspect admission');finalSettle.reject(Error('native final settle failure'));
 await assert.rejects(e.task,/native final settle failure/);assert.equal(e.disposed,true);assert.equal(c.canvas.dataset.operationError,'native final settle failure');assert.equal(e.events.filter(x=>x.kind==='inspect-run').length,1,'Late error must be caught after the normal inspect succeeds');return {events:e.events,settles};
});
await test('Verbatim real poller makes the old async helper fail while native load remains in flight',async()=>{
 const e=helperEnv({clickWaitForNative:true},oldAsyncHelper),{gates,reached}=e;await watchdog(reached.draw.promise,'draw');await assert.rejects(watchdog(e.task,'old async helper'),error=>error.code==='BUSY');
 const state=await e.probe();assert.equal(state.value,false);assert.equal(state.scheduled,0);assert.equal(e.predicateKind,'AsyncFunction');assert.equal(e.events.some(x=>x.kind==='inspect-run'),false);
 gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persist');gates.persist.resolve();await watchdog(e.nativeTask,'cleanup native open');return {terminalWaitValue:state.value,predicateKind:e.predicateKind,events:e.events};
});
await test('Returned-handle guard rejects an accidental async predicate before API admission',async()=>{
 const mutant=helper.replace('page.waitForFunction(({before,name})=>{','page.waitForFunction(async({before,name})=>{');assert.notEqual(mutant,helper);
 const e=helperEnv({clickWaitForNative:true},mutant),{gates,reached}=e;await watchdog(reached.draw.promise,'draw');await assert.rejects(watchdog(e.task,'async mutant guard'),/completion predicate returned a non-true result/);
 assert.equal((await e.probe()).value,false);assert.equal(e.events.some(x=>x.kind==='inspect-run'),false);assert.equal(e.completedDisposed,true);assert.equal(e.disposed,true);
 gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persist');gates.persist.resolve();await watchdog(e.nativeTask,'cleanup native open');return {guardRejected:true,events:e.events};
});

const report={pass:results.every(x=>x.pass),scope:'CPU-only semantic proof using verbatim source functions and synthetic dependency gates. No browser, rendering, GPU, real IndexedDB, import/decode, or production qualification.',candidate:new URL('.',root).pathname,indexSHA256:sha(html),fileControlsSHA256:sha(await readFile(new URL('tests/file-controls.mjs',root))),actualHelperSHA256:sha(helper),playwrightPollerSHA256:sha(playwrightPoller),oldAsyncHelperSHA256:sha(oldAsyncHelper),runtimeFragments:Object.fromEntries(Object.entries(pieces).map(([k,v])=>[k,{startLine:v.startLine,sha256:v.sha256}])),checks:results};
await mkdir(new URL('./results/',import.meta.url),{recursive:true});
await writeFile(new URL('./results/file-controls-sequence.json',import.meta.url),JSON.stringify(report,null,2)+'\n');

console.log(JSON.stringify(report,null,2));if(!report.pass)process.exitCode=1;
