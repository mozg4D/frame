Frame HASH + core Documentation: focused Windows qualification only

Technical source/test overlay. No user scenes, credentials, captured reports,
editor UI, node_modules or browser binaries are included. This is public
exchange transport, not a main/live release. The old editor copy is excluded.

Base is an existing isolated qualified HASH target with exact core 4c0d1ed8...
and required SHA manifests. Target must be NEW and outside base/package.
Existing base files, results, and other worktrees stay unchanged.
Existing Playwright + playwright-core 1.64.1 are copied, not installed.

1. Verify ZIP SHA and external manifest SHA against the delivery receipt.
2. Inspect ZIP paths: no absolute/parent paths; extract to a fresh packet dir.
3. Verify embedded PACKAGE-SHA256.json equals the external manifest byte-for-byte.
4. node prepare.mjs <qualified HASH base> <new destination> --dry-run
5. node prepare.mjs <qualified HASH base> <new destination>
6. In the new target, sequential CPU checks:
   node tests/syntax.mjs
   node tests/hash-best-effort.mjs
   node tests/plugin-references.mjs
   node tests/scene-documentation.mjs
   node tests/hash-docs-lifecycle.mjs
7. Before GPU work, read current process/GPU/RAM load using already available
   tools. Do not alter any ongoing recording/printing job, driver, setting, or process.
   If resources are materially busy/unknown, report and wait for coordination.
8. Only small focused headless gates, one at a time, hardware GPU only:
   node tests/hash-docs-browser.mjs --headless
   node tests/hash-best-effort-browser.mjs --headless
   node tests/plugin-references-browser.mjs --headless
   Each uses an isolated browser context with a tiny synthetic scene, not user
   models. Native text limits use bounded 1 Mi UTF-16 data. Do not run concurrent
   GPU gates. Preserve exact reports and all failures; stop at the first failure.

STOP after focused checks. Do NOT automatically run npm test, stress, test:all,
heavy benchmarks, 100M fixtures, Thermal/Structural/CFD solvers, or print tests.
Full standard/stress needs a separate current-load and impact assessment, with
operator coordination around other ongoing workloads. A focused pass is not a release.

The prepared-target manifest contains exact copied files. Additional base files
and historic results are not copied. Preparation validates all required inputs
before creating a new target; it never overwrites an existing target. No network,
installation, publishing, execution or browser work is performed by prepare.mjs.
