# Scene documentation core architecture

## Native storage

Documentation is plain scene-author text in the existing root HASH parameters
record, alongside timeline metadata. It is not a plugin, scene object, or
independent store. Native record reconstruction preserves current documentation;
new empty records do not inherit the previous scene's text. The decoder validates
text before publication. Native Save and Share consume the same records.

## Operations and concurrency

Seven core operations are available: docs.get, docs.create, docs.update,
docs.delete, docs.replace, docs.search, and docs.inspect. Strict schemas use the
existing command queue. Every write requires a version returned by docs.get.
The version includes a scene-session epoch and revision. Scene replacement
invalidates earlier edit tokens even if the text is identical.

Partial replacement verifies UTF-16 offsets, exact expected text, and revision.
It rejects a boundary inside a surrogate pair. Text is capped at 1 Mi UTF-16
units; whitespace-only text is absent. Nonempty leading/trailing whitespace is
preserved. Literal search returns at most 1000 matches and a truncation flag.

Standalone Object: <32-hex native HASH> lines represent object references.
Inspection reports present, missing, invalid, or ambiguous references without
removing historical mentions. A retained native shell is present even if its
plugin implementation is unavailable.

Successful text mutations mark the scene dirty and synchronously notify local
subscribers with the current text/version. Scene-reset notification occurs after
native nodes and parents have been rebuilt. Geometry Undo snapshots do not own
root documentation, so a mesh edit cannot rewind more recent text.

## Merge, copy and unknown authoring

Scene Merge appends incoming documentation under
`--- Imported scene documentation ---` when current text exists. Neither text
is deduplicated or summarized. Only exact incoming Object: HASH lines use the
actual object-identity map, including uppercase tokens. Existing references and
unresolved/malformed lines are retained. Clipboard and duplicate do not append
scene-level documentation.

Combined length is checked before geometry allocation and again against current
text after asynchronous geometry work. Text is committed only after successful
flush and same-scene validation. Geometry Undo can remove imported objects while
retaining the imported notes; their references then report missing.

Unknown plugin/tag payloads use the separate schema-aware HASH authoring path.
Opaque strings are never remapped by the documentation mapper. Declared typed
identity records retain their existing remapping semantics. Unavailable authoring
stays inactive, with unresolved-reference flags when identities were copied.
The native address collision guard protects root parameters; documentation needs
no new XOR-addressed property or plugin record.

## Native file lifecycle

Native file Open and post-picker Save share the existing API command tail.
The picker starts synchronously and reserves its queue position before it
resolves. A cancelled picker cannot create a writable. Early serializer failure
best-effort aborts the writable and preserves the original error.

Replacement Open can recover a failed or missing scene by draining previous work
without requiring an already healthy scene. Save and Merge retain normal initial
settlement. Every successful operation requires final settlement. New owns the
existing native I/O lock throughout asynchronous work.

Merge checks scene/GPU ownership around asynchronous boundaries. Failure restores
appearance metadata and resource ownership without restoring root parameters or
overwriting current documentation. The material library is recreated from native
bytes/paths before structure restoration; old asynchronous atlas work is retired.
Temporary rollback maps do not enter geometry Undo history. This is not a promise
of atomic replacement Open after prior-scene disposal if GPU upload fails.

## Separate editor boundary

No detached editor implementation is included in this core qualification.
A future same-origin editor should use one authoritative scene document, preserve
pending local drafts during conflicts, enforce scene epochs, and reject stale or
foreign message sources. Local coordinated editing does not imply cross-computer
collaboration or automatic persistence to disk.

## Qualification

CPU checks cover metadata reconstruction, version races, Unicode replacement,
reference status, Merge normalization, actual lifecycle functions with controlled
faults, queue ordering, cancellation, recovery, and cleanup. CPU mocks are not
hardware evidence. Actual native Save/Open, Share, Merge, Undo, WebGPU resource
ownership, delayed texture completion, and load budgets require browser testing
against this exact source fingerprint. Predecessor results do not qualify a new
combined core.
