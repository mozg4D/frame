import assert from 'node:assert/strict';
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {launch, ready} from '../tools/browser.mjs';

const paths = ['index.html', 'tests/hash-docs-browser.mjs', 'tools/browser.mjs', 'plugins/index.json'];
const hashes = async () => Object.fromEntries(await Promise.all(paths.map(async p => [p, createHash('sha256').update(await readFile(new URL('../' + p, import.meta.url))).digest('hex')])));
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const limit = 1048576;
const ids = {group: 'abcdef0123456789abcdef0123456789', mesh: 'bcdef0123456789abcdef0123456789a', child: 'cdef0123456789abcdef0123456789ab', instance: 'def0123456789abcdef0123456789abc'};
const keys = {text: ids.mesh, bytes: 'e'.repeat(32), refs: 'f'.repeat(32)};
const missing = '0'.repeat(32);
const importedText = `Incoming Ω 😀 e\u0301\nObject: ${ids.group.toUpperCase()}\nObject: ${ids.mesh}\nObject: ${missing}\nObject: not-a-hash\nObject: ${ids.group} extra\nLiteral ${ids.mesh}`;

// Only bounded synthetic files, packed by the application codec. No fixture files
// belonging to the user and no test-only runtime authoring/model implementation.
async function makeFixture({ids: h, keys: k, documentation}) {
  const {K, T} = FrameHash, records = new Map();
  const put = (id, type, value) => records.set(id, {id, type, value});
  const prop = (id, key, type, value) => put(FrameHash.address(id, key), type, value);
  put(K.version, T.uint32, new Uint32Array([1]));
  put(K.all, T.ids, Object.values(h));
  put(K.parameters, T.text, JSON.stringify({version: 1, frame: 0, total: 120, materials: [], documentation}));
  for (const [name, id] of Object.entries(h)) {
    prop(id, 'type', T.bytes, new Uint8Array([name === 'mesh' ? 1 : 0]));
    prop(id, 'name', T.text, 'Docs fixture ' + name);
    prop(id, 'matrix', T.float64, new Float64Array([1,0,0,0,1,0,0,0,1,0,0,0]));
    if (name !== 'group') prop(id, 'parent', T.ids, [h.group]);
  }
  prop(h.mesh, 'positions', T.float32, new Float32Array([0,0,0,12,0,0,0,9,0]));
  prop(h.mesh, 'indices', T.uint32, new Uint32Array([0,1,2]));
  prop(h.instance, 'spline', T.bytes, FrameSpline.encodeShape({type: 'instance', params: {object: h.mesh}}));
  const authoring = type => ({version: 1, plugin: {id: 'hash-docs-unavailable', type, params: {Owner: h.mesh, Note: h.group, Nested: {literal: [h.mesh, 'Object: ' + h.group]}}}, tags: [], animation: []});
  const group = authoring('hash_docs_group');
  group.pluginRecords = [{key: k.text, type: T.text}, {key: k.bytes, type: T.bytes}, {key: k.refs, type: T.ids}];
  prop(h.group, 'parameters', T.text, JSON.stringify(group));
  prop(h.mesh, 'parameters', T.text, JSON.stringify(authoring('hash_docs_mesh')));
  prop(h.group, k.text, T.text, 'Opaque Ω 😀|' + h.mesh);
  prop(h.group, k.bytes, T.bytes, new Uint8Array([0,1,127,128,255]));
  prop(h.group, k.refs, T.ids, [h.mesh, h.child]);
  const parts = [];
  for (const r of records.values()) parts.push((await FrameHash.pack(r)).blob);
  const bytes = new Uint8Array(await new Blob(parts).arrayBuffer());
  if (bytes.length > 2 * 1048576) throw Error('Synthetic fixture exceeded its bounded size');
  const chunks = [];
  for (let i = 0; i < bytes.length; i += 16384) chunks.push(String.fromCharCode(...bytes.subarray(i, i + 16384)));
  return {base64: btoa(chunks.join('')), bytes: bytes.length};
}
async function decodeFile(base64) {
  const blob = new Blob([Uint8Array.from(atob(base64), c => c.charCodeAt(0))]);
  const index = await FrameHash.index(blob), out = {};
  for (const [id, r] of index) { const v = await FrameHash.read(blob, r); out[id] = {type: r.type, value: typeof v === 'string' ? v : Array.from(v)}; }
  const global = JSON.parse(out[FrameHash.K.parameters]?.value || '{}');
  return {documentation: global.documentation ?? '', objects: out[FrameHash.K.all].value.map(hash => {
    const authoring = JSON.parse(out[FrameHash.address(hash, 'parameters')]?.value || '{}');
    return {hash, authoring, records: Object.fromEntries((authoring.pluginRecords || []).map(r => [r.key, out[FrameHash.address(hash, r.key)]]))};
  })};
}
function openComplete({bytes, previous}) {
  const c = document.querySelector('#frame-engine-canvas'), a = document.querySelector('#app');
  if (!c || a.inert || !frameEngine.idle || c.dataset.ready !== 'true' || c.dataset.operationError || !c.dataset.hashLoad || c.dataset.hashLoad === previous) return false;
  const d = JSON.parse(c.dataset.hashLoad);
  return d.fileBytes === bytes && Number.isFinite(d.elapsedMs);
}

// Uses a separate context, including when called from the shared suite.
export async function hashDocsBrowserChecks(parent) {
  const sources = await hashes(), checks = [], timings = [], cases = [], errors = [], consoleErrors = [], diagnostics = {};
  const context = await parent.context().browser().newContext({viewport: {width: 1280, height: 900}, serviceWorkers: 'block'});
  const page = await context.newPage();
  page.on('pageerror', e => errors.push(e.stack || e.message));
  page.on('console', m => { if (m.type() === 'error') consoleErrors.push(m.text()); });
  const check = (name, pass, detail) => { checks.push({name, pass: !!pass, ...(detail === undefined ? {} : {detail})}); assert.ok(pass, name + (detail === undefined ? '' : ': ' + JSON.stringify(detail))); };
  const equal = (name, a, b) => check(name, same(a, b), same(a, b) ? undefined : {actual: a, expected: b});
  const timed = async (name, budgetMs, fn) => { const start = performance.now(), value = await fn(), ms = performance.now() - start; timings.push({name, ms, budgetMs}); check(name + ' latency', ms < budgetMs, {ms, budgetMs}); return value; };
  const call = (name, args = {}) => timed(name, /scene\.(open|merge|export|share)|edit\.(paste|history)/.test(name) ? 6000 : 3000, () => page.evaluate(([n,a]) => frameAI.call(n,a), [name,args]));
  const get = () => call('docs.get');
  const update = async text => call('docs.update', {text, version: (await get()).version});
  const state = () => call('scene.inspect');
  const make = documentation => timed('Pack synthetic HASH', 3000, () => page.evaluate(makeFixture, {ids, keys, documentation}));
  const decode = data => page.evaluate(decodeFile, data.base64);
  const exported = async () => decode(await call('scene.export', {includeData: true}));
  const reject = async (name, command, args, expected) => {
    assert.ok(expected instanceof RegExp, 'Every rejection requires its specific expected error');
    const before = await get();
    // Catch inside the application page: transport failures, timeouts and other
    // Playwright exceptions must fail the test, not count as valid rejections.
    const error = await timed(name, 3000, () => page.evaluate(async ([n,a]) => {
      try { await frameAI.call(n,a); return null; }
      catch (e) { return {message:e.message, code:e.code}; }
    }, [command,args]));
    check(name + ' rejects for the specified reason', !!error && typeof error.code === 'string' && expected.test(error.message), {expected:String(expected),error});
    equal(name + ' leaves text and version unchanged', await get(), before);
  };
  let currentCase, result, scoped = false;
  const run = async (name, fn) => { currentCase = {name, pass: false}; cases.push(currentCase); await fn(); currentCase.pass = true; currentCase = null; };
  const finishGPU = () => page.evaluate(async () => { const s = window.__hashDocsGPU; await s.device.queue.onSubmittedWorkDone(); return {validation: (await s.device.popErrorScope())?.message || null, uncaptured: s.errors, lost: s.lost, changed: s.device !== frameEngine.renderer.device}; });
  const nativeOpen = async data => timed('Native file-input Open completion', 6000, async () => {
    const previous = await page.locator('#frame-engine-canvas').getAttribute('data-hash-load');
    await page.locator('#frameSceneFile').setInputFiles({name: 'docs-fixture.hash', mimeType: 'application/x-frame-hash', buffer: Buffer.from(data.base64, 'base64')});
    await page.waitForFunction(openComplete, {bytes: data.bytes, previous}, {timeout: 6000}); await state();
  });
  // Browser filesystem boundary only: real Save As menu and native streaming
  // serializer write to an in-memory writable instead of a system file dialog.
  const nativeSave = async () => timed('Native Save As HASH completion', 6000, async () => {
    await page.evaluate(() => {
      window.__hashDocsSave = {parts: [], closed: false};
      window.showSaveFilePicker = async options => ({name: options.suggestedName, createWritable: async () => ({write: async data => __hashDocsSave.parts.push(data), close: async () => { __hashDocsSave.closed = true; }})});
    });
    await page.mouse.move(400, 500); await page.locator('#btnSave').hover();
    await page.getByRole('menuitem', {name: 'Frame scene (.hash)', exact: true}).click();
    await page.waitForFunction(() => __hashDocsSave.closed && !document.querySelector('#app').inert, {}, {timeout: 6000});
    const bytes = Buffer.from(await page.evaluate(async () => Array.from(new Uint8Array(await new Blob(__hashDocsSave.parts).arrayBuffer()))));
    check('Native Save produced nonempty HASH', bytes.length > 0);
    return {base64: bytes.toString('base64'), bytes: bytes.length};
  });
  let fixture, saved;
  try {
    await page.goto(parent.url()); await ready(page);
    diagnostics.hardware = await page.evaluate(() => {
      const device = frameEngine.renderer.device;
      window.__hashDocsGPU = {device, errors: [], lost: null};
      device.addEventListener('uncapturederror', e => __hashDocsGPU.errors.push(e.error.message));
      device.lost.then(e => { __hashDocsGPU.lost = {reason: e.reason, message: e.message}; });
      device.pushErrorScope('validation');
      return device.adapterInfo ? Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(k => [k, device.adapterInfo[k]])) : null;
    }); scoped = true;
    check('Real identifiable hardware WebGPU; no software fallback', diagnostics.hardware && Object.values(diagnostics.hardware).some(v => typeof v === 'string' && v) && !diagnostics.hardware.isFallbackAdapter && !/swiftshader|llvmpipe|lavapipe|software/i.test(JSON.stringify(diagnostics.hardware)), diagnostics.hardware);
    await page.evaluate(() => {
      window.__hashDocsEvents = [];
      // Observe synchronously. Calling frameAI here would queue inspection until
      // after replacement and conceal stale node identities at reset dispatch.
      addEventListener('frame-documentation-change', e => __hashDocsEvents.push({state: structuredClone(e.detail), hashes: nodes.map(n => n.nativeHash)}));
    });
    await run('Queued Docs CRUD, CAS, UTF-16 replace, literal search and inspection', async () => {
      await call('scene.new'); const empty = await get(); equal('New scene text absent', empty.text, '');
      let d = await call('docs.create', {text: 'A😀B Ω e\u0301\n', version: empty.version});
      await reject('Create cannot overwrite existing documentation', 'docs.create', {text: 'lost', version: d.version}, /Documentation already exists/);
      await reject('Stale CAS cannot overwrite text', 'docs.update', {text: 'lost', version: empty.version}, /Documentation changed; read current version before editing/);
      await reject('Replace rejects a split surrogate', 'docs.replace', {start: 2, end: 3, expected: '\ude00', text: 'x', version: d.version}, /Replacement splits a Unicode surrogate pair/);
      await reject('Replace rejects mismatched expected text', 'docs.replace', {start: 1, end: 3, expected: 'wrong', text: 'x', version: d.version}, /Documentation replacement precondition failed/);
      d = await call('docs.replace', {start: 1, end: 3, expected: '😀', text: '🧠', version: d.version});
      equal('Replace preserves Unicode including combining mark', d.text, 'A🧠B Ω e\u0301\n');
      equal('Search uses UTF-16 offsets', (await call('docs.search', {query: '🧠'})).matches, [{start: 1, end: 3}]);
      const races = await timed('Concurrent queued CAS writers', 3000, () => page.evaluate(async v => Promise.all(['winner','loser'].map(text => frameAI.call('docs.update', {text, version: v}).then(value => ({ok:true,value}), e => ({ok:false,error:e.message})))), d.version));
      equal('Exactly one same-version queued write succeeds', races.map(r => r.ok), [true,false]); check('Concurrent CAS loser reports the specific version conflict', /Documentation changed; read current version before editing/.test(races[1].error)); equal('CAS loser cannot replace winner', (await get()).text, 'winner');
      await reject('Wrong documentation type', 'docs.update', {text: 12, version: (await get()).version}, /arguments\.text must be string/);
      await reject('Oversize documentation update', 'docs.update', {text: 'x'.repeat(limit + 1), version: (await get()).version}, /arguments\.text is too long/);
      await update('x'.repeat(limit)); check('Exact UTF-16 size limit accepted', (await call('docs.inspect')).length === limit);
      const search = await call('docs.search', {query:'x'}); check('Search result cap is 1000 with truncation', search.matches.length === 1000 && search.truncated);
      await reject('Empty search query', 'docs.search', {query:''}, /Nonempty literal search required/);
      await update(' \t\r\n '); equal('Whitespace-only documentation normalizes absent', (await get()).text, '');
      await call('docs.create', {text:'again',version:(await get()).version});
      await call('docs.delete', {version:(await get()).version}); check('Delete reports absent', !(await call('docs.inspect')).exists);
    });
    const assertShells = async (label, mapping = ids) => {
      const objects = (await state()).objects, by = name => objects.find(o => o.hash === mapping[name]);
      check(label + ' retains group/mesh shells and actual mesh triangle', by('group')?.type === 'group' && by('mesh')?.type === 'mesh' && by('mesh').mesh?.triangles === 1);
      for (const n of ['mesh','child','instance']) equal(label + ' parent ' + n, by(n)?.parent, mapping.group);
      check(label + ' retains native child and instance link', by('child')?.type === 'group' && by('instance')?.type === 'instance' && by('instance').params.object === mapping.mesh);
      const data = await exported(), owner = data.objects.find(o => o.hash === mapping.group);
      equal(label + ' opaque literal JSON remains unchanged', owner.authoring.plugin.params, {Owner:ids.mesh, Note:ids.group, Nested:{literal:[ids.mesh,'Object: '+ids.group]}});
      equal(label + ' mesh shell opaque JSON remains unchanged', data.objects.find(o => o.hash === mapping.mesh).authoring.plugin.params, {Owner:ids.mesh, Note:ids.group, Nested:{literal:[ids.mesh,'Object: '+ids.group]}});
      equal(label + ' declared text including field key remains literal', owner.records[keys.text], {type:7,value:'Opaque Ω 😀|'+ids.mesh});
      equal(label + ' declared binary bytes preserved', owner.records[keys.bytes], {type:0,value:[0,1,127,128,255]});
      equal(label + ' declared typed identities follow native mapping', owner.records[keys.refs], {type:4,value:[mapping.mesh,mapping.child]});
      if (mapping.group !== ids.group) check(label + ' remapped plugin shell is explicitly unresolved', owner.authoring.pluginReferencesUnresolved === true);
    };
    await run('Native Open/Save and Share with unavailable owners and scene epoch', async () => {
      fixture = await make(importedText);
      diagnostics.fixture = {bytes:fixture.bytes, sha256:createHash('sha256').update(Buffer.from(fixture.base64,'base64')).digest('hex')};
      const sentinel = await call('scene.create', {type:'group', name:'Previous scene reset sentinel'});
      await update('Previous scene text\nObject: '+sentinel.hash);
      const old = await get(); await nativeOpen(fixture);
      equal('Native Open imports documentation exactly', (await get()).text, importedText); check('Open changes epoch', (await get()).version.split(':')[0] !== old.version.split(':')[0]);
      await reject('Old scene version rejected after Open', 'docs.update', {text:'lost',version:old.version}, /Documentation changed; read current version before editing/);
      const event = await page.evaluate(() => __hashDocsEvents.at(-1));
      equal('Synchronous Open reset observes rebuilt node identities', [...event.hashes].sort(), Object.values(ids).sort());
      equal('Synchronous Open reset observes new text', event.state.text, importedText);
      check('Reset event excludes previous-scene identity', !event.hashes.includes(sentinel.hash));
      equal('References classify present/missing/invalid without dropping lines', (await call('docs.inspect')).references.map(r=>r.status), ['present','present','missing','invalid','invalid']);
      await assertShells('Opened'); saved = await nativeSave(); equal('Native Save stores root documentation', (await decode(saved)).documentation, importedText);
      await call('scene.new'); const newEvent = await page.evaluate(() => __hashDocsEvents.at(-1)); equal('New reset synchronously observes empty nodes', newEvent.hashes, []); equal('New clears docs', (await get()).text, '');
      await nativeOpen(saved); await assertShells('Save/Open'); equal('Save/Open keeps exact text', (await get()).text, importedText);
      const shared = await call('scene.share'); check('Share returns embedded HASH link', typeof shared.url === 'string' && shared.url.includes('#scene='));
      await call('scene.new'); await call('scene.open', {url:shared.url}); await assertShells('Share/Open'); equal('Share/Open preserves documentation', (await get()).text, importedText);
    });
    await run('Duplicate and native clipboard do not import scene documentation', async () => {
      const before = await get();
      const assertCopy = async (label, previous, result) => {
        const after = (await state()).objects, previousIDs = new Set(previous.map(o=>o.hash));
        equal(label + ' adds exactly the four native subtree objects', after.length, previous.length + 4);
        const fresh = after.filter(o=>!previousIDs.has(o.hash));
        equal(label + ' publishes four distinct fresh native IDs', new Set(fresh.map(o=>o.hash)).size, 4);
        check(label + ' fresh IDs are valid and not source identities', fresh.every(o=>/^[a-f0-9]{32}$/.test(o.hash) && !Object.values(ids).includes(o.hash)));
        const root = fresh.find(o=>o.name==='Docs fixture group' && o.parent===null);
        check(label + ' returns the new native root', root && result.objects.some(o=>o.hash===root.hash));
        const mapping = {group:root.hash};
        for (const name of ['mesh','child','instance']) mapping[name] = fresh.find(o=>o.parent===root.hash && o.name==='Docs fixture '+name)?.hash;
        check(label + ' retains every native child with a fresh identity', Object.values(mapping).every(Boolean) && new Set(Object.values(mapping)).size===4);
        const withoutSelection = ({selected, ...object}) => object;
        for (const old of previous) equal(label + ' leaves resident object '+old.hash+' unchanged apart from selection', withoutSelection(after.find(o=>o.hash===old.hash)), withoutSelection(old));
        await assertShells(label, mapping);
        equal(label + ' does not append documentation or change version', await get(), before);
      };
      let previous = (await state()).objects;
      const duplicate = await call('scene.duplicate', {ids:[ids.group]});
      await assertCopy('Duplicate', previous, duplicate);
      await call('scene.select', {ids:[ids.group]}); await call('edit.copy');
      previous = (await state()).objects;
      const paste = await call('edit.paste');
      await assertCopy('Clipboard paste', previous, paste);
    });
    await run('Merge remaps only exact incoming Object refs; text survives geometry Undo/Redo', async () => {
      await nativeOpen(saved);
      const current = `Current stays\nObject: ${ids.group}\nObject: ${ids.mesh.toUpperCase()}`;
      await update(current);
      await context.route('**/hash-docs-incoming.hash', route => route.fulfill({contentType:'application/octet-stream',body:Buffer.from(fixture.base64,'base64')}));
      const roots = await call('scene.merge', {url:'hash-docs-incoming.hash'}), group = roots.objects.find(o=>o.name==='Docs fixture group');
      check('Merge creates a fresh group identity', group && group.hash !== ids.group);
      const objects = (await state()).objects, mapping = {group:group.hash};
      for (const name of ['mesh','child','instance']) mapping[name] = objects.find(o=>o.parent===group.hash && o.name==='Docs fixture '+name)?.hash;
      check('Actual merged identities are all distinct and valid', Object.values(mapping).every(h=>typeof h==='string' && /^[a-f0-9]{32}$/.test(h)) && new Set(Object.values(mapping)).size===4);
      const incoming = importedText.replace('Object: '+ids.group.toUpperCase(), 'Object: '+mapping.group).replace('Object: '+ids.mesh+'\n', 'Object: '+mapping.mesh+'\n');
      const expected = current+'\n\n--- Imported scene documentation ---\n'+incoming;
      equal('Current refs untouched, exact incoming uppercase/lowercase refs remapped; literal/malformed refs untouched', (await get()).text, expected);
      await assertShells('Merged', mapping);
      const newest = expected+'\nNewest independent text 🧠'; await update(newest);
      await call('edit.history', {action:'undo'}); equal('Geometry Undo preserves newest docs', (await get()).text, newest);
      check('Merge Undo removes imported geometry', !(await state()).objects.some(o=>o.hash===mapping.group));
      equal('Undo keeps historical refs but marks imported objects missing', (await call('docs.inspect')).references.map(r=>r.status), ['present','present','missing','missing','missing','invalid','invalid']);
      await call('edit.history', {action:'redo'}); equal('Geometry Redo preserves newest docs', (await get()).text, newest);
      equal('Redo resolves imported refs again', (await call('docs.inspect')).references.map(r=>r.status), ['present','present','present','present','missing','invalid','invalid']);
      const final = await nativeSave(); await call('scene.new'); await nativeOpen(final); equal('Merge/edit/Undo/Redo/Save/Open keeps newest text', (await get()).text, newest); await assertShells('Reopened merge', mapping);
      equal('Reopened merge keeps ref statuses', (await call('docs.inspect')).references.map(r=>r.status), ['present','present','present','present','missing','invalid','invalid']);
    });
    await run('Invalid HASH docs preflight and Merge combined-size rejection are atomic', async () => {
      const objects = (await state()).objects;
      for (const [label,text] of [['wrong-type',12],['oversize','x'.repeat(limit+1)]]) {
        const bad = await make(text); await reject('HASH '+label, 'scene.open', {name:label+'.hash',base64:bad.base64}, /Invalid scene author metadata/); equal(label+' preserves published objects', (await state()).objects, objects);
      }
      await update('x'.repeat(limit)); const before = (await state()).objects;
      await reject('Merge refuses combined documentation overflow', 'scene.merge', {url:'hash-docs-incoming.hash'}, /Invalid documentation text/); equal('Overflow Merge leaves native objects unchanged', (await state()).objects, before);
      const whitespace = await make(' \t\r\n '); await call('scene.open', {name:'whitespace.hash',base64:whitespace.base64}); equal('HASH whitespace normalization agrees with API', (await get()).text, '');
      const version = (await get()).version; await call('scene.new'); check('New scene invalidates equal empty-text epoch', (await get()).version.split(':')[0] !== version.split(':')[0]);
      await reject('Previous empty scene token is stale', 'docs.update', {text:'lost',version}, /Documentation changed; read current version before editing/);
    });
    await call('scene.open', {name:'docs-final-frame-fixture.hash',base64:fixture.base64});
    diagnostics.frames = await call('diagnostics.frame', {frames:3});
    check('Measured CPU/GPU frames stay within existing small-scene budget', diagnostics.frames.frames.length===3 && diagnostics.frames.frames.every(f=>Number.isFinite(f.cpuMs)&&Number.isFinite(f.gpuMs)&&f.cpuMs<100&&f.gpuMs<100), diagnostics.frames);
    diagnostics.gpu = await finishGPU(); scoped = false;
    check('No JavaScript, console or WebGPU errors/loss/replacement', !errors.length&&!consoleErrors.length&&!diagnostics.gpu.validation&&!diagnostics.gpu.uncaptured.length&&!diagnostics.gpu.lost&&!diagnostics.gpu.changed, {errors,consoleErrors,gpu:diagnostics.gpu});
    check('No unexpected operation error remains', !(await page.locator('#frame-engine-canvas').getAttribute('data-operation-error')));
    result = {pass:true,browserVerified:true,gpuVerified:true};
  } catch (error) {
    if (currentCase) currentCase.error = error.message;
    result = {pass:false,browserVerified:false,gpuVerified:false,error:error.stack||String(error)};
  } finally {
    if (scoped) try { diagnostics.gpu = await finishGPU(); } catch(e) { diagnostics.gpuCaptureError=e.message; }
    await context.close();
  }
  Object.assign(result, {indexSHA256:sources['index.html'],sources,sourcesAfter:await hashes(),checks,cases,timings,diagnostics,errors,consoleErrors});
  if (!same(result.sources,result.sourcesAfter)) Object.assign(result,{pass:false,browserVerified:false,gpuVerified:false,error:(result.error||'')+'\nSources changed during HASH+Docs browser test'});
  return result;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const sources = await hashes(); let session, result;
  try { session = await launch({headless:process.argv.includes('--headless')}); await ready(session.page); result = await hashDocsBrowserChecks(session.page); }
  catch(error) { result={pass:false,browserVerified:false,gpuVerified:false,indexSHA256:sources['index.html'],error:error.stack||String(error)}; }
  finally { await session?.close(); }
  result.sources=sources; result.sourcesAfter=await hashes();
  if (!same(sources,result.sourcesAfter)) Object.assign(result,{pass:false,browserVerified:false,gpuVerified:false,error:(result.error||'')+'\nSources changed during standalone run'});
  await mkdir(new URL('./results/',import.meta.url),{recursive:true});
  await writeFile(new URL('./results/hash-docs-browser.json',import.meta.url),JSON.stringify(result,null,2));
  console.log(JSON.stringify(result,null,2)); process.exitCode=result.pass?0:1;
}
