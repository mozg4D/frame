import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {launch,ready} from '../tools/browser.mjs';

const sourceHashes=async()=>Object.fromEntries(await Promise.all(['index.html','tests/plugin-references-browser.mjs','tests/plugin-references.mjs','tools/browser.mjs'].map(async path=>[path,createHash('sha256').update(await readFile(new URL('../'+path,import.meta.url))).digest('hex')])));

// Test-only plugin exercises the native document/validation/record bridge.
// Nothing is injected into core source or added to the production catalogue.
export async function pluginReferenceBrowserChecks(parent){
 const sources=await sourceHashes(),indexSHA256=sources['index.html'];
 const context=await parent.context().browser().newContext({viewport:{width:1280,height:900},serviceWorkers:'block'}),page=await context.newPage(),checks=[],timings=[],errors=[],consoleErrors=[];
 const observe=p=>{p.on('pageerror',e=>errors.push(e.stack||e.message));p.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});};observe(page);
 const callOn=(p,name,args={})=>p.evaluate(([n,a])=>frameAI.call(n,a),[name,args]),call=(name,args={})=>callOn(page,name,args),objects=async p=>(await callOn(p||page,'scene.inspect')).objects,inspect=async h=>(await objects()).find(n=>n.hash===h);
 const check=(name,value)=>{assert.ok(value,name);checks.push(name);},timed=async(operation,budgetMs,fn)=>{const begin=performance.now(),result=await fn(),ms=performance.now()-begin;timings.push({operation,ms,budgetMs});check(operation+' latency',ms<budgetMs);return result;};
 let scoped=false,result;const diagnostics={};
 try{
  // Seed native identities before declaring an enum whose literal exactly equals
  // an actual copied hash. Reopen the native file after test-manifest discovery.
  await page.goto(parent.url());await ready(page);await call('scene.new');
  const A=await call('scene.create',{type:'group',name:'Parent A'}),B=await call('scene.create',{type:'group',name:'Owner B'}),E=await call('scene.create',{type:'group',name:'External E'}),seed=await call('scene.export',{includeData:true});
  const id='reference-test',type='reference_fixture',recordKey='f'.repeat(32),catalogue=JSON.parse(await readFile(new URL('../plugins/index.json',import.meta.url),'utf8'));
  const manifest={id,name:'Reference fixture',module:'plugin.js',icon:'../mill/icon.svg',objects:[{type,name:'Reference fixture',fields:{Owner:'',External:'',Note:'',Path:'',Choice:[A.hash,'other'],Number:1,Clear:true},textFields:['Note','Path'],parameterResets:{Owner:{Number:0}}}]};
  const module=`export function activate(context){let validations=0;context.editor.register({parameters(n,changes){validations++;if(changes.Owner===''&&n.params.Clear===false)throw Error('Reference clear forbidden');for(const key of ['Owner','External'])if(Object.hasOwn(changes,key)&&changes[key]&&!context.document.nodes.some(q=>q.nativeHash===changes[key]&&q.type==='group'))throw Error('Expected canonical group reference');return changes;}});context.operations.register([{id:'records',description:'Inspect test records',inputSchema:{type:'object',properties:{},additionalProperties:false},readOnly:true,run(hash){return {records:context.document.object(hash).pluginRecords||{},validations};}},{id:'set-records',description:'Set test reference record',inputSchema:{type:'object',properties:{values:{type:'array',items:{type:'string'},maxItems:2}},required:['values'],additionalProperties:false},readOnly:false,run(hash,args){context.document.transaction(()=>context.document.setRecord(hash,${JSON.stringify(recordKey)},4,args.values));return true;}}]);}`;
  await context.route('**/plugins/index.json',r=>r.fulfill({json:[...catalogue,id+'/plugin.json']}));
  await context.route('**/plugins/'+id+'/plugin.json',r=>r.fulfill({json:manifest}));
  await context.route('**/plugins/'+id+'/plugin.js',r=>r.fulfill({contentType:'text/javascript',body:module}));
  await page.reload();await ready(page);await call('scene.open',{name:'reference-seed.hash',base64:seed.base64});
  const hardware=await page.evaluate(()=>{const d=frameEngine.renderer.device;window.__referenceDevice=d;window.__referenceGPU=[];window.__referenceLost=null;d.addEventListener('uncapturederror',e=>__referenceGPU.push(e.error.message));d.lost.then(e=>window.__referenceLost={reason:e.reason,message:e.message});d.pushErrorScope('validation');return d.adapterInfo?Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(k=>[k,d.adapterInfo[k]])):null;});scoped=true;diagnostics.hardware=hardware;
  check('Identifiable hardware WebGPU, with no software fallback',hardware&&Object.values(hardware).some(v=>typeof v==='string'&&v)&&!hardware.isFallbackAdapter&&!/swiftshader|llvmpipe|lavapipe|software/i.test(JSON.stringify(hardware)));
  const C=await call('plugins.create',{plugin:id}),command=(operation,args={},hash=C.hash,p=page)=>callOn(p,'plugins.command',{id:hash,operation,args});
  await call('scene.update',{id:C.hash,name:'Reference C',parent:A.hash,params:{Owner:A.hash,External:E.hash,Note:A.hash,Path:'pose:'+A.hash+':x',Number:7}});
  const drop=async(targetHash,sourceHash,key='Owner')=>{
   await call('scene.select',{ids:[targetHash]});await page.locator('#tabAttributes').click();
   const source=await inspect(sourceHash),row=page.locator('#row-'+source.id+' .ob-name'),field=page.locator('#attrContent .cloner-object-drop[data-field="'+key+'"]');
   await row.scrollIntoViewIfNeeded();const a=await row.boundingBox(),b=await field.boundingBox();assert.ok(a&&b,'Native reference drag must be visible');
   await page.mouse.move(a.x+a.width/2,a.y+a.height/2);await page.mouse.down();await page.mouse.move(a.x+a.width/2+5,a.y+a.height/2,{steps:2});await page.mouse.move(b.x+b.width/2,b.y+b.height/2,{steps:12});await page.mouse.up();await objects();
  };
  const expectedDiagnostic=async(expected,label)=>{const actual=await page.locator('#frame-engine-canvas').getAttribute('data-operation-error');check(label,actual===expected&&errors.length===0);await page.evaluate(message=>{const c=document.querySelector('#frame-engine-canvas');if(c.dataset.operationError!==message)throw Error('Unexpected diagnostic change');delete c.dataset.operationError;delete c.dataset.operationStack;},expected);};
  const clear=async(hash,key='Owner',button='Delete')=>{await call('scene.select',{ids:[hash]});await page.locator('#tabAttributes').click();await page.locator('#attrContent .cloner-object-drop[data-field="'+key+'"]').press(button);await objects();};
  const beforeCalls=(await command('records')).validations;
  await timed('Native canonical reference drop',1500,()=>drop(C.hash,B.hash));
  check('Reference field stores native hash and runs parameter hooks/reset', (await inspect(C.hash)).params.Owner===B.hash&&(await inspect(C.hash)).params.Number===0&&(await command('records')).validations>beforeCalls);
  const wrong=await call('scene.create',{type:'target',name:'Wrong reference type'}),valid=JSON.stringify((await inspect(C.hash)).params);
  await timed('Rejected native reference drop',1500,()=>drop(C.hash,wrong.hash));
  check('Wrong type rejects before parameter mutation',JSON.stringify((await inspect(C.hash)).params)===valid);
  await expectedDiagnostic('Expected canonical group reference','Failure uses native UI diagnostics instead of an uncaught page error');
  // The last successful transaction is object creation, not the rejected drop.
  await call('edit.history',{action:'undo'});check('Rejected drop creates no Undo entry',!(await inspect(wrong.hash))&&(await inspect(C.hash)).params.Owner===B.hash);
  await call('edit.history',{action:'undo'});check('Reference drop Undo restores prior canonical hash',(await inspect(C.hash)).params.Owner===A.hash);
  await call('edit.history',{action:'redo'});check('Reference drop Redo restores canonical target',(await inspect(C.hash)).params.Owner===B.hash);
  await timed('Native reference Delete clear',1500,()=>clear(C.hash));check('Clear persists empty reference',(await inspect(C.hash)).params.Owner==='');
  await call('edit.history',{action:'undo'});check('Clear Undo restores target',(await inspect(C.hash)).params.Owner===B.hash);
  await call('edit.history',{action:'redo'});check('Clear Redo restores empty value',(await inspect(C.hash)).params.Owner==='');
  await drop(C.hash,B.hash);await timed('Native reference Backspace clear',1500,()=>clear(C.hash,'Owner','Backspace'));check('Backspace uses the validated clear path',(await inspect(C.hash)).params.Owner==='');await call('edit.history',{action:'undo'});
  await call('scene.update',{id:C.hash,params:{Clear:false}});const blockedClear=JSON.stringify((await inspect(C.hash)).params);await clear(C.hash);check('Rejected native clear leaves parameters intact',JSON.stringify((await inspect(C.hash)).params)===blockedClear);await expectedDiagnostic('Reference clear forbidden','Invalid clear follows the native error path');await call('edit.history',{action:'undo'});check('Rejected clear adds no Undo entry',(await inspect(C.hash)).params.Clear===true&&(await inspect(C.hash)).params.Owner===B.hash);
  await command('set-records',{values:[B.hash,E.hash]});
  const originalParams=JSON.stringify((await inspect(C.hash)).params),originalRecords=JSON.stringify((await command('records')).records);
  const verify=async(roots,label,p=page,externalHash=E.hash)=>{
   const list=await objects(p),a=roots.find(n=>n.name==='Parent A'),b=roots.find(n=>n.name==='Owner B'),c=list.find(n=>n.type===type&&n.parent===a?.hash);
   check(label+' copies both owners and their child',a&&b&&c&&a.hash!==A.hash&&b.hash!==B.hash&&c.hash!==C.hash);
   check(label+' remaps explicit owner independently of parent',c.params.Owner===b.hash&&c.params.Owner!==a.hash);
   check(label+' retains text, enum, path and external hash literals',c.params.Note===A.hash&&c.params.Choice===A.hash&&c.params.Path==='pose:'+A.hash+':x'&&c.params.External===externalHash);
   const records=(await command('records',{},c.hash,p)).records;check(label+' remaps typed reference records',JSON.stringify(records[recordKey].value)===JSON.stringify([b.hash,externalHash]));
   return {a,b,c};
  };
  let copied=await timed('Native object duplicate',3000,()=>call('scene.duplicate',{ids:[A.hash,B.hash]})),copy=await verify(copied.objects,'Duplicate');
  await call('edit.history',{action:'undo'});check('Copy Undo removes copied identities',!(await inspect(copy.a.hash))&&!(await inspect(copy.b.hash))&&!(await inspect(copy.c.hash)));
  await call('edit.history',{action:'redo'});check('Copy Redo retains identities and remapped reference',(await inspect(copy.c.hash)).params.Owner===copy.b.hash);await call('scene.delete',{ids:[copy.a.hash,copy.b.hash]});
  const lone=(await timed('Native reference-only duplicate',3000,()=>call('scene.duplicate',{ids:[C.hash]}))).objects[0];
  check('Reference-only copy preserves uncopied owner',lone.params.Owner===B.hash&&lone.params.External===E.hash);await call('scene.delete',{ids:[lone.hash]});
  const partial=(await call('scene.duplicate',{ids:[A.hash]})).objects[0],partialRef=(await objects()).find(n=>n.type===type&&n.parent===partial.hash);
  check('Copied parent is not substituted for a different uncopied owner',partialRef.params.Owner===B.hash);await call('scene.delete',{ids:[partial.hash]});
  await call('scene.select',{ids:[A.hash,B.hash]});await timed('Native object clipboard capture',3000,()=>call('edit.copy'));
  await call('scene.update',{id:C.hash,params:{Owner:A.hash}});copied=await timed('Native same-tab clipboard paste',3000,()=>call('edit.paste'));copy=await verify(copied.objects,'Same-tab paste');
  check('Clipboard retains source-time reference despite later source edits',(await inspect(C.hash)).params.Owner===A.hash&&copy.c.params.Owner===copy.b.hash);await call('scene.delete',{ids:[copy.a.hash,copy.b.hash]});await call('scene.update',{id:C.hash,params:{Owner:B.hash}});
  // Ctrl tree drag shares the same native copy transaction, with a new parent.
  const destination=await call('scene.create',{type:'group',name:'Row destination'});await call('scene.select',{ids:[A.hash,B.hash]});
  await timed('Native Ctrl tree-row copy',3000,async()=>{const src=await inspect(A.hash),dst=await inspect(destination.hash),from=page.locator('#row-'+src.id+' .ob-name'),to=page.locator('#row-'+dst.id);await from.scrollIntoViewIfNeeded();await to.scrollIntoViewIfNeeded();const a=await from.boundingBox(),b=await to.boundingBox();assert.ok(a&&b);await page.keyboard.down('Control');try{await page.mouse.move(a.x+a.width/2,a.y+a.height/2);await page.mouse.down();await page.mouse.move(a.x+a.width/2+5,a.y+a.height/2,{steps:2});await page.mouse.move(b.x+80,b.y+8,{steps:12});await page.mouse.up();}finally{await page.keyboard.up('Control');}await page.waitForFunction(async h=>(await frameAI.call('scene.inspect')).objects.filter(n=>n.parent===h).length===2,destination.hash,{timeout:3000});await objects();});
  const rowRoots=(await objects()).filter(n=>n.parent===destination.hash);await verify(rowRoots,'Ctrl tree-row copy');await call('scene.delete',{ids:[destination.hash]});
  check('Copies leave original parameters and native record ownership unchanged',JSON.stringify((await inspect(C.hash)).params)===originalParams&&JSON.stringify((await command('records')).records)===originalRecords);
  const saved=await timed('Native reference HASH export',3000,()=>call('scene.export',{includeData:true}));
  await timed('Native reference HASH Open',5000,()=>call('scene.open',{name:'plugin-references.hash',base64:saved.base64}));
  check('HASH Open retains native references and literal controls',JSON.stringify((await inspect(C.hash)).params)===originalParams&&JSON.stringify((await command('records')).records)===originalRecords);
  await context.route('**/plugin-references.hash',r=>r.fulfill({body:Buffer.from(saved.base64,'base64')}));
  copied=await timed('Native reference HASH Merge',5000,()=>call('scene.merge',{url:'plugin-references.hash'}));copy=await verify(copied.objects,'HASH Merge',page,copied.objects.find(n=>n.name==='External E').hash);
  // E is internal in the full HASH file; selected-set cross-tab paste below
  // separately verifies that a target absent from the copied file stays external.
  await call('scene.delete',{ids:copied.objects.map(n=>n.hash)});
  await call('scene.select',{ids:[A.hash,B.hash]});await call('edit.copy');
  const second=await context.newPage();observe(second);
  try{await second.goto(parent.url());await ready(second);await second.evaluate(()=>{const d=frameEngine.renderer.device;window.__referenceDevice=d;window.__referenceGPU=[];window.__referenceLost=null;d.addEventListener('uncapturederror',e=>__referenceGPU.push(e.error.message));d.lost.then(e=>window.__referenceLost={reason:e.reason,message:e.message});d.pushErrorScope('validation');});await callOn(second,'scene.open',{name:'reference-target.hash',base64:saved.base64});const cross=await timed('Native cross-tab clipboard paste',5000,()=>callOn(second,'edit.paste'));await verify(cross.objects,'Cross-tab paste',second);check('Cross-tab copy leaves original source untouched',JSON.stringify((await inspect(C.hash)).params)===originalParams&&JSON.stringify((await command('records')).records)===originalRecords);const gpu=await second.evaluate(async()=>({validation:(await __referenceDevice.popErrorScope())?.message||null,uncaptured:__referenceGPU,lost:__referenceLost,changed:__referenceDevice!==frameEngine.renderer.device}));diagnostics.crossTabGPU=gpu;check('Cross-tab target has no WebGPU errors, device loss or replacement',!gpu.validation&&!gpu.uncaptured.length&&!gpu.lost&&!gpu.changed);}finally{await second.close();}
  // Built-in controls retain native reference semantics and cycle rejection.
  for(const builtin of ['instance','cloner','target']){
   const n=await call('scene.create',{type:builtin,...builtin==='cloner'?{params:{type:'object'}}:{}});
   await timed(builtin+' native reference drop',1500,()=>drop(n.hash,B.hash,'object'));check(builtin+' stores canonical reference',(await inspect(n.hash)).params.object===B.hash);
   await clear(n.hash,'object');check(builtin+' reference clear succeeds',(await inspect(n.hash)).params.object==='');
   if(builtin==='target'){await call('scene.update',{id:n.hash,parent:B.hash});await drop(n.hash,B.hash,'object');check('Target cycle rejects without mutating reference',(await inspect(n.hash)).params.object==='');await expectedDiagnostic('Target link would create a transform cycle','Target cycle uses native diagnostics');}
   if(builtin==='instance'){const child=await call('scene.create',{type:'group',parent:n.hash});await drop(n.hash,child.hash,'object');check('Instance descendant cycle rejects without mutating reference',(await inspect(n.hash)).params.object==='');await expectedDiagnostic('Invalid instance source','Instance cycle uses native diagnostics');}
   await call('scene.delete',{ids:[n.hash]});
  }
  const shadowTarget=await call('scene.create',{type:'target',name:B.hash}),collisionTarget=await call('scene.create',{type:'target',name:'Collision target'});
  await timed('Canonical drop with a hash-named Target shadow',1500,()=>drop(collisionTarget.hash,B.hash,'object'));
  check('Hash-named Target cannot falsely reject a valid canonical group link',(await inspect(collisionTarget.hash)).params.object===B.hash);
  await call('scene.select',{ids:[collisionTarget.hash]});check('Canonical reference label resolves the actual target, not its name shadow',(await page.locator('#attrContent .cloner-object-drop[data-field="object"]').innerText())==='Owner B');
  const collisionInstance=await call('scene.create',{type:'instance',name:'Collision instance'});await drop(collisionInstance.hash,B.hash,'object');
  const collisionSave=await call('scene.export',{includeData:true});await call('scene.open',{name:'hash-name-collision.hash',base64:collisionSave.base64});
  check('HASH preserves Instance and Target canonical identities despite an earlier matching name',(await inspect(collisionInstance.hash)).params.object===B.hash&&(await inspect(collisionTarget.hash)).params.object===B.hash&&(await inspect(shadowTarget.hash)).name===B.hash);
  await call('scene.select',{ids:[collisionInstance.hash]});check('Reopened canonical label still names the real source',(await page.locator('#attrContent .cloner-object-drop[data-field="object"]').innerText())==='Owner B');
  await clear(collisionTarget.hash,'object');await call('scene.update',{id:collisionTarget.hash,parent:B.hash});await call('scene.create',{type:'group',name:B.hash});
  await drop(collisionTarget.hash,B.hash,'object');check('Hash-named group cannot hide a real Target transform cycle',(await inspect(collisionTarget.hash)).params.object==='');await expectedDiagnostic('Target link would create a transform cycle','Hash/name collision preserves native cycle diagnostics');
  const emptyShadow=await call('scene.create',{type:'group',name:''}),placeholderShadow=await call('scene.create',{type:'group',name:'Drop object'}),clearedSentinels=[];
  for(const type of ['instance','cloner','target']){
   const n=await call('scene.create',{type,name:'Sentinel '+type,...type==='cloner'?{params:{type:'object'}}:{}});
   await drop(n.hash,B.hash,'object');check(type+' sentinel drop stores the canonical source',(await inspect(n.hash)).params.object===B.hash);
   await clear(n.hash,'object');check(type+' sentinel native Clear stores empty before export',(await inspect(n.hash)).params.object==='');
   // Clear edits a reference, not generator validity. Enabled Object Cloner and
   // Instance require a source. Keep the cleared field in a legal saved state.
   if(type==='cloner')await timed('Cleared Cloner matrix mode',1500,()=>call('scene.update',{id:n.hash,params:{type:'matrix'}}));
   if(type==='instance')await timed('Cleared Instance disable',1500,()=>call('scene.update',{id:n.hash,enabled:false}));
   const state=await inspect(n.hash);check(type+' sentinel is exportable with its empty reference',state.params.object===''&&!state.buildError&&state.enabled===(type!=='instance')&&(type!=='cloner'||state.params.type==='matrix'));clearedSentinels.push(n.hash);
  }
  // Native create() chooses Matrix. Its untouched placeholder must survive the
  // same shape/HASH serializer used by Object mode, even with a name shadow.
  const defaultCloner=await call('scene.create',{type:'cloner',name:'Default placeholder'});
  check('Native default Cloner is enabled Matrix with an unbound placeholder',defaultCloner.params.type==='matrix'&&defaultCloner.params.object==='Drop object'&&defaultCloner.enabled&&!defaultCloner.buildError);
  check('Sentinel scene has no build errors before HASH export',(await objects()).every(n=>!n.buildError));
  const sentinelSave=await timed('Native sentinel HASH export',3000,()=>call('scene.export',{includeData:true}));await timed('Native sentinel HASH Open',5000,()=>call('scene.open',{name:'cleared-sentinel-references.hash',base64:sentinelSave.base64}));
  for(const hash of clearedSentinels){const n=await inspect(hash);check('Cleared reference remains empty after HASH despite an empty-named object '+hash,n.params.object==='');check(n.type+' sentinel retains its exportable mode and enabled state after HASH',!n.buildError&&n.enabled===(n.type!=='instance')&&(n.type!=='cloner'||n.params.type==='matrix'));}
  check('Default Cloner placeholder remains unbound after HASH despite a same-named object',(await inspect(defaultCloner.hash)).params.object==='Drop object');
  const reopenedDefault=await inspect(defaultCloner.hash);check('Default Cloner remains enabled Matrix without a build error after HASH',reopenedDefault.enabled&&reopenedDefault.params.type==='matrix'&&!reopenedDefault.buildError);
  check('Both sentinel name shadows remain present after HASH',(await inspect(emptyShadow.hash)).name===''&&(await inspect(placeholderShadow.hash)).name==='Drop object');
  check('Sentinel scene has no build errors after HASH Open',(await objects()).every(n=>!n.buildError));
  check('No unexpected native diagnostic remains',!(await page.locator('#frame-engine-canvas').getAttribute('data-operation-error')));
  const gpu=await page.evaluate(async()=>({validation:(await __referenceDevice.popErrorScope())?.message||null,uncaptured:__referenceGPU,lost:__referenceLost,changed:__referenceDevice!==frameEngine.renderer.device}));scoped=false;diagnostics.gpu=gpu;
  check('No JavaScript, console, WebGPU validation, device-loss or replacement errors',!errors.length&&!consoleErrors.length&&!gpu.validation&&!gpu.uncaptured.length&&!gpu.lost&&!gpu.changed);
  result={pass:true,indexSHA256,checks,timings,diagnostics,errors,consoleErrors};return result;
 }catch(error){result={pass:false,indexSHA256,checks,timings,diagnostics,errors,consoleErrors,error:error.stack};return result;}finally{if(scoped)await page.evaluate(()=>__referenceDevice.popErrorScope()).catch(()=>{});await context.close();if(result){result.sources=sources;result.sourcesAfter=await sourceHashes();if(JSON.stringify(sources)!==JSON.stringify(result.sourcesAfter)){result.pass=false;result.error=(result.error||'')+'\nReference test sources changed during the run';}}}
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 const sources=await sourceHashes();let session,result;try{session=await launch({headless:process.argv.includes('--headless')});await ready(session.page);result=await pluginReferenceBrowserChecks(session.page);}catch(error){result={pass:false,checks:[],error:error.stack,browserVerified:false};}finally{await session?.close();}
 result.sources=sources;result.sourcesAfter=await sourceHashes();if(JSON.stringify(sources)!==JSON.stringify(result.sourcesAfter)){result.pass=false;result.error=(result.error||'')+'\nReference test sources changed during the run';}
 await mkdir(new URL('./results/',import.meta.url),{recursive:true});await writeFile(new URL('./results/plugin-references-browser.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;
}
