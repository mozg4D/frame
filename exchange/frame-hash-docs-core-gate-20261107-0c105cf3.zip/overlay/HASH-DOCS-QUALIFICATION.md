# Isolated HASH + core Documentation qualification

Core SHA256: dc71a654ab8d5406244be074ba49d25b3df8e8034542c7bcd93ac03be33d62dc

This is a new source fingerprint, not the predecessor's qualified binary.
No browser or hardware pass is claimed. No main/live changes. The detached
editor implementation is excluded.

Inputs:
- HASH best-effort core 4c0d1ed81036af94618d2bb42d074f7e47ae5734a9f5a94bf9f0736370bdd3a2.
- Frozen core Docs e3c8f8aee9e6519f4f619bb979793927aeade375cef16d166e15ddc22ccf64cf.
- Qualified reference browser fixture 603b8806fb8861bd92455cc335593ac7c1630d57d86ba1b07ca66ff82f915d44.

Changes are confined to this copy. Unknown-plugin authoring remapping, declared
record ownership guards, preserved literal payloads and HASH diagnostics remain.
Docs root metadata/API are added; reset notification follows rebuilt native
nodes/parents. Merge final text validation precedes history commit/text import.
Temporary appearance/mesh rollback snapshots do not escape into Undo history.

Lifecycle hardening:
- Same-scene/GPU checks before global appearance writes and after async stages.
- Appearance-only rollback preserves current root documentation/version,
  restores native library bytes/paths and selection, and retires stale atlas work.
- Baseline resource identities are protected; new UV/map resources are released
  once, including UV allocated before registration. Rollback failure still
  attempts owned geometry cleanup and preserves both errors.
- New owns the existing I/O lock through all awaits; baseline-capture failure
  releases it. Eager, queued and post-settle API BUSY checks precede mutation.
- Native UI Open and Save reuse the existing API tail, not a second queue.
  Save starts its picker synchronously and reserves queue order before it resolves.
  Cancelled picker cannot open a writable. Early serializer failure aborts it.
- Replacement Open can recover after failed startup or missing scene by draining
  prior work without requiring an already-healthy scene. Save/Merge cannot use
  this recovery path; every successful operation still completes final settle.

Completed checks on this exact core:
- Syntax: 2 executable scripts, 5 lazy scripts.
- HASH host: 124/124.
- Reference host: 52/52.
- Docs host: 10/10.
- Lifecycle fault/ordering/recovery tests: 21/21 in approximately 95 ms against
  a 5-second budget. These execute actual extracted runtime functions with CPU
  mocks and are not hardware fault-injection evidence.
- Source and fixture checks completed.
- Standard and stress each reached 219 host assertions with no assertion failures,
  then failed to launch absent bundled Chromium. They are NOT passes.

Required next sequence on the isolated hardware target:
1. Verify HASH-DOCS-SOURCES.json and core SHA before any execution.
2. Run syntax, host HASH/reference/Docs/lifecycle checks sequentially.
3. node tests/hash-docs-browser.mjs --headless
4. node tests/hash-best-effort-browser.mjs --headless
5. node tests/plugin-references-browser.mjs --headless
STOP after focused gates. Assess live machine CPU/RAM/GPU load and coordinate
with other ongoing workloads before any larger suite. Neither command below is
authorized by this focused runner plan without that separate decision:
- npm test -- --headless
- npm run test:stress -- --headless

Keep exact before/after source hashes, NVIDIA/nonfallback adapter evidence,
GPU/page/console diagnostics and complete reports. Stop on a failure, preserve
its report, and diagnose without weakening assertions or quietly changing source.
Do not run simultaneous GPU gates or change another target/worktree.

The focused browser module covers real API calls, native file controls and
serializer, Share, unknown-plugin shells/records, Docs CAS/Unicode/limits,
Merge reference mapping and independent text through geometry Undo/Redo.
Actual GPU-error/resource-failure injection, delayed texture completion and
large-text/object reference-inspection scaling still need hardware qualification;
CPU mocks cannot establish absence of WebGPU leaks. Replacement Open is still
not universally atomic after prior-scene disposal if GPU upload itself fails.
