import test from 'node:test';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {assembleConduction,gridSchema,MAX_CELLS,activate,solveConductionGPU} from '../plugin.js';
import {referenceSystem,solveDense,cases} from './reference.mjs';

const near=(a,b,tolerance=1e-10)=>assert.ok(Math.abs(a-b)<=tolerance*Math.max(1,Math.abs(a),Math.abs(b)),`${a} != ${b}`);
const matrix=grid=>{
  const {count,dimensions:d,coefficients:c}=grid,A=Array.from({length:count},()=>new Float64Array(count)),b=new Float64Array(count);
  for(let i=0;i<count;i++){A[i][i]=c[i*8+6];b[i]=c[i*8+7];for(let side=0;side<6;side++)if(c[i*8+side])A[i+0][i+[-1,1,-d[0],d[0],-d[0]*d[1],d[0]*d[1]][side]]=-c[i*8+side];}
  return {A,b};
};
test('assembly matches an independent shared-face resistance model in all three axes',()=>{
  for(const [name,input]of Object.entries(cases)){
    const actual=matrix(assembleConduction(input)),expected=referenceSystem(input);
    for(let i=0;i<actual.b.length;i++){near(actual.b[i],expected.b[i]);for(let j=0;j<actual.b.length;j++){near(actual.A[i][j],expected.A[i][j]);near(actual.A[i][j],actual.A[j][i]);}}
    const solution=solveDense(actual),oracle=solveDense(expected);
    solution.forEach((t,i)=>near(t,oracle[i],1e-9));
    assert.equal(solution.length,input.dimensions.reduce((a,b)=>a*b),name);
  }
});
test('half-cell Dirichlet conditions reproduce the linear slab solution',()=>{
  const solution=solveDense(matrix(assembleConduction(cases.slab)));
  solution.forEach((t,i)=>near(t,100*((i%16)+.5)/16,1e-10));
});
test('harmonic interface conductance reproduces two layers in series',()=>{
  const input=cases.composite,g=assembleConduction(input),temperature=solveDense(matrix(g));
  const q=100/(.04/1+.04/4);
  temperature.forEach((t,i)=>{const x=(i+.5)*.01;near(t,q*(x<.04?x:.04+(x-.04)/4));});
  const outgoing=temperature.reduce((sum,t,i)=>sum+g.accounting[i*4]*t-g.accounting[i*4+1],0);near(outgoing,0);
  near(g.coefficients[3*8+1],g.coefficients[4*8]);
});
test('uniform insulated backward Euler heating has exact temperature and energy rise',()=>{
  const g=assembleConduction(cases.transient),temperature=solveDense(matrix(g));
  temperature.forEach(t=>near(t,20.125));
  const stored=temperature.reduce((sum,t,i)=>sum+g.accounting[i*4+2]*(t-g.accounting[i*4+3]),0);near(stored,g.sourcePower,1e-9);
});
test('volumetric source power does not change when resolution changes',()=>{
  const coarse=assembleConduction({...cases.source3d,dimensions:[2,2,2],cellSize:[.02,.02,.02]});
  const fine=assembleConduction({...cases.source3d,dimensions:[4,4,4],cellSize:[.01,.01,.01]});
  near(coarse.sourcePower,fine.sourcePower);near(coarse.sourcePower,50000*.04**3);
});
test('steady positive and negative sources obey energy balance and comparison principle',()=>{
  for(const name of ['source3d','sink']){const g=assembleConduction(cases[name]),temperature=solveDense(matrix(g));
    const outgoing=temperature.reduce((sum,t,i)=>sum+g.accounting[i*4]*t-g.accounting[i*4+1],0);near(outgoing,g.sourcePower,1e-9);
    assert.ok(temperature.every(t=>name==='sink'?t<20:t>20));
  }
});
test('transient insulated diffusion conserves total heat for heterogeneous heat capacity',()=>{
  const input={dimensions:[2,3,2],cellSize:[.01,.02,.03],conductivity:[4],heatCapacity:Array.from({length:12},(_,i)=>1e6*(i+1)),initial:Array.from({length:12},(_,i)=>10+i*7),boundary:{},timeStep:12};
  const g=assembleConduction(input),t=solveDense(matrix(g));
  const energy=t.reduce((s,v,i)=>s+g.accounting[i*4+2]*(v-g.initial[i]),0);near(energy,0,1e-8);
  assert.ok(t.every(v=>v>=10&&v<=87));
});
test('invalid, singular and unrepresentable inputs reject before GPU work',()=>{
  for(const patch of [
    {unknown:true},{dimensions:[0,2,2]},{dimensions:[256,256,256]},{cellSize:[0,.1,.1]},
    {conductivity:[0]},{conductivity:[-1]},{conductivity:[NaN]},{conductivity:[1,2]},
    {initial:[-274]},{initial:[Infinity]},{heatCapacity:[0]},{source:[NaN]},
    {boundary:{}},{boundary:{xMin:null}},{boundary:{unexpected:20}},{timeStep:0},
    {tolerance:0},{maxIterations:2.5},{cellSize:[1e-300,1e-300,1e-300]},
    {conductivity:[1e300]}
  ])assert.throws(()=>assembleConduction({...cases.source3d,...patch}),undefined,JSON.stringify(patch));
  assert.equal(MAX_CELLS,262144);assert.equal(gridSchema.additionalProperties,false);
});
test('failed GPU allocation or scoped error retires owned buffers and balances shared scopes',async()=>{
  const prior=Object.fromEntries(['GPUBufferUsage','GPUShaderStage'].map(key=>[key,globalThis[key]]));
  globalThis.GPUBufferUsage={STORAGE:1,COPY_DST:2,COPY_SRC:4,UNIFORM:8,MAP_READ:16};globalThis.GPUShaderStage={COMPUTE:1};
  try {
    for(const mode of ['throw','scoped']){
      const allocated=[],scopes=[];let calls=0;
      const device={
        limits:{maxBufferSize:1e9,maxStorageBufferBindingSize:1e9,maxComputeWorkgroupsPerDimension:65535},
        createShaderModule:()=>({getCompilationInfo:async()=>({messages:[]})}),createBindGroupLayout:()=>({}),createPipelineLayout:()=>({}),createComputePipelineAsync:async()=>({}),createBindGroup:()=>({}),
        pushErrorScope:filter=>scopes.push(filter),popErrorScope:()=>Promise.resolve(scopes.pop()==='validation'&&mode==='scoped'?{message:'Injected resource validation failure'}:null),
        createBuffer(){if(++calls===4&&mode==='throw')throw Error('Injected allocation failure');const b={destroyed:0,destroy(){this.destroyed++;}};allocated.push(b);return b;},queue:{writeBuffer(){}}
      };
      await assert.rejects(solveConductionGPU(device,assembleConduction(cases.slab)),/Injected/);
      assert.ok(allocated.length>0);assert.ok(allocated.every(b=>b.destroyed===1));assert.equal(scopes.length,0);
    }
  } finally {for(const [key,value]of Object.entries(prior)){if(value===undefined)delete globalThis[key];else globalThis[key]=value;}}
});
test('cell and boundary inputs remain immutable; independent grids do not share arrays',()=>{
  const input=structuredClone(cases.slab),copy=JSON.stringify(input),a=assembleConduction(input),b=assembleConduction(input);
  a.coefficients[0]=123;a.initial[0]=123;
  assert.notEqual(a.coefficients[0],b.coefficients[0]);assert.notEqual(a.initial[0],b.initial[0]);assert.equal(JSON.stringify(input),copy);
});
test('native foundation exposes no scene Solve or unimplemented tag controls',async()=>{
  const n={type:'thermal',nativeHash:'thermal-owner',params:{Ambient:20,Initial:20},enabled:true};let operations,editor,attributes,viewport;
  const context={version:1,device:null,document:{nodes:[n],world:()=>[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]},operations:{register:v=>operations=v},editor:{register:v=>editor=v},attributes:{register:v=>attributes=v},viewport:{register:async v=>viewport=v},requestAttributes(){},requestDraw(){}};
  await activate(context);
  assert.equal(operations.find(o=>o.id==='status').run(n.nativeHash).sceneSolver,false);
  assert.equal(operations.find(o=>o.id==='status').run(n.nativeHash).state,'idle');
  assert.deepEqual(attributes(n.nativeHash).actions,[{id:'create-fan',label:'Fan'},{id:'create-probe',label:'Probe'},{id:'clear',label:'Clear',busy:false,cancel:'cancel',disabled:true}]);assert.equal(viewport.lines.length,72);
  assert.throws(()=>operations.find(o=>o.id==='solve-grid').run(n.nativeHash,{...cases.slab,dimensions:[0,1,1]}));
  assert.equal(operations.find(o=>o.id==='status').run(n.nativeHash).state,'idle');
  assert.throws(()=>editor.parameters(n,{Ambient:-300}));
  const job=operations.find(o=>o.id==='solve-grid').run(n.nativeHash,cases.slab);assert.equal(job.state,'running');await editor.flush({author:true});
  const failed=operations.find(o=>o.id==='status').run(n.nativeHash);assert.equal(failed.error.code,'WEBGPU_REQUIRED');assert.equal(failed.state,'failed');
  await operations.find(o=>o.id==='clear').run(n.nativeHash);assert.equal(operations.find(o=>o.id==='status').run(n.nativeHash).state,'idle');
});
test('native helper surface discards fragments and still satisfies the WGSL return contract',async()=>{
  let viewport;const started=performance.now();
  await activate({version:1,device:null,document:{nodes:[]},operations:{register(){}},editor:{register(){}},attributes:{register(){}},viewport:{register:async value=>{viewport=value;}}});
  // Inspect the actual descriptor registered by activate, not a copied shader.
  // discard does not supply the return value of a non-void WGSL function.
  assert.equal(viewport.shader,'fn pluginSurface(local:vec3f, normal:vec3f, build:vec3f, settings:vec4f)->vec4f { discard; return vec4f(0.0); }');
  assert.equal(viewport.lines.length,72);assert.deepEqual(viewport.bounds,{min:[-50,-50,-50],max:[50,50,50]});assert.deepEqual(viewport.settings(),[0,0,0,0]);
  assert.ok(performance.now()-started<1000,'Native helper registration exceeded its 1000 ms CPU budget.');
});
test('32³ coefficient assembly has an explicit completed-operation budget',()=>{
  const started=performance.now(),grid=assembleConduction({dimensions:[32,32,32],cellSize:[.001,.001,.001],conductivity:[205]});
  const wallMs=performance.now()-started;assert.ok(wallMs<1000,`assembly ${wallMs.toFixed(1)} ms exceeds 1000 ms`);
  assert.equal(grid.count,32768);console.log(JSON.stringify({name:'Thermal 32³ assembly',wallMs,limitMs:1000,hostTypedBytes:grid.coefficients.byteLength+grid.accounting.byteLength+grid.initial.byteLength}));
});

test('prescribed inward flux produces the analytical slab gradient and closes energy',()=>{
  const g=assembleConduction(cases.fluxSlab),t=solveDense(matrix(g));
  t.forEach((v,i)=>near(v,20+100*((i%8)+.5)*.01/2));
  near(t.reduce((sum,v,i)=>sum+g.accounting[i*4]*v-g.accounting[i*4+1],0),0);
});
test('signed flux on different face areas gives the exact transient energy rise',()=>{
  const g=assembleConduction(cases.fluxTransient),t=solveDense(matrix(g));
  const incoming=(100-20)*.02*.03+30*.01*.03+40*.01*.02;
  near(t[0],20+incoming*2/(2e6*.01*.02*.03));
  near(g.sourcePower,0);
  near(g.accounting[0]*t[0]-g.accounting[1]+g.accounting[2]*(t[0]-g.accounting[3]),0);
});
test('flux input rejects conflicts, unknown faces, nonfinite values and unanchored steady domains',()=>{
  for(const boundaryFlux of [{xMin:1},{badFace:1},{xMax:NaN},{xMax:Infinity},[],42])
    assert.throws(()=>assembleConduction({...cases.fluxSlab,boundaryFlux}),{code:'INVALID_ARGUMENT'});
  assert.throws(()=>assembleConduction({...cases.fluxSlab,boundary:{}}),{code:'UNANCHORED_DOMAIN'});
  assert.throws(()=>assembleConduction({...cases.fluxSlab,boundaryFlux:{xMax:1e308}}),{code:'NUMERICAL_RANGE'});
  const input=structuredClone(cases.fluxDefault),before=JSON.stringify(input);
  assembleConduction(input);assert.equal(JSON.stringify(input),before);
});
test('32³ flux assembly meets the completed-operation latency budget',()=>{
  const started=performance.now();
  assembleConduction({dimensions:[32,32,32],cellSize:[.001,.002,.003],conductivity:[205],boundaryFlux:{xMax:500}});
  const wallMs=performance.now()-started;
  assert.ok(wallMs<1000,`Flux assembly exceeded 1000 ms: ${wallMs}`);
  console.log(JSON.stringify({name:'Thermal 32³ flux assembly',wallMs,limitMs:1000}));
});

test('fixed boundary flux power is resolution independent on every axis',()=>{
  for(let axis=0;axis<3;axis++)for(const sign of [-1,1]){
    const face=['x','y','z'][axis]+'Max',span=[.04,.06,.08],q=sign*75;
    for(const resolution of [1,2,4]){
      const g=assembleConduction({dimensions:[resolution,resolution,resolution],cellSize:span.map(x=>x/resolution),conductivity:[2],initial:[20],boundary:{},boundaryFlux:{[face]:q},timeStep:1});
      const incoming=Array.from({length:g.count},(_,i)=>g.accounting[i*4+1]).reduce((a,b)=>a+b,0);
      near(incoming,q*span[(axis+1)%3]*span[(axis+2)%3]);
    }
  }
});

test('Probe native creation uses one transaction, native parent/reference and minimal attributes',async()=>{
  const {nativeCreationFixture,math}=await import('./native-creation-fixture.mjs'),native=nativeCreationFixture(),n=native.create('thermal');n.nativeHash='owner';native.sync();let operations,editor,attributes;
  const D=native.context.document;
  await activate({version:1,device:null,document:D,math,operations:{register:v=>operations=v},editor:{register:v=>{editor=v;native.context.editor.register(v);}},attributes:{register:v=>attributes=v},viewport:{register:async()=>{}},requestAttributes(){},requestDraw(){}});
  const created=operations.find(o=>o.id==='create-probe').run('owner');
  assert.equal(created.type,'thermal_probe');assert.equal(native.transactions,1);assert.deepEqual(native.selected,{hash:created.hash,area:'objects'});
  const p=D.nodes.find(n=>n.nativeHash===created.hash);assert.equal(p.parent,n.id);assert.equal(p.params.Thermal,'owner');assert.deepEqual(Array.from(native.packed(created.hash)),[.02,0,0,0,.02,0,0,0,.02,0,0,0]);
  assert.equal(attributes(created.hash).actions[0].label,'Measure');
  assert.throws(()=>editor.parameters(p,{Thermal:'missing'}),{code:'INVALID_ARGUMENT'});
  await assert.rejects(operations.find(o=>o.id==='measure').run(created.hash),{code:'NO_RESULT'});
});
test('Neumaier source accounting preserves small signed residual between cancelling large sources',()=>{
 for(const source of [[1e20,1,-1e20],[-1e20,-1,1e20],[1,1e20,-1e20],[1e20,-1e20,1]]){
  const grid=assembleConduction({dimensions:[3,1,1],cellSize:[1,1,1],conductivity:[1],source,boundary:{xMin:0,xMax:0}});
  assert.equal(grid.sourcePower,source.includes(-1)?-1:1);
 }
});
