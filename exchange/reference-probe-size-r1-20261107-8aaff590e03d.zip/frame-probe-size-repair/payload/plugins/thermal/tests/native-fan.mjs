import test from 'node:test';
import assert from 'node:assert/strict';
import {nativeCreationFixture,math,manifest} from './native-creation-fixture.mjs';
import {activate} from '../plugin.js';
import {inspectNativeFans,validateFanParameters} from '../native-fan.js';
import {fixture as jobFixture,sceneRequest} from './native-job-fixture.mjs';
import {historyFixture} from './native-history-fixture.mjs';
import {fixtureFluidOccurrence} from './native-fluid-fixture.mjs';
globalThis.GPUBufferUsage={STORAGE:1,COPY_DST:2,COPY_SRC:4,UNIFORM:8,MAP_READ:16};globalThis.GPUShaderStage={COMPUTE:1};globalThis.GPUMapMode={READ:1};

const defaults=()=>Object.fromEntries(Object.entries(manifest.objects.find(o=>o.type==='thermal_fan').fields).map(([k,v])=>[k,Array.isArray(v)?v[0]:v]));
async function fixture(){
 const native=nativeCreationFixture(),owner=native.create('thermal');owner.nativeHash='owner';native.sync();
 const worlds={owner:native.world('owner')},locals={};let operations,editor,attributes,viewport;
 const D={...native.context.document,nodes:native.nodes,world:hash=>worlds[hash]??native.world(hash),local:hash=>locals[hash]??native.local(hash)};
 const context={version:1,device:null,document:D,math,operations:{register:v=>operations=v},editor:{register:v=>{editor=v;native.context.editor.register(v);}},attributes:{register:v=>attributes=v},viewport:{register:async v=>viewport=v},requestAttributes(){},requestDraw(){},scene:{capture(){throw Error('Fan authoring must not capture geometry.');}}};
 await activate(context);
 const op=id=>operations.find(o=>o.id===id),call=(id,hash='owner')=>op(id).run(hash,{});
 const create=()=>{const {hash}=call('create-fan');locals[hash]=native.local(hash);worlds[hash]=native.world(hash);return D.nodes.find(n=>n.nativeHash===hash);};
 // Explicit frame overrides below are only for detached metadata edge cases.
 // Initial authoring always runs actual extracted core create/sync/record paths.
 const transform=(fan,local=locals[fan.nativeHash],ownerWorld=worlds.owner)=>{locals[fan.nativeHash]=local;worlds.owner=ownerWorld;worlds[fan.nativeHash]=math.mul(ownerWorld,local);};
 return {native,D,owner,worlds,locals,context,editor,attributes,viewport,op,call,create,transform,get transactions(){return native.transactions;},get selected(){return native.selected;}};
}
test('native Fan is manifest-only authoring, created in one native transaction with explicit reference and selected Attributes',async()=>{
 const f=await fixture(),fan=f.create(),metadata=f.call('fan-inputs');
 assert.equal(f.transactions,1);assert.equal(fan.parent,f.owner.id);assert.equal(fan.params.Thermal,'owner');assert.deepEqual(f.selected,{hash:fan.nativeHash,area:'objects'});
 assert.deepEqual(Array.from(f.native.packed(fan.nativeHash)),[.25,0,0,0,.25,0,0,0,.25,-25,-12.5,-12.5]);
 assert.equal(Object.hasOwn(fan,'creationFrame'),false);
 assert.equal(metadata.selection.status,'unique');assert.equal(metadata.fan.mapping.status,'supported-frame');assert.deepEqual(metadata.fan.mapping.centerMM,[-25,-12.5,-12.5]);assert.deepEqual(metadata.fan.mapping.sizeMM,[25,25,25]);
 assert.equal(metadata.solverEligible,false);assert.equal(metadata.solverCoupled,false);assert.equal(metadata.fan.mapping.solverEligible,false);assert.equal(metadata.fan.authored.params['Shutoff pressure'],0);
 assert.equal(f.op('fan-inputs').readOnly,true);assert.equal(f.op('create-fan').readOnly,false);assert.deepEqual(f.op('create-fan').inputSchema,{type:'object',properties:{},additionalProperties:false});
 assert.deepEqual(f.attributes(fan.nativeHash),{units:{'Shutoff pressure':'Pa','Free flow':'m³/s'},ranges:{'Shutoff pressure':{min:0},'Free flow':{min:Number.MIN_VALUE}},actions:[]});
 assert.equal(f.viewport.lines.length,72);assert.equal(f.viewport.render,undefined);assert.equal(f.editor.beforeTransform,undefined);assert.deepEqual(fan.tags,[]);assert.equal(fan.pluginRecords,undefined);
});
test('actual native sync reproduces the old transform-only defect, without accepting its 100 mm result as the default',async()=>{
 const f=await fixture();
 f.native.entry.editor={...f.editor,created:n=>{if(n.type==='thermal_fan')n.transform=[-25,0,.25,-12.5,0,.25,-12.5,0,.25];}};
 const fan=f.create(),metadata=f.call('fan-inputs');
 assert.deepEqual(fan.transform,[-25,0,.25,-12.5,0,.25,-12.5,0,.25]);
 assert.equal(f.native.packed(fan.nativeHash),undefined);
 assert.deepEqual(metadata.fan.box.worldEdgeLengthsMM,[100,100,100]);
 assert.deepEqual(metadata.fan.mapping.sizeMM,[100,100,100]);
 assert.deepEqual(metadata.fan.mapping.centerMM,[0,0,0]);
});
test('standalone native creation receives the same 25 mm frame without assigning an owner',async()=>{
 const f=await fixture(),fan=f.native.create('thermal_fan');f.native.sync();
 assert.equal(fan.parent,null);assert.equal(fan.params.Thermal,'');
 assert.deepEqual(Array.from(f.native.local(fan.nativeHash)),[.25,0,0,0,0,.25,0,0,0,0,.25,0,-25,-12.5,-12.5,1]);
 const metadata=f.call('fan-inputs',fan.nativeHash);assert.equal(metadata.fan.ownerResolution.status,'unassigned');assert.deepEqual(metadata.fan.box.worldEdgeLengthsMM,[25,25,25]);
});
test('native default is installed once; repeated sync preserves the matrix and later authored edits',async()=>{
 const f=await fixture(),fan=f.create(),hash=fan.nativeHash,initial=Array.from(f.native.packed(hash));
 assert.equal(Object.hasOwn(fan,'creationFrame'),false);f.native.sync();assert.deepEqual(Array.from(f.native.packed(hash)),initial);
 const edited=math.mul(math.rotation([0,0,1],.37),math.stretch([1,0,0],.5));edited.set([3,4,5],12);f.native.setLocal(hash,edited);
 // Obsolete UI fallback values must never replace an installed native matrix.
 fan.transform=[99,0,99,99,0,99,99,0,99];f.native.sync();f.native.sync();
 assert.deepEqual(Array.from(f.native.local(hash)),Array.from(edited));assert.equal(Object.hasOwn(fan,'creationFrame'),false);
});
test('native defaults are parent-local under a translated rotated anisotropically scaled owner',async()=>{
 const f=await fixture(),ownerFrame=math.mul(math.rotation([0,0,1],.71),math.stretch([1,0,0],2));ownerFrame.set([10,20,30],12);f.native.setLocal('owner',ownerFrame);f.worlds.owner=ownerFrame;
 const fan=f.create(),local=f.native.local(fan.nativeHash);assert.deepEqual(Array.from(local.slice(12,15)),[-25,-12.5,-12.5]);
 assert.deepEqual(Array.from(f.native.world(fan.nativeHash)),Array.from(math.mul(ownerFrame,local)));
 assert.deepEqual([local[0],local[5],local[10]],[.25,.25,.25]);assert.equal(f.call('fan-inputs').fan.mapping.status,'supported-frame');assert.deepEqual(f.call('fan-inputs').fan.mapping.sizeMM,[25,25,25]);
});
test('32 complete source-extracted native Fan creations and syncs stay below 1500 ms',async()=>{
 const f=await fixture(),started=performance.now();for(let i=0;i<32;i++){const fan=f.create();assert.deepEqual([0,5,10].map(k=>100*f.native.local(fan.nativeHash)[k]),[25,25,25]);}
 const wallMs=performance.now()-started;assert.ok(wallMs<1500,`${wallMs} ms exceeds 1500 ms`);console.log(JSON.stringify({operation:'32 source-extracted native Fan creations and syncs',wallMs,budgetMs:1500,hardwareVerified:false}));
});
test('invalid Fan parameters and owner type reject before mutation; arbitrary native transforms have no parameter clamp',async()=>{
 const f=await fixture(),fan=f.create(),before=JSON.stringify(f.D.nodes),transactions=f.transactions;
 for(const patch of [{Thermal:'missing'},{Thermal:fan.nativeHash},{Thermal:null},{'Shutoff pressure':-1},{'Shutoff pressure':Infinity},{'Free flow':0},{'Free flow':NaN},{Direction:'X'},{hiddenBox:[1,2,3]}]){
  assert.throws(()=>f.editor.parameters(fan,patch),{code:'INVALID_ARGUMENT'});assert.equal(JSON.stringify(f.D.nodes),before);assert.equal(f.transactions,transactions);
 }
 for(const patch of [{Thermal:''},{'Shutoff pressure':0},{'Free flow':Number.MIN_VALUE},{Direction:'Reverse'}])assert.deepEqual(f.editor.parameters(fan,patch),{});
 assert.throws(()=>f.call('create-fan',fan.nativeHash),{code:'INVALID_OWNER'});assert.equal(f.transactions,transactions);
});
test('owner resolution and unique direct-enabled selection are independent of frame/profile, visibility and hierarchy',async()=>{
 const f=await fixture();assert.equal(f.call('fan-inputs').selection.status,'missing');const a=f.create(),b=f.create();
 assert.equal(f.call('fan-inputs').selection.status,'multiple');b.enabled=false;let m=f.call('fan-inputs');assert.equal(m.selection.status,'unique');assert.equal(m.selection.disabledFanCount,1);
 a.visible=false;f.owner.enabled=false;m=f.call('fan-inputs');assert.equal(m.selection.status,'unique');assert.equal(m.fan.ownerResolution.enabled,false);assert.equal(m.selection.ancestorEnabledState,'not-qualified');assert.equal(m.solverEligible,false);
 a.parent='unrelated';m=f.call('fan-inputs');assert.equal(m.selection.status,'unique');assert.equal(m.fan.mapping.status,'unsupported-frame');assert.equal(m.fan.ownerHash,'owner');
 a.params['Free flow']=-1;m=f.call('fan-inputs');assert.equal(m.selection.status,'unique');assert.equal(m.fan.profile.status,'invalid');
 a.params.Thermal='';m=f.call('fan-inputs',a.nativeHash);assert.equal(m.selection.status,'unresolved-owner');assert.equal(m.fan.ownerResolution.status,'unassigned');
 a.params.Thermal='owner';f.D.nodes.splice(f.D.nodes.indexOf(f.owner),1);m=f.call('fan-inputs',a.nativeHash);assert.equal(m.fan.ownerResolution.status,'missing-owner');assert.equal(m.fan.mapping.status,'unresolved-owner');
});
test('native local-X direction follows arbitrary owner rotation/reflection/anisotropic scale without inverse roundoff',async()=>{
 const f=await fixture(),fan=f.create(),scale=math.I();scale[0]=-2;scale[5]=3;scale[10]=.5;scale.set([15,-25,40],12);
 const world=math.mul(math.rotation([1,2,3],.713),scale);f.transform(fan,undefined,world);
 let m=f.call('fan-inputs').fan;assert.equal(m.mapping.status,'supported-frame');assert.deepEqual(m.mapping.sizeMM,[25,25,25]);assert.deepEqual(m.directionLocal,[1,0,0]);assert.ok(Math.abs(Math.hypot(...m.normalizedWorldAxis)-1)<1e-14);
 const axis=Array.from(world.slice(0,3),x=>x/Math.hypot(...world.slice(0,3)));m.normalizedWorldAxis.forEach((x,i)=>assert.ok(Math.abs(x-axis[i])<1e-15));
 fan.params.Direction='Reverse';m=f.call('fan-inputs').fan;assert.deepEqual(m.directionLocal,[-1,0,0]);m.normalizedWorldAxis.forEach((x,i)=>assert.ok(Math.abs(x+axis[i])<1e-15));
});
test('native rotated/sheared/reflected/zero/projective frames stay authored but never pass physical-frame mapping',async()=>{
 const cases=[math.rotation([0,0,1],.2),math.shear([1,0,0],[0,1,0],.1),math.stretch([1,0,0],-1),math.stretch([1,0,0],0),math.I(),math.I()];cases[4][3]=.1;cases[5][4]=Number.MIN_VALUE;
 for(const local of cases){const f=await fixture(),fan=f.create();f.transform(fan,local);const before=JSON.stringify(local),m=f.call('fan-inputs').fan;assert.equal(m.mapping.status,'unsupported-frame');assert.equal(JSON.stringify(local),before);assert.deepEqual(f.editor.parameters(fan,{}),{});assert.equal(m.mapping.solverEligible,false);}
});
test('evaluated constraints and invalid owner frames reject mapping; results contain no borrowed frame arrays',async()=>{
 const f=await fixture(),fan=f.create();f.worlds[fan.nativeHash][12]+=Number.EPSILON*32;assert.equal(f.call('fan-inputs').fan.mapping.status,'unsupported-frame');f.transform(fan);
 for(const bad of [math.shear([1,0,0],[0,1,0],.5),math.stretch([1,0,0],0)]){f.transform(fan,undefined,bad);assert.equal(f.call('fan-inputs').fan.mapping.status,'unsupported-frame');}
 f.transform(fan,undefined,math.I());const m=f.call('fan-inputs').fan;m.mapping.centerMM[0]=999;m.authored.params.Direction='Reverse';assert.equal(fan.params.Direction,'Forward');assert.equal(f.call('fan-inputs').fan.mapping.centerMM[0],-25);
 f.worlds[fan.nativeHash][0]=Infinity;assert.equal(f.call('fan-inputs').fan.mapping.status,'unsupported-frame');
});
test('disabled zero-pressure and unsupported-size Fans do not gain implicit sheet qualification',async()=>{
 const f=await fixture(),fan=f.create();fan.enabled=false;const local=math.I();local[0]=1e100;local[12]=1e100;f.transform(fan,local);const m=f.call('fan-inputs',fan.nativeHash);
 assert.equal(m.selection.status,'missing');assert.equal(m.fan.authored.enabled,false);assert.equal(m.fan.mapping.status,'supported-frame');assert.equal(m.fan.mapping.solverEligible,false);assert.ok(m.fan.mapping.unchecked.includes('box-containment'));
});
test('extreme authored frames never leak nonfinite diagnostics or a falsely normalized direction',async()=>{
 const f=await fixture(),fan=f.create();f.worlds[fan.nativeHash][0]=1e308;let m=f.call('fan-inputs').fan;assert.equal(m.mapping.status,'unsupported-frame');
 const finite=value=>{if(typeof value==='number')assert.ok(Number.isFinite(value));else if(value&&typeof value==='object')Object.values(value).forEach(finite);};finite(m);
 const local=math.I();local[0]=local[1]=Number.MIN_VALUE;f.transform(fan,local);m=f.call('fan-inputs').fan;assert.equal(m.mapping.status,'unsupported-frame');assert.ok(Math.abs(Math.hypot(...m.normalizedWorldAxis)-1)<1e-14);finite(m);
});
test('authoring-only Fan edits do not retire explicit-request fields; native source edits still do',async()=>{
 const f=await jobFixture();await f.solve();const saved=f.direct('status').job;
 const fan={nativeHash:'fan',type:'thermal_fan',enabled:true,params:{...defaults(),Thermal:'owner'}};f.context.document.nodes.push(fan);f.worlds.fan=math.I();
 for(const mutate of [()=>fan.params.Direction='Reverse',()=>fan.params.Thermal='',()=>fan.enabled=false,()=>f.worlds.fan[12]++,()=>f.context.document.nodes.pop()]){mutate();f.editor.documentChanged();assert.equal(f.direct('status').state,'ready');assert.equal(f.direct('status').job,saved);}
 f.snapshot.meshes[1].matrix[12]=1e-13;f.editor.documentChanged();assert.equal(f.direct('status').state,'stale');assert.equal(f.gpu.stats().live,0);
});
test('Actual core frame Undo preserves detached Fan job; authoring replacement rejects it before hash-resolved restart (CPU emulator)',async()=>{
 const f=await jobFixture();f.owner.id='owner-id';
 const fan={id:'fan-id',nativeHash:'fan',parent:'owner-id',type:'thermal_fan',enabled:true,params:{...defaults(),Thermal:'owner'},tags:[]};f.owner.tags=[];f.probe.tags=[];f.context.document.nodes.push(fan);
 const history=historyFixture(f.context.document.nodes,()=>f.editor.restored());Object.defineProperty(f.context.document,'nodes',{get:()=>history.nodes});
 const packed=y=>[.25,0,0,0,.25,0,0,0,.25,-25,y,-12.5];history.setFrame('fan',packed(-12.5));Object.defineProperty(f.worlds,'fan',{get:()=>math.unpack(history.frame('fan'))});
 const before=await f.solve(sceneRequest(1)),temperatures=(await f.call('inspect',{count:24})).temperatures,u=(await f.call('inspect-velocity',{component:'u',count:30})).values;
 const retained=async()=>{assert.strictEqual(f.context.document.nodes.find(n=>n.nativeHash==='owner'),f.owner);assert.strictEqual(f.context.document.nodes.find(n=>n.nativeHash==='fan'),fan);assert.equal(f.direct('status').job,before.status.job);assert.equal(f.direct('status').state,'ready');assert.deepEqual((await f.call('inspect',{count:24})).temperatures,temperatures);assert.deepEqual((await f.call('inspect-velocity',{component:'u',count:30})).values,u);};
 fan.params.Direction='Reverse';f.editor.documentChanged();await retained();
 const frames=history.frames();history.setFrame('fan',packed(3));history.pushFrame(frames,history.frames());f.editor.documentChanged();await retained();
 await history.undo();assert.deepEqual(history.frame('fan'),packed(-12.5));assert.equal(fan.params.Direction,'Reverse');f.editor.documentChanged();await retained();
 history.deleteOwner('owner');f.editor.documentChanged();assert.equal(f.context.document.nodes.some(n=>n.nativeHash==='owner'),false);await history.undo();
 const restored=f.context.document.nodes.find(n=>n.nativeHash==='owner');assert.notStrictEqual(restored,f.owner);assert.equal(restored.nativeHash,f.owner.nativeHash);assert.equal(f.direct('status').state,'idle');assert.equal(f.direct('status').job,null);
 await assert.rejects(f.call('inspect'),{code:'NO_RESULT'});await assert.rejects(f.call('inspect-velocity',{component:'u'}),{code:'NO_RESULT'});
 f.snapshot.meshes.reverse();const capture=await f.call('scene-inputs'),args=sceneRequest(1);args.settings.fluidOccurrence=fixtureFluidOccurrence(capture,'fluid');assert.equal(args.settings.fluidOccurrence,1);
 const fresh=await f.solve(args);assert.equal(fresh.status.state,'ready');assert.notEqual(fresh.status.job,before.status.job);assert.deepEqual((await f.call('inspect',{count:24})).temperatures,temperatures);assert.deepEqual((await f.call('inspect-velocity',{component:'u',count:30})).values,u);
 const solid=f.snapshot.meshes.find(m=>m.hash==='solid');solid.tags.find(t=>t.kind==='thermal_heater').params.Power=76;f.change();f.editor.documentChanged();assert.equal(f.direct('status').state,'stale');
 await assert.rejects(f.call('inspect'),{code:'NO_RESULT'});await assert.rejects(f.call('inspect-velocity',{component:'u'}),{code:'NO_RESULT'});await f.call('clear');assert.equal(f.gpu.stats().live,0);assert.equal(f.gpu.stats().scopes,0);assert.equal(f.borrowedDestroyed,0);
});
test('1000 complete Fan inspections in a 10000-node native document stay within 1500 ms without scene/GPU work',async()=>{
 const f=await fixture();f.create();for(let i=0;i<9998;i++)f.D.nodes.push({id:'other'+i,nativeHash:'other'+i,type:'group'});
 const start=performance.now();for(let i=0;i<1000;i++)assert.equal(inspectNativeFans(f.context,'owner').fan.mapping.status,'supported-frame');const wallMs=performance.now()-start;
 assert.ok(wallMs<1500,`${wallMs} ms exceeds 1500 ms`);console.log(JSON.stringify({operation:'1000 fan-inputs / 10000 native records',wallMs,budgetMs:1500,hardwareVerified:false}));
});
