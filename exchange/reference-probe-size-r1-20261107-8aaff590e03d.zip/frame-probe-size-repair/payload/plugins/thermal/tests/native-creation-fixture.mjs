import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {webcrypto} from 'node:crypto';

// CPU contract fixture, not browser/Undo/render verification. Execute the core's
// actual create -> visibility sync -> native sync -> native record installation,
// bridge and affine/frame readers. Only unrelated UI/GPU/animation endpoints and
// record-key addressing are adapters; never translate n.transform into matrices.
export const core=await readFile(new URL('../../../index.html',import.meta.url),'utf8');
export const manifest=JSON.parse(await readFile(new URL('../plugin.json',import.meta.url),'utf8'));
const section=(start,end)=>{const a=core.indexOf(start),b=core.indexOf(end,a);assert.ok(a>=0&&b>a,`Missing native contract: ${start}`);return core.slice(a,b);};
const line=start=>{const a=core.indexOf(start),b=core.indexOf('\n',a);assert.ok(a>=0&&b>a,`Missing native contract: ${start}`);return core.slice(a,b);};
const affine=section('const FM=(()=>{','\n\n    const POSE_WGSL');
export const math=new Function(affine+';return FM;')();
const sources=[
 affine,
 line('const defaults = fields =>'),
 line('  function owner(n){return types.get(n?.type);}'),
 section('function hardwareName(n){','\nfunction demo()'),
 section('  function bridge(entry){','\nlet creating='),
 section('function frameSyncEngineVisibility(){','\n\n// SLP1:'),
 section('    function nativeRecord(id,type,value){','\n    function deformationRevision('),
 section('    function syncNativeObjects(objects){','\n    function nativeCamera()'),
 ...['nativeValue(h,field)','poseObjects()','objectLocal(h)','transformParent(h,parent=nativeValue(h,\'parent\')?.[0])'].map(name=>line('    function '+name+'{')),
 section('    function objectWorld(h,seen=new Set()){','\n    function '),
 line('    function putFrame(h,field,m){')
].join('\n');

export function nativeCreationFixture(){
 return new Function('manifest','crypto',`
  const nodes=[],definitions=Object.fromEntries(manifest.objects.map(o=>[o.type,[o.name,'plugin:'+manifest.id,o.fields]]));
  const entry={manifest},types=new Map(manifest.objects.map(o=>[o.type,entry]));
  let serial=0,transactions=0,selected=new Set(),focusId,anchorId,selectedTag,selectedTags=new Set(),selectionArea;
  const node=id=>nodes.find(n=>n.id===id),FramePlugins={owner:n=>types.get(n?.type),dispatch:(method,...args)=>entry.editor?.[method]?.(...args)||null};
  const FrameHash={address:(id,field)=>id+':'+field,newId:()=>crypto.randomUUID().replaceAll('-',''),K:{version:'version',all:'all',camera:'camera',parameters:'parameters',units:'units'},T:{uint32:3,ids:4,text:7,bytes:0,float64:6}};
  const scene={records:new Map(),meshes:[]},frameCurves={},FrameMorph={sceneChannels:()=>new Map()},timelineFrame=0,timelineTotal=120;
  let poseRecordCache=null;const poseWorlds=new Map(),poseConstraints=new Map();
  const FrameSpline={supported:new Set(),generators:new Set(),shape:()=>null},frameAuthoring=n=>({plugin:manifest.id,type:n.type,params:{...n.params}}),frameValidateAuthoring=value=>value?JSON.parse(value):null;
  const appearanceTags=()=>[],frameSoloContains=()=>true,viewportLightingSignature=()=>'',snapshotFrames=()=>[],syncReplicas=()=>{},setVisibility=()=>{},draw=()=>{},drawGizmo=()=>{};
  const syncPoseWorld=()=>{poseWorlds.clear();poseRecordCache=null;};
  let objectSelection=[],selectionScope='objects',selectedMeshes=[],selectedMesh=null,selectionBox=null,componentPivot=null,coordinateCache=null,nativeIOBusy=false,frameUITransaction=false;
  const showMenu=()=>{},current=()=>node(focusId),playing=false;
  const handles={hidden:true},activateTab=()=>{},refreshSelection=()=>{},render=()=>{},snapshot=()=>{},checkpoint=()=>{},restore=()=>{},stop=()=>{},commitFrames=()=>{};
  const commit=fn=>{transactions++;fn();frameSyncEngineVisibility();};
  const window={FrameSpline,frameEngine:{scene,pluginMath:null,pluginWorld:hash=>Array.from(objectWorld(hash)),pluginLocal:hash=>Array.from(objectLocal(hash)),syncObjects:objects=>syncNativeObjects(objects)}};
  ${sources}
  window.frameEngine.pluginMath=FM;
  const context=bridge(entry);
  return {context,nodes,math:FM,create,entry,sync:frameSyncEngineVisibility,
   setLocal:(hash,m)=>{putFrame(hash,'matrix',Float64Array.from(m));syncPoseWorld();},
   packed:hash=>nativeValue(hash,'matrix'),local:objectLocal,world:objectWorld,
   get transactions(){return transactions;},get selected(){return {hash:node([...selected][0])?.nativeHash,area:selectionArea};}};
 `)(manifest,webcrypto);
}
