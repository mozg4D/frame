Native Probe size qualification overlay R1

Technical source code only. This is not a runtime release or general qualification.
Input PACKAGE-SHA256.json: 922fcf973a0218b41edeea35b54d44eeb33d9b062befa13e0a45a7f3071ff936
Output PACKAGE-SHA256.json: 13a4f6c3ec8c7051a167933a978c71c649b8630ff356d4b719ab109b88eef900

1. Verify the original packet with unchanged prepare.verifyPackage(). Clone into
   an absent sibling directory. Keep all original packets and reports untouched.
2. Read DELTA.json. For each of its ten repository paths, require the existing
   overlay file and OVERLAY-SHA256.json entry to match oldSHA256. A null oldSHA256
   requires both file and manifest key to be absent. Validate payload bytes
   against newSHA256 before copying. Reject unexpected paths or symlinks.
3. Copy each payload file to overlay/path. Update its hash in OVERLAY-SHA256.json
   and documentation/FROZEN-SOURCES.json in DELTA order. Write JSON through Node
   JSON.stringify(value,null,2)+'\n', UTF-8 without BOM. Copy PROBE-SIZE-REPAIR.json
   unchanged to packet root.
4. Rebuild PACKAGE-SHA256.json from sorted forward-slash relative regular paths,
   excluding itself, with the same JSON formatting. Verify the exact output SHA
   above, then verifyPackage(). Thirteen manifest entries change: ten code files,
   two hash metadata files, and the new receipt. No other runtime files change.
5. Use unchanged prepare.mjs with the same exact adef baseline. Dry-run, prepare
   into an absent target, then verifyTarget. No existing target may be overwritten.

Only use the focused gates authorized by the coordinator. Suggested sequence:
node tests/plugin-references.mjs
node --test plugins/thermal/tests/native-probe.mjs plugins/thermal/tests/numerics.mjs
node plugins/thermal/tests/native-probe-browser.mjs --headless
node plugins/thermal/tests/run.mjs --headless
Stop on any failure and preserve unique reports and logs. Never run aggregate,
standard/stress or user-scene tests without separate authorization.

The only runtime change initializes the Probe native frame at local scale .02.
Native origin, sampling, physics, core, Fan and catalogue are unchanged. The
current source-level native Fan/history regressions are included alongside the
Probe tests so the code set matches the separately validated CPU candidate.
The original private evidence and updated documentation are not in this ZIP.
