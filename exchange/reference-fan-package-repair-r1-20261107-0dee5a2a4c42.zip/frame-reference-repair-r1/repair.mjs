// Rebuild an isolated qualification packet without modifying its input packet.
import {readFile,readdir,lstat,realpath,mkdir,copyFile,writeFile} from 'node:fs/promises';
import {constants} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve,relative,join,dirname,isAbsolute,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url));
export const originalManifestSHA256='2e4f2ccef26ee683e5e64de3285552dc9ecfa68fdd75f8b906bf5848c0ad8b59';
export const originalArchiveSHA256='674d2b7f4bb9980f4324c0dfc2da6634e9ffe92d4dcc9b5313969764f50fa168';
export const coreSHA256='a8e82c4e8986a57b5b4b0d72539c5bbe60dbbfb8c6671e588492bedb4a77eba0';
export const payload={
 'frame-sw.js':'07d92c8cf7defe9b9ebd6dc2c92c674d6c9f8ab4f40a1541f9310e42a911f5b9',
 'plugins/index.json':'76b263f994b14e9a7bc9c0fa83f38f729f2abb757ae01f710c63f05be0eae3d0'
};
export const sha=b=>createHash('sha256').update(b).digest('hex');
const exists=async p=>{try{await lstat(p);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}};
const inside=(a,b)=>{const r=relative(a,b);return r===''||(!r.startsWith('..'+sep)&&r!=='..'&&!isAbsolute(r));};
function pathValid(p){if(typeof p!=='string'||!p||isAbsolute(p)||p.includes('\\')||p.includes(':')||p.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('Invalid packet-relative path');return p;}
async function inventory(root,prefix=''){let paths=[];for(const entry of await readdir(join(root,prefix),{withFileTypes:true})){const path=prefix?prefix+'/'+entry.name:entry.name;if(entry.isSymbolicLink())throw Error('Packet symlinks are not allowed');if(entry.isDirectory())paths.push(...await inventory(root,path));else if(entry.isFile())paths.push(path);else throw Error('Unsupported packet entry');}return paths.sort();}
async function manifest(root){const paths=await inventory(root),bytes=await readFile(join(root,'PACKAGE-SHA256.json'));if(sha(bytes)!==originalManifestSHA256)throw Error('Original package manifest SHA256 mismatch');const map=JSON.parse(bytes);for(const [p,h]of Object.entries(map)){pathValid(p);if(!/^[a-f0-9]{64}$/.test(h)||sha(await readFile(join(root,p)))!==h)throw Error('Original package file SHA256 mismatch: '+p);}if(JSON.stringify(paths.filter(p=>p!=='PACKAGE-SHA256.json'))!==JSON.stringify(Object.keys(map).sort()))throw Error('Unexpected or missing original package file');return map;}
async function writeJSON(path,value){await writeFile(path,JSON.stringify(value,null,2)+'\n');}
export async function repair(source,destination,{dryRun=false}={}){
 source=await realpath(resolve(source));destination=resolve(destination);
 if(await exists(destination))throw Error('Destination already exists; nothing was changed');
 destination=join(await realpath(dirname(destination)),relative(dirname(destination),destination));
 if(inside(source,destination)||inside(destination,source)||inside(here,destination)||inside(destination,here))throw Error('Destination must be outside the original and repair packets');
 const original=await manifest(source);
 for(const [p,h]of Object.entries(payload))if(sha(await readFile(join(here,'payload',p)))!==h)throw Error('Repair payload SHA256 mismatch: '+p);
 const overlay=JSON.parse(await readFile(join(source,'OVERLAY-SHA256.json'))),base=JSON.parse(await readFile(join(source,'BASE-COPY-SHA256.json'))),focused=JSON.parse(await readFile(join(source,'BASE-FOCUSED-SHA256.json'))),roles=JSON.parse(await readFile(join(source,'OVERLAY-ROLES.json')));
 if(overlay['index.html']!==coreSHA256)throw Error('Unexpected candidate core');
 const old={'frame-sw.js':'96cdfd836efc60589e901c34b7a2874b4376390eef97cf098d33c7d976ceebad','plugins/index.json':payload['plugins/index.json']};
 for(const [p,h]of Object.entries(old)){if(base[p]!==h||focused[p]!==h||Object.hasOwn(overlay,p))throw Error('Unexpected original dependency assignment: '+p);delete base[p];delete focused[p];overlay[p]=payload[p];roles[p]='exact isolated qualification dependency';}
 const html=await readFile(join(source,'overlay/index.html'),'utf8'),sw=await readFile(join(here,'payload/frame-sw.js'),'utf8');
 const htmlVersion=html.match(/name="frame-version" content="([^"]+)"/)?.[1],workerVersion=sw.match(/const VERSION='([^']+)'/)?.[1];
 if(!htmlVersion||htmlVersion!==workerVersion)throw Error('Service worker/core release version mismatch');
 const result={kind:'isolated-reference-packet-repair-r1',prepared:!dryRun,dryRun,originalManifestSHA256,originalArchiveSHA256,coreSHA256,payload,version:htmlVersion,overlayFiles:Object.keys(overlay).length,focusedBaseFiles:Object.keys(focused).length,browserStarted:false,hardwareVerified:false,thermalSolveReady:false,releaseQualified:false,structuralIntegrationQualified:false};
 if(dryRun)return result;
 await mkdir(destination);
 for(const p of [...Object.keys(original),'PACKAGE-SHA256.json']){const to=join(destination,p);await mkdir(dirname(to),{recursive:true});await copyFile(join(source,p),to,constants.COPYFILE_EXCL);}
 await manifest(source);await manifest(destination);
 for(const p of Object.keys(payload)){const to=join(destination,'overlay',p);await mkdir(dirname(to),{recursive:true});await copyFile(join(here,'payload',p),to,constants.COPYFILE_EXCL);}
 for(const [name,value]of [['OVERLAY-SHA256.json',overlay],['BASE-COPY-SHA256.json',base],['BASE-FOCUSED-SHA256.json',focused],['OVERLAY-ROLES.json',roles],['PACKAGING-REPAIR.json',result]])await writeJSON(join(destination,name),value);
 const readme=await readFile(join(destination,'README.txt'),'utf8');
 await writeFile(join(destination,'README.txt'),'PACKAGING REPAIR R1: See PACKAGING-REPAIR.txt. Prior packaging evidence is historical.\n\n'+readme.replace('Fifteen small startup/catalogue files','Thirteen small startup/catalogue files'));
 await copyFile(join(here,'PACKAGING-REPAIR.txt'),join(destination,'PACKAGING-REPAIR.txt'),constants.COPYFILE_EXCL);
 await manifest(source);
 const final={};for(const p of await inventory(destination))if(p!=='PACKAGE-SHA256.json')final[p]=sha(await readFile(join(destination,p)));await writeJSON(join(destination,'PACKAGE-SHA256.json'),final);
 for(const [p,h]of Object.entries(overlay))if(sha(await readFile(join(destination,'overlay',p)))!==h)throw Error('Repaired overlay verification failed: '+p);
 for(const [p,h]of Object.entries(original))if(p.startsWith('overlay/')&&sha(await readFile(join(destination,p)))!==h)throw Error('An original runtime/test overlay byte changed: '+p);
 result.packageManifestSHA256=sha(await readFile(join(destination,'PACKAGE-SHA256.json')));return result;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const args=process.argv.slice(2),dryRun=args.includes('--dry-run'),pos=args.filter(a=>a!=='--dry-run');try{if(pos.length!==2||args.some(a=>a.startsWith('--')&&a!=='--dry-run'))throw Error('Usage: node repair.mjs <original packet> <new packet> [--dry-run]');console.log(JSON.stringify(await repair(pos[0],pos[1],{dryRun}),null,2));}catch(error){console.error(error.message);process.exitCode=1;}
}
