Native Fan history fixture repair R1

This is a source-only technical patch for an isolated hardware qualification packet.
It is not a runtime release and does not change physics, core code or the live site.

Input PACKAGE-SHA256.json: d1b3bffd935a2028cf98921b002761f554a90bd6c4256f0136cee6ae6db2374f
Output PACKAGE-SHA256.json: 922fcf973a0218b41edeea35b54d44eeb33d9b062befa13e0a45a7f3071ff936
Patch JSON SHA256: 55d1be5d6684e8132139d2b1200950c35336c1b71131776de9a148a534838e3d

Verify the existing packet with its unchanged prepare.verifyPackage(). Copy it to
an absent sibling directory. Never edit the source packet or previous reports.
Read native-fan-browser-replacements.json. Verify oldSha256 on overlay/path. Apply
its four replacements in order, requiring exactly one match per old block.
Verify newSha256 on the complete resulting UTF-8 file before writing it.
Update only that path's hash in OVERLAY-SHA256.json and documentation/FROZEN-SOURCES.json.
Copy FAN-HISTORY-REPAIR.json to the new packet root unchanged. Serialize updated
JSON with Node JSON.stringify(value,null,2)+'\n', UTF-8, no BOM.
Rebuild PACKAGE-SHA256.json from all sorted forward-slash relative regular paths,
excluding itself. Verify the exact output manifest SHA above and verifyPackage().
Exactly four manifest entries change: the browser fixture, those two metadata
files, and the new FAN-HISTORY-REPAIR.json. All runtime files remain unchanged.

Use unchanged prepare.mjs with the same verified exact adef baseline, dry-run then
prepare into an absent target. VerifyTarget must pass before running anything.
Run only the focused gates authorized by the coordinator. Preserve all failures.
Do not run standard/stress or touch an existing scene without separate approval.
The source-history CPU regressions and documentation remain with the candidate;
this small overlay carries only the fixture needed for the hardware repeat.
