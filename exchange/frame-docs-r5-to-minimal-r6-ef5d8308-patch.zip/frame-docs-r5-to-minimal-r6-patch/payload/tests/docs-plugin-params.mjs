// CPU-only execution of the actual retained H15 validator, not a reimplementation.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
const start=html.indexOf('const FramePluginTags='),end=html.indexOf('const FrameDocumentation=',start);
assert.ok(start>=0&&end>start);assert.equal(html.split('const FramePluginTags=').length,2);
const source=html.slice(start,end),{params,...otherExports}=new Function(source+'return FramePluginTags;')();
assert.deepEqual(otherExports,{});assert.equal(typeof params,'function');
const spec={fields:{Count:3,Weight:0.5,Enabled:true,Mode:['Normal','Fast'],Code:[1,2],Label:''},ranges:{Count:{min:0,max:9,int:true},Weight:{min:-1,max:1}}};
const original=structuredClone(spec),checks=[];
const check=(name,run)=>{run();assert.deepEqual(spec,original,'Declaration unchanged: '+name);checks.push(name);};
check('omitted and empty params produce all typed defaults, including first enum values',()=>{const expected={Count:3,Weight:0.5,Enabled:true,Mode:'Normal',Code:1,Label:''};assert.deepEqual(params(spec),expected);assert.deepEqual(params(spec,{}),expected);assert.deepEqual(params({}),{});});
check('partial values preserve defaults and inputs; outputs are independent',()=>{const input={Weight:-0.25,Enabled:false,Mode:'Fast',Code:2,Label:'日本 😀'};const copy=structuredClone(input),a=params(spec,input),b=params(spec,input);assert.deepEqual(input,copy);assert.deepEqual(a,{Count:3,...copy});assert.notEqual(a,input);assert.notEqual(a,b);a.Mode='changed';assert.equal(b.Mode,'Fast');assert.deepEqual(input,copy);});
check('inclusive endpoints and integral values are accepted',()=>{for(const value of [0,9])assert.equal(params(spec,{Count:value}).Count,value);for(const value of [-1,1])assert.equal(params(spec,{Weight:value}).Weight,value);});
for(const [label,input,pattern] of [
 ['null record',null,/Invalid plugin tag parameters/],['array record',[],/Invalid plugin tag parameters/],['string record','x',/Invalid plugin tag parameters/],['number record',1,/Invalid plugin tag parameters/],['boolean record',false,/Invalid plugin tag parameters/],
 ['unknown field',{Missing:4},/Unknown plugin tag parameter/],['numeric string',{Count:'3'},/Invalid plugin tag parameter/],['boolean number',{Enabled:1},/Invalid plugin tag parameter/],['string boolean',{Enabled:'false'},/Invalid plugin tag parameter/],['wrong string field',{Label:3},/Invalid plugin tag parameter/],['enum string type',{Code:'1'},/Invalid plugin tag parameter/],['enum wrong value',{Mode:'Missing'},/Invalid plugin tag parameter/],['enum array value',{Mode:['Normal']},/Invalid plugin tag parameter/],['null field',{Count:null},/Invalid plugin tag parameter/],['undefined field',{Count:undefined},/Invalid plugin tag parameter/],
 ['NaN',{Count:NaN},/Invalid plugin tag parameter/],['positive infinity',{Weight:Infinity},/Invalid plugin tag parameter/],['negative infinity',{Weight:-Infinity},/Invalid plugin tag parameter/],['below minimum',{Count:-1},/outside range/],['above maximum',{Count:10},/outside range/],['fractional integer',{Count:3.5},/outside range/],['continuous below minimum',{Weight:-1.001},/outside range/],['continuous above maximum',{Weight:1.001},/outside range/],['late invalid field after valid override',{Count:5,Enabled:false,Missing:4},/Unknown plugin tag parameter/]
])check('rejects '+label+' without mutation',()=>{const before=structuredClone(input);assert.throws(()=>params(spec,input),pattern);assert.deepEqual(input,before);});
check('own-field validation rejects inherited declaration keys',()=>{for(const key of ['constructor','toString','__proto__'])assert.throws(()=>params(spec,JSON.parse('{"'+key+'":1}')),/Unknown plugin tag parameter/);});
check('frozen declarations and values remain usable without writes',()=>{const frozen=structuredClone(spec);Object.values(frozen.ranges).forEach(Object.freeze);Object.values(frozen.fields).filter(Array.isArray).forEach(Object.freeze);Object.freeze(frozen.fields);Object.freeze(frozen.ranges);Object.freeze(frozen);const input=Object.freeze({Count:4,Enabled:false});assert.equal(params(frozen,input).Count,4);});
console.log(JSON.stringify({pass:true,qualification:'CPU actual FramePluginTags.params; no new tag UI/API or declaration/effective implementation',checks,indexSHA256:createHash('sha256').update(html).digest('hex'),validatorSHA256:createHash('sha256').update(source).digest('hex')},null,2));
