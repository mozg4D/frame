// Source-bound H17 regression through actual settle, command FIFO and native queue.
// All other editor/scene/hardware dependencies are explicit fixtures.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
const between=(a,b)=>{assert.equal(html.split(a).length,2,'Unique source anchor: '+a);const start=html.indexOf(a),end=html.indexOf(b,start+a.length);assert.ok(end>start,a);return html.slice(start,end);};
const flushSource=between('  async function flush(options={})','\n');
const settleSource=between('      async function settle(allowGesture=false)','\n');
const queueSource=between('      let documentationWindow=null;','      const fail=');
const callSource=between('      async function call(name,args={},bridgeGuard=null)','\n      const listTools=');
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const tick=()=>new Promise(resolve=>setTimeout(resolve,0));
const observe=promise=>{const state={settled:false};state.promise=promise.then(value=>{state.settled=true;return {value};},error=>{state.settled=true;return {error};});return state;};
const checks=[];const check=async(name,fn)=>{await fn();checks.push(name);};
const makeFlush=hooks=>new Function('hooks',flushSource+';return flush;')(hooks);
await check('success waits for every hook and forwards identical options',async()=>{const gate=deferred(),options={mode:'test'},calls=[];const flush=makeFlush(()=>[{flush:o=>{assert.equal(o,options);calls.push(1);}},{},{flush:o=>{assert.equal(o,options);calls.push(2);return gate.promise;}}]);const state=observe(flush(options));await tick();assert.deepEqual(calls,[1,2]);assert.equal(state.settled,false);gate.resolve();assert.equal((await state.promise).error,undefined);});
await check('synchronous throw does not prevent later hooks and drains a pending rejection',async()=>{const gate=deferred(),first=Error('first'),last=Error('last'),calls=[];const flush=makeFlush(()=>[{flush:()=>{calls.push('throw');throw first;}},{flush:()=>{calls.push('pending');return gate.promise;}},{flush:()=>calls.push('last')}]);const state=observe(flush());await tick();assert.deepEqual(calls,['throw','pending','last']);assert.equal(state.settled,false);gate.reject(last);assert.equal((await state.promise).error,first);});
function fixture(hooks){
 const events=[],resolved=Promise.resolve();const c={Promise,Map,Set,JSON,performance,events,sequence:0,tail:resolved,nativeIOBusy:false,api:{ready:resolved,transforming:false},canvas:{dataset:{ready:'true'}},scene:{},docs:{get:()=>({version:'fixture:0'})},tools:new Map(),json:x=>JSON.parse(JSON.stringify(x)),validate(){},fail:(code,message)=>{throw Object.assign(Error(message),{code});},window:{dispatchEvent(){}},CustomEvent:class{},stop(){},FramePlugins:{loadUsed:async()=>{},flush:makeFlush(hooks)},FrameMorph:{flush:async()=>{}},FrameGeometry:{flush:async()=>{}},FrameSpline:{flush:async()=>{}},loadLibraryObjects:async()=>{},heldPointers:new Set(),boxDrag:null,drag:null,nodes:[],wheelBusy:false,pendingWheel:false};
 for(const key of ['objectActionQueue','clipboardSerial','selectionPending','selectionQueue','editSerial','appearanceQueue','polygonClick','loopSerial','replicaQueue','animationSerial','measureQueue'])c[key]=resolved;
 vm.createContext(c);vm.runInContext(queueSource+'\n'+settleSource+'\n'+callSource,c);
 c.tools.set('ordinary',{inputSchema:{},annotations:{readOnlyHint:false},run:()=>{events.push('api-body');return 'api';}});
 return c;
}
for(const firstRoute of ['native','api'])for(const lateOutcome of ['resolve','reject'])await check(firstRoute+' failure keeps next FIFO slot pending until every hook '+lateOutcome+'s',async()=>{
 const first=deferred(),late=deferred(),error=Error('first hook failure'),trace=[];let phase=0;
 const c=fixture(()=>phase++===0?[{flush:()=>{trace.push('first-start');return first.promise;}},{flush:()=>{trace.push('late-start');return late.promise.then(value=>{trace.push('late-end');return value;},e=>{trace.push('late-error');throw e;});}}]:[]);
 const failed=observe(firstRoute==='native'?c.frameNativeFileTask(()=>c.events.push('failed-native-body')):c.call('ordinary'));
 const next=observe(firstRoute==='native'?c.call('ordinary'):c.frameNativeFileTask(()=>{c.events.push('next-native-body');return 'native';}));
 await tick();assert.deepEqual(trace,['first-start','late-start']);first.reject(error);await tick();await tick();
 assert.equal(failed.settled,false,'Failed operation must not release its FIFO slot before drain');assert.equal(next.settled,false,'Next FIFO task must remain blocked');assert.deepEqual(c.events,[],'Neither failed nor next task body may execute');assert.equal(phase,1,'Next settle must not start');
 if(lateOutcome==='reject')late.reject(Error('late hook failure'));else late.resolve();
 assert.equal((await failed.promise).error,error,'Original first rejection preserved');assert.equal((await next.promise).error,undefined);assert.deepEqual(c.events,[firstRoute==='native'?'api-body':'next-native-body']);assert.equal(trace.at(-1),lateOutcome==='reject'?'late-error':'late-end');
});
console.log(JSON.stringify({pass:true,qualification:'CPU actual flush + settle + command/native FIFO; no browser or hardware',checks,indexSHA256:createHash('sha256').update(html).digest('hex'),flushSHA256:createHash('sha256').update(flushSource).digest('hex')},null,2));
