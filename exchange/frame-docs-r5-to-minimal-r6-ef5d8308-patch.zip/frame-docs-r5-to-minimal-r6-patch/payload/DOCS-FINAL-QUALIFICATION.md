# R6 minimal Docs subset

Release stamp: 2026 08 nov 00:14. This is a new source candidate, not a transfer of the R5 qualification. The interrupted candidate is preserved separately. This copy has not been published or uploaded.

## Exact source scope

`qualification/minimal-subset/SOURCE-PROOF.json` preserves the interrupted extraction proof. The CPU proof reconstructs exact R5 and pinned main afce7bc3aedeb9f7a86e2c7cca5735d894e07dac, then independently assembles this subset. H01 in the historical hunk table contains R5's stamp; the final subset stamp is applied separately and checked exactly.

The selection retains 41 entire hunks, reverts 41 entire hunks and splits H15/H23/H83. It excludes new tag UI/API/animation, sampler, sampled-volume, boundary/provenance and polygon changes. Necessary common-core dependencies stay together: strict known-tag params validation, all-hook flush drain, known/unknown HASH handling, opaque records, typed reference remapping/collision handling, native Merge rollback, New lock and Docs commit after geometry flush.

All four detached Docs runtime files and every R5 behavioral CPU/browser test remain byte-identical. The current file-controls sync helper and actual about:blank smoke are unchanged. Only the CPU runner replaces its old R5 hash-bound provenance step with the exact subset proof and adds two regressions. Historical provenance tests and metadata are retained, not relabeled as current PASS.

## Qualification commands

1. `node tests/docs-final-cpu-gate.mjs` or `powershell -File tools/qualify-docs-cpu.ps1` runs 18 sequential CPU stages and exact inventory checks before/after each stage. See the current `DOCS-FINAL-CPU-RESULT.json` rather than historical reports.
2. On the authorized Windows target, run the unchanged actual blank predicate smoke `node tests/file-controls-predicate-smoke.mjs` with the same supported headless setup as R5.
3. Run the unchanged nine-stage browser gate `node tests/docs-integrated-browser-gate.mjs --headless` (or its existing PowerShell wrapper) on the final frozen inventory. Stop on the first failed stage and preserve reports.

The exact source inventory excludes generated `DOCS...RESULT.json` and `tests/results`. Do not change any source or regenerate inventory during a qualification run. A forced browser timeout leaves descendant cleanup uncertain until checked. Browser assertions, diagnostic policy and budgets have not been relaxed.

The params suite executes the actual retained validator and tests defaults, types, enums, bounds, non-finite values and successful/failed nonmutation. The flush suite executes the actual flush, settle, API call and native FIFO, proving that an early hook rejection cannot release the slot while another hook is pending; late resolution and rejection are both covered.

## Preserved safety contracts and limitations

Composition captures the DOM draft before repaint/disconnect; CAS and scene epochs remain intact. Only the verified editor port can use the private write lane. Ordinary/public calls remain FIFO; sealed Save cannot wait on its own reserved queue slot. Dirty New/Open refuses instead of replacing the scene.

Browser and hardware checks are unrun on this new subset until its current reports exist. Real OS IME and installed-PWA checks are separate unrun gates. Synthetic events do not qualify real OS IME. Native Undo/Redo after a remote edit may safely do nothing; this is not a complete collaborative-history contract. PWA staging and the exact predecessor transition do not guarantee arbitrary mixed-deployment atomicity or rollback.

No Unite, standard/stress, printer/CNC, OBS or user scenes are part of this focused qualification. Local preparation does not publish; the release coordinator verifies fresh main/live identity and exact-source browser results before using the user's existing publication authorization.

Historical root manifests and instructions are under `qualification/minimal-subset/historical-r5/`. All older source-bound reports are historical only.
