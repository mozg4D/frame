# R5 focused Docs correction

Runtime version 2026 07 nov 23:20. R5 browser qualification is UNRUN. R4 offline functional checks passed but an implicit /favicon.ico request caused console FAIL. Original Windows reports remain untouched on Windows. This correction declares the existing cached SVG icon in Docs HTML and synchronizes index/SW stamps, with focused regression and exact source provenance. No console filtering, timeout or broader runtime changes.

No Unite, standard/stress, printer/CNC, uploads or publication. OS IME and broader release qualification remain open.

## Historical R4/R3 technical instructions

The text below is historical source-bound context. Its version and status statements do not describe R5. Existing focused commands and limits remain applicable.

# R4 focused Docs correction

Runtime version 2026 07 nov 23:03. R4 browser qualification is UNRUN. Historical Windows R3 results: CPU15 and first six browser stages PASS, offline PWA FAIL, final two stages NOT RUN. Original Windows reports remain untouched and are not cloud originals. This correction changes only temporary SW URL hash normalization, synchronized index/SW stamps, reviewed regression/diagnostic fixtures and exact source provenance.

No Unite or standard/stress suites, printer/CNC execution, user scenes/media, uploads or publication are authorized by this package. Actual OS IME, installed-PWA and broader release qualification remain open.

## Historical R3 technical instructions and limitations

The following source-bound R3 text is historical. Its version and execution-status statements do not describe R4. Existing focused commands and limits remain applicable.

# Unified Docs qualification copy

Status: frozen unified source candidate, not published or release-qualified. The exact independently reviewed Save barrier is incorporated, including active standard/focused lifecycle adapters. Browser, WebGPU hardware, real OS IME and installed-PWA gates have not run on this source. No prior PASS transfers to this copy.

## Inputs and scope

- ce96 editor integration is the explicit predecessor. Its earlier HASH/reference/lifecycle/core Docs work is retained; those are existing candidate changes relative to production, not newly qualified work.
- Frozen composition repair changes the detached editor and synchronization modules. Its event/storage/epoch tests are CPU fixtures, not an OS IME or native browser-history qualification.
- The independently approved Save barrier reserves the existing command order and seals exact acknowledged Docs state for Save/export/Share; pending New/Open refuses without replacing the current scene. The original 21 lifecycle assertions remain unchanged through the explicit adapter used by standard and focused entrypoints.
- Frozen PWA layer changes only the runtime version stamp and the worker's four Docs precache entries. Source-test and server MIME changes are development tools.
- The exact production predecessor is captured at commit afce7bc3aedeb9f7a86e2c7cca5735d894e07dac. Its 20-file declared PWA closure matches live bytes and pinned repository Git blobs. Its meta/title/worker version is 2026 05 nov 08:55. Optional models, textures and user scenes are not part of this capture.
- The copy does not import Thermal, Atomic stable-ID, SceneControl or other pending runtime candidates. The existing file-control fixture uses only a tiny Atomic authoring example, not a solver.

Original manifests, qualification documents and reports are retained byte for byte under qualification/predecessor-ce96, qualification/composition and qualification/pwa. These are historical, source-bound records. Current source layers and current live delta have separate manifests; inherited metadata is not a blanket release qualification.

## Current checks

The final sequential CPU gate must pass against this frozen inventory; its current result is recorded separately in DOCS-FINAL-CPU-RESULT.json. No older CPU report qualifies this source. All browser modules are syntax checked only. The two new browser children record parent/editor JavaScript and console errors and independent old/new main-page GPU validation/OOM/internal scopes, uncaptured errors, loss, device identity, adapter/browser metadata and fresh frame samples. GPU observation starts after ready; it is not a certification of all startup GPU work. The root DOCS-INTEGRATED-BROWSER-RESULT.json explicitly says not run.

CPU command: node tests/docs-final-cpu-gate.mjs

Future focused browser command, only on an authorized isolated hardware target: node tests/docs-integrated-browser-gate.mjs --headless

The browser runner checks the frozen source inventory before and after each child, including failed children, runs sequentially, stops on first failure and has a five-minute per-child limit. Generated DOCS…RESULT.json reports and tests/results are excluded from source hashing; immutable predecessor evidence remains included. Do not edit source or regenerate the inventory during a qualification run. A timeout forcibly stops the child and prevents later gates; browser descendant cleanup is then uncertain and must be checked before another run. Source hashes alone are not proof that all browser processes closed.

Focused sequence currently includes unchanged file controls, existing Docs/HASH/reference checks, fresh offline Docs, real-keyboard Undo/Redo across an acknowledged remote edit, and the exact captured production-page/new-worker transition. The exact reviewed immediate-input Save/Share/Open/New transport gate follows file controls.

The remote-history gate records actual native behavior. A safe Undo no-op after a remote patch is a limitation, not proof of a complete collaborative history contract. Silent remote-text loss/corruption, duplicate writes or parent/editor divergence is a failure to preserve and investigate, not a reason to weaken assertions.

The live-transition gate first requires the exact predecessor worker to control its page and verifies its entire declared cached closure. It then installs the exact candidate without reloading the old page, checks unsaved scene preservation and candidate cached shell/Docs hashes, and opens a fresh offline window for acknowledged edit and HASH roundtrip. It does not assert beta-editor/new-host compatibility or installed-PWA behavior.

## Still required

- Run the final source-bound CPU gate and independent final-source review.
- On real hardware, run the bounded focused browser sequence, including immediate input followed by Save/Share/Open/New with held writes and held acknowledgements, without preparatory docs.get or settle calls.
- Exercise real OS IME in the actual browser, including remote changes, final composition input, disconnect/reload recovery and scene-epoch changes. Synthetic CompositionEvent fixtures cannot satisfy this gate.
- Review recorded native Undo/Redo behavior across remote changes and explicitly preserve its limitations.
- Treat installed PWA, broader standard/stress suites and hardware resource-failure behavior as separate unrun gates. This document does not authorize their execution.

## Release risks and live delta

DOCS-LIVE-DELTA.json compares every asset in the verified 20-file production closure and identifies preexisting versus newly integrated differences. Eighteen captured assets remain unchanged. index.html already had a substantial ce96 candidate delta, then gains the reviewed barrier and final PWA stamp. frame-sw.js changes from production only in the PWA layer. Four detached Docs files become required precache resources.

The worker does not cryptographically bind downloaded runtime assets to index.html, clients.claim can switch an old page to a new worker, and no general rollback mechanism is provided. Successful resource staging and a focused transition test do not prove arbitrary mixed-deployment atomicity. The capture describes the observed production bytes at its timestamp, not a promise that production remains unchanged later.

No main push, site deployment, upload, user-scene mutation, OBS work or browser launch was performed for this integration.

Final qualification-only version: 2026 07 nov 22:08.

The barrier browser harness has a separately recorded test-only strengthening layer. It asserts parent epoch/semantic scene/native Save-target preservation before releasing held traffic, tests actual native New and file-input Open, instruments the real OPFS writable boundary on cancellation, and collects bounded best-effort GPU diagnostics on failure. These assertions have not run in a browser.
