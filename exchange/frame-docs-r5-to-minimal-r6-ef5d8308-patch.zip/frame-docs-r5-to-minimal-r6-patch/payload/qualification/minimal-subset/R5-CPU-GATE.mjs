// CPU-only, sequential qualification. No browser import, install, or launch.
import {spawnSync} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
import {verify} from './docs-gate-inventory.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const steps=['syntax.mjs','docs-final-syntax.mjs','scene-documentation.mjs','documentation-sync.mjs','documentation-selection.mjs','documentation-editor-events.mjs','documentation-save-barrier.mjs','hash-docs-barrier-lifecycle.mjs','file-controls-sequence.mjs','hash-best-effort.mjs','plugin-references.mjs','docs-editor-integration.mjs','docs-pwa-cache.mjs','docs-live-predecessor-test.mjs','docs-browser-diagnostics-test.mjs','docs-gate-inventory-test.mjs'];
const report={pass:false,qualification:'CPU only; browser and hardware not run',steps:[]};let baseline;
try{
 baseline=await verify(root);report.sourcesBefore=baseline;
 for(const name of steps){
  await verify(root,baseline);const started=performance.now();
  const result=spawnSync(process.execPath,['tests/'+name],{cwd:root,encoding:'utf8',timeout:60000,killSignal:'SIGKILL',maxBuffer:8*1024*1024});
  const step={name,exitCode:result.status,signal:result.signal,error:result.error?.message,elapsedMs:performance.now()-started,stdout:result.stdout,stderr:result.stderr};report.steps.push(step);
  try{await verify(root,baseline);step.inventoryAfter=true;}catch(error){step.inventoryAfter=false;throw error;}
  if(result.error||result.status!==0)throw Error('STOP: '+name+' did not pass');
 }
 report.pass=true;
}catch(error){report.error=error.stack||String(error);}finally{
 if(baseline)try{report.sourcesAfter=await verify(root,baseline);}catch(error){report.pass=false;report.cleanupInventoryError=error.message;}
 await writeFile(join(root,'DOCS-FINAL-CPU-RESULT.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({pass:report.pass,qualification:report.qualification,error:report.error,steps:report.steps.map(({stdout,stderr,...step})=>step)},null,2));process.exitCode=report.pass?0:1;
}
