# R6 minimal Docs editor integration

See DOCS-FINAL-QUALIFICATION.md for current source scope, commands and limitations. The R5 editor runtime and all behavioral assertions are unchanged; R5 results do not qualify the new core subset. Historical editor integration instructions are preserved under qualification/minimal-subset/historical-r5/.
