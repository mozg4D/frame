# Minimal Docs R6 source packet

This strict packet reconstructs the minimal Docs R6 candidate from exactly the verified broad R5 source. Base inventory: fafbaaba462ebb0ebffde9e23a48a5605c34e893bcbdf8232fd763a3c4b8e179 (193 source files). Target inventory: 87ea5859509b2ba6e0cc87a8ecb658d30a1ac2f4da6f09c649e66aa61101196f (211 source files). Version: 2026 08 nov 00:14.

Verify the independently supplied ZIP SHA-256 first. Preserve all previous source trees, archives, failures and reports. From this extracted packet folder, set $R5 to the exact original R5 source and $R6 to a NEW separate sibling folder:

    node .\apply-docs-minimal-r6.mjs --check $R5
    if ($LASTEXITCODE -ne 0) { throw 'STOP: input preflight failed' }
    node .\apply-docs-minimal-r6.mjs --apply $R5 $R6
    if ($LASTEXITCODE -ne 0) { throw 'STOP: patch failed; preserve incomplete output' }
    node "$R6\tests\docs-final-cpu-gate.mjs"
    if ($LASTEXITCODE -ne 0) { throw 'STOP: CPU18 failed' }

The applier validates exact source, metadata, payload and target hashes before writing. It refuses changed or unknown inventoried source files, unsafe paths, symlinks and existing or overlapping output. It copies only inventoried source plus four known metadata files. It never copies node_modules, .git, tests/results or root result reports, changes the R5 input, installs dependencies, or launches a browser. Inventoried historical CPU-only provenance is copied with its historical labels; it is not evidence of a new browser pass.

Only after explicit qualification authorization, using already available Playwright and Chromium, run the tiny actual-poller smoke before the sequential nine-stage browser gate. Stop on any failure:

    node "$R6\tests\file-controls-predicate-smoke.mjs"
    if ($LASTEXITCODE -ne 0) { throw 'STOP: predicate smoke failed' }
    node "$R6\tests\docs-integrated-browser-gate.mjs" --headless
    if ($LASTEXITCODE -ne 0) { throw 'STOP: focused browser gate failed' }

This package does not authorize browser execution, dependency installation, main/live changes or publication. Minimal R6 browser/hardware qualification is UNRUN when this packet is sealed. Broader standard/stress gates, OS IME and optional features are not qualified by CPU18 or the focused gate. No private scenes, Windows reports or optional fixture expansion are included.
