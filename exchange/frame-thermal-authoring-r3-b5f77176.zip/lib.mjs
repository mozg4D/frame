import {readFile,readdir,lstat,mkdir,writeFile,realpath} from 'node:fs/promises';
import {resolve,dirname,basename,join,sep,isAbsolute} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
export const packet=dirname(fileURLToPath(import.meta.url));
export const COMMIT='d98aca74b4be7e4703a26bf51caa874821dcc73b';
export const FREEZE='e1dab1c18e0da88a7cd6b1f23647e047e6b1291f656ea466b80e70ed376eaf12';
export const hash=b=>createHash('sha256').update(b).digest('hex');
export const blob=b=>createHash('sha1').update(Buffer.concat([Buffer.from(`blob ${b.length}\0`),b])).digest('hex');
export const fail=m=>{throw Error(m);};
export const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
export const overlap=(a,b)=>{a=a.toLowerCase();b=b.toLowerCase();return a===b||a.startsWith(b+sep)||b.startsWith(a+sep);};
export function valid(p){return typeof p==='string'&&p.length>0&&!p.includes('\\')&&!p.includes(':')&&!isAbsolute(p)&&!/[\x00-\x1f<>"|?*]/.test(p)&&p.split('/').every(x=>x&&x!=='.'&&x!=='..'&&!/[. ]$/.test(x)&&!/^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(x));}
export async function cleanPath(arg,{missing=false}={}){
 const p=resolve(arg);let cur=p,parts=[];while(dirname(cur)!==cur){parts.unshift(basename(cur));cur=dirname(cur);}
 for(let i=0;i<parts.length;i++){cur=join(cur,parts[i]);let s;try{s=await lstat(cur);}catch(e){if(e.code==='ENOENT'&&missing&&i===parts.length-1)return p;throw e;}if(s.isSymbolicLink())fail('Symlink/junction path rejected: '+cur);if(i<parts.length-1&&!s.isDirectory())fail('Non-directory ancestor: '+cur);}
 return p;
}
export async function regular(root,rel){if(!valid(rel))fail('Unsafe pathname: '+rel);const p=await cleanPath(join(root,rel)),s=await lstat(p);if(!s.isFile())fail('Not a regular file: '+rel);return readFile(p);}
export async function inventory(root,{excludeResults=false}={}){
 await cleanPath(root);const rows=[];
 async function at(dir,prefix=''){for(const name of (await readdir(dir)).sort()){const rel=prefix+name;if(!valid(rel))fail('Unsafe pathname: '+rel);const p=join(dir,name),s=await lstat(p);if(s.isSymbolicLink())fail('Symlink/junction entry: '+rel);if(s.isDirectory()){if(excludeResults&&rel==='tests/results')continue;await at(p,rel+'/');}else if(s.isFile()){const b=await readFile(p);rows.push({path:rel,bytes:b.length,sha256:hash(b),gitBlobSHA1:blob(b)});}else fail('Nonregular entry: '+rel);}}
 await at(root);rows.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);if(new Set(rows.map(r=>r.path.toLowerCase())).size!==rows.length)fail('Case-colliding filenames');return rows;
}
export function checkRows(rows){const names=new Set();for(const r of rows){if(!valid(r.path)||names.has(r.path.toLowerCase())||!Number.isSafeInteger(r.bytes)||r.bytes<0||!/^[a-f0-9]{64}$/.test(r.sha256)||!/^[a-f0-9]{40}$/.test(r.gitBlobSHA1))fail('Invalid inventory descriptor: '+r.path);names.add(r.path.toLowerCase());}return rows;}
export function verifiedBytes(b,d){if(b.length!==d.bytes||hash(b)!==d.sha256||blob(b)!==d.gitBlobSHA1)fail('Source bytes/digest mismatch: '+d.path);return b;}
export async function verifyTree(root,expected,options={}){const actual=await inventory(root,options);if(!equal(actual,expected))fail('Exact source inventory mismatch: '+root);return actual;}
export async function put(root,p,b){if(!valid(p))fail('Unsafe output pathname');await mkdir(dirname(join(root,p)),{recursive:true});await cleanPath(dirname(join(root,p)));await writeFile(join(root,p),b,{flag:'wx'});}
export async function save(root,p,value){return put(root,p,Buffer.from(JSON.stringify(value,null,2)+'\n'));}
export async function newDirectory(arg,inputs=[]){const p=await cleanPath(arg,{missing:true});if(inputs.some(x=>overlap(x,p)))fail('Destination overlaps input or evidence: '+p);try{await lstat(p);fail('Destination already exists; preserve all previous sources and results: '+p);}catch(e){if(e.code!=='ENOENT')throw e;}await mkdir(p);return p;}
export function args(keys,flags=[]){const a=process.argv.slice(2),o={};for(let i=0;i<a.length;i++){const k=a[i];if(!keys.includes(k)&&!flags.includes(k))fail('Unknown argument: '+k);if(Object.hasOwn(o,k))fail('Duplicate argument: '+k);o[k]=flags.includes(k)?true:a[++i];if(o[k]===undefined)fail('Missing argument: '+k);}return o;}
export async function verifyPacket(seal){
 if(!/^[a-f0-9]{64}$/.test(seal||''))fail('Explicit --seal SHA-256 is required');
 await cleanPath(packet);const lockBytes=await regular(packet,'packet-lock.json');if(hash(lockBytes)!==seal)fail('Packet seal mismatch');const lock=JSON.parse(lockBytes);checkRows(lock.files);
 const actual=await inventory(packet);if(!equal(actual.filter(x=>x.path!=='packet-lock.json'),lock.files))fail('Packet inventory mismatch');
 const m=JSON.parse(await regular(packet,'manifest.json'));const overlayBytes=await regular(packet,'overlay-manifest.json');if(hash(overlayBytes)!==FREEZE||m.frozenOverlayManifestSHA256!==FREEZE||m.baseCommit!==COMMIT||m.format!==1)fail('Frozen source identity mismatch');
 for(const rows of [m.baseFiles,m.finalFiles])checkRows(rows);
 if(m.baseFiles.length!==525||m.overlayFiles.length!==23||m.finalFiles.length!==545||!equal(JSON.parse(overlayBytes),m.overlayFiles))fail('Source cardinality/freeze mismatch');
 const expected=new Map(m.baseFiles.map(r=>[r.path,r]));let replaced=0;
 for(const d of m.overlayFiles){if(!valid(d.path))fail('Unsafe overlay pathname');const old=expected.get(d.path);if((old?.gitBlobSHA1||null)!==d.baseBlob)fail('Overlay original Git identity mismatch: '+d.path);if(old)replaced++;const r={path:d.path,bytes:d.bytes,sha256:d.sha256,gitBlobSHA1:d.blob};checkRows([r]);verifiedBytes(await regular(packet,'overlay/'+d.path),r);expected.set(d.path,r);}
 if(replaced!==3||!equal([...expected.values()].sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0),m.finalFiles))fail('Base plus overlay does not exactly equal final source');
 if(m.network.maxConcurrency!==3||m.network.responseTimeoutMs!==60000||m.network.totalExpectedBytes!==204029885||m.network.totalExpectedBytes!==m.baseFiles.reduce((s,r)=>s+r.bytes,0)||m.network.maxResponseBytes!==23124384)fail('Network byte/concurrency contract changed');
 return {m,packetBefore:actual};
}
export function urlFor(d,commit=COMMIT){if(commit!==COMMIT||!valid(d.path))fail('Only immutable expected commit and safe path accepted');return `https://raw.githubusercontent.com/mozg4D/frame/${COMMIT}/${d.path.split('/').map(encodeURIComponent).join('/')}`;}
export async function fetchPinned(d,fetcher=fetch){
 checkRows([d]);if(d.bytes>23124384)fail('Response descriptor exceeds maximum');const url=urlFor(d);
 const response=await fetcher(url,{redirect:'error',signal:AbortSignal.timeout(60000),headers:{Accept:'application/octet-stream','Accept-Encoding':'identity'}});
 if(response.status!==200||response.url!==url||response.redirected||!response.body)fail('Pinned response status/URL/body mismatch: '+d.path);
 const length=response.headers.get('content-length'),range=response.headers.get('content-range'),encoding=response.headers.get('content-encoding');
 if(range!==null||(encoding!==null&&encoding!=='identity')||(length!==null&&(!/^\d+$/.test(length)||Number(length)!==d.bytes)))fail('Pinned response length/range/encoding mismatch: '+d.path);
 const chunks=[];let size=0;for await(const chunk of response.body){size+=chunk.length;if(size>d.bytes)fail('Pinned response too large: '+d.path);chunks.push(Buffer.from(chunk));}return verifiedBytes(Buffer.concat(chunks),d);
}
export async function preserveFailure(evidence,error,stage,details={}){if(!evidence)return;try{await save(evidence,'firstFAIL.json',{pass:false,stage,error:error.stack||String(error),...details});}catch(e){if(e.code!=='EEXIST')throw e;}}
