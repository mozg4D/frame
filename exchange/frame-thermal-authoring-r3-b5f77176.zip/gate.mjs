import {readFile,writeFile,lstat,mkdir} from 'node:fs/promises';
import {join,resolve,dirname} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {spawnSync,spawn} from 'node:child_process';
import {packet,args,fail,verifyPacket,cleanPath,newDirectory,verifyTree,inventory,regular,put,save,hash,overlap,equal,preserveFailure} from './lib.mjs';
import {processInventory,identity} from './owned-processes.mjs';
let evidence,source,stage='preflight',before,m,packetBefore,runtimeBefore,runtime;
const testFiles=['authoring-preview','native-probe','native-selection','native-history-contract','opaque-authoring','browser-gate-contract'].map(s=>'plugins/thermal/tests/'+s+'.mjs');
async function command(name,argv,{timeout=120000,env=process.env}={}){stage=name;const r=spawnSync(process.execPath,argv,{cwd:source,encoding:'utf8',timeout,maxBuffer:16*1024*1024,env,windowsHide:true});await put(evidence,name+'.stdout.txt',Buffer.from(r.stdout||''));await put(evidence,name+'.stderr.txt',Buffer.from(r.stderr||''));await save(evidence,name+'.command.json',{executable:'node',argv,status:r.status,signal:r.signal,error:r.error?.message,timeoutMs:timeout});if(r.error||r.signal||r.status!==0)fail(name+' failed; inspect preserved stdout/stderr and firstFAIL');return r.stdout;}
async function hardwareCommand(argv,env){
 stage='06-hardware-authoring';let stdout='',stderr='',timedOut=false;
 const child=spawn(process.execPath,argv,{cwd:source,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
 await save(evidence,'06-hardware-authoring.command.json',{executable:'node',argv,pid:child.pid,softDeadlineMs:300000,autoKill:false});
 const timer=setTimeout(async()=>{timedOut=true;console.error('Hardware soft deadline reached. NO automatic process kill. Preserve evidence; coordinator must confirm cleanup of recorded owned processes only.');await preserveFailure(evidence,Error('300-second hardware soft deadline exceeded; no automatic kill. Owned-process cleanup must be confirmed.'),stage,{nodePID:child.pid,ownershipFiles:['runtime-ownership.json','runtime-owned-processes.jsonl']});},300000);
 child.stdout.on('data',b=>{stdout+=b;});child.stderr.on('data',b=>{stderr+=b;});
 const outcome=await new Promise((ok,no)=>{child.once('error',no);child.once('close',(status,signal)=>ok({status,signal}));}).finally(()=>clearTimeout(timer));
 await put(evidence,stage+'.stdout.txt',Buffer.from(stdout));await put(evidence,stage+'.stderr.txt',Buffer.from(stderr));await save(evidence,stage+'.exit.json',{...outcome,timedOut,autoKill:false});
 // The parent checks every recorded owned identity only after the child Node
 // exits. Its original Windows console is expected to survive browser.close().
 const cleanup=JSON.parse(await regular(evidence,'runtime-cleanup.json'));
 const known=new Set(cleanup.knownOwnedProcesses.map(identity));let remaining=[];
 for(let i=0;i<3;i++){remaining=(await processInventory()).filter(r=>known.has(identity(r)));if(!remaining.length)break;await new Promise(r=>setTimeout(r,500));}
 await save(evidence,'runtime-post-exit.json',{pass:remaining.length===0,childExited:true,nodePID:child.pid,status:outcome.status,signal:outcome.signal,remaining,knownOwnedProcesses:cleanup.knownOwnedProcesses});
 if(remaining.length)fail('Recorded owned processes remain after child Node exit; manual owned-process cleanup required.');
 if(timedOut||outcome.signal||outcome.status!==0)fail('Hardware process failed/abnormally terminated or exceeded soft deadline. Preserve all evidence; no rerun without diagnosis.');
 if(cleanup.pass!==true||cleanup.normalCloseCompleted!==true||cleanup.remaining.length)fail('Owned browser cleanup is not confirmed');
 try{await lstat(join(evidence,'runtime-ownership-error.json'));fail('Ownership tracking failed; manual cleanup confirmation required');}catch(e){if(e.code!=='ENOENT')throw e;}
 return stdout;
}
async function runtimeInventory(){return {playwright:await inventory(runtime.pw),playwrightCore:await inventory(runtime.core),browser:{sha256:hash(await readFile(runtime.browser)),bytes:(await lstat(runtime.browser)).size}};}
try{
 const o=args(['--seal','--source','--evidence','--playwright-root','--browser','--browser-sha256'],['--cpu','--hardware']);
 ({m,packetBefore}=await verifyPacket(o['--seal']));if(!!o['--cpu']===!!o['--hardware']||!o['--source']||!o['--evidence'])fail('Choose exactly --cpu or --hardware plus --source ROOT --evidence NEW --seal HASH');
 if(Number(process.versions.node.split('.')[0])<22||process.env.NODE_OPTIONS)fail('Node >=22 with no NODE_OPTIONS is required');
 source=await cleanPath(o['--source']);evidence=await newDirectory(o['--evidence'],[source,packet]);
 await save(evidence,'packet-before.json',packetBefore);before=await verifyTree(source,m.finalFiles,{excludeResults:true});await save(evidence,'source-before.json',before);
 const generatedBefore=await inventory(source);await save(evidence,'all-files-before.json',generatedBefore);
 const resultRel=o['--cpu']?'tests/results/thermal-core-references.json':'tests/results/thermal-authoring-preview.json';
 try{await lstat(join(source,resultRel));fail('This gate result already exists; use another new reconstructed target, never overwrite first results');}catch(e){if(e.code!=='ENOENT')throw e;}
 if(o['--cpu']){
  if(o['--playwright-root']||o['--browser']||o['--browser-sha256'])fail('CPU gate never loads a browser installation');
  const syntax=await command('01-core-syntax',['tests/syntax.mjs']);if(!/scripts: 2, lazyScripts: 5/.test(syntax))fail('Unexpected core syntax counts');
  const modules=m.finalFiles.filter(x=>x.path.startsWith('plugins/thermal/')&&/\.(mjs|js)$/.test(x.path));
  for(let i=0;i<modules.length;i++)await command('02-module-syntax-'+String(i+1).padStart(2,'0'),['--check',modules[i].path]);
  const cpu=await command('03-focused-cpu',['--test','--test-reporter=tap',...testFiles]);for(const line of ['# tests 56','# pass 56','# fail 0','# cancelled 0','# skipped 0','# todo 0'])if(!cpu.split(/\r?\n/).includes(line))fail('Unexpected focused CPU count: '+line);
  await command('04-native-references',['plugins/thermal/tests/core-reference-contract.mjs']);const refs=JSON.parse(await regular(source,resultRel));if(refs.pass!==true||refs.checks.length!==52||refs.indexSHA256!==m.finalFiles.find(x=>x.path==='index.html').sha256||refs.timings.length!==4||refs.timings.some(t=>!(t.ms<t.budgetMs)||t.budgetMs!==500))fail('Unexpected reference count/source/budget');await save(evidence,'native-reference-result.json',refs);
  const doc=JSON.parse(await command('05-doc-cpu',['tests/documentation-button-state.mjs']));if(doc.pass!==true||doc.assertions!==17||!(doc.ms<1000))fail('Unexpected Doc count/budget');await save(evidence,'doc-result.json',doc);
  await save(evidence,'gate-result.json',{pass:true,scope:'CPU source contracts only',focusedGroups:56,referenceAssertions:52,docAssertions:17,syntaxScripts:2,syntaxLazyScripts:5,thermalModules:modules.length,hardware:'UNRUN',standard:'UNRUN (contains Unite)',stress:'UNRUN',numerical:'NOT QUALIFIED'});
 }else{
  if(!o['--playwright-root']||!o['--browser']||!/^[a-f0-9]{64}$/.test(o['--browser-sha256']||''))fail('Hardware gate needs explicit existing --playwright-root, --browser and independently recorded --browser-sha256');
  const pw=await cleanPath(o['--playwright-root']),browser=await cleanPath(o['--browser']);if([pw,browser].some(p=>overlap(p,source)||overlap(p,packet)||overlap(p,evidence)))fail('Existing runtime must be external to packet/source/evidence');
  const req=createRequire(join(pw,'package.json')),core=dirname(req.resolve('playwright-core/package.json'));
  for(const [p,name] of [[pw,'playwright'],[core,'playwright-core']]){const pkg=JSON.parse(await regular(p,'package.json'));if(pkg.name!==name||pkg.version!=='1.64.1')fail('Existing '+name+' must be version 1.64.1');}
  await regular(pw,'index.mjs');const bs=await lstat(browser);if(!bs.isFile()||hash(await readFile(browser))!==o['--browser-sha256'])fail('Existing browser digest mismatch');
  runtime={pw,core,browser};runtimeBefore=await runtimeInventory();await save(evidence,'runtime-before.json',runtimeBefore);
  const temp=join(evidence,'runtime-temp');await mkdir(temp);const env={...process.env,TEMP:temp,TMP:temp,TMPDIR:temp,FRAME_PACKET_EVIDENCE:evidence,FRAME_BROWSER:browser,FRAME_DPR:'1',PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD:'1',FRAME_PACKET_PLAYWRIGHT_ENTRY:join(pw,'index.mjs'),FRAME_PACKET_RUNTIME_REPORT:join(evidence,'runtime-startup.json')};
  await hardwareCommand(['--experimental-loader',pathToFileURL(join(packet,'playwright-loader.mjs')).href,'--import',pathToFileURL(join(packet,'runtime-bind.mjs')).href,'plugins/thermal/tests/authoring-browser.mjs','--headless'],env);
  const result=JSON.parse(await regular(source,resultRel));await save(evidence,'hardware-result.json',result);
  if(result.pass!==true||result.hardwareVerified!==true||result.checks.length!==109||result.timings.length!==17||result.checks.some(c=>c.pass!==true)||result.timings.some(t=>!Number.isFinite(t.ms)||!(t.ms<t.limit)))fail('Hardware result incomplete, failed or unexpected gate/timing count');
  for(const [p,h] of Object.entries(result.sources))if(m.finalFiles.find(x=>x.path===p)?.sha256!==h)fail('Hardware report source mismatch: '+p);
  if(Object.keys(result.sources).length!==10||!result.evidence?.preview||!result.evidence?.probe)fail('Missing complete source or both authoring/Probe evidence');
  await save(evidence,'gate-result.json',{pass:true,scope:'Hardware authoring only',checks:109,timings:17,standard:'UNRUN (contains Unite)',stress:'UNRUN',largeScene:'UNRUN',numerical:'NOT QUALIFIED'});
 }
 stage='after-run source binding';await save(evidence,'source-after.json',await verifyTree(source,m.finalFiles,{excludeResults:true}));const allAfter=await inventory(source);await save(evidence,'all-files-after.json',allAfter);
 for(const old of generatedBefore)if(!equal(allAfter.find(x=>x.path===old.path),old))fail('Existing file changed during gate: '+old.path);
 if(!equal(allAfter.filter(x=>!generatedBefore.some(b=>b.path===x.path)).map(x=>x.path),[resultRel]))fail('Unexpected generated files during gate');
 if(!equal(await inventory(packet),packetBefore))fail('Packet changed during gate');await save(evidence,'packet-after.json',packetBefore);
 if(runtime){const after=await runtimeInventory();await save(evidence,'runtime-after.json',after);if(!equal(after,runtimeBefore))fail('Existing runtime changed during gate');}
 await save(evidence,'result.json',{pass:true,sourceUnchanged:true,packetUnchanged:true,firstFailureOverwritten:false,baseCommit:m.baseCommit,freeze:m.frozenOverlayManifestSHA256});console.log(JSON.stringify({pass:true,sourceUnchanged:true,evidence}));
}catch(error){await preserveFailure(evidence,error,stage);if(evidence&&source){try{await save(evidence,'source-after-failure.json',await inventory(source));}catch(e){await save(evidence,'source-after-failure-error.json',{error:e.message}).catch(()=>{});}}console.error(error.stack);process.exitCode=1;}
