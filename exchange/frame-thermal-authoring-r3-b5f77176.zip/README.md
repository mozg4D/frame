# Frame Thermal authoring-only r3: isolated LAB gate packet

**PREPARED ONLY. Do not run on LAB until the coordinator gives the hardware queue GO. No publication, upload, installation, standard/stress/Unite or numerical qualification is performed by this packet.**

This packet reconstructs the complete public source base at immutable Git commit `d98aca74b4be7e4703a26bf51caa874821dcc73b`, then applies the frozen authoring-only delta. It does not depend on any historical LAB checkout. The previous numerical baseline is not an acceptable implicit input.

## Exact scope and closure

- Base: 525 public tracked files, exactly **204,029,885 bytes**. Full fetch means about 204 MB decimal (194.58 MiB) once, not that large fixtures will run.
- Overlay: 23 files, replacing 3 and adding 20. Final exact source: **545 files**.
- Original Git tree: `d01c077697f8d3dd7bea42b1ef8db58ae80ff6e9`.
- Frozen overlay manifest SHA-256: `e1dab1c18e0da88a7cd6b1f23647e047e6b1291f656ea466b80e70ed376eaf12`.
- Every source byte is checked by exact path, length, SHA-256 and Git blob SHA-1. Full original source is reconstructed and checked before applying the overlay; final source is independently checked afterward.
- Native Thermal box, 25 mm Fan pointing along local X, 2 mm Probe, explicit native references/transforms, disabled Under construction status. No solver, physical domain, field state, Material/Heater tag registration or temperature measurement.
- This is a source closure, not a claim that external runtime dependencies are contained. Node >=22 and the LAB's existing Playwright **1.64.1**, playwright-core **1.64.1**, and Chromium **156** are external inputs. Hardware mode records full Playwright/core file inventories and the browser executable's exact bytes/hash before and after. It requires an independently recorded browser SHA-256 and checks the actual launched browser major. It does not authenticate every Chromium companion DLL or the OS/GPU driver; those remain the existing trusted LAB runtime.
- No `node_modules`, generated reports, private notes, private data, or user profiles are in the ZIP. Public repository fixture paths are in the immutable manifest, and a full fetch retrieves those public tracked fixtures. Existing private/local fixtures are neither used nor copied.

## Trust and immutable delivery

Verify the ZIP SHA-256 against the independently supplied delivery value **before extraction/execution**. Extract to a fresh packet directory. The scripts verify a sealed exact packet inventory, including themselves. Do not modify any script, source, manifest, threshold or inventory to make a run pass.

PowerShell examples below assume your current directory is the extracted packet. Replace only the destination and existing runtime paths. Existing targets are rejected, never overwritten. Every evidence path must also be new. Do not put source/evidence/runtime inside the packet or inside one another. Existing node_modules stays outside the reconstructed source.

```powershell
$seal = (Get-FileHash .\packet-lock.json -Algorithm SHA256).Hash.ToLowerInvariant()
node .\bootstrap.mjs --verify-package --seal $seal
node .\transport-negative-controls.mjs --seal $seal --evidence 'C:\LAB\thermal-r3-transport-controls-NEW'
```

The controls are network-free and CPU-only. Windows junction creation is used to prove junction rejection. If the platform denies that operation, preserve the failure and report the restriction rather than skipping the control.

### Reconstruct from the pinned public base

Only after the authorized source-transfer step, run:

```powershell
node .\bootstrap.mjs --fetch --out 'C:\LAB\thermal-r3-source-NEW' --evidence 'C:\LAB\thermal-r3-rebuild-NEW' --seal $seal
```

Preflight is completely network-free: packet seal, all 23 payloads, inventory/path constraints, all expected digests, exact commit, byte limits and new/disjoint destination paths are checked first. Only then does it create the new source target and fetch the 525 immutable `raw.githubusercontent.com/mozg4D/frame/<commit>/<encoded-path>` URLs. Each response must be status 200 from exactly that URL, with no redirect or partial/content-range/encoded response, and exact length and both hashes. At most 3 requests are in flight; each has a 60-second deadline. Maximum per-response body is 23,124,384 bytes; expected total is exactly 204,029,885. There are no retries, moving branches, archive substitutions, mirror URLs, API fallbacks or installation commands. Any problem fails closed and leaves partial output/evidence intact. Do not reuse that destination.

Alternatively, an already available **complete pristine 525-file exact base** can be read offline. No files may be absent or extra, including `.git`, `node_modules` or results. A base with missing historical inputs is rejected before copying.

```powershell
node .\bootstrap.mjs --local-base 'C:\LAB\exact-d98aca74-pristine' --out 'C:\LAB\thermal-r3-source-NEW' --evidence 'C:\LAB\thermal-r3-rebuild-NEW' --seal $seal
```

This command only reads the old base. The source target must still be a new path. Never point `--out` at an old numerical source, a working checkout or live-site files.

### CPU gate

```powershell
node .\gate.mjs --cpu --source 'C:\LAB\thermal-r3-source-NEW' --evidence 'C:\LAB\thermal-r3-cpu-NEW' --seal $seal
```

This runs the following exact source commands, plus `node --check` for every Thermal `.js`/`.mjs` module (16 modules):

```text
node tests/syntax.mjs
node --test --test-reporter=tap plugins/thermal/tests/authoring-preview.mjs plugins/thermal/tests/native-probe.mjs plugins/thermal/tests/native-selection.mjs plugins/thermal/tests/native-history-contract.mjs plugins/thermal/tests/opaque-authoring.mjs plugins/thermal/tests/browser-gate-contract.mjs
node plugins/thermal/tests/core-reference-contract.mjs
node tests/documentation-button-state.mjs
```

Expected: 2 executable + 5 lazy scripts, **56 focused test groups**, **52 core-reference assertions**, **17 Doc assertions**, zero failed/cancelled/skipped/todo. The 56 include fourteen source-bound browser-gate contract groups, including seven rejection-boundary controls. Expected custom Error.code is captured inside the page before Playwright serialization; exact rejection-code assertions are preserved. CPU fixtures adapt GPU/DOM/checkpoint storage and do not qualify native browser/HASH behavior.

### Dedicated hardware gate, only after GO

Use the actual existing installation paths. `$browserHash` must come from the known LAB binary, independently of this packet. No `npm install`, `npx`, browser install, registry access or package download is needed or allowed. The wrapper maps only the bare `playwright` import to the explicit existing package; no files or links are added to the 545-file source. Its additional launch wrapper checks the browser version without changing any source assertions.

```powershell
$browser = 'C:\EXISTING\chromium-156\chrome.exe'
$browserHash = (Get-FileHash $browser -Algorithm SHA256).Hash.ToLowerInvariant()
node .\gate.mjs --hardware --source 'C:\LAB\thermal-r3-source-NEW' --evidence 'C:\LAB\thermal-r3-hardware-NEW' --playwright-root 'C:\EXISTING\node_modules\playwright' --browser $browser --browser-sha256 $browserHash --seal $seal
```

The frozen r3 source harness is:

```text
node plugins/thermal/tests/authoring-browser.mjs --headless
```

The wrapper supplies the explicit existing runtime using a Node loader/preload, exact executable path, DPR 1 and no NODE_OPTIONS. It invokes that harness only, with a 300-second soft watchdog. It never automatically kills the hardware Node/Chromium process. Ownership polling is serialized with at most one query in flight; close cancels the timer and awaits any in-flight query before final cleanup verification. Tracking failures stay fail-closed but do not prevent closing the owned browser. The preload records the owned Node PID, fresh TEMP/profile root and descendant PID/creation identities, then confirms normal browser close and disappearance of browser-lifetime descendants. The exact pre-launch Node/console identities are excluded only from this in-child browser-close check, not by process name. After the child Node exits, the parent verifies that every recorded owned identity, including that baseline console, has disappeared; an orphan remains a failure. Both runtime-cleanup.json and runtime-post-exit.json must pass. The soft watchdog writes firstFAIL, warns the operator and waits for normal shutdown or coordinator intervention. Timeout, ownership-tracking failure, abnormal exit or unconfirmed cleanup is never PASS. Before another hardware run, the coordinator must inspect those records and terminate only verified owned processes if needed; never use blanket chrome/node process termination. This ownership query uses existing Windows PowerShell/CIM; missing access is a blocker, not a skipped check. It includes native Probe checks, never runs `tests/run.mjs`, and accepts only complete authoring + Probe evidence. Successful expected expansion: **109 checks and 17 timed operations** (65/9 authoring, 44/8 Probe). The static expansion and all budgets are documented in `gate-ledger.json`; this is not a hardware PASS.

Hardware requirements include identifiable non-software WebGPU with `isFallbackAdapter === false`, native decoded/displayed 32×32 icon, exact creation/selection/reference/native HASH/clipboard/history behavior, 12 timing-query frames per helper gate with every CPU/GPU frame <50 ms, no GPU/page errors/device loss, no solver modules or numerical buffers. Operation budgets are unchanged: owner/Fan creation <10,000 ms; Fan/Probe transforms and reference drops <1,500 ms; queued Fan creation+transform <11,500 ms; native HASH export <3,000 ms/open <10,000 ms; Probe creation <2,000 ms; queued Probe <3,500 ms with its separate <2,000/<1,500 ms split; 32 Probe creation operations <10,000 ms. CPU creation batch is <1,500 ms; reference batches each <500 ms; Doc lifecycle <1,000 ms.

## Evidence and first failure

Only a final `result.json` with `pass: true`, no `firstFAIL.json`, unchanged source/packet inventories, and all expected stage results is a pass. A partial or intermediate gate-result is not an overall pass. The runners stop at the first failure and preserve `firstFAIL.json` with exclusive creation. Stage stdout/stderr/commands, source inventories before/after, generated-output inventories, and external runtime inventories are separate evidence, not source files. Failure snapshots do not overwrite earlier evidence.

Generated source outputs are restricted to `tests/results/thermal-core-references.json` for CPU and `tests/results/thermal-authoring-preview.json` for hardware. Existing generated files are inventoried and must remain unchanged. A gate refuses to overwrite its existing result. To repeat a failed or completed gate, reconstruct another new target and choose another new evidence directory. Do not delete or edit old failure artifacts to rerun.

**`npm test` / standard / stress: UNRUN.** The standard `tests/run.mjs` includes Unite, which is intentionally postponed. Large-scene/100M-triangle and numerical qualification are UNRUN. This authoring preview has no solver. No claim transfers from any earlier numerical/hardware result. This packet is pinned to its stated base; it does not reconcile a newer main or establish live-site cache/version readiness.
