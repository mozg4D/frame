Native Probe/Fan selection qualification overlay R1

Technical source code only. This is not a runtime release or general qualification.
Input PACKAGE-SHA256.json: 13a4f6c3ec8c7051a167933a978c71c649b8630ff356d4b719ab109b88eef900
Output PACKAGE-SHA256.json: 491a6a799d6a0ade12a60c50f1d35632c026430c6b9dbbb4473c62d50af89ab5

1. Verify the original R5 packet using unchanged prepare.verifyPackage(). Clone
   into an absent sibling directory. Preserve original packets and all reports.
2. Read DELTA.json in order. For each of its nine repository paths, require both
   existing overlay bytes and OVERLAY-SHA256.json to match oldSHA256. A null
   oldSHA256 requires both file and key absent. Verify payload newSHA256 before
   copying. Reject unexpected paths, symlinks and any mismatched bytes.
3. Copy payload files into overlay/path. Update hashes in OVERLAY-SHA256.json
   and documentation/FROZEN-SOURCES.json in DELTA order. Use Node
   JSON.stringify(value,null,2)+'\n', UTF-8 without BOM. Copy
   NATIVE-SELECTION-REPAIR.json unchanged into packet root.
4. Rebuild PACKAGE-SHA256.json from sorted forward-slash regular relative paths,
   excluding itself, with identical JSON formatting. Require the exact output
   hash above and verifyPackage(). Twelve manifest entries change: nine code
   files, two metadata files and one receipt. No other runtime file changes.
5. Use unchanged prepare.mjs and the same exact adef baseline. Dry-run, prepare
   into an absent target, verifyTarget. Never overwrite an existing target.

Only run focused gates explicitly authorized by the coordinator, serially:
node tests/plugin-references.mjs
node --test plugins/thermal/tests/native-selection.mjs plugins/thermal/tests/native-probe.mjs plugins/thermal/tests/native-fan.mjs plugins/thermal/tests/numerics.mjs
node plugins/thermal/tests/native-probe-browser.mjs --headless
node plugins/thermal/tests/native-fan-browser.mjs --headless
node plugins/thermal/tests/run.mjs --headless
Stop on the first failure and preserve uniquely named reports and logs. Never
run aggregate, standard/stress or user-scene tests without separate approval.

Both creation operations await native editor.selectOwner after their original
single transaction. No core, physics, sampling, schema or geometry default
changes. Strict child-local, world-frame and bounds checks remain; the owner
must not move. Tests cover immediate Attributes/API edits without reselection,
queued create-and-transform, repeated creation, Undo/Redo, newer selections,
component modes, selector rejection recovery, and native API-tail completion.
The cloud browser executable is absent; hardware checks remain pending.
