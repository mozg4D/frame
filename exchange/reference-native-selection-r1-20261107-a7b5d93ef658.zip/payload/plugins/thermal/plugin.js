import {sampleProbe,copyPhysicalFrame} from './probe.js';
import {THERMAL_TAGS, inspectSceneInputs} from './scene-inputs.js';
import {inspectGeometry} from './geometry.js';
import {nativeSceneSchema,snapshotNativeSceneRequest} from './native-scene-request.js';
import {advanceTouchingSceneConjugateGPU} from './scene-conjugate-duration.js';
import {exactOccurrenceStamp,sceneIdentityMatches,sharedThermalDeviceState} from './scene-identity.js';
import {validateFanParameters,inspectNativeFans} from './native-fan.js';
// Explicit-grid conduction with separate scene tag authoring/inspection. No scene voxelization.
export const MAX_CELLS = 262144;
const FACES = ['xMin', 'xMax', 'yMin', 'yMax', 'zMin', 'zMax'];
const error = (code, message) => Object.assign(new Error(message), {code});
const objectSchema = properties => ({type:'object', properties, additionalProperties:false});
const emptySchema = objectSchema({});
const numericArray = (minItems, maxItems, minimum) => ({type:'array', minItems, maxItems, items:{type:'number', ...(minimum === undefined ? {} : {exclusiveMinimum:minimum})}});
export const gridSchema = {...objectSchema({
  dimensions:{type:'array', minItems:3, maxItems:3, items:{type:'integer', minimum:1, maximum:256}},
  cellSize:numericArray(3, 3, 0),
  conductivity:numericArray(1, MAX_CELLS, 0),
  heatCapacity:numericArray(1, MAX_CELLS, 0),
  source:numericArray(1, MAX_CELLS),
  initial:numericArray(1, MAX_CELLS),
  boundary:objectSchema(Object.fromEntries(FACES.map(k => [k, {type:'number', minimum:-273.15}]))),
  boundaryFlux:objectSchema(Object.fromEntries(FACES.map(k => [k, {type:'number'}]))),
  timeStep:{type:'number', exclusiveMinimum:0},
  tolerance:{type:'number', minimum:1e-6, maximum:.1},
  maxIterations:{type:'integer', minimum:1, maximum:20000}
}), required:['dimensions', 'cellSize', 'conductivity']};

// Cell-centred finite volumes. Each shared face has one reciprocal conductance.
// The returned Float64 coefficients are also useful for independent numerical inspection.
export function assembleConduction(input, defaults = {ambient:20, initial:20}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw error('INVALID_ARGUMENT', 'Expected a grid object.');
  for (const key of Object.keys(input)) if (!Object.hasOwn(gridSchema.properties, key)) throw error('INVALID_ARGUMENT', 'Unknown grid field: '+key);
  const dimensions = input.dimensions;
  if (!Array.isArray(dimensions) || dimensions.length !== 3 || dimensions.some(n => !Number.isInteger(n) || n < 1 || n > 256)) throw error('INVALID_ARGUMENT', 'dimensions must contain three integers from 1 to 256.');
  const count = dimensions.reduce((a,b) => a*b, 1);
  if (count > MAX_CELLS) throw error('GRID_LIMIT', 'The explicit-grid foundation supports at most '+MAX_CELLS+' cells.');
  const cellSize = input.cellSize;
  if (!Array.isArray(cellSize) || cellSize.length !== 3 || cellSize.some(x => !Number.isFinite(x) || x <= 0)) throw error('INVALID_ARGUMENT', 'cellSize must contain three positive metre lengths.');
  const volume = cellSize.reduce((a,b) => a*b, 1);
  if (!Number.isFinite(volume) || volume <= 0) throw error('INVALID_ARGUMENT', 'Invalid physical cell volume.');
  const field = (name, fallback, positive = false, temperature = false) => {
    const values = input[name] ?? fallback;
    if (!Array.isArray(values) || (values.length !== 1 && values.length !== count) || values.some(x => !Number.isFinite(x) || positive && x <= 0 || temperature && x < -273.15)) throw error('INVALID_ARGUMENT', name+' must contain one value or one valid value per cell.');
    return i => values[values.length === 1 ? 0 : i];
  };
  const conductivity = field('conductivity', null, true), capacity = field('heatCapacity', [1e6], true);
  const source = field('source', [0]), temperature = field('initial', [defaults.initial], false, true);
  const flux = input.boundaryFlux ?? {};
  if (!flux || typeof flux !== 'object' || Array.isArray(flux) || Object.entries(flux).some(([k,v]) => !FACES.includes(k) || !Number.isFinite(v))) throw error('INVALID_ARGUMENT', 'Boundary flux faces must be finite inward heat flux densities in W/m².');
  const boundary = input.boundary ?? Object.fromEntries(FACES.filter(k => !Object.hasOwn(flux, k)).map(k => [k, defaults.ambient]));
  if (!boundary || typeof boundary !== 'object' || Array.isArray(boundary) || Object.entries(boundary).some(([k,v]) => !FACES.includes(k) || !Number.isFinite(v) || v < -273.15)) throw error('INVALID_ARGUMENT', 'Boundary faces must be finite temperatures in Celsius; omit insulated faces.');
  if (Object.keys(flux).some(k => Object.hasOwn(boundary, k))) throw error('INVALID_ARGUMENT', 'A face cannot prescribe both temperature and heat flux.');
  const timeStep = input.timeStep;
  if (timeStep !== undefined && (!Number.isFinite(timeStep) || timeStep <= 0)) throw error('INVALID_ARGUMENT', 'timeStep must be positive seconds.');
  if (timeStep === undefined && !Object.keys(boundary).length) throw error('UNANCHORED_DOMAIN', 'An insulated steady domain has no unique temperature. Supply a fixed-temperature face or a transient timeStep.');
  const tolerance = input.tolerance ?? 1e-4, maxIterations = input.maxIterations ?? 20000;
  if (!Number.isFinite(tolerance) || tolerance < 1e-6 || tolerance > .1 || !Number.isInteger(maxIterations) || maxIterations < 1 || maxIterations > 20000) throw error('INVALID_ARGUMENT', 'Invalid numerical convergence limits.');
  const coefficients = new Float64Array(count*8), accounting = new Float64Array(count*4), initial = new Float64Array(count);
  const strides = [1, dimensions[0], dimensions[0]*dimensions[1]];
  let sourcePower = 0, sourceCorrection = 0;
  for (let i=0; i<count; i++) {
    const xyz = [i%dimensions[0], Math.floor(i/dimensions[0])%dimensions[1], Math.floor(i/strides[2])];
    const k = conductivity(i), massRate = timeStep === undefined ? 0 : capacity(i)*volume/timeStep;
    let diagonal = massRate, rhs = source(i)*volume + massRate*temperature(i), boundaryG = 0, boundaryGT = 0;
    const cellPower=source(i)*volume,nextPower=sourcePower+cellPower;
    sourceCorrection+=Math.abs(sourcePower)>=Math.abs(cellPower)?(sourcePower-nextPower)+cellPower:(cellPower-nextPower)+sourcePower;
    sourcePower=nextPower;
    initial[i] = temperature(i);
    for (let axis=0; axis<3; axis++) for (let side=0; side<2; side++) {
      const face = axis*2+side, step = side ? 1 : -1;
      if (xyz[axis]+step >= 0 && xyz[axis]+step < dimensions[axis]) {
        const other = conductivity(i+step*strides[axis]);
        const g = (2/(1/k+1/other))*volume/(cellSize[axis]*cellSize[axis]);
        if (!Number.isFinite(g) || g <= 0) throw error('NUMERICAL_RANGE', 'A face conductance is not representable.');
        coefficients[i*8+face] = g;
        diagonal += g;
      } else if (Object.hasOwn(boundary, FACES[face])) {
        const g = 2*k*volume/(cellSize[axis]*cellSize[axis]);
        if (!Number.isFinite(g) || g <= 0) throw error('NUMERICAL_RANGE', 'A boundary conductance is not representable.');
        diagonal += g;
        rhs += g*boundary[FACES[face]];
        boundaryG += g;
        boundaryGT += g*boundary[FACES[face]];
      } else if (Object.hasOwn(flux, FACES[face])) {
        const power = flux[FACES[face]]*volume/cellSize[axis];
        rhs += power;
        // Positive inward flux contributes negative outward boundary power.
        boundaryGT += power;
      }
    }
    coefficients[i*8+6] = diagonal;
    coefficients[i*8+7] = rhs;
    accounting.set([boundaryG, boundaryGT, massRate, temperature(i)], i*4);
    if (!Number.isFinite(diagonal) || diagonal <= 0 || !Number.isFinite(rhs)) throw error('NUMERICAL_RANGE', 'Grid coefficients exceed the supported numerical range.');
  }
  // Fail before any GPU mutation on overflow/underflow of a nonzero coefficient.
  for (const data of [coefficients, accounting, initial]) for (const value of data) {
    const f = Math.fround(value);
    if (!Number.isFinite(f) || value !== 0 && f === 0) throw error('NUMERICAL_RANGE', 'Grid values are not representable in Float32.');
  }
  sourcePower+=sourceCorrection;
  if (!Number.isFinite(sourcePower)) throw error('NUMERICAL_RANGE', 'Source power overflow.');
  return {dimensions:[...dimensions], cellSize:[...cellSize], count, volume, coefficients, accounting, initial, sourcePower, timeStep:timeStep ?? null, tolerance, maxIterations};
}

export const conductionWGSL = `
struct Config { dimensions:vec4u, groups:vec4u };
struct Cell { a:vec4f, b:vec4f };
@group(0) @binding(0) var<storage,read> cells:array<Cell>;
@group(0) @binding(1) var<storage,read> accounts:array<vec4f>;
@group(0) @binding(2) var<storage,read> sourceT:array<f32>;
@group(0) @binding(3) var<storage,read_write> targetT:array<f32>;
@group(0) @binding(4) var<storage,read_write> partials:array<Cell>;
@group(0) @binding(5) var<storage,read_write> summary:array<vec4f>;
@group(0) @binding(6) var<uniform> cfg:Config;
var<workgroup> valuesA:array<vec4f,64>;
var<workgroup> valuesB:array<vec4f,64>;
fn finite(v:f32)->bool { return (bitcast<u32>(v)&0x7f800000u)!=0x7f800000u; }
fn neighbours(i:u32,c:Cell)->f32 {
  let x=i%cfg.dimensions.x; let y=(i/cfg.dimensions.x)%cfg.dimensions.y;
  let stride=cfg.dimensions.x*cfg.dimensions.y; let z=i/stride; var sum=0.;
  if(x>0u){sum+=c.a.x*sourceT[i-1u];} if(x+1u<cfg.dimensions.x){sum+=c.a.y*sourceT[i+1u];}
  if(y>0u){sum+=c.a.z*sourceT[i-cfg.dimensions.x];} if(y+1u<cfg.dimensions.y){sum+=c.a.w*sourceT[i+cfg.dimensions.x];}
  if(z>0u){sum+=c.b.x*sourceT[i-stride];} if(z+1u<cfg.dimensions.z){sum+=c.b.y*sourceT[i+stride];}
  return sum;
}
@compute @workgroup_size(64) fn iterate(@builtin(global_invocation_id) id:vec3u) {
  let i=id.x; if(i>=cfg.dimensions.w){return;} let c=cells[i];
  targetT[i]=sourceT[i]+(2./3.)*((c.b.w+neighbours(i,c))/c.b.z-sourceT[i]);
}
fn reduce(lane:u32) {
  workgroupBarrier(); var stride=32u;
  loop { if(lane<stride){let a=valuesA[lane];let b=valuesA[lane+stride];valuesA[lane]=vec4f(max(a.x,b.x),min(a.y,b.y),max(a.z,b.z),a.w+b.w);valuesB[lane]+=valuesB[lane+stride];}
    workgroupBarrier(); if(stride==1u){break;} stride/=2u;
  }
}
@compute @workgroup_size(64) fn diagnose(@builtin(global_invocation_id) id:vec3u,@builtin(local_invocation_index) lane:u32,@builtin(workgroup_id) group:vec3u) {
  var a=vec4f(0.,3.402823e38,-3.402823e38,0.);var b=vec4f(0.);let i=id.x;
  if(i<cfg.dimensions.w){let c=cells[i];let t=sourceT[i];let q=accounts[i];let residual=abs(c.b.z*t-neighbours(i,c)-c.b.w)/c.b.z;
    let outflow=q.x*t-q.y;let storage=q.z*(t-q.w);
    if(finite(t)&&finite(residual)&&finite(outflow)&&finite(storage)){a=vec4f(residual,t,t,outflow);b.x=storage;}else{b.y=1.;}
  }
  valuesA[lane]=a;valuesB[lane]=b;reduce(lane);if(lane==0u){partials[group.x]=Cell(valuesA[0],valuesB[0]);}
}
@compute @workgroup_size(64) fn summarize(@builtin(local_invocation_index) lane:u32) {
  var a=vec4f(0.,3.402823e38,-3.402823e38,0.);var b=vec4f(0.);
  for(var i=lane;i<cfg.groups.x;i+=64u){let p=partials[i];a=vec4f(max(a.x,p.a.x),min(a.y,p.a.y),max(a.z,p.a.z),a.w+p.a.w);b+=p.b;}
  valuesA[lane]=a;valuesB[lane]=b;reduce(lane);if(lane==0u){summary[0]=valuesA[0];summary[1]=valuesB[0];}
}
`;

// Push and pop the shared-device scope stack within one synchronous JS turn.
// Never hold an open scope across an await: other plugins use this same device.
async function checkedGPU(device, work) {
  device.pushErrorScope('validation');device.pushErrorScope('out-of-memory');
  let value, failure;
  try {value=work();} catch(e) {failure=e;}
  const memory=device.popErrorScope(),validation=device.popErrorScope();
  const errors=await Promise.all([memory,validation]);
  if(failure)throw failure;
  const gpuError=errors.find(Boolean);if(gpuError)throw error('GPU_ERROR',gpuError.message);
  return value;
}

// Caller owns the result, but never the borrowed shared device.
export async function solveConductionGPU(device, grid, {check=()=>{}} = {}) {
  check();
  const fieldFrame=grid.fieldFrame?copyPhysicalFrame(grid.fieldFrame):null;
  if (!device) throw error('WEBGPU_REQUIRED', 'Thermal requires the existing Frame WebGPU device.');
  const started = performance.now(), resources = new Set();
  let retained = null, peakBytes = 0, allocatedBytes = 0, readbackBytes = 0;
  const make = (label, size, usage) => {
    if (size > device.limits.maxBufferSize || (usage&GPUBufferUsage.STORAGE) && size > device.limits.maxStorageBufferBindingSize) throw error('GPU_LIMIT', 'Thermal allocation exceeds shared-device limits.');
    const buffer = device.createBuffer({label:'Thermal '+label, size, usage}); resources.add(buffer);
    allocatedBytes += size; peakBytes = Math.max(peakBytes, allocatedBytes); return buffer;
  };
  try {
    const module = device.createShaderModule({label:'Thermal finite-volume conduction', code:conductionWGSL});
    const info = await module.getCompilationInfo();
    const errors = info.messages.filter(m => m.type === 'error');
    if (errors.length) throw error('SHADER_COMPILATION', errors.map(m=>m.message).join('; '));
    check();
    const entries = [0,1,2,3,4,5,6].map(binding => ({binding, visibility:GPUShaderStage.COMPUTE, buffer:{type:binding===6?'uniform':binding<3?'read-only-storage':'storage'}}));
    const layout = device.createBindGroupLayout({entries}), pipelineLayout = device.createPipelineLayout({bindGroupLayouts:[layout]});
    const pipelines = {};
    for (const entryPoint of ['iterate','diagnose','summarize']) pipelines[entryPoint] = await device.createComputePipelineAsync({label:'Thermal '+entryPoint, layout:pipelineLayout, compute:{module,entryPoint}});
    check();
    const {temperatures,groups,summary,staging,bindings}=await checkedGPU(device,()=>{
    const storage = GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST|GPUBufferUsage.COPY_SRC;
    const coefficients = make('conductances',grid.count*32,storage), accounts = make('energy accounting',grid.count*16,storage);
    const temperatures = [make('temperature A',grid.count*4,storage),make('temperature B',grid.count*4,storage)];
    const groups = Math.ceil(grid.count/64);
    if (groups > device.limits.maxComputeWorkgroupsPerDimension) throw error('GPU_LIMIT','Grid dispatch exceeds the shared device limit.');
    const partials = make('partial metrics',groups*32,storage), summary = make('metrics',32,storage);
    const uniform = make('configuration',32,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
    const staging = make('metric readback',32,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST);
    device.queue.writeBuffer(coefficients,0,new Float32Array(grid.coefficients));
    device.queue.writeBuffer(accounts,0,new Float32Array(grid.accounting));
    device.queue.writeBuffer(temperatures[0],0,new Float32Array(grid.initial));
    device.queue.writeBuffer(uniform,0,new Uint32Array([...grid.dimensions,grid.count,groups,0,0,0]));
    const bindings = [0,1].map(parity => device.createBindGroup({layout,entries:[coefficients,accounts,temperatures[parity],temperatures[1-parity],partials,summary,uniform].map((buffer,binding)=>({binding,resource:{buffer}}))}));
    return {temperatures,groups,summary,staging,bindings};
    });
    check();
    let parity = 0, iterations = 0, metrics;
    const diagnose = async () => {
      check(); await checkedGPU(device,()=>{const encoder = device.createCommandEncoder({label:'Thermal residual and energy'});
      const pass = encoder.beginComputePass(); pass.setBindGroup(0,bindings[parity]);
      pass.setPipeline(pipelines.diagnose); pass.dispatchWorkgroups(groups);
      pass.setPipeline(pipelines.summarize); pass.dispatchWorkgroups(1); pass.end();
      encoder.copyBufferToBuffer(summary,0,staging,0,32); device.queue.submit([encoder.finish()]);
      });
      await staging.mapAsync(GPUMapMode.READ); let values;
      try { values = new Float32Array(staging.getMappedRange()).slice(); } finally { staging.unmap(); }
      readbackBytes += 32; check();
      if (values[5] > 0 || !Array.from(values).every(Number.isFinite)) throw error('NONFINITE_RESULT','The numerical solve produced a non-finite value.');
      return values;
    };
    metrics = await diagnose();
    while (metrics[0] > grid.tolerance && iterations < grid.maxIterations) {
      check(); await checkedGPU(device,()=>{const encoder = device.createCommandEncoder({label:'Thermal bounded iteration batch'}), pass = encoder.beginComputePass();
      pass.setPipeline(pipelines.iterate);
      const batch = Math.min(64,grid.maxIterations-iterations);
      for (let i=0;i<batch;i++) {pass.setBindGroup(0,bindings[parity]);pass.dispatchWorkgroups(groups);parity=1-parity;}
      pass.end();device.queue.submit([encoder.finish()]);iterations += batch;
      });
      metrics = await diagnose();
      // Yield between bounded submissions so cancel and ordinary editor input can run.
      await new Promise(resolve => setTimeout(resolve,0));
    }
    if (metrics[0] > grid.tolerance) throw error('NOT_CONVERGED','The conduction residual did not reach the requested tolerance.');
    if (metrics[1] < -273.15-.001) throw error('NONPHYSICAL_TEMPERATURE','The prescribed source would drive temperature below absolute zero.');
    check();retained = temperatures[parity];
    const result = {
      dimensions:[...grid.dimensions],cellSize:[...grid.cellSize],count:grid.count,...fieldFrame?{fieldFrame}:{},
      buffer:retained,device,
      metrics:{iterations,residualK:metrics[0],minTemperature:metrics[1],maxTemperature:metrics[2],sourcePowerW:grid.sourcePower,boundaryPowerW:metrics[3],storagePowerW:metrics[4],energyImbalanceW:grid.sourcePower-metrics[3]-metrics[4],timeStep:grid.timeStep,wallMs:performance.now()-started,peakGPUBytes:peakBytes,retainedGPUBytes:grid.count*4,readbackBytes},
      dispose(){this.buffer?.destroy();this.buffer=null;this.metrics.retainedGPUBytes=0;},
      async inspect(offset=0,count=1){
        if (!this.buffer) throw error('RETIRED_RESULT','The thermal field was retired.');
        if (!Number.isInteger(offset)||offset<0||!Number.isInteger(count)||count<1||count>256||offset+count>this.count) throw error('INVALID_ARGUMENT','Inspect at most 256 existing cells.');
        const source = this.buffer;let staging;
        try {await checkedGPU(device,()=>{staging=device.createBuffer({label:'Thermal bounded temperature inspection',size:count*4,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});const encoder=device.createCommandEncoder();encoder.copyBufferToBuffer(source,offset*4,staging,0,count*4);device.queue.submit([encoder.finish()]);});await staging.mapAsync(GPUMapMode.READ);
          const temperatures=Array.from(new Float32Array(staging.getMappedRange()));staging.unmap();
          if(this.buffer!==source)throw error('RETIRED_RESULT','The thermal field was retired during inspection.');
          this.metrics.readbackBytes+=count*4;return {offset,temperatures};
        } finally {staging?.destroy();}
      }
    };
    return result;
  } finally {
    for (const buffer of resources) if (buffer !== retained) buffer.destroy();
  }
}

export async function activate(context) {
  if (context.version !== 1) throw error('API_VERSION','Unsupported Frame plugin API.');
  const jobs = new Map(), readings = new Map(), geometryControllers = new Map(), pending = new Set(), workTails = new Map(), D = context.document;
  let serial = 0;
  const owner = hash => {const n=D.nodes.find(n=>n.nativeHash===hash&&n.type==='thermal');if(!n)throw error('INVALID_OWNER','Thermal object no longer exists.');return n;};
  const signature = hash => {const n=owner(hash);return JSON.stringify([n.params,n.enabled,Array.from(D.world(hash))]);};
  const current = job => {
    if(job.failure)throw error(job.failure.code,job.failure.message);
    if(job.deviceState.lost)throw error('DEVICE_LOST','Shared WebGPU device was lost.');
    if(jobs.get(job.hash)!==job||context.device!==job.device||owner(job.hash)!==job.owner||signature(job.hash)!==job.signature)throw error('STALE_JOB','Thermal inputs or shared device changed.');
    if(job.source&&!sceneIdentityMatches(context,job.hash,job.source.signature,job.source.transformStamp))throw error('STALE_JOB','Scene geometry or Thermal tags changed.');
  };
  const stop = (job,reason={code:'CANCELLED',message:'Thermal job cancelled.'}) => {
    if(!job)return;job.failure??=reason;job.controller.abort();
  };
  const release = job => {job.result?.dispose();job.result=null;};
  const stale = (job,e) => {stop(job,{code:e.code||'STALE_JOB',message:e.message});release(job);if(job.state!=='running')job.state='stale';};
  const status = hash => {
    owner(hash);const job=jobs.get(hash);
    if(job?.state==='ready'){try{current(job);}catch(e){stale(job,e);}}
    const scene=job?.kind==='scene';
    const value={stage:scene?'two-cuboid-conjugate-duration':'conduction-foundation',sceneSolver:false,generalSceneSolver:false,geometryCoupled:scene,authoring:scene?'explicit-request':null,state:job?.state||'idle',job:job?.id||null,error:job?.error||job?.failure||null};
    if(job?.result){try{
      Object.assign(value,{dimensions:job.result.dimensions,cellSize:job.result.cellSize,...job.result.metrics});
      if(scene){const d=job.result.diagnostics;Object.assign(value,{boundary:'adiabatic',initialVelocity:'rest',duration:d.duration,pressureRise:d.pressureRise,correctedFlow:d.correctedFlow});}
    }catch(e){stale(job,e);return status(hash);}}
    return value;
  };
  const retire = hash => {geometryControllers.get(hash)?.abort();const job=jobs.get(hash);if(!job)return;stop(job);release(job);jobs.delete(hash);context.requestAttributes();context.requestDraw();};
  const invalidate = () => {
    for(const controller of geometryControllers.values())controller.abort();
    for(const [hash,job]of jobs){if(D.nodes.find(n=>n.nativeHash===hash&&n.type==='thermal')!==job.owner){retire(hash);continue;}if(job.state!=='running'&&job.state!=='ready')continue;try{current(job);}catch(e){stale(job,e);}}
    for(const hash of readings.keys())reading(hash);
  };
  // One owner/job path for explicit conduction and the restricted scene chain.
  // Retiring work drains before a replacement allocates; no overlapping owner
  // GPU jobs, retained history, continuation state or second document model.
  const start = (hash,kind,solve,source=null) => {
    const n=owner(hash);if(n.enabled===false)throw error('DISABLED','Enable Thermal before solving.');
    let previous=workTails.get(hash);retire(hash);
    const job={id:++serial,hash,kind,owner:n,signature:signature(hash),source,device:context.device,deviceState:sharedThermalDeviceState(context.device),controller:new AbortController(),state:'running',failure:null,result:null,error:null};jobs.set(hash,job);
    job.work=(async()=>{let result;
      try{
        await previous;previous=null;current(job);
        result=await solve(job);current(job);
        job.result=result;result=null;job.state='ready';
      }catch(e){result?.dispose();const reason=job.failure||e;job.error={code:reason.code||'SOLVE_FAILED',message:reason.message};job.state=reason.code==='CANCELLED'?'cancelled':['STALE_JOB','STALE_CLASSIFICATION','INVALID_OWNER','RETIRED_RESULT'].includes(reason.code)?'stale':'failed';}
      finally{context.requestAttributes();context.requestDraw();}
    })();
    workTails.set(hash,job.work);pending.add(job.work);job.work.then(()=>{pending.delete(job.work);if(workTails.get(hash)===job.work)workTails.delete(hash);});context.requestAttributes();
    return status(hash);
  };
  const stopRunning = hash => {geometryControllers.get(hash)?.abort();const job=jobs.get(hash);if(job?.state==='running')stop(job);return {work:workTails.get(hash)};};
  const preflightGrid = (hash,args) => {const n=owner(hash);if(n.enabled===false)throw error('DISABLED','Enable Thermal before solving.');return assembleConduction(args,{ambient:n.params.Ambient,initial:n.params.Initial});};
  const preflightScene = (hash,args) => {const n=owner(hash);if(n.enabled===false)throw error('DISABLED','Enable Thermal before solving.');return snapshotNativeSceneRequest(args,n.params.Initial);};
  // The job never retains native source buffers through a capture closure.
  const sceneStamp = hash => {const snapshot=context.scene.capture(hash,[],THERMAL_TAGS);return {signature:snapshot.signature,transformStamp:exactOccurrenceStamp(snapshot)};};
  const probe = hash => {const n=D.nodes.find(n=>n.nativeHash===hash&&n.type==='thermal_probe');if(!n)throw error('INVALID_OWNER','Probe object no longer exists.');return n;};
  const probeStamp = n => JSON.stringify([n.params,n.enabled,Array.from(D.world(n.nativeHash))]);
  const reading = hash => {const saved=readings.get(hash);if(!saved)return null;try{current(saved.job);const n=probe(hash);if(saved.job.state!=='ready'||saved.job.result!==saved.result||n!==saved.probe||saved.stamp!==probeStamp(n)){readings.delete(hash);return null;}return saved.value;}catch{readings.delete(hash);return null;}};
  context.operations.register([
    {id:'create-fan',description:'Create a separate native Fan box as a Thermal child with an explicit owner reference. Authoring only: the explicit-request numerical solver does not consume this Fan.',inputSchema:emptySchema,readOnly:false,async run(hash){
      owner(hash);let n;D.transaction(()=>{n=D.create('thermal_fan',hash,'Fan');n.params.Thermal=hash;D.select(n.nativeHash,'objects');});await context.editor.selectOwner(n.nativeHash);return {hash:n.nativeHash,type:n.type,authoringOnly:true};
    }},
    {id:'fan-inputs',description:'Inspect a native Fan or the unique directly enabled Fan referencing this Thermal. Reports authored local-X/world direction and exact supported frame mapping separately from selection; never certifies containment, alignment, ancestor enabled state or solver eligibility. No geometry capture or GPU work.',inputSchema:emptySchema,readOnly:true,run:hash=>inspectNativeFans(context,hash)},
    {id:'inspect-geometry',description:'Validate the aggregate scene polygon boundary using shared volume preparation and release it. Does not classify materials, convert physical volume, or solve heat.',inputSchema:emptySchema,readOnly:true,interrupt(hash){geometryControllers.get(hash)?.abort();},async run(hash){owner(hash);geometryControllers.get(hash)?.abort();const controller=new AbortController();geometryControllers.set(hash,controller);try{return await inspectGeometry(context,hash,{signal:controller.signal});}finally{if(geometryControllers.get(hash)===controller)geometryControllers.delete(hash);}}},
    {id:'scene-inputs',description:'Inspect bounded effective Thermal Material/Heater authoring on captured scene occurrences. No geometry classification, power normalization or scene simulation is performed.',inputSchema:objectSchema({offset:{type:'integer',minimum:0},count:{type:'integer',minimum:1,maximum:256}}),readOnly:true,run(hash,args){
      owner(hash);const start=performance.now(),snapshot=context.scene.capture(hash,[],THERMAL_TAGS),captureMs=performance.now()-start;
      return {...inspectSceneInputs(snapshot,args),metrics:{captureMs,wallMs:performance.now()-start},captureScope:'whole-scene'};
    }},
    {id:'create-probe',description:'Create a native Probe at the Thermal origin, referencing exactly this owner and its current converged numerical job.',inputSchema:emptySchema,readOnly:false,async run(hash){
      owner(hash);let n;D.transaction(()=>{n=D.create('thermal_probe',hash,'Probe');n.params.Thermal=hash;D.select(n.nativeHash,'objects');});await context.editor.selectOwner(n.nativeHash);return {hash:n.nativeHash,type:n.type};
    }},
    {id:'measure',description:'Measure this Probe owner’s exact current converged job. Explicit grids use cell-centre interpolation; restricted scene fields retain physical scale and resistance-aware contact. Exterior points reject; at most eight cells are read.',inputSchema:emptySchema,readOnly:true,async run(hash){
      const n=probe(hash);if(n.enabled===false)throw error('DISABLED','Enable Probe before measuring.');
      const source=owner(n.params.Thermal),job=jobs.get(source.nativeHash);if(job?.state!=='ready'||!job.result)throw error('NO_RESULT','No current converged thermal field.');
      const stamp=probeStamp(n),world=D.world(hash),ownerWorld=D.world(source.nativeHash),inverse=context.math.inv(ownerWorld);
      const check=()=>{current(job);if(probe(hash)!==n||probeStamp(n)!==stamp)throw error('STALE_PROBE','Probe changed while measuring.');};
      readings.delete(hash);context.requestAttributes();const value=job.kind==='scene'?await job.result.measureProbe(hash):await sampleProbe(job.result,inverse,[world[12],world[13],world[14]],check,ownerWorld);check();
      readings.set(hash,{job,result:job.result,probe:n,stamp,value});context.requestAttributes();return value;
    }},
    {id:'solve-grid',description:'Experimental numerical API: solve explicit SI conduction cells, not scene geometry. Fields contain one value or one per x-fastest cell. Boundary face temperatures are Celsius; omitted faces are insulated. A timeStep performs one backward-Euler step.',inputSchema:gridSchema,readOnly:false,
      interrupt(hash,args){preflightGrid(hash,args);return stopRunning(hash);},
      run(hash,args){const grid=preflightGrid(hash,args);return start(hash,'grid',job=>solveConductionGPU(job.device,grid,{check:()=>current(job)}));}
    },
    {id:'solve-scene',description:'Isolated candidate only: explicit 1..10-step, <=0.1 s from-rest adiabatic two-cuboid conjugate solve. Requires two complete buffer-backed twelve-triangle cuboids, full local-X contact, explicit left fluid occurrence and grid-aligned partial local-X fan sheet. Saved Fan objects are not consumed. No native domain solve, general geometry, steady cooling, sections or CPU fallback.',inputSchema:nativeSceneSchema,readOnly:false,
      interrupt(hash,args){preflightScene(hash,args);return stopRunning(hash);},
      run(hash,args){const request=preflightScene(hash,args),source=sceneStamp(hash);
        return start(hash,'scene',job=>advanceTouchingSceneConjugateGPU(context,hash,{...request,signal:job.controller.signal}),source);
      }
    },
    {id:'status',description:'Read the owner job state and bounded diagnostics. geometryCoupled distinguishes the restricted two-cuboid candidate from explicit-grid conduction. sceneSolver/generalSceneSolver stay false: there is no general scene solver or saved domain/Fan solve.',inputSchema:emptySchema,readOnly:true,run:status},
    {id:'inspect',description:'Read at most 256 cell-centre temperatures from a current converged field. Flattening is x + nx * (y + ny * z).',inputSchema:objectSchema({offset:{type:'integer',minimum:0},count:{type:'integer',minimum:1,maximum:256}}),readOnly:true,async run(hash,args){
      const job=jobs.get(hash);if(!job?.result||job.state!=='ready')throw error('NO_RESULT','No current converged thermal field.');current(job);
      const values=await job.result.inspect(args.offset??0,args.count??1);current(job);return values;
    }},
    {id:'inspect-velocity',description:'Read at most 256 MAC-face velocities from the current restricted scene field. Components are u/v/w along physical orthonormal owner axes, in m/s. Not available for explicit conduction grids.',inputSchema:{...objectSchema({component:{type:'string',enum:['u','v','w']},offset:{type:'integer',minimum:0},count:{type:'integer',minimum:1,maximum:256}}),required:['component']},readOnly:true,async run(hash,args){
      const job=jobs.get(hash);if(job?.kind!=='scene'||job.state!=='ready'||!job.result)throw error('NO_RESULT','No current restricted scene velocity field.');current(job);
      const values=await job.result.inspectVelocity(args.component,args.offset??0,args.count??1);current(job);return values;
    }},
    {id:'cancel',description:'Stop scheduling this numerical job and drain its work without publishing a partial field. The synchronous validated interrupt runs before the native API queue barrier.',inputSchema:emptySchema,readOnly:false,interrupt:stopRunning,async run(hash,_args,interruption){owner(hash);const job=jobs.get(hash);if(job?.state==='running')stop(job);await Promise.all([interruption?.work,workTails.get(hash)]);return status(hash);}},
    {id:'clear',description:'Release this numerical field and drain retired work. Native authoring remains unchanged.',inputSchema:emptySchema,readOnly:false,interrupt:stopRunning,async run(hash,_args,interruption){owner(hash);const work=workTails.get(hash);retire(hash);await Promise.all([interruption?.work,work]);return status(hash);}}

  ]);
  context.editor.register({
    documentChanged:invalidate,restored:invalidate,
    created:n=>{if(n.type==='thermal_probe'){const frame=context.math.I();frame[0]=frame[5]=frame[10]=.02;n.creationFrame=Array.from(context.math.pack(frame));}if(n.type==='thermal_fan'){const frame=context.math.I();frame[0]=frame[5]=frame[10]=.25;frame.set([-25,-12.5,-12.5],12);n.creationFrame=Array.from(context.math.pack(frame));}},
    parameters:(n,changes)=>{if(n.type==='thermal_fan'){validateFanParameters(D,{...n.params,...changes});return {};}if(n.type==='thermal_probe'){const value=changes.Thermal??n.params.Thermal;if(typeof value!=='string'||value&&!D.nodes.some(q=>q.nativeHash===value&&q.type==='thermal'))throw error('INVALID_ARGUMENT','Select a Thermal object.');return {};}if(n.type!=='thermal')return null;for(const value of Object.values({...n.params,...changes}))if(!Number.isFinite(value)||value < -273.15)throw error('INVALID_ARGUMENT','Temperature must be at least absolute zero.');return {};},
    rowColor:n=>n.type==='thermal'&&jobs.get(n.nativeHash)?.state==='failed'?'#ee554b':null,
    // Generic API settle/selection must stay responsive. Explicit authoring,
    // output and render barriers drain active AND retired work. Simulation
    // flushes never advance Thermal time or implicitly start a solve.
    flush:async(options={})=>{if(options.author||options.output||options.render)await Promise.all([...pending]);}
  });
  context.attributes.register(hash=>{
    const n=D.nodes.find(n=>n.nativeHash===hash);
    if(n?.type==='thermal_probe'){const value=reading(hash);return {actions:[{id:'measure',label:value?value.temperature.toFixed(2)+' °C':'Measure'}]};}
    if(n?.type==='thermal_fan')return {units:{'Shutoff pressure':'Pa','Free flow':'m³/s'},ranges:{'Shutoff pressure':{min:0},'Free flow':{min:Number.MIN_VALUE}},actions:[]};
    const job=jobs.get(hash);return {units:{Ambient:'°C',Initial:'°C'},actions:[{id:'create-fan',label:'Fan'},{id:'create-probe',label:'Probe'},{id:'clear',label:'Clear',busy:job?.state==='running',cancel:'cancel',disabled:!job}]};
  });
  const lines=[];for(let axis=0;axis<3;axis++)for(let a=0;a<2;a++)for(let b=0;b<2;b++){const p=[-50,-50,-50],q=[-50,-50,-50];p[(axis+1)%3]=q[(axis+1)%3]=a?50:-50;p[(axis+2)%3]=q[(axis+2)%3]=b?50:-50;q[axis]=50;lines.push(...p,...q);}
  await context.viewport.register({bounds:{min:[-50,-50,-50],max:[50,50,50]},lines:new Float32Array(lines),color:[.86,.61,.46,1],selectedColor:[1,.75,.5,1],settings:()=>[0,0,0,0],shader:'fn pluginSurface(local:vec3f, normal:vec3f, build:vec3f, settings:vec4f)->vec4f { discard; return vec4f(0.0); }',retire});
}
