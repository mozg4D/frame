import {launch,ready} from '../../../tools/browser.mjs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pluginChecks} from './index.mjs';

let session,result;
try {
  session=await launch({headless:process.argv.includes('--headless')});
  // Allow isolated development without editing the shared catalogue.
  const catalogue=JSON.parse(await readFile(new URL('../../index.json',import.meta.url),'utf8'));
  if(!catalogue.includes('thermal/plugin.json')){
    catalogue.push('thermal/plugin.json');
    await session.page.route('**/plugins/index.json',route=>route.fulfill({contentType:'application/json',body:JSON.stringify(catalogue)}));
    await session.page.reload();
  }
  await ready(session.page);
  const errors=[];session.page.on('pageerror',e=>errors.push(e.stack));
  await session.page.evaluate(()=>{window.__thermalGPU=[];window.__thermalLost=null;const d=frameEngine.renderer.device;d.addEventListener('uncapturederror',e=>__thermalGPU.push(e.error.message));d.lost.then(e=>__thermalLost={reason:e.reason,message:e.message});d.pushErrorScope('validation');});
  result=await pluginChecks(session.page);
  result.gpu=await session.page.evaluate(async()=>({validation:(await frameEngine.renderer.device.popErrorScope())?.message||null,uncaptured:__thermalGPU,lost:__thermalLost}));
  result.errors=errors;result.pass&&=!errors.length&&!result.gpu.validation&&!result.gpu.uncaptured.length&&!result.gpu.lost;
} catch(e) {result={pass:false,checks:[],timings:[],error:e.stack,hardwareVerified:false};}
finally {await session?.close();}
result.sources={};for(const path of ['index.html','plugins/thermal/tests/native-selection.mjs','plugins/thermal/tests/native-probe-browser.mjs','plugins/thermal/tests/native-probe.mjs','plugins/thermal/tests/native-creation-fixture.mjs','plugins/thermal/tests/numerics.mjs','plugins/thermal/plugin.json','plugins/thermal/native-fan.js','plugins/thermal/tests/native-fan.mjs','plugins/thermal/tests/native-fan-browser.mjs','plugins/thermal/native-scene-request.js','plugins/thermal/tests/native-job-browser.mjs','plugins/thermal/tests/native-job.mjs','plugins/thermal/tests/native-job-fixture.mjs','plugins/thermal/tests/run.mjs','plugins/thermal/tests/index.mjs','plugins/thermal/scene-conjugate-duration.js','plugins/thermal/tests/duration-browser-fixtures.mjs','plugins/thermal/plugin.js','plugins/thermal/scene-conjugate.js','plugins/thermal/tests/scene-conjugate-browser.mjs','plugins/thermal/tests/scene-conjugate-fixture.mjs','plugins/thermal/probe.js','plugins/thermal/scene-inputs.js','plugins/thermal/geometry.js','plugins/thermal/scene-grid.js','plugins/thermal/box-classifier.js','plugins/thermal/scene-pipeline.js','plugins/thermal/touching-classifier.js','plugins/thermal/scene-identity.js','plugins/thermal/layered-heat-gpu.js','plugins/thermal/mac-projection-gpu.js','plugins/thermal/conjugate-heat-gpu.js','plugins/thermal/tests/conjugate-heat-gpu-checks.mjs','plugins/thermal/fluid-heat-gpu.js','plugins/thermal/forced-heat-gpu.js','plugins/thermal/tests/forced-heat-gpu-checks.mjs','plugins/thermal/forced-temperature-gpu.js','plugins/thermal/tests/forced-temperature-gpu-checks.mjs','plugins/thermal/project-temperature-gpu.js','plugins/thermal/tests/project-temperature-gpu-checks.mjs','plugins/thermal/temperature-advection-gpu.js','plugins/thermal/tests/temperature-advection-gpu-checks.mjs','plugins/thermal/mac-fan-gpu.js','plugins/thermal/tests/mac-fan-gpu-checks.mjs','plugins/thermal/mac-viscosity-gpu.js','plugins/thermal/tests/mac-viscosity-gpu-checks.mjs','plugins/thermal/tests/mac-projection-gpu-checks.mjs','plugins/thermal/tests/layered-gpu-checks.mjs','plugins/thermal/plugin.json','plugins/thermal/icon.svg'])result.sources[path]=createHash('sha256').update(await readFile(new URL('../../../'+path,import.meta.url))).digest('hex');
await mkdir(new URL('../../../tests/results/',import.meta.url),{recursive:true});
await writeFile(new URL('../../../tests/results/thermal.json',import.meta.url),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;
