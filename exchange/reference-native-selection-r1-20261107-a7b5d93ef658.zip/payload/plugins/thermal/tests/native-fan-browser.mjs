import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {launch,ready} from '../../../tools/browser.mjs';
import {boundaries,request,classified} from './scene-conjugate-fixture.mjs';
import {sceneConjugateInputs} from '../scene-conjugate.js';
import {stepFanConjugate} from './fan-conjugate-reference.mjs';
import {fixtureFluidOccurrence} from './native-fluid-fixture.mjs';

// Real frameAI / native editor / shared hardware only, in a fresh context.
// Do not point this harness at the user's live scene. No numerical substitution.
// Ordinary copy's reference assertion deliberately fails until core remaps its
// declared plugin reference fields. It must not be relaxed to match old refs.
export async function nativeFanBrowserChecks(parent,check,timed){
 const context=await parent.context().browser().newContext({viewport:{width:1280,height:900},serviceWorkers:'block'}),page=await context.newPage(),errors=[];
 page.on('pageerror',e=>errors.push(e.stack));
 try{
  const catalogue=JSON.parse(await readFile(new URL('../../index.json',import.meta.url),'utf8'));if(!catalogue.includes('thermal/plugin.json'))catalogue.push('thermal/plugin.json');
  await page.route('**/plugins/index.json',r=>r.fulfill({json:catalogue}));
  // Observation only: retain the real document context to compare JS identities.
  // No editor/GPU hooks, result substitutions or changes to shipped module bytes.
  const module=await readFile(new URL('../plugin.js',import.meta.url),'utf8'),activation='export async function activate(context) {';
  if(module.split(activation).length!==2)throw Error('Native Fan activation observer marker changed');
  await page.route('**/plugins/thermal/plugin.js',r=>r.fulfill({contentType:'text/javascript',body:module.replace(activation,activation+'\nwindow.__fanNativeContext=context;')}));
  await page.goto(parent.url());await ready(page);
  const call=(name,args={})=>page.evaluate(([n,a])=>frameAI.call(n,a),[name,args]),inspect=async()=> (await call('scene.inspect')).objects;
  const hardware=await page.evaluate(()=>{const d=frameEngine.renderer.device;window.__fanGPU=[];window.__fanLost=null;d.addEventListener('uncapturederror',e=>__fanGPU.push(e.error.message));d.lost.then(e=>__fanLost={reason:e.reason,message:e.message});return d.adapterInfo?Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(k=>[k,d.adapterInfo[k]])):null;});
  check('Fan harness uses identifiable hardware WebGPU',hardware&&Object.values(hardware).some(v=>typeof v==='string'&&v)&&!hardware.isFallbackAdapter&&!/swiftshader|llvmpipe|lavapipe|software/i.test(JSON.stringify(hardware)),hardware);
  const old=await inspect();if(old.length)await call('scene.delete',{ids:old.filter(n=>!n.parent).map(n=>n.hash)});
  const owner=await timed('Fan native owner creation',10000,()=>call('plugins.create',{plugin:'thermal'})),cmd=(operation,args={},id=owner.hash)=>call('plugins.command',{id,operation,args});
  const schema=await call('plugins.describe',{plugin:'thermal'});check('Fan authoring operations have strict discoverable schemas',schema.operations.some(o=>o.id==='create-fan'&&!o.readOnly&&o.inputSchema.additionalProperties===false)&&schema.operations.some(o=>o.id==='fan-inputs'&&o.readOnly),schema.operations);
  const beforeFrames=await call('diagnostics.frame',{frames:6});
  await page.locator('#tabAttributes').click();
  await timed('native Fan Attributes button',10000,async()=>{await page.locator('#attrContent [data-plugin-action-button="create-fan"]').click();await call('scene.inspect');});
  let fan=(await inspect()).find(n=>n.type==='thermal_fan');
  check('native Fan action authors selected child and explicit reference',fan?.parent===owner.hash&&fan.params.Thermal===owner.hash&&fan.selected,fan);
  check('Fan has ordinary SI fields, no Solve or hidden dimensions',JSON.stringify(Object.keys(fan.params).sort())===JSON.stringify(['Direction','Free flow','Shutoff pressure','Thermal'].sort())&&await page.locator('#attrContent [data-plugin-action-button="solve-scene"]').count()===0,fan.params);
  const fanHash=fan.hash,read=()=>cmd('fan-inputs',{},fanHash),initial=await read();
  check('default native box has exact 25 mm size and signed local-X metadata',JSON.stringify(initial.fan.mapping.sizeMM)==='[25,25,25]'&&JSON.stringify(initial.fan.mapping.centerMM)==='[-25,-12.5,-12.5]'&&JSON.stringify(initial.fan.directionLocal)==='[1,0,0]'&&!initial.solverEligible&&!initial.solverCoupled,initial);
  await call('view.set',{coordinates:'object',focus:fanHash});
  check('native helper has selectable box edges',await page.locator(`.frame-plugin-hit[data-hash="${fanHash}"]`).count()>0&&!!await page.locator(`.frame-plugin-hit[data-hash="${fanHash}"]`).first().getAttribute('d'));
  // Do not reselect the Fan before this edit: creation must return with actual
  // engine selection synchronized, not merely its object-tree row highlighted.
  const actionOwner=(await inspect()).find(n=>n.hash===owner.hash),actionFan=(await inspect()).find(n=>n.hash===fanHash);
  await timed('immediate Fan Attributes translation',1500,()=>call('transform.set',{channel:'position',axis:0,value:-20,coordinates:'world'}));
  const immediate=(await inspect()).find(n=>n.hash===fanHash),unchangedOwner=(await inspect()).find(n=>n.hash===owner.hash),movedFrame=[...actionFan.matrix];movedFrame[9]=-20;
  check('Fan Attributes action immediately targets child native local/world frame, never owner',JSON.stringify(immediate.matrix)===JSON.stringify(movedFrame)&&JSON.stringify(immediate.worldMatrix.slice(12,15))==='[-20,-12.5,-12.5]'&&JSON.stringify(immediate.bounds.min)==='[-32.5,-25,-25]'&&JSON.stringify(immediate.bounds.max)==='[-7.5,0,0]'&&JSON.stringify(unchangedOwner.matrix)===JSON.stringify(actionOwner.matrix)&&JSON.stringify(unchangedOwner.worldMatrix)===JSON.stringify(actionOwner.worldMatrix),{fan:immediate,ownerBefore:actionOwner,ownerAfter:unchangedOwner});
  await call('edit.history',{action:'undo'});check('immediate Fan translation Undo restores exact native default',JSON.stringify((await inspect()).find(n=>n.hash===fanHash).matrix)===JSON.stringify(actionFan.matrix));
  await call('edit.history',{action:'redo'});check('immediate Fan translation Redo restores child frame only',JSON.stringify((await inspect()).find(n=>n.hash===fanHash).matrix)===JSON.stringify(movedFrame)&&JSON.stringify((await inspect()).find(n=>n.hash===owner.hash).worldMatrix)===JSON.stringify(actionOwner.worldMatrix));
  await call('edit.history',{action:'undo'});
  const beforeInvalid=JSON.stringify((await inspect()).find(n=>n.hash===fanHash));
  for(const params of [{'Shutoff pressure':-1},{'Free flow':0},{Direction:'invalid'},{Thermal:fanHash},{Thermal:'missing'}]){
   const rejected=await call('scene.update',{id:fanHash,params}).then(()=>false,()=>true);
   check('invalid native Fan parameter preserves complete record',rejected&&JSON.stringify((await inspect()).find(n=>n.hash===fanHash))===beforeInvalid,params);
  }
  await timed('native Fan parameter transaction',1500,()=>call('scene.update',{id:fanHash,params:{Direction:'Reverse','Shutoff pressure':2,'Free flow':.2}}));
  check('Reverse is exact negative local X',JSON.stringify((await read()).fan.directionLocal)==='[-1,0,0]');
  await call('edit.history',{action:'undo'});check('parameter Undo restores forward/off authored values',(await read()).fan.authored.params.Direction==='Forward'&&(await read()).fan.authored.params['Shutoff pressure']===0);
  await call('edit.history',{action:'redo'});check('parameter Redo restores curve and direction',(await read()).fan.authored.params.Direction==='Reverse'&&(await read()).fan.authored.params['Free flow']===.2);

  // Rotation remains ordinary authoring. The mapper is strict, not a UI clamp.
  await call('scene.select',{ids:[fanHash]});await timed('native Fan rotation',1500,()=>call('transform.set',{channel:'rotation',axis:2,value:30,coordinates:'object'}));
  let mapped=await read();check('native rotated Fan remains authored with unit world direction but unsupported physical mapping',mapped.fan.mapping.status==='unsupported-frame'&&Math.abs(Math.hypot(...mapped.fan.normalizedWorldAxis)-1)<1e-12,mapped);
  await call('edit.history',{action:'undo'});check('transform Undo restores exact mapping',(await read()).fan.mapping.status==='supported-frame');
  await call('scene.select',{ids:[owner.hash]});await call('transform.set',{channel:'rotation',axis:2,value:31,coordinates:'object'});mapped=await read();
  check('common owner rotation preserves exact native-local mapping',mapped.fan.mapping.status==='supported-frame'&&Math.abs(mapped.fan.normalizedWorldAxis[1])>.1,mapped);
  await call('edit.history',{action:'undo'});
  const other=await call('plugins.create',{plugin:'thermal'});await call('scene.update',{id:fanHash,parent:other.hash});mapped=await read();
  check('reparenting does not silently reassign explicit owner',mapped.ownerHash===owner.hash&&mapped.fan.mapping.status==='unsupported-frame',mapped);
  await call('edit.history',{action:'undo'});await call('scene.update',{id:fanHash,params:{Thermal:other.hash}});mapped=await read();check('reference change is independent from hierarchy',mapped.ownerHash===other.hash&&mapped.fan.mapping.status==='unsupported-frame',mapped);
  await call('edit.history',{action:'undo'});await call('scene.delete',{ids:[other.hash]});
  const beforeSecond=(await inspect()).map(n=>({hash:n.hash,matrix:n.matrix,worldMatrix:n.worldMatrix}));
  const second=await timed('queued Fan API create and immediate transform',11500,()=>page.evaluate(async owner=>{
   const start=performance.now();let selectedAt;
   const created=frameAI.call('plugins.command',{id:owner,operation:'create-fan',args:{}}).then(fan=>{selectedAt=performance.now();return fan;}),moved=frameAI.call('transform.set',{channel:'position',axis:1,value:2,coordinates:'world'}).then(()=>performance.now());
   const [fan,finished]=await Promise.all([created,moved]);return {...fan,creationMs:selectedAt-start,transformMs:finished-selectedAt};
  },owner.hash));
  check('queued Fan creation and transform retain individual latency budgets',second.creationMs<10000&&second.transformMs>=0&&second.transformMs<1500,second);
  const afterSecond=await inspect(),secondFan=afterSecond.find(n=>n.hash===second.hash),secondFrame=[.25,0,0,0,.25,0,0,0,.25,-25,2,-12.5];
  check('queued Fan API creation targets only its new child without selection repair',secondFan?.selected&&JSON.stringify(secondFan.matrix)===JSON.stringify(secondFrame)&&JSON.stringify(secondFan.worldMatrix.slice(12,15))==='[-25,2,-12.5]'&&JSON.stringify(secondFan.bounds.min)==='[-37.5,-10.5,-25]'&&JSON.stringify(secondFan.bounds.max)==='[-12.5,14.5,0]'&&beforeSecond.every(old=>{const now=afterSecond.find(n=>n.hash===old.hash);return JSON.stringify(now?.matrix)===JSON.stringify(old.matrix)&&JSON.stringify(now?.worldMatrix)===JSON.stringify(old.worldMatrix);}),{before:beforeSecond,after:afterSecond});
  await call('edit.history',{action:'undo'});check('API Fan translation Undo restores default frame',JSON.stringify((await inspect()).find(n=>n.hash===second.hash).matrix)==='[0.25,0,0,0,0.25,0,0,0,0.25,-25,-12.5,-12.5]');
  await call('edit.history',{action:'undo'});check('Fan creation has one Undo checkpoint and selection adds none',!(await inspect()).some(n=>n.hash===second.hash));
  await call('edit.history',{action:'redo'});check('Fan creation Redo restores native child and explicit reference',(await inspect()).some(n=>n.hash===second.hash&&n.parent===owner.hash&&n.params.Thermal===owner.hash));
  check('multiple enabled Fans cannot be silently chosen',(await cmd('fan-inputs')).selection.status==='multiple');
  await call('scene.update',{id:second.hash,enabled:false});check('direct disabled Fan is excluded from unique record selection',(await cmd('fan-inputs')).selection.status==='unique');
  await call('scene.update',{id:fanHash,visible:false});check('visibility is presentation only, not implicit ownership/physics',(await cmd('fan-inputs')).selection.status==='unique');
  await call('scene.update',{id:owner.hash,enabled:false});mapped=await read();check('disabled owner/ancestors do not acquire an unsupported physics claim',mapped.fan.ownerResolution.enabled===false&&mapped.selection.ancestorEnabledState==='not-qualified'&&!mapped.solverEligible,mapped);
  await call('scene.update',{id:owner.hash,enabled:true});await call('scene.update',{id:fanHash,visible:true});await call('scene.delete',{ids:[second.hash]});

  // The helpers are not captured surfaces. Native tags remain authoritative on
  // actual geometry and existing explicit scene requests remain unchanged.
  const meshes=[];for(const [i,b]of boundaries().entries()){
   const mesh=await call('mesh.create',{vertices:Array.from(b.positions),indices:Array.from(b.indices),storage:'auto'});meshes.push(mesh.hash);
   await call('tag.set',{ids:[mesh.hash],kind:'thermal_material',enabled:true,params:{Conductivity:i?8:2,'Heat capacity':i?21:10}});
  }
  await call('tag.set',{ids:[meshes[1]],kind:'thermal_heater',enabled:true,params:{Power:75}});
  const source=await cmd('scene-inputs');check('Fan/domain helpers are never source solid occurrences',source.totalOccurrences===2&&source.occurrences.every(o=>meshes.includes(o.hash)),source);
  const argsFor=capture=>{const args={...request(),stepCount:1,cumulativeDivergenceDriftBudgetK:.001};args.settings.fluidOccurrence=fixtureFluidOccurrence(capture,meshes[0]);return args;};
  const args=argsFor(source);
  const finish=async()=>{const until=performance.now()+15000;while(performance.now()<until){const s=await cmd('status');if(s.state!=='running')return s;await new Promise(r=>setTimeout(r,10));}throw Error('Native scene completion exceeded 15 s');};
  await cmd('solve-scene',args);const solved=await timed('explicit-request solve with authoring Fan',15000,finish);check('existing explicit request owns its numerical field',solved.state==='ready'&&solved.authoring==='explicit-request',solved);
  const baseline=(await cmd('inspect',{count:24})).temperatures,baselineU=(await cmd('inspect-velocity',{component:'u',count:30})).values;
  check('explicit-request baseline contains all 24 finite temperatures and 30 u faces',baseline.length===24&&baseline.every(Number.isFinite)&&baselineU.length===30&&baselineU.every(Number.isFinite),{temperatures:baseline,u:baselineU});
  const referenceFixture=classified(),input=sceneConjugateInputs(referenceFixture.source,referenceFixture.classification,referenceFixture.world,referenceFixture.settings).input,{divergenceDriftBudgetK,boundary,...base}=input,{viscosity,...fluid}=input.fluid;
  const expected=stepFanConjugate({...base,fluid,fan:{...input.fan,viscosity},boundary:{}}),fieldError=(temperatures,u)=>({temperatureErrorK:Math.max(...temperatures.map((t,i)=>Math.abs(t+273.15-expected.temperature[i]))),velocityError:Math.max(...u.map((v,i)=>Math.abs(v-expected.u[i])))});
  const baselineError=fieldError(baseline,baselineU);check('explicit-request baseline matches independent one-step physics',baselineError.temperatureErrorK<=.0005&&baselineError.velocityError<=.00002&&solved.duration.completedSteps===1&&solved.duration.completedTime===.01&&Math.abs(solved.duration.sourceEnergy-.75)<1e-10,{...baselineError,status:solved});
  await page.evaluate(({ownerHash,fanHash})=>{const nodes=__fanNativeContext.document.nodes;window.__fanIdentity={owner:nodes.find(n=>n.nativeHash===ownerHash),fan:nodes.find(n=>n.nativeHash===fanHash)};if(!__fanIdentity.owner||!__fanIdentity.fan)throw Error('Native owner/Fan identity is missing');},{ownerHash:owner.hash,fanHash});
  const identity=()=>page.evaluate(({ownerHash,fanHash})=>{const D=__fanNativeContext.document,owner=D.nodes.find(n=>n.nativeHash===ownerHash),fan=D.nodes.find(n=>n.nativeHash===fanHash);return {ownerPresent:!!owner,ownerSame:owner===__fanIdentity.owner,ownerId:owner?.id,ownerHash:owner?.nativeHash,fanPresent:!!fan,fanSame:fan===__fanIdentity.fan,fanId:fan?.id,fanHash:fan?.nativeHash};},{ownerHash:owner.hash,fanHash});
  const originalIdentity=await identity(),beforeFan=await read(),sameValues=(values,before)=>JSON.stringify(values)===JSON.stringify(before);
  const unchangedField=async name=>{const currentIdentity=await identity(),status=await cmd('status'),values=(await cmd('inspect',{count:24})).temperatures,u=(await cmd('inspect-velocity',{component:'u',count:30})).values;check(name,currentIdentity.ownerSame&&currentIdentity.fanSame&&currentIdentity.ownerId===originalIdentity.ownerId&&currentIdentity.ownerHash===owner.hash&&currentIdentity.fanId===originalIdentity.fanId&&status.state==='ready'&&status.authoring==='explicit-request'&&status.job===solved.job&&sameValues(values,baseline)&&sameValues(u,baselineU),{identity:currentIdentity,status,temperatures:values,u});};
  await call('scene.update',{id:fanHash,params:{Direction:'Forward','Shutoff pressure':0}});
  const editedFan=await read();check('unused Fan parameter edit actually changes its authored curve and direction',beforeFan.fan.authored.params.Direction==='Reverse'&&beforeFan.fan.authored.params['Shutoff pressure']===2&&editedFan.fan.authored.params.Direction==='Forward'&&editedFan.fan.authored.params['Shutoff pressure']===0,{before:beforeFan,after:editedFan});
  await unchangedField('unused Fan parameter edit preserves identical owner, job, temperatures and u field');
  await call('scene.select',{ids:[fanHash]});await timed('unused Fan native translation',1500,()=>call('transform.set',{channel:'position',axis:1,value:3,coordinates:'world'}));
  const movedFan=await read();check('unused Fan translation changes only its authored frame',JSON.stringify(editedFan.fan.mapping.centerMM)==='[-25,-12.5,-12.5]'&&JSON.stringify(movedFan.fan.mapping.centerMM)==='[-25,3,-12.5]'&&JSON.stringify(movedFan.fan.mapping.sizeMM)==='[25,25,25]',{before:editedFan,after:movedFan});
  await unchangedField('unused Fan transform preserves identical owner, job, temperatures and u field');
  await timed('unused Fan native transform Undo',1500,()=>call('edit.history',{action:'undo'}));
  const undoneFan=await read();check('transform Undo restores exact Fan frame without undoing its parameters',JSON.stringify(undoneFan.fan.mapping)===JSON.stringify(editedFan.fan.mapping)&&JSON.stringify(undoneFan.fan.authored.params)===JSON.stringify(editedFan.fan.authored.params),{before:editedFan,after:undoneFan});
  await unchangedField('unused Fan transform Undo preserves identical owner, job, temperatures and u field');

  // Native frame history keeps the node objects. Deletion followed by native
  // document Undo replaces them, and must never revive a derived field.
  await timed('native Thermal owner deletion',1500,()=>call('scene.delete',{ids:[owner.hash]}));
  const deletedIdentity=await identity();check('native owner deletion removes owner and child Fan identities',!deletedIdentity.ownerPresent&&!deletedIdentity.fanPresent,deletedIdentity);
  await timed('native Thermal owner delete Undo',1500,()=>call('edit.history',{action:'undo'}));
  const restoredIdentity=await identity(),retired=await cmd('status');
  check('delete Undo replaces owner JS identity while preserving native hash and authored Fan reference',restoredIdentity.ownerPresent&&!restoredIdentity.ownerSame&&restoredIdentity.ownerId===originalIdentity.ownerId&&restoredIdentity.ownerHash===owner.hash&&restoredIdentity.fanPresent&&!restoredIdentity.fanSame&&restoredIdentity.fanHash===fanHash&&(await read()).fan.ownerHash===owner.hash,restoredIdentity);
  const inspectRejection=(operation='inspect',args={count:24})=>page.evaluate(async({ownerHash,operation,args})=>{try{await frameAI.call('plugins.command',{id:ownerHash,operation,args});return null;}catch(error){return {code:error.code,message:error.message};}},{ownerHash:owner.hash,operation,args});
  const retiredRead=await inspectRejection(),retiredVelocity=await inspectRejection('inspect-velocity',{component:'u',count:30});check('actual owner replacement retires job and rejects old temperature and velocity reads',retired.state==='idle'&&retired.job===null&&retiredRead?.code==='NO_RESULT'&&retiredVelocity?.code==='NO_RESULT',{status:retired,rejection:retiredRead,velocityRejection:retiredVelocity,oldJob:solved.job});
  const restoredCapture=await cmd('scene-inputs'),freshArgs=argsFor(restoredCapture);
  check('replacement solve resolves stable fluid hash in the complete current capture',restoredCapture.occurrences.find(o=>o.occurrence===freshArgs.settings.fluidOccurrence)?.hash===meshes[0],{fluidHash:meshes[0],before:source,after:restoredCapture,fluidOccurrence:freshArgs.settings.fluidOccurrence});
  await cmd('solve-scene',freshArgs);const restarted=await timed('explicit-request restart after owner replacement',15000,finish),freshValues=(await cmd('inspect',{count:24})).temperatures,freshU=(await cmd('inspect-velocity',{component:'u',count:30})).values;
  // Recomputed GPU fields use the native numerical harness comparison budgets;
  // bitwise equality above is required only for reads of the SAME retained job.
  const temperatureDifferenceK=Math.max(...freshValues.map((t,i)=>Math.abs(t-baseline[i]))),velocityDifference=Math.max(...freshU.map((u,i)=>Math.abs(u-baselineU[i])));
  check('fresh explicit request after owner replacement has a new job and matching physical field',restarted.state==='ready'&&restarted.authoring==='explicit-request'&&restarted.job!==solved.job&&freshValues.length===24&&freshU.length===30&&temperatureDifferenceK<=.0005&&velocityDifference<=.00002,{status:restarted,temperatures:freshValues,u:freshU,temperatureDifferenceK,velocityDifference,oldJob:solved.job});
  const freshError=fieldError(freshValues,freshU);check('fresh replacement job still matches independent one-step physics',freshError.temperatureErrorK<=.0005&&freshError.velocityError<=.00002&&restarted.duration.completedSteps===1&&restarted.duration.completedTime===.01&&Math.abs(restarted.duration.sourceEnergy-.75)<1e-10,{...freshError,status:restarted});
  await call('tag.set',{ids:[meshes[1]],kind:'thermal_heater',enabled:true,params:{Power:76}});const stale=await cmd('status'),staleRead=await inspectRejection(),staleVelocity=await inspectRejection('inspect-velocity',{component:'u',count:30});check('authoritative Heater edit still retires existing field',stale.state==='stale'&&stale.job===restarted.job&&staleRead?.code==='NO_RESULT'&&staleVelocity?.code==='NO_RESULT',{status:stale,rejection:staleRead,velocityRejection:staleVelocity});await cmd('clear');
  await call('scene.delete',{ids:meshes});

  await timed('100 completed frameAI Fan inspections',3000,async()=>{for(let i=0;i<100;i++)await read();});
  const extra=[];await timed('32 native Fan authoring operations',10000,async()=>{for(let i=0;i<32;i++)extra.push((await cmd('create-fan')).hash);});
  await call('view.set',{index:0,single:true,focus:owner.hash});await call('diagnostics.frame',{frames:6});const afterFrames=await call('diagnostics.frame',{frames:12});
  check('Fan helpers have bounded measured CPU/GPU frames',afterFrames.timestampQueries&&afterFrames.frames.every(f=>Number.isFinite(f.cpuMs)&&Number.isFinite(f.gpuMs)&&f.cpuMs<50&&f.gpuMs<50),{beforeFrames,afterFrames});
  await call('scene.delete',{ids:extra});
  const saved=await call('scene.export',{includeData:true}),savedFan=(await inspect()).find(n=>n.hash===fanHash);
  await call('scene.delete',{ids:[fanHash]});check('delete removes Fan record',(await cmd('fan-inputs')).selection.status==='missing');await call('edit.history',{action:'undo'});check('delete Undo restores authoritative reference',(await read()).fan.ownerHash===owner.hash);
  await call('scene.open',{name:'thermal-fan.hash',base64:saved.base64});fan=(await inspect()).find(n=>n.hash===fanHash);
  check('HASH Open retains native Fan parameters, frame and owner reference only',JSON.stringify(fan.params)===JSON.stringify(savedFan.params)&&JSON.stringify(fan.matrix)===JSON.stringify(savedFan.matrix)&&fan.params.Thermal===owner.hash&&(await cmd('status')).state==='idle',fan);
  await page.route('**/thermal-fan-merge.hash',r=>r.fulfill({body:Buffer.from(saved.base64,'base64')}));
  const merged=(await call('scene.merge',{url:'thermal-fan-merge.hash'})).objects.find(n=>n.type==='thermal'),mergedFan=(await inspect()).find(n=>n.type==='thermal_fan'&&n.parent===merged?.hash);
  check('HASH Merge remaps native Fan reference with copied owner',!!merged&&merged.hash!==owner.hash&&mergedFan?.params.Thermal===merged.hash,{merged,mergedFan});await call('scene.delete',{ids:[merged.hash]});
  const dropReference=async sourceHash=>{
   await call('scene.select',{ids:[fanHash]});await page.locator('#tabAttributes').click();
   const source=(await inspect()).find(n=>n.hash===sourceHash),row=page.locator(`.ob-row[data-id="${source.id}"] .ob-name`),field=page.locator('#attrContent .cloner-object-drop[data-field="Thermal"]');
   await row.scrollIntoViewIfNeeded();const a=await row.boundingBox(),b=await field.boundingBox();if(!a||!b)throw Error('Native reference drag target is not visible');
   await page.mouse.move(a.x+a.width/2,a.y+a.height/2);await page.mouse.down();await page.mouse.move(a.x+a.width/2+5,a.y+a.height/2,{steps:2});await page.mouse.move(b.x+b.width/2,b.y+b.height/2,{steps:12});await page.mouse.up();await call('scene.inspect');
  };
  // Real native reference drop is a separate core validation gate from API
  // scene.update. Old cores store session IDs and bypass plugin validation.
  const referenceOwner=await call('plugins.create',{plugin:'thermal'}),wrongType=await call('scene.create',{type:'group'});
  await timed('native Thermal reference drop',1500,()=>dropReference(referenceOwner.hash));
  let dropped=(await inspect()).find(n=>n.hash===fanHash);
  check('native reference drop stores canonical native hash',dropped.params.Thermal===referenceOwner.hash,{dropped,referenceOwner});
  const validParams=JSON.stringify(dropped.params);await dropReference(wrongType.hash);dropped=(await inspect()).find(n=>n.hash===fanHash);
  check('wrong-type native reference drop rejects before mutation',JSON.stringify(dropped.params)===validParams,dropped);
  const droppedSave=await call('scene.export',{includeData:true});await call('scene.open',{name:'fan-dropped-reference.hash',base64:droppedSave.base64});
  check('native dropped owner reference survives HASH Open',(await read()).fan.ownerResolution.status==='resolved'&&(await read()).ownerHash===referenceOwner.hash);
  await call('scene.update',{id:fanHash,params:{Thermal:owner.hash}});await call('scene.delete',{ids:[referenceOwner.hash,wrongType.hash]});
  const gpu=await page.evaluate(()=>({errors:__fanGPU,lost:__fanLost}));check('Fan native workflow has no page/GPU errors',!errors.length&&!gpu.errors.length&&!gpu.lost,{errors,gpu});

  // Keep these hard requirements. Known old core copies leave Thermal pointing
  // at the original owner; such copies must never be treated as qualified.
  for(const kind of ['duplicate','clipboard']){
   let copy;if(kind==='duplicate')copy=(await call('scene.duplicate',{ids:[owner.hash]})).objects.find(n=>n.type==='thermal');
   else{await call('scene.select',{ids:[owner.hash]});await call('edit.copy');copy=(await call('edit.paste')).objects.find(n=>n.type==='thermal');}
   const copiedFan=(await inspect()).find(n=>n.type==='thermal_fan'&&n.parent===copy?.hash);
   check(`native ${kind} remaps internal Fan owner reference`,!!copy&&copiedFan?.params.Thermal===copy.hash,{copy,copiedFan,expectedOwner:copy?.hash});
   check(`native ${kind} owns independent idle state`,(await cmd('status',{},copy.hash)).state==='idle');await call('scene.delete',{ids:[copy.hash]});
  }
  return {hardware,beforeFrames,afterFrames,gpu,authoringOnly:true,solverEligible:false,missingGates:['Native domain/grid/duration authoring and saved-Fan solver coupling.','General geometry, sections and ancestor computation semantics.','Full application/stress qualification, including 100M-triangle interaction performance.']};
 }finally{await context.close();}
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const checks=[],timings=[];let session,result;
 const check=(name,pass,detail)=>{checks.push({name,pass:!!pass,detail});if(!pass)throw Error(name+': '+JSON.stringify(detail));};
 const timed=async(name,limit,fn)=>{const start=performance.now(),value=await fn(),ms=performance.now()-start;timings.push({name,ms,limit});check(name+' latency',ms<limit,{ms,limit});return value;};
 try{session=await launch({headless:process.argv.includes('--headless')});const evidence=await nativeFanBrowserChecks(session.page,check,timed);result={pass:true,hardwareVerified:true,checks,timings,evidence};}
 catch(e){result={pass:false,hardwareVerified:false,checks,timings,error:e.stack};}
 finally{await session?.close();}
 result.sources={};for(const path of ['index.html','plugins/thermal/tests/native-selection.mjs','plugins/thermal/tests/native-creation-fixture.mjs','plugins/thermal/plugin.js','plugins/thermal/plugin.json','plugins/thermal/native-fan.js','plugins/thermal/tests/native-fan.mjs','plugins/thermal/tests/native-fan-browser.mjs','plugins/thermal/tests/native-fluid-fixture.mjs','plugins/thermal/tests/scene-conjugate-fixture.mjs','plugins/thermal/scene-conjugate.js','plugins/thermal/tests/fan-conjugate-reference.mjs'])result.sources[path]=createHash('sha256').update(await readFile(new URL('../../../'+path,import.meta.url))).digest('hex');
 await mkdir(new URL('../../../tests/results/',import.meta.url),{recursive:true});await writeFile(new URL('../../../tests/results/thermal-native-fan.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;
}
