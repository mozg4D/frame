// CPU-only contract proof. Verbatim runtime functions; stubbed DOM/GPU/decode dependencies.
// Never runs a browser, imports a scene, or writes into the frozen candidate.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root=new URL('../',import.meta.url);
const html=await readFile(new URL('index.html',root),'utf8');
const sha=x=>createHash('sha256').update(x).digest('hex');
const pieces={};
function extract(name,start,end){const a=html.indexOf(start),b=html.indexOf(end,a+start.length);assert.ok(a>=0&&b>a,name);pieces[name]={startLine:html.slice(0,a).split('\n').length,sha256:sha(html.slice(a,b)),source:html.slice(a,b)};return pieces[name].source;}
const native=extract('nativeIO','    function nativeIOStart(label){','    async function nativeReadGPU');
const load=extract('loadHash','    async function loadHash(file,name=file.name','    async function newFile()');
const event=extract('nativeSceneEvent','    function nativeSceneEvent(name){','    function nativeSceneStats(name){');
const queue=extract('enqueueAndNativeTask','      let documentationWindow=null;','      const fail=');
const call=extract('call','      async function call(name,args={},bridgeGuard=null)','\n');
const placeholder=extract('openScenePlaceholder','async function openScenePlaceholder(name)','\n');
const open=extract('openSceneFile','async function openSceneFile(file','\n');
const remember=extract('rememberSceneFile','function rememberSceneFile(source','\n');
const persist=extract('persistRecentFiles','function persistRecentFiles(){','\n');
const fileDispatch=extract('loadFileDispatch','      loadFile:(file,options)=>','\n').trim().replace(/,$/,'');
const idle=extract('idle','      get idle(){','\n').trim().replace(/,$/,'');
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const watchdog=(promise,label)=>{let timer;return Promise.race([promise,new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('Bounded proof timed out: '+label)),2000))]).finally(()=>clearTimeout(timer));};
const results=[];
function env({priorRows=true,holdSource=false}={}){
 const events=[],gates={source:deferred(),draw:deferred(),gpu:deferred(),persist:deferred()},reached={source:deferred(),draw:deferred(),gpu:deferred(),persist:deferred()};
 const app={inert:false},button={disabled:false},canvas={dataset:{ready:'true'}},status={hidden:true},elements=new Map([['app',app],['frame-engine-read',button],['frame-engine-canvas',canvas],['dV',{}]]);
 let progress=null;
 const record=(kind,extra={})=>events.push({kind,...snap(),...extra});
 const snap=()=>({rows:c.rows.map(x=>x.name),idle:c.api.idle,inert:app.inert,buttonDisabled:button.disabled,ready:canvas.dataset.ready,progress:!!progress,operationError:canvas.dataset.operationError||null,remembered:c.remembered,sceneEventCount:c.sceneEventCount});
 const file=new File(['synthetic payload is not decoded'],'selected.hash');
 const c={performance,setTimeout,Map,Set,Promise,Uint32Array,JSON,Blob,console,events,rows:priorRows?[{name:'old row'}]:[],remembered:0,sceneEventCount:0,
 nativeIOBusy:false,selectionBusy:false,editDrag:null,gizmoSession:null,coreNumeric:null,editFinishing:false,undoBusy:false,button,canvas,status,hoverCursor:{inside:false},scene:{meshes:[],records:new Map()},sceneFrameDirty:false,displayUnitIndex:2,rescaleUnitIndex:2,units:['m','cm','mm'],selectionScope:null,objectSelection:[],componentPivot:null,metaUndo:[],metaRedo:[],selectionSignature:'',lastImportReport:null,
 objectActionQueue:Promise.resolve(),clipboardSerial:Promise.resolve(),selectionQueue:Promise.resolve(),editSerial:Promise.resolve(),appearanceQueue:Promise.resolve(),replicaQueue:Promise.resolve(),animationSerial:Promise.resolve(),tail:Promise.resolve(),sequence:0,
 splineMaterialOrigins:new Map(),polygonTools:{soft:true},frameSoloIds:null,appearanceSignature:'',FrameHash:{K:{parameters:'params'}},
 recentFilesReady:Promise.resolve(),recentSceneFiles:new Map(),recentFileCompanions:new Map(),recentFileNames:['selected.hash'],recentFileWrites:Promise.resolve(),sceneFileName:'old.hash',sceneFileHandle:null,
 FramePlugins:{ready:Promise.resolve()},FrameSpline:{flush:async()=>{}},docs:{get:()=>({version:'fixture:0'})},settle:async()=>{},tools:new Map(),validate:()=>{},json:x=>x,stop:()=>{},
 fail:(code,message)=>{throw Object.assign(Error(message),{code});},CustomEvent:class{constructor(type,init){this.type=type;this.detail=init.detail;}},
 fileOperationError:e=>{canvas.dataset.operationError=e.message;record('operation-error',{message:e.message});},
 document:{getElementById:id=>id==='frame-file-progress'?progress:elements.get(id),createElement:()=>({setAttribute(){},remove(){progress=null;}})},
 $:id=>id==='btnSolo'?{classList:{remove(){}},ariaPressed:false}:elements.get(id),
 nativeDecodePlan:async()=>({objects:[{hash:'new-hash',name:'new row',flags:3,type:0}],meshes:0,appearance:{ids:[]},records:new Map(),camera:[],importReport:{}}),
 nativeObjects:()=>[{hash:'new-hash',name:'new row',flags:3,type:0}],appearanceLibrary:()=>[],nativeSceneStats:()=>{},
 getRenderer:async()=>({device:{queue:{writeBuffer(){},onSubmittedWorkDone(){record('gpu-wait');reached.gpu.resolve();return gates.gpu.promise;}}}}),
 sceneFromMeshes:(_gpu,meshes)=>({meshes,records:new Map(),triangleCount:0}),
 draw:()=>{record('draw-wait');reached.draw.resolve();return gates.draw.promise;},
 window:{dispatchEvent:e=>{if(e.type==='frame-engine-scene'){c.rows=e.detail.objects;c.sceneEventCount++;record('scene-event',{name:e.detail.name});}else record(e.type,e.detail);}}
 };
 c.recentFilesDB=Promise.resolve({transaction(){const tx={objectStore:()=>({put(){c.remembered++;record('persist-wait');reached.persist.resolve();}})};gates.persist.promise.then(()=>tx.oncomplete(),error=>{tx.error=error;tx.onerror();});return tx;}});
 elements.set('frame-engine-host',{append(el){progress=el;record('native-start');}});
 for(const name of ['touchActivity','frameSyncMaterials','endPolygonTool','clearSplineDisplays','clearEdits','checkSession','disposeScene','clearFeatureDraws','clearPickGroups','installNativeRecords','uploadPolygonSets','resetView','applyNativeCamera','setVisibility','disposeMesh','trimRecentFiles'])c[name]=()=>{};
 c.api={ready:Promise.resolve()};c.window.FrameSpline=c.FrameSpline;
 const source=holdSource?{name:file.name,getFile:()=>{record('source-wait');reached.source.resolve();return gates.source.promise;}}:file;
 c.recentSceneFiles.set(file.name,source);
 vm.createContext(c);vm.runInContext(native+load+event+queue+call+placeholder+open+remember+persist+'\nObject.defineProperty(api,"idle",Object.getOwnPropertyDescriptor({'+idle+'},"idle"));api.loadFile=({'+fileDispatch+'}).loadFile;',c);
 c.window.frameEngine=c.api;c.frameEngine=c.api;
 c.tools.set('scene.inspect',{inputSchema:{},annotations:{readOnlyHint:true},run:()=>{record('inspect-run');return {objects:c.rows};}});
 return {c,events,gates,reached,snap,file,record};
}
async function test(name,fn){const started=performance.now();try{const detail=await fn();results.push({name,pass:true,elapsedMs:performance.now()-started,detail});}catch(error){results.push({name,pass:false,error:error.stack});}}
await test('New scene rows are observable while real loadHash still holds native IO, even with no old row',async()=>{
 const e=env({priorRows:false}),{c,gates,reached}=e;
 const selected=c.openScenePlaceholder('selected.hash');await watchdog(reached.draw.promise,'draw');
 assert.deepEqual(c.rows.map(x=>x.name),['new row']);assert.equal(c.api.idle,false);assert.equal(c.nativeIOBusy,true);assert.equal(c.canvas.dataset.ready,'loading');
 await assert.rejects(c.call('scene.inspect'),x=>x.code==='BUSY'&&x.message==='Finish the native file operation first');
 assert.equal(e.events.some(x=>x.kind==='frame-ai-call'),false,'Eager rejection is before command start event');
 e.record('expected-busy-after-row');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');assert.equal(c.nativeIOBusy,true);e.record('gpu-still-pending');
 gates.gpu.resolve();await watchdog(reached.persist.promise,'persistence');assert.equal(c.nativeIOBusy,false);assert.equal(c.api.idle,true);gates.persist.resolve();await watchdog(selected,'selected open');
 const result=await c.call('scene.inspect');assert.equal(result.objects[0].name,'new row');assert.equal(c.canvas.dataset.operationError,undefined);
 return {events:e.events};
});
await test('Old row plus old idle is true while current handle getFile has not admitted any native load',async()=>{
 const e=env({holdSource:true}),{c,gates,reached}=e,oldWrite=c.recentFileWrites;
 const selected=c.openScenePlaceholder('selected.hash');await watchdog(reached.source.promise,'source');
 assert.equal(c.api.idle,true);assert.equal(c.canvas.dataset.ready,'true');assert.equal(c.rows[0].name,'old row');assert.equal(c.sceneEventCount,0);assert.equal(c.recentFileWrites,oldWrite);e.record('false-old-idle-row');
 gates.source.resolve(e.file);await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persistence');
 assert.notEqual(c.recentFileWrites,oldWrite);assert.equal(c.nativeIOBusy,false);assert.equal(c.sceneEventCount,1);gates.persist.resolve();await watchdog(selected,'selected open');
 return {events:e.events};
});
await test('Post-scene idle observation admits one inspect behind native persistence instead of bypassing queue',async()=>{
 const e=env(),{c,gates,reached}=e,oldWrite=c.recentFileWrites;const selected=c.openScenePlaceholder('selected.hash');
 await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persistence');
 assert.ok(c.sceneEventCount===1&&c.api.idle&&!c.document.getElementById('app').inert&&c.canvas.dataset.ready==='true'&&!c.document.getElementById('frame-file-progress'));assert.notEqual(c.recentFileWrites,oldWrite);
 const inspection=c.call('scene.inspect');await Promise.resolve();assert.equal(e.events.some(x=>x.kind==='inspect-run'),false,'Native tail still owns persistence');gates.persist.resolve();
 const [,result]=await watchdog(Promise.all([selected,inspection]),'native completion + inspect');assert.equal(result.objects[0].name,'new row');
 return {events:e.events};
});
await test('Failed GPU completion cannot pass event plus idle: error and loading state remain explicit',async()=>{
 const e=env(),{c,gates,reached}=e,oldWrite=c.recentFileWrites;const selected=c.openScenePlaceholder('selected.hash');
 await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.reject(Error('injected GPU completion failure'));await watchdog(selected,'failed open');
 assert.equal(c.sceneEventCount,1);assert.equal(c.api.idle,true);assert.equal(c.canvas.dataset.ready,'loading');assert.equal(c.canvas.dataset.operationError,'injected GPU completion failure');assert.equal(c.recentFileWrites,oldWrite);assert.equal(c.remembered,0);
 return {events:e.events};
});
await test('Persistence failure sets operationError despite changed promise and healthy engine; success observer must fail',async()=>{
 const e=env(),{c,gates,reached}=e,oldWrite=c.recentFileWrites;const selected=c.openScenePlaceholder('selected.hash');
 await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persistence');
 const replacement=c.recentFileWrites;assert.notEqual(replacement,oldWrite);assert.equal(c.api.idle,true);assert.equal(c.canvas.dataset.ready,'true');
 gates.persist.reject(Error('injected IndexedDB write failure'));await watchdog(replacement,'caught persistence failure');await watchdog(selected,'selected open failure');
 assert.equal(c.canvas.dataset.operationError,'injected IndexedDB write failure');assert.equal(c.api.idle,true);assert.equal(c.recentFileNames[0],'selected.hash');
 return {events:e.events,note:'Actual persistRecentFiles catches the storage rejection. Awaiting the changed promise alone is NOT a success assertion; operationError must be checked after await.'};
});
// Execute the exact current UI helper against controlled, verbatim runtime functions.
const fixture=await readFile(new URL('tests/file-controls.mjs',root),'utf8');
const helperStart=fixture.indexOf('open=async name=>{'),helperEnd=fixture.indexOf('\n try{',helperStart);
assert.ok(helperStart>=0&&helperEnd>helperStart);const helper=fixture.slice(helperStart+'open='.length,helperEnd).trim().replace(/;$/,'');
function helperEnv(options={}){
 const e=env(options),{c}=e,waiting=deferred(),observed=deferred();let predicate,args,disposed=false,nativeTask,probeCount=0;
 c.document.querySelector=selector=>selector==='#frame-engine-canvas'?c.canvas:selector==='#app'?c.document.getElementById('app'):selector==='#frame-file-progress'?c.document.getElementById('frame-file-progress'):null;
 const evaluate=(fn,arg)=>{c.__fixtureArgument=arg;return vm.runInContext('('+fn.toString()+')(__fixtureArgument)',c);};
 const page={mouse:{move:async()=>{}},getByRole:()=>({click:async()=>{nativeTask=c.openScenePlaceholder('selected.hash');}}),locator:selector=>({hover:async()=>{},first(){return this;},waitFor:async()=>{assert.equal(selector,'#obInner .ob-row');assert.ok(c.rows.length,'Original row assertion remains');}}),
 evaluateHandle:async fn=>({value:await evaluate(fn),dispose:async()=>{disposed=true;}}),evaluate:async(fn,arg)=>evaluate(fn,arg),
 waitForFunction:(fn,input,options)=>{assert.equal(options.timeout,3000,'Native completion deadline remains 3 seconds');predicate=fn;args={...input,before:input.before.value};waiting.resolve();return observed.promise;}};
 const openHelper=new Function('page','call','persist','return ('+helper+');')(page,(name,args)=>c.call(name,args),async()=>{await c.recentFilesReady;await c.recentFileWrites;});
 const task=openHelper('selected.hash');task.catch(()=>{});
 const probe=async()=>{await waiting.promise;probeCount++;try{const result=await evaluate(predicate,args);if(result)observed.resolve(true);return result;}catch(error){observed.reject(error);return {error:error.message};}};
 return {...e,waiting,task,probe,get disposed(){return disposed;},get nativeTask(){return nativeTask;},get probeCount(){return probeCount;}};
}
await test('Actual helper rejects old idle/row and early new row, then awaits persistence before one inspect',async()=>{
 const e=helperEnv({holdSource:true}),{c,gates,reached}=e;await watchdog(reached.source.promise,'source');await watchdog(e.waiting.promise,'observer');
 assert.equal(await e.probe(),false,'Old idle and old row are not current Open completion');assert.equal(e.events.some(x=>x.kind==='inspect-run'),false);
 gates.source.resolve(e.file);await watchdog(reached.draw.promise,'draw');assert.equal(await e.probe(),false,'Newly rendered row before native GPU completion is not completion');
 gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');assert.equal(await e.probe(),false);gates.gpu.resolve();await watchdog(reached.persist.promise,'persist');
 let observed=false;const pending=e.probe().then(x=>{observed=true;return x;});await Promise.resolve();assert.equal(observed,false,'Actual async predicate awaits pending persistence');assert.equal(e.events.some(x=>x.kind==='inspect-run'),false);
 gates.persist.resolve();assert.equal(await pending,true);await watchdog(e.task,'helper');assert.equal(e.events.filter(x=>x.kind==='inspect-run').length,1);assert.equal(e.disposed,true);return {events:e.events,probes:e.probeCount};
});
await test('Actual helper fails storage rejection even though persistRecentFiles catches it',async()=>{
 const e=helperEnv(),{gates,reached}=e;await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persist');
 const pending=e.probe();gates.persist.reject(Error('storage failure'));assert.equal((await pending).error,'storage failure');await assert.rejects(e.task,/storage failure/);assert.equal(e.events.some(x=>x.kind==='inspect-run'),false);assert.equal(e.disposed,true);return {events:e.events};
});
await test('Actual helper fails native load error instead of accepting released idle or an existing row',async()=>{
 const e=helperEnv(),{gates,reached}=e;await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.reject(Error('GPU completion failure'));await watchdog(e.nativeTask,'native error');
 assert.equal((await e.probe()).error,'GPU completion failure');await assert.rejects(e.task,/GPU completion failure/);assert.equal(e.events.some(x=>x.kind==='inspect-run'),false);assert.equal(e.disposed,true);return {events:e.events};
});
await test('Actual helper detects native final-settle error after a normal queued inspect can recover',async()=>{
 const e=helperEnv(),{c,gates,reached}=e;let settles=0;c.settle=async()=>{if(++settles===2)throw Error('native final settle failure');};
 await watchdog(reached.draw.promise,'draw');gates.draw.resolve();await watchdog(reached.gpu.promise,'GPU');gates.gpu.resolve();await watchdog(reached.persist.promise,'persist');
 const pending=e.probe();gates.persist.resolve();await pending;await assert.rejects(e.task,/native final settle failure/);assert.equal(e.disposed,true);assert.equal(c.canvas.dataset.operationError,'native final settle failure');assert.equal(e.events.filter(x=>x.kind==='inspect-run').length,1,'Late error must be caught after the normal inspect succeeds');return {events:e.events,settles};
});

const report={pass:results.every(x=>x.pass),scope:'CPU-only semantic proof using verbatim source functions and synthetic dependency gates. No browser, rendering, GPU, real IndexedDB, import/decode, or production qualification.',candidate:new URL('.',root).pathname,indexSHA256:sha(html),fileControlsSHA256:sha(await readFile(new URL('tests/file-controls.mjs',root))),actualHelperSHA256:sha(helper),runtimeFragments:Object.fromEntries(Object.entries(pieces).map(([k,v])=>[k,{startLine:v.startLine,sha256:v.sha256}])),checks:results};
await mkdir(new URL('./results/',import.meta.url),{recursive:true});
await writeFile(new URL('./results/file-controls-sequence.json',import.meta.url),JSON.stringify(report,null,2)+'\n');

console.log(JSON.stringify(report,null,2));if(!report.pass)process.exitCode=1;
