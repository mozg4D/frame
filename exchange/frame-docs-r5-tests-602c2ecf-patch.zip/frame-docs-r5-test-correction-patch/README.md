# R5 file-controls test correction only

This patch changes only tests/file-controls.mjs, its new exact-helper regression, the CPU runner (16th stage), and source inventory. Runtime index/SW/Docs/assets and version 2026 07 nov 23:20 are byte-identical to R5. Geometry assertions and the 3000 ms full-reload budget remain unchanged. The causal completion wait checks operation errors before, after, and after inspection. No runtime repair, error filtering or timing relaxation is implied.

The original R5 package/layer/source maps remain unchanged as historical provenance. The current inventory and this exact patch identify corrected test sources. Previous Windows failure and trace files remain preserved on Windows; they are not cloud originals. The corrected browser fixture remains UNRUN until separately tested.

Verify the ZIP SHA-256 supplied separately. From this extracted patch folder, set $R5 to the exact original R5 source, $Fixed to a NEW sibling destination:

    node .\apply-docs-r5-tests.mjs --check $R5
    if ($LASTEXITCODE -ne 0) { throw 'R5 preflight failed' }
    node .\apply-docs-r5-tests.mjs --apply $R5 $Fixed
    if ($LASTEXITCODE -ne 0) { throw 'Patch failed; preserve incomplete output' }
    node "$Fixed\tests\docs-final-cpu-gate.mjs"
    if ($LASTEXITCODE -ne 0) { throw 'CPU16 failed' }

Only after the authorized Windows browser environment is ready and existing Playwright/Chromium dependencies resolve from the new folder:

    node "$Fixed\tests\docs-integrated-browser-gate.mjs" --headless
    if ($LASTEXITCODE -ne 0) { throw 'STOP: focused browser gate failed' }

The existing full focused runner starts with corrected file-controls, runs nine children sequentially, checks source before/after each, stops on failure and retains its five-minute child limit. No new wrapper or browser infrastructure. Forced termination leaves descendant cleanup uncertain; check it before a later run. Do not overwrite existing failures without preserving them.

The source-only applier refuses existing output, hashes all inputs/outputs and never edits R5, launches browsers or copies/installs dependencies. If ad hoc diagnostic files polluted inventoried paths, preserve that tree and reconstruct a clean R5 from its previously verified source/patch chain. Never delete diagnostic evidence or regenerate the baseline inventory to evade a check.

No standard/stress, unrelated Unite, printer/CNC work, user scenes/media, main/live changes, upload or publication. Actual OS IME and broader release qualification remain separate. Runtime/PWA behavior is not newly certified by CPU or package checks.
