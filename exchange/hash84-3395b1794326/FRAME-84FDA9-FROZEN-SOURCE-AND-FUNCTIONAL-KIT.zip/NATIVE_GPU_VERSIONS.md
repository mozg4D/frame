# Isolated native GPU version adapter

Status: implementation fragment and CPU-mock tests only. It is **not installed**
in Frame, is **not hardware-tested**, and does not make the existing native
mutable renderer an immutable GPU backend. No live page, existing candidate,
Git branch, or `main` was changed by this work.

## Inputs and verified source behavior

The source reviewed was `frame-canonical-runtime-8df4081/index.html`:

- `duplicateResource(gpu, source, label)` allocates a matching GPUBuffer, or
  uses `makePagedTexture` for a native paged texture.
- `copyResource(encoder, source, target)` copies the entire allocation on GPU.
- `nativeReadGPU(gpu, resource, count)` reads `count * 4` bytes, with bounded
  temporary GPU readback allocation, including paged row/layer handling.
- `releaseGPU(resource)` defers destruction while the native `gpuLeases`
  entry has a positive count, marking it retired instead.
- `releaseBorrowed` decrements that same count and destroys a retired resource
  after the last borrower releases it.
- `checkSession(gpu)` checks current native renderer identity and `gpu.dead`.
  That native session has no dedicated device epoch and no reusable public
  `retainResource` function.

The implementation calls these dependencies. It contains no replacement mesh,
geometry, topology, or paged upload algorithm.

## API and ownership

`createFrameSceneGPUVersions({getSession, checkSession, retainResource,
duplicateResource, copyResource, releaseGPU, readGPU})` returns a frozen adapter.
All dependencies are trusted. `getSession()` and `checkSession(gpu)` are
synchronous; `getSession` returns the native renderer object, not a Promise.
Use `nativeReadGPU` as the `readGPU` dependency.

- `capture({resource, type, byteLength, count})` returns a Promise for a frozen
  owned version. It retains the source and submits its private copy before its
  first await. That queue submission is the snapshot cut: later source writes
  cannot alter the copy. It then waits for submitted work and checks validation,
  allocation errors, and session/device identity before publishing.
- `fork(version, write)` leases the old version synchronously, makes an
  unpublished writable copy, and awaits
  `write({gpu, resource, encoder})`. A second private copy seals the resulting
  staged bytes, after encoded writes, before publication. Retaining the staging
  handle does not give access to the published allocation. A failed fork leaves
  the old version unchanged and disposes unpublished allocations.
- `validate(version)` returns `true`, or throws for foreign, forged, disposed,
  stale-session, or known-lost-device versions.
- `binding(version)` returns the exact frozen allocation handle or frozen native
  paged-texture wrapper. It does not read a live mesh field or use a live getter.
- `readback(version)` returns a **fresh Uint8Array of exactly `byteLength`**.
  It trims word padding for byte records and preserves float/integer bit patterns.
  It is explicit readback; capture and fork never invoke it.
- `dispose(version)` relinquishes adapter ownership. It is idempotent for an
  authentic version, returning `true` once and then `false`. A stale version can
  still be disposed. In-flight fork/readback leases survive concurrent disposal.

Public version properties are exactly `{deviceEpoch, type, byteLength, count}`.
The allocation handle and session identity are private WeakMap values.
An owned version must be disposed when no longer owned; garbage collection of
its JavaScript descriptor does not perform GPU disposal.

Supported numeric HASH types are `0` (bytes), `3` (uint32), and `5` (float32).
For scalar records, `byteLength === count * 4`. For byte records, including
material face masks, `count === Math.ceil(byteLength / 4)`. Thus a five-byte
face-mask record has count two, even if its GPU allocation is 16 bytes.
Zero logical length is supported with native allocation minimum four bytes.

Native paged resources must match the current scalar `r32uint` layout with one
channel, positive width/height/layers, sufficient logical count, and matching
allocation capacity. The adapter does not reinterpret packed RG/RGBA formats.

## Native lifetime bridge

`createFrameNativeResourceRetainer(gpuLeases, releaseGPU)` supplies the missing
synchronous retain/release primitive. It increments the existing native lease,
returns an idempotent release closure, and follows `releaseBorrowed` semantics
for the final release of a retired allocation.

Integration must pass the **actual existing native `gpuLeases` WeakMap** used by
`releaseGPU` and native borrowers. A separate lookalike map does not protect
lifetime. The caller must own or otherwise know that the source is live when it
calls capture; the WebGPU API does not expose a general destroyed-buffer query.

Illustrative dependency assembly, deliberately not installed by this fragment:

```js
const gpuVersions = createFrameSceneGPUVersions({
  getSession: () => renderer,
  checkSession,
  retainResource: createFrameNativeResourceRetainer(gpuLeases, releaseGPU),
  duplicateResource,
  copyResource,
  releaseGPU,
  readGPU: nativeReadGPU
});
```

## Trusted write and renderer contracts

The callback can await preparation and encode writes into the supplied encoder.
It must target the writable staging resource only, must not finish/submit that
encoder or manipulate error scopes, and must finish its GPU allocation/queue
calls before settling. It must not await another fork/readback on the same
device, because those long-lived scoped operations are serialized. It must not
retain and later use the supplied GPU/encoder capabilities to mutate unrelated
resources. It is not a plugin sandbox.

The initial staging copy is submitted before calling `write`. Final writes and
sealing copy are submitted in one command buffer, in that order. The temporary
staging allocation is destroyed after completion. The extra sealing allocation
is intentional isolation and adds peak memory/copy cost; performance has not
been measured.

`binding` is renderer-only **read-only borrowing by contract**. Freezing a
GPUBuffer object cannot remove `destroy()` or prevent a trusted caller from
using it as a GPU write target. A renderer must preserve version ownership
until GPU use is finished, and must not pass its binding to any current
in-place native editor. SceneStore snapshots/transactions must provide that
ownership boundary.

## Error scopes and device epochs: integration blockers

WebGPU error scopes are a **device-global stack**. Capture pushes and pops its
own scopes synchronously before yielding. This fragment serializes its async
fork/readback scopes across adapter instances on the same device and permits
nested synchronous capture scopes. Every successfully pushed scope is popped,
including cleanup after a rejected pop, callback, allocation, or submission.
Resource cleanup waits for all work and scope results to settle.

This only coordinates this fragment. Existing native renderer functions also
push/pop error scopes across awaits. Installing the adapter beside those
operations without a shared scheduling/error-scope policy is unsafe: overlapping
native operations can consume each other's scopes or attribute errors wrongly.
A device-wide integration plan and hardware tests are required before exposing
this as an installed native capability. No runtime hook or coordinator for the
existing renderer was added here.

`deviceEpoch` is an adapter-generated monotonically assigned token for observed
native session/device identity. Current native `gpu.dead`, `checkSession`,
current renderer/device identity, and observed `device.lost` are checked. It is
not a new persistent epoch field in the renderer. Integration must not revive
a previously retired session object in place without an observable new identity
or explicit generation contract.

A returned GPU handle is not a security capability boundary. This adapter
therefore does not promise immutable geometry if other code violates the
read-only binding/staged-write contracts, directly destroys a borrowed resource,
or bypasses native lifetime accounting. It makes no blanket `immutableGpuPins`
claim for legacy mutable mesh handles.

## Verification

Run:

```sh
node --test tests/native-gpu-versions.test.cjs
```

Current result: **27 CPU-mock tests passed, zero skipped** in the original
workspace. Tests cover synchronous capture ordering, concurrent retirement,
copy isolation, sealed staging, disposal while fork/readback is pending,
byte-mask padding, raw float bit patterns, paged textures, metadata rejection,
foreign/disposed versions, session/device loss, allocation/validation/OOM/
submission/queue/scope-pop failures, balanced scopes, native borrowed leases,
and overlapping adapter operations.

Two source-backed tests execute the actual unmodified native
`copyResource`/`duplicateResource` and `nativeReadGPU` definitions against fake
GPU APIs. The packaged tests read the candidate index.html directly and fail if it is
missing. They do not prove browser WebGPU validation, driver behavior,
real GPU memory pressure, actual device-loss timing, renderer installation,
shader correctness, browser rendering, or performance.
