# Addressed SceneStore foundation

Status: isolated runtime foundation, **not installed into the editor**. The factory
is inline in `index.html`, but the existing native/UI writers still use the prior
RAM-table vertical slice. This work is not a completed migration, a new file
format, a clipboard implementation, or a production GPU/history approval.

## What is implemented

`createFrameSceneStore(FrameHash, {gpu, documentId})` owns one private address-keyed
JavaScript Map. `store.records` is a readonly addressed facade over that Map,
not a scene array, serialized object tree or second independently mutable graph.
It uses the existing HASH codec and native low types, keys and XOR addresses.
There is no replacement serializer, new generic low type or JSON scene container.
No authored relationships are hidden outside HASH; type-4 lists remain records.

Each stored RecordRef is immutable. CPU text is shared safely; typed arrays and
ID lists are owned on admission, and array reads return copies. `ref.at(index)`
and `store.scalar(address)` avoid array copies for element/scalar reads. RecordRef
constructors require a private factory key and their prototypes are frozen:
`ref.constructor` cannot admit caller-owned mutable payloads. CPU aliases share
private immutable payloads, not a cloned scene. The store never exposes those
private bytes for writing.

### Transactions and deltas

- `store.begin(label)` returns one transaction. `get(address)` captures a stable
  first-read ref and monotonically increasing address revision. GPU reads hold
  a lifetime owner until the transaction closes.
- `set(address,type,value)`, `put(ref)`, `alias(address,ref)`, `delete(address)`,
  `patchRange(address,elementOffset,typedValues)` stage addressed changes only.
  Range editing currently copies the whole addressed CPU record; it is not a
  zero-copy range representation. No routine operation encodes/compresses the
  scene or reads GPU data back.
- `expect(address,revision)` adds/checks a CAS dependency. Tombstone revisions
  detect absent -> create -> delete as well as edit-back and Undo ABA. First-read
  refs and versions are repeated, not silently updated during asynchronous work.
- `reserveAddresses(addresses)` reserves concrete empty slots. It materializes
  the input before checking/claiming so iterable callbacks cannot steal another
  transaction's reservation. This is **not semantic owner/asset/author identity
  reservation**. It cannot prove unknown ownership or reference domains.
- `captureGPU(address,sourceDescriptor)` and `forkGPU(address,sourceRef,write)`
  stage private native GPU versions through the injected adapter. Await them
  before commit. A pending same-address GPU operation rejects all second CPU/GPU
  writes with `STAGING_ADDRESS_BUSY`, rather than using completion order.
- `tx.commit()` / `store.commit(tx)` is synchronous and closes the transaction.
  It validates epoch, all read revisions, reservations, values and resource
  versions before publication. It returns
  `{committed, documentId, epoch, revision, delta}`. A no-op has committed false
  and delta null. Calling commit with pending GPU work rejects and aborts the
  transaction; a late result disposes itself exactly once.
- `tx.abort()` is idempotent. A replaced document invalidates old transactions
  before they can read or reserve its records. Pending native staging owns its
  temporary resources until it can finish cleanup; abort does not publish it.
- A delta contains only frozen `{id,before,after}` changed-record entries, with
  before/after GPU ownership already retained before old ownership is dropped.
  The caller owns `delta.release()` and can take independent `delta.acquireUse()`
  leases. A release cannot destroy versions still held by another active use.
- `store.replay(delta,'undo'|'redo')` validates every affected entry before
  changing any. Monotonic revisions reject stale computations; separate causal
  lineage tokens permit legitimate overlapping linear Undo/Redo. Unrelated
  transactions restoring the same ref cannot impersonate the earlier lineage.
  This does **not** create a second command history stack or integrate Frame's
  selection/camera/gesture chronology.

The canonical batch and retained delta exist before observers run. Observers are
notification-only; sync errors, async rejections and prohibited reentrant edits
are diagnostics, never a false failed commit that a caller should retry. There
is no mutable asynchronous `afterCopy` hook. An actual high-level command must
still stage and publish history chronology, projection and selection together;
record-only publication does not prove that integration.

### Exact version leases

`pinVersions(refs)` retains precisely the supplied versions. Use this for a plan
already based on RecordRefs. It does not re-resolve addresses or claim that
arbitrarily supplied refs constitute a coherent semantic scene closure.

`pinAddresses(addresses, {expectedEpoch, expectedRevisions})` captures current
versions synchronously. Optional planned epoch and revision Map enforce CAS.
Without those options it explicitly means current versions at that call, not a
snapshot of an earlier plan. Pin handles expose document identity and acquisition
epoch/revision bookkeeping, not a second source of authored data.

A pin owns one lease, `pin.acquireUse(purpose)` starts a separate active use, and
`pin.release()` releases its owner. All releases are idempotent. Replacing the
clipboard releases its ownership, not in-flight Paste/export uses. Taking a use
is O(1); the exact-ref membership Set is shared by the lease.

`gpuBinding(ref,activeUse)` requires a private live use from this store covering
that **exact ref**, then checks the adapter's exact resource/device epoch. A use
for another record, alias, store, released use or stale GPU session is not
accepted. The returned binding is a trusted renderer-only read-only borrow.
Keep the use until submitted work finishes; never mutate/destroy that binding.
Raw GPU handles cannot be made a JavaScript capability sandbox by freezing them.

Old immutable pins intentionally survive `store.replace()` so clipboard sources
and in-flight exports can outlive New/Delete/history trim on the same live GPU.
That does not authorize writes into a replacement document: destination
transactions/deltas are bound to their own epoch. Source/destination semantic
reference checks belong in the missing high-level capture/remap facade.

`collect()` retires zero-owner native versions outside canonical publication;
disposal errors are diagnostics. Owners must close transactions, release pins,
uses and deltas, and schedule collection. No GC finalizer is relied on.

### GPU content isolation and explicit export

See [NATIVE_GPU_VERSIONS.md](NATIVE_GPU_VERSIONS.md). Capture submits a private
GPU copy before its first await. Fork uses unpublished COW staging and a second
sealing copy so an escaped staging handle cannot mutate the published version.
This deliberately does not assume every existing native writer obeys audited
COW. Native duplicate/copy/readback helpers are reused, not reimplemented mesh
algorithms. Capture/fork are GPU copies, never CPU readbacks.

Byte masks preserve exact byteLength and trim native word padding during explicit
export. Float32 and uint32 preserve bits. Native scalar r32uint paged resources
are supported by the adapter; Morph rest/evaluated semantics still require
schema/renderer integration. Arbitrary plugin resource roles are not inferred.

`exportRecords(pin)` is an explicit serialization boundary. It takes an active
use before its first await, serializes CPU values with the existing codec,
reads immutable GPU versions only here, and emits opaque raw blocks unchanged.
It is a low-level addressed-subdocument export, not schema-complete Copy/export.

## Unknown-data boundary

Opaque input checks raw uint16 type/flags, the 16-byte address and uint64 length.
It owns the complete block in RAM. Returned bytes are copies; Save/export retain
raw header, flags and payload exactly. Existing opaque versions cannot be
silently edited/deleted by a generic transaction. Identical content is a no-op.
`alias(newAddress,opaqueRef)` rejects `OPAQUE_REMAP_SCHEMA`; it does not leave an
old physical ID in a new Map slot or guess how to rewrite hidden references.
Explicit schema-safe readdressing is not implemented here.

Unknown records still do not reveal their owner through XOR. Missing plugins,
known low types or valid framing do not prove ownership/reference/resource
closure. This foundation cannot supply semantic lossless capture, Merge or
identity-safe Duplicate. There is no automatic best-effort downgrade.

## Integration gate: do not rename unavailable capabilities into existence

True low-level capabilities: immutable CPU refs/pins; immutable GPU refs only
with the specific injected/tested adapter; addressed CAS transactions, concrete
address reservations, retained record deltas and atomic canonical record batches.

Still false: `identityReservations`, `recordDeltaHistory`, `ownershipClosure`,
`schemaRemap`, and `recordDrivenProjection`. The agreed future
`capture -> capsule -> preparePaste -> atomic command commit -> exportHash`
facade is **not implemented**. Clipboard controller/planner fragments cannot be
wired by aliasing similarly named methods or calling `restoreStructure(objects)`.

Before installing a real domain:

1. Move its reads and writes to the one store; delete the duplicate UI/plugin
   authority and sync path. Do not keep a shadow Map as a migration convenience.
2. Ingest directly into its eventual canonical ownership to avoid an extra
   permanent table or CPU geometry mirror. Measure large-file peak staging RAM.
3. Join existing native UID/author reservations and declared schema ownership.
   Address slots alone do not reserve all semantic identity domains.
4. Stage resource bindings and record-driven projection; publish command history,
   selection and chronology in the same operation before visible publication.
5. Join one device-global scheduling/error-scope policy. The adapter coordinates
   only its own scopes; installing beside unrelated awaited native scopes is
   unsafe. Existing in-place writers must not receive immutable bindings.
6. Reuse the existing single history timeline, camera policy and draft/gesture
   cancellation. Do not append a second Undo stack or generic binary snapshots.
7. Pass strict architecture, full npm, native hardware, stress and relevant large
   fixture gates against the exact integrated bytes before publication.

## Measured limits, not completion claims

The 100k-owner synthetic CPU run has 200001 native name/type/list records.
Completed rename + Undo + Redo touches one changed address, has zero readbacks,
and stays well below the 2 ms p95 test budget. `K.all` list edits remain O(N).
These are not UI frame timings, hardware latency or large polygon-memory proof.

Separate-process after-GC estimates for this simple fixture measured about
53.65 MiB for a plain mutable native Map versus 122.59 MiB for the immutable
store and its version bookkeeping (about 2.28x). Initial seed was 3.19 versus
4.62 seconds. These are synthetic retained JS heap estimates, not peak RAM or a
complete editor baseline. Reduced per-record closures helped, but minimal
large-scene memory degradation is **not established**. Optimize measured
bookkeeping/layout without weakening CAS, ownership or the single-authority rule.
GPU fork needs an extra sealing allocation/copy and hardware cost remains unmeasured.

This staged foundation adds code and removes no legacy authority yet. It must
not be presented as code reduction or an architecturally completed app.


## Live RAM-table timeline domain

The later timeline step removes mutable UI frame/range authority and its native
JSON synchronization. `timelineFrame` and `timelineTotal` are read-through global
handles into `scene.records`; Morph's normalized preview is editor state only.
Native rebuild carries the exact addressed scalar records. Existing chronological
Undo restores those records through the same native writer, but still obtains
its values from the legacy full-scene UI snapshot. There is no second history.

This step does not install this immutable factory, complete transaction/CAS
integration, or make the remaining history/plugin/clipboard domains compliant.
The strict gate still fails with ten real violations after the earlier Circuit
schema step. New guard cases detect reintroducing mutable UI time or regenerating
its JSON. Do not equate passing CPU domain checks with hardware/full-suite,
large-memory, or publication qualification.

## Documentation domain in the existing RAM table

The live Docs controller now uses the native literal text record `K.documentation`
(type 7) and native owner membership for reference inspection. Rebuild retains its
record identity. Its old global-JSON extraction, recreation and controller writer
have been removed. Strict text validation applies at Open and edit admission;
unsupported encodings remain opaque, ignored on reads and protected from writes.
Merge preflights destination writability before importing geometry. No former
JSON-property converter or second Docs state/history has been introduced.

This does not install the immutable SceneStore or remove the ten remaining strict
audit violations. Existing high-level Merge/history publication ordering remains
outside this domain step; the native literal writer alone is not proof of a
whole-command atomic transaction. GPU qualification and full standard/stress
results must name their exact source hashes separately from CPU evidence.

## Native per-owner record declarations

The live RAM-table path now persists field ownership/type declarations as native
`recordKeys` (type 4) and `recordTypes` (type 0) columns. The old unavailable-owner
WeakMap and JSON declaration property have been removed from persisted authority.
Retained rows derive from the canonical columns and opaque payload records.
One native namespace check serves Open, plugin-write admission and staged table
publication. Its reverse ID index invalidates on addressed ID-list mutation.
Unknown schema encodings and their partners remain raw, inactive and read-only.

This is a prerequisite for schema-driven Copy, not installation of that facade.
Do not set ownershipClosure/schemaRemap/recordDrivenProjection/identityReservations
or recordDeltaHistory true: full ownership/resource roles, semantic reservations,
shared scopes, atomic command projection and unified chronology remain incomplete.
The remaining strict migration defects still block architectural qualification.

Known ownership columns needed by uninterpreted/missing data are retained through
the existing managed-address policy even when their owner leaves the live owner
list, allowing native Delete/Undo restoration without a shadow metadata history.
This conservative orphan retention is not completed ownership-aware garbage
collection; resource/reference closure and high-level history still need the
unified store. New replaces the whole table normally.

## Live plugin-value domain

Live plugin-value reads now address the native table; writes replace its primitive
record and declaration columns after preflight/allocation. Shared value leases
retire the separate author-array mirror. Native Open validates owned arrays in
place. Numeric typed values are trusted read-only borrows; this existing native
RAM-map path does not provide the separate SceneStore's immutable RecordRefs.
The history restore DTO is transient and replaced by the shared native accessor.
It is still full decoded history, not addressed deltas. Do not enable any pending
capability flag or install the GPU adapter from this domain change.

The derived namespace cache invalidates only on native ID relationships, avoiding
O(owner-count) reindexing on unrelated plugin IDs/schema columns. CPU retained
memory/latency fixtures are separate from peak Open, live-editor and hardware
qualification. Strict audit still fails for nine real remaining domains. No waiver.
