import {objectFlagsHashChecks} from '../tests/hash-object-flags-browser.mjs';
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {launch,ready} from '../tools/browser.mjs';
import {canonicalHashChecks} from '../tests/hash-canonical-browser.mjs';
import {pluginChecks as atomicChecks} from '../plugins/atomic/tests/index.mjs';
import {pluginChecks as circuitChecks} from '../plugins/circuit/tests/index.mjs';
import {hashBestEffortBrowserChecks} from '../tests/hash-best-effort-browser.mjs';
const manifest=JSON.parse(await readFile(new URL('../QUALIFIED-SOURCE-SHA256.json',import.meta.url))),root=new URL('../',import.meta.url),sha=b=>createHash('sha256').update(b).digest('hex');
const expected=manifest;
const sources=async()=>Object.fromEntries(await Promise.all(Object.keys(expected).map(async name=>[name,sha(await readFile(new URL(name,root)))])));
const report={pass:false,runID:process.argv[2],started:new Date().toISOString(),kind:'Focused native checks; strict architecture migration remains incomplete',sources:await sources(),errors:[],consoleErrors:[]};let session;
const progress=async stage=>writeFile(new URL('native-progress.json',import.meta.url),JSON.stringify({runID:report.runID,indexSHA256:report.sources['index.html'],stage,at:new Date().toISOString()})+'\n');
try{
 assert.deepEqual(report.sources,expected);assert.match(report.runID,/^[a-f0-9]{32}$/);
 session=await launch({headless:true});const page=session.page;page.on('pageerror',e=>report.errors.push(e.stack));page.on('console',m=>{if(m.type()==='error')report.consoleErrors.push(m.text());});await ready(page);
 report.hardware=await page.evaluate(()=>{const d=frameEngine.renderer.device;window.__recordDevice=d;window.__recordGPU=[];window.__recordLost=null;d.pushErrorScope('validation');d.addEventListener('uncapturederror',e=>__recordGPU.push(e.error.message));d.lost.then(e=>__recordLost={reason:e.reason,message:e.message});return Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(k=>[k,d.adapterInfo[k]]));});
 assert.equal(report.hardware.isFallbackAdapter,false);assert.ok(!/swiftshader|llvmpipe/i.test(JSON.stringify(report.hardware)));
 await progress('canonical');report.canonical=await canonicalHashChecks(page);assert.ok(report.canonical.pass,report.canonical.error);
 await progress('object-flags');report.objectFlags=await objectFlagsHashChecks(page);assert.ok(report.objectFlags.pass,report.objectFlags.error);
 await progress('best-effort');report.bestEffort=await hashBestEffortBrowserChecks(page);assert.ok(report.bestEffort.pass,report.bestEffort.error);
 await progress('atomic');report.atomic=await atomicChecks(page);assert.ok(report.atomic.pass,report.atomic.error);
 await progress('circuit');report.circuit=await circuitChecks(page);assert.ok(report.circuit.pass,report.circuit.error);
 report.gpu=await page.evaluate(async()=>{await __recordDevice.queue.onSubmittedWorkDone();return {validation:(await __recordDevice.popErrorScope())?.message||null,uncaptured:__recordGPU,lost:__recordLost,replaced:__recordDevice!==frameEngine.renderer.device};});
 report.pass=!report.errors.length&&!report.consoleErrors.length&&!report.gpu.validation&&!report.gpu.uncaptured.length&&!report.gpu.lost&&!report.gpu.replaced;
}catch(error){report.error=error.stack||String(error);}finally{if(session&&!report.gpu)report.gpu=await session.page.evaluate(async()=>{await __recordDevice.queue.onSubmittedWorkDone();return {validation:(await __recordDevice.popErrorScope())?.message||null,uncaptured:__recordGPU,lost:__recordLost,replaced:__recordDevice!==frameEngine.renderer.device};}).catch(error=>({inspectionError:String(error)}));await session?.close();report.finished=new Date().toISOString();report.sourcesAfter=await sources();report.indexSHA256=report.sources['index.html'];if(JSON.stringify(report.sources)!==JSON.stringify(report.sourcesAfter)){report.pass=false;report.error='Source changed during native test';}await writeFile(new URL('native.json',import.meta.url),JSON.stringify(report,null,2));}
console.log(JSON.stringify({pass:report.pass,indexSHA256:report.indexSHA256,canonicalChecks:report.canonical?.checks.length,bestEffortChecks:report.bestEffort?.checks.length,error:report.error}));process.exitCode=report.pass?0:1;
