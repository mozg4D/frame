// Strict migration gate. Remaining violations are failures, not waived baselines.
// This targeted audit supplements source review and behavioral tests; it is not
// a proof that arbitrary future code cannot introduce another mutable authority.
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';

export function auditHashArchitecture({html,agents,app,plugins,circuit,atomic=''}){
  const violations=[];
  const add=(id,source,needle,reason)=>{const at=source.indexOf(needle);if(at>=0)violations.push({id,line:source.slice(0,at).split('\n').length,reason});};
  const require=(id,source,needle,reason)=>{if(!source.includes(needle))violations.push({id,line:null,reason});};
  add('mutable-ui-creation',html,'nodes.unshift(n)','Ordinary create still publishes an independent mutable UI node before native records.');
  const snapshotStart=html.indexOf('function snapshot(){'),snapshotEnd=html.indexOf('window.frameUIUndoBytes=',snapshotStart),snapshot=html.slice(snapshotStart,snapshotEnd);
  if(snapshotStart>=0&&/\bnodes\b/.test(snapshot))violations.push({id:'whole-scene-snapshot-history',line:html.slice(0,snapshotStart).split('\n').length,reason:'UI history still snapshots the complete decoded scene; JSON or a generic binary wrapper is not addressed record-delta history.'});
  add('ui-to-native-synchronization',html,'syncObjects(eligible.map(n=>','The retained UI tree still generates native object specs; non-name domains remain dual authority.');
  add('native-authoring-json',html,"JSON.stringify(authoring)",'Native object authoring still uses a JSON record instead of addressed typed properties.');
  add('native-global-json',html,"JSON.stringify(global)",'Global scene authoring still uses a JSON record.');
  add('mutable-plugin-bridge',html,'get nodes(){return nodes;}','Plugins still receive the mutable UI scene instead of read-through native handles.');
  add('mutable-plugin-records-atomic',atomic,'delete row.pluginRecords','Atomic must clear canonical records rather than deleting its read-through projection.');
  add('mutable-plugin-records',html,'(n.pluginRecords??={})[key]','Plugin writes still update a separate node.pluginRecords object.');
  require('plugin-value-read-through',html,"get(){return nativePluginRecords(this.nativeHash);}",'Plugin record projections must read the addressed table.');
  require('plugin-value-write-through',html,'window.frameEngine.setPluginRecord(hash,key,type,value)','Plugin values must write through native addressed fields.');
  add('duplicate-plugin-cpu-mirror',html,'type:record.type,author,value','Plugin leases must not retain both author arrays and native typed copies.');
  add('mutable-attribute-writes',html,'container[key]=next','Animation/field writes still mutate decoded parameter/tag containers.');
  add('decoded-scene-clipboard',html,'structuredClone(poseObjects().filter','Clipboard retains a decoded scene copy rather than an addressed native subdocument.');
  add('json-clone-source-cage',html,'JSON.parse(JSON.stringify(e))','Source cage logic retains JSON cloning.');
  add('mutable-timeline-authority',html,'let timelineFrame=','The converted timeline must not regain independent mutable UI time.');
  const timelineSync=html.slice(html.indexOf('    function installNativeRecords('),html.indexOf('    function deformationRevision('));
  if(/const global=\{[^;]*\b(?:frame|total):/.test(timelineSync))violations.push({id:'timeline-json-synchronization',line:null,reason:'Timeline time must remain addressed RAM data, not regenerated native JSON.'});
  add('circuit-json-authoring',circuit,'JSON.stringify(data)','Circuit authoring still writes a JSON scene record.');
  const codecStart=html.indexOf('function createFrameHashCodec(){'),codecEnd=html.indexOf('const FrameHash=createFrameHashCodec();',codecStart),codec=html.slice(codecStart,codecEnd);
  if(/\b(?:value|object|json|structured)\s*:\s*1\b/.test(codec))violations.push({id:'generic-object-low-type',line:html.slice(0,codecStart).split('\n').length,reason:'A generic value low type can conceal a nested scene tree; it needs removal, not an authoring exception.'});
  add('authoring-exception-doc',app,'intentional authoring exception','The project documentation grants a forbidden JSON scene exception.');
  add('missing-plugin-rejection-doc',plugins,'unknown plugin is rejected','Documentation still authorizes rejecting files solely because a plugin is unavailable.');
  require('mandatory-contract-doc',agents,'## Mandatory HASH architecture','Project instructions must state the non-negotiable architecture.');
  require('canonical-ram-ingest',html,'const transport=new Blob([await file.arrayBuffer()]),index=await hash.index(transport),records=new RecordMap();','The complete RAM-table ingestion path is missing.');
  require('unknown-ram-retention',html,'opaque:{encoding:entry.encoding,bytes}','Unsupported records need owned RAM bytes, not deletion or a source-file slice.');
  require('name-read-through',html,"get(){return nativeObjectName(this.nativeHash);}",'The converted native name path must remain a read-through property.');
  require('name-write-through',html,"nativePut(scene.records,hash,'name',FrameHash.T.text,value)",'The converted native name path must write the canonical addressed record.');
  for(const [name,bit]of [['visible',1],['enabled',2],['folded',4]]){
    require('object-'+name+'-read-through',html,'get(){return !!(nativeObjectFlags(this.nativeHash)&'+bit+');}','Object '+name+' must read native flags.');
    require('object-'+name+'-write-through',html,'set(value){nativeSetObjectFlag(this.nativeHash,'+bit+',value);}','Object '+name+' must write native flags.');
  }
  require('object-flags-ui-binding',html,'window.frameEngine?.bindObjectFlags(n);','Native flags must replace the UI projection after publication.');
  require('timeline-read-through',html,'read:()=>window.frameEngine?.timelineState?.()','Timeline UI handles must read the live native table.');
  require('timeline-write-through',html,'return window.frameEngine.setTimelineState(frame,total);','Timeline writes must target the live native table.');
  require('documentation-read-through',html,'read:()=>nativeDocumentationText()','Docs must read their native literal text field.');
  require('documentation-write-through',html,'write:nativeWriteDocumentation','Docs must write their native literal text field.');
  require('documentation-native-reference-lookup',html,'hasObject:hash=>!!scene?.nativeOwnerIds?.has(hash)','Docs reference lookup must use native owner membership.');
  require('native-record-declaration-columns',html,'FrameHashRecords.putSchema(records,o.hash,pluginRecords)','Record ownership declarations must use native addressed columns.');
  require('record-declarations-excluded-from-json',html,'const {recordValues,pluginRecords,...authoring}=preservedAuthoring','Record ownership declarations must not be serialized inside object JSON.');
  require('shared-native-namespace-validation',html,'for(const address of pluginAddresses.keys())FrameHashRecords.checkAddress(records,address)','File and edit namespace validation must share the addressed core schema.');
  add('documentation-json-synchronization',html,'global.documentation=','Docs must not be regenerated inside global JSON.');
  add('documentation-json-read',html,"JSON.parse(raw).documentation",'Docs must not read a nested JSON scene property.');
  const from=html.indexOf('function createFrameHashRecordTable(hash){'),to=html.indexOf('function createFrameHashCodec(){',from),store=html.slice(from,to);
  if(from<0||to<=from)violations.push({id:'missing-record-table',line:null,reason:'The central record table is missing.'});
  else{
    add('json-in-record-table',store,'JSON.','The canonical table must not introduce JSON encoding/decoding or clones.');
    add('lazy-source-table',store,'file.slice(','The retained canonical CPU table must not be backed by source-file slices.');
    add('linear-field-lookup',store,'.find(','HASH field access must use the address-keyed Map, not linear record search.');
    add('shadow-record-declarations',store,'unknownDeclarations=new WeakMap()','Record declarations must derive from canonical native columns, not a second owner map.');
  }
  return violations;
}

export async function runHashArchitectureAudit(root=new URL('../',import.meta.url)){
  const read=path=>readFile(new URL(path,root),'utf8');
  const [html,agents,app,plugins,circuit,atomic]=await Promise.all(['index.html','AGENTS.md','app.md','plugins.md','plugins/circuit/data.js','plugins/atomic/plugin.js'].map(read));
  return auditHashArchitecture({html,agents,app,plugins,circuit,atomic});
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
  const violations=await runHashArchitectureAudit();
  for(const v of violations)console.error(v.id+(v.line?' at line '+v.line:'')+': '+v.reason);
  console.log('HASH architecture violations: '+violations.length+'. Migration '+(violations.length?'INCOMPLETE':'gate passed')+'.');
  process.exitCode=violations.length?1:0;
}
