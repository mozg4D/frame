import assert from 'node:assert/strict';
import {hash,source} from './load-runtime.mjs';
const line=name=>{const found=source.split('\n').find(l=>l.trim().startsWith('function '+name+'('));assert.ok(found,name);return found;};
const section=(a,b)=>{const i=source.indexOf(a),j=source.indexOf(b,i);assert.ok(i>=0&&j>i,a);return source.slice(i,j);};
const table=new Function(section('function createFrameHashRecordTable(hash){','function createFrameHashCodec(){')+';return createFrameHashRecordTable;')()(hash);
const writable=source.match(/objectFlagsWritable:(.*?),bindPluginRecords/)[1];
const code=[line('nativeRecord'),line('nativePut'),line('nativeValue'),section('    const nativeNameViews=','    function nativeObjectFlags('),section('    function nativeObjectFlags(','    function nativeTimelineState(')].join('\n');
export function objectFlagEngine(records=new Map(),owners=[]){
 return new Function('FrameHash','FrameHashRecords','records','owners',`let scene={records,nativeOwnerIds:new Set(owners)},nativeIOBusy=false,sceneFrameDirty=false,poseRecordCache={records,objects:[]};${code};return {bind:bindObjectFlags,bindName:bindObjectName,read:nativeObjectFlags,write:nativeSetObjectFlag,check:nativeCheckObjectFlags,busy:value=>nativeIOBusy=value,swap:records=>scene={records,nativeOwnerIds:scene.nativeOwnerIds},writable:${writable},get cache(){return poseRecordCache},resetCache:()=>{poseRecordCache={records:scene.records,objects:[]};sceneFrameDirty=false;},get dirty(){return sceneFrameDirty},get records(){return scene.records}};`)(hash,table,records,owners);
}

export function nativeFlagRecords(owners){const {records}=table.begin();table.put(records,hash.K.all,{id:hash.K.all,type:hash.T.ids,value:owners});table.checkAddress(records,hash.address(owners[0],idForField()));return records;}
function idForField(){return '00000000000000000000000000000900';}
