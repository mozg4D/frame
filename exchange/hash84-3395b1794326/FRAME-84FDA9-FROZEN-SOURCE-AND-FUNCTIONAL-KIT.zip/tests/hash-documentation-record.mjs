import assert from 'node:assert/strict';
import test from 'node:test';
import {performance} from 'node:perf_hooks';
import {hash,source as html,id,opaqueBlock} from './load-runtime.mjs';
const section=(a,b)=>{const start=html.indexOf(a),end=html.indexOf(b,start);assert.ok(start>=0&&end>start,a);return html.slice(start,end);};
const docFactory=new Function(section('const FrameDocumentation=','const FramePlugins=')+';return FrameDocumentation;')();
const tableFactory=new Function(section('function createFrameHashRecordTable(hash){','function createFrameHashCodec(){')+';return createFrameHashRecordTable;')();
const {K,T}=hash,table=tableFactory(hash),helpers=section('    function nativeDocumentationText(','    function deformationRevision(');
const nativePut=html.split('\n').find(line=>line.trim().startsWith('function nativePut('));
function environment(records=new Map(),owners=new Set()){
 return new Function('FrameHash','FrameHashRecords','FrameDocumentation','records','owners',`
  let scene={records,nativeOwnerIds:owners},sceneFrameDirty=false,poseRecordCache=null;const events=[];
  function nativeRecord(id,type,value){return {id,type,value};}
  ${nativePut}\n${helpers}
  const docs=FrameDocumentation.create({read:()=>nativeDocumentationText(),write:nativeWriteDocumentation,hasObject:hash=>scene.nativeOwnerIds.has(hash),notify:state=>events.push(state),newEpoch:()=>String(events.length)});
  return {docs,events,read:nativeDocumentationText,check:nativeCheckDocumentationWrite,get records(){return scene.records;},get dirty(){return sceneFrameDirty;},replace:records=>scene={records,nativeOwnerIds:new Set()}};
 `)(hash,table,docFactory,records,owners);
}
test('Docs live in one addressed literal text record; unrelated global JSON is never touched',()=>{
 let globalReads=0;class Addressed extends Map{get(key){if(key===K.parameters)globalReads++;return super.get(key);}}
 const globals={id:K.parameters,type:T.text,value:'{"version":1,"materials":[],"uninterpreted":"literal"}'},records=new Addressed([[K.parameters,globals]]),e=environment(records),v=e.docs.get();
 e.docs.create({text:'Literal JSON is text: {"x":1}\nObject: '+id(1),version:v.version});
 assert.equal(records.get(K.documentation).type,T.text);assert.equal(records.get(K.documentation).value,e.docs.get().text);assert.equal(globalReads,0);assert.equal(Map.prototype.get.call(records,K.parameters),globals);
 e.docs.delete({version:e.docs.get().version});assert.equal(records.has(K.documentation),false);assert.equal(e.dirty,true);assert.equal(globalReads,0);
});
test('existing Doc CAS, Unicode edits and notifications use the actual native text writer',()=>{
 const e=environment(),before=e.docs.get();const created=e.docs.create({text:'Hello 😀',version:before.version});assert.throws(()=>e.docs.update({text:'stale',version:before.version}),/changed/);
 const next=e.docs.replace({start:0,end:5,expected:'Hello',text:'Привет',version:created.version});assert.equal(next.text,'Привет 😀');assert.equal(e.records.get(K.documentation).value,next.text);assert.equal(e.events.length,2);
 for(const text of ['bad\ud800','x'.repeat(docFactory.limit+1)]){const current=e.docs.get(),record=e.records.get(K.documentation);assert.throws(()=>e.docs.update({text,version:current.version}),/Invalid documentation/);assert.deepEqual(e.docs.get(),current);assert.equal(e.records.get(K.documentation),record);}
});
test('uninterpretable text stays raw and read-only, including no-op empty restore',()=>{
 const bytes=opaqueBlock(K.documentation,0x8040),opaque={id:K.documentation,type:64,opaque:{encoding:0x8040,bytes}},e=environment(new Map([[K.documentation,opaque]])),initial=e.docs.get();
 assert.equal(initial.text,'');assert.deepEqual(e.docs.update({text:'',version:initial.version}),initial);assert.throws(()=>e.docs.create({text:'Do not replace unknown bytes',version:initial.version}),/unsupported HASH/);
 assert.equal(e.records.get(K.documentation),opaque);assert.equal(e.events.length,0);assert.deepEqual(opaque.opaque.bytes,bytes);
});
test('native reference resolution uses owner membership, not UI rows or linear owner scans',()=>{
 const owners=new Set([id(1)]);owners[Symbol.iterator]=()=>{throw Error('No owner scan');};const e=environment(new Map(),owners);
 e.docs.create({text:'Object: '+id(1)+'\nObject: '+id(2)+'\nObject: invalid',version:e.docs.get().version});
 assert.deepEqual(e.docs.inspect().references.map(r=>r.status),['present','missing','invalid']);
 assert.ok(html.includes('hasObject:hash=>!!scene?.nativeOwnerIds?.has(hash)'));assert.ok(!section('const FrameDocumentation=','const FramePlugins=').includes('known.filter('));
});
test('an actual table replacement changes reads immediately; reset fences stale versions',()=>{
 const e=environment();e.docs.create({text:'Old',version:e.docs.get().version});const old=e.docs.get();e.replace(new Map([[K.documentation,{id:K.documentation,type:T.text,value:'New'}]]));assert.equal(e.docs.get().text,'New');e.docs.reset();assert.notEqual(e.docs.get().version,old.version);assert.throws(()=>e.docs.update({text:'Old draft',version:old.version}),/changed/);
});
test('Merge preflight rejects a Doc write to an opaque target before capture or copy publication',()=>{
 const start=html.indexOf('async function mergeFile('),end=html.indexOf('    async function loadHash(',start),source=html.slice(start,end),preflight=source.indexOf('nativeCheckDocumentationWrite(FrameDocumentation.merge('),upload=source.indexOf('await nativeDecodeMesh('),final=source.indexOf('nativeCheckDocumentationWrite(mergedDocumentation)'),commit=source.indexOf('commitObjectCopy(g)');
 assert.ok(preflight>=0&&preflight<upload);assert.ok(final>=0&&final<commit);
 const e=environment(new Map([[K.documentation,{id:K.documentation,type:64,opaque:{bytes:Uint8Array.of(1)}}]]));assert.throws(()=>e.check(docFactory.merge(e.docs.get().text,'Imported',new Map())),/unsupported HASH/);assert.equal(e.events.length,0);
});
test('known native text codec preserves Unicode, literal syntax and exact content',async()=>{
 const e=environment(),text='\0Literal JSON {"x":3}\n😀\nObject: '+id(1);e.docs.create({text,version:e.docs.get().version});const packed=await hash.pack(e.records.get(K.documentation)),ingested=await table.ingest(packed.blob),fresh=environment(ingested.records);assert.equal(fresh.docs.get().text,text);assert.equal(ingested.records.size,1);assert.equal(ingested.records.has(K.parameters),false);
});
test('Doc edits stay independent of a large unrelated metadata payload',()=>{
 const global={id:K.parameters,type:T.text,value:JSON.stringify({version:1,materials:[],padding:'x'.repeat(1048576)})};let touched=0;class Addressed extends Map{get(key){if(key===K.parameters)touched++;return super.get(key);}}
 const e=environment(new Addressed([[K.parameters,global]])),start=performance.now();for(let i=0;i<2000;i++)e.docs.update({text:'Doc '+i,version:e.docs.get().version});const elapsedMs=performance.now()-start;assert.equal(touched,0);assert.ok(elapsedMs<500,{elapsedMs});console.log(JSON.stringify({operation:'2000 Doc edits beside 1MiB unrelated metadata',elapsedMs,budgetMs:500,unrelatedMetadataReads:touched,scope:'Actual CPU controller/native writer, not browser/GPU qualification'}));
});
