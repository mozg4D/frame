'use strict';
const fs=require('node:fs'),path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
const start=html.indexOf('const createFrameSceneGPUVersions = (() => {'),end=html.indexOf('// One canonical addressed table',start);
if(start<0||end<=start)throw Error('Actual inline native GPU version adapter is missing');
module.exports=new Function(html.slice(start,end)+';return {createFrameSceneGPUVersions,createFrameNativeResourceRetainer};')();
