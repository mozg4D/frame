// Retain failure diagnostics too; the common happy path already captures once.
export async function collectFailureGPU(session,report){
 if(report.gpu)return;
 try{
  if(!session)throw Error('Browser session was not created');
  report.gpu=await session.page.evaluate(async()=>{
   const device=window.__frameGPUDevice;if(!device)throw Error('Validation scope was not installed');
   await device.queue.onSubmittedWorkDone();
   return {validation:(await device.popErrorScope())?.message||null,uncaptured:window.__frameGPU,lost:window.__frameGPULost,changed:device!==window.frameEngine.renderer.device};
  });
  if(report.gpu.validation||report.gpu.uncaptured?.length||report.gpu.lost||report.gpu.changed)report.pass=false;
 }catch(error){report.gpu={inspectionError:error.message||String(error)};report.pass=false;report.errors.push('GPU failure inspection: '+report.gpu.inspectionError);}
}
