// Independent current-format fixture writer, not an old-file reader/converter.
export function authoringRecords(hash,owner,metadata){
 const {pluginRecords,...core}=metadata,{T}=hash,rows=[{id:hash.address(owner,'parameters'),type:T.text,value:JSON.stringify(core)}];
 if(pluginRecords?.length)rows.push({id:hash.address(owner,'recordKeys'),type:T.ids,value:pluginRecords.map(r=>r.key)},{id:hash.address(owner,'recordTypes'),type:T.bytes,value:Uint8Array.from(pluginRecords,r=>r.type)});
 return rows;
}
export async function authoringBlob(hash,owner,metadata){return new Blob((await Promise.all(authoringRecords(hash,owner,metadata).map(r=>hash.pack(r)))).map(r=>r.blob));}
