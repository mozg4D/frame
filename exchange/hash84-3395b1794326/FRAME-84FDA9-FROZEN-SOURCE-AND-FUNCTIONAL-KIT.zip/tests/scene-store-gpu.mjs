import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createFrameSceneStore,createFrameSceneGPUVersions,hash,id} from './load-runtime.mjs';
const {fixture,deferred}=createRequire(import.meta.url)('./native-gpu-fixture.cjs');
const fails=code=>e=>e.code===code;
function runtime(){const f=fixture(),gpu=createFrameSceneGPUVersions(f.deps),store=createFrameSceneStore(hash,{gpu});return {f,gpu,store};}
async function original(store,f,{key=id(1),type=3,byteLength=16,count=4}={}){
  const source=f.buffer(16,Uint8Array.from({length:16},(_,i)=>i+1)),tx=store.begin('Capture');await tx.captureGPU(key,{resource:source,type,byteLength,count});tx.commit().delta.release();return {ref:store.records.get(key),source};
}
function binding(store,ref){const pin=store.pinVersions([ref]),use=pin.acquireUse('render');pin.release();return {resource:store.gpuBinding(ref,use),use};}

test('core/adaptor capture snapshots bytes before first await; no routine edit/copy readback',async()=>{
  const {f,store}=runtime(),source=f.buffer(16,Uint8Array.of(1,2,3,4)),tx=store.begin('Capture');const capture=tx.captureGPU(id(1),{resource:source,type:3,byteLength:16,count:4});f.data(source).fill(99);await capture;const result=tx.commit();result.delta.release();
  const r=store.records.get(id(1)),borrow=binding(store,r);assert.deepEqual([...f.data(borrow.resource).slice(0,4)],[1,2,3,4]);borrow.use.release();
  const metadata=store.begin('Rename');metadata.set(id(2),hash.T.text,'No readback');metadata.alias(id(3),r);metadata.commit().delta.release();assert.equal(f.readCalls,0);assert.equal(store.stats.readbacks,0);
});

test('active use survives clipboard ownership release, source replacement and collect',async()=>{
  const {f,store}=runtime(),{ref}=await original(store,f),pin=store.pinVersions([ref]),use=pin.acquireUse('paste');const resource=store.gpuBinding(ref,use);
  pin.release();store.replace();store.collect();assert.equal(f.states.get(resource).destroyed,false);assert.throws(()=>store.gpuBinding(ref),fails('ACTIVE_USE_REQUIRED'));
  assert.equal(store.gpuBinding(ref,use),resource);use.release();store.collect();assert.equal(f.states.get(resource).destroys,1);assert.throws(()=>store.gpuBinding(ref,use),fails('ACTIVE_USE_REQUIRED'));
});

test('transaction first-read lease keeps exact GPU version alive through concurrent edit and collection',async()=>{
  const {f,store}=runtime(),{ref}=await original(store,f),reader=store.begin('Read repeatable');reader.get(id(1));const borrow=binding(store,ref),old=borrow.resource;borrow.use.release();
  const replace=store.begin('Replace resource');replace.delete(id(1));replace.commit().delta.release();store.collect();assert.equal(f.states.get(old).destroyed,false);
  assert.equal(reader.get(id(1)),ref);const pin=store.pinVersions([reader.get(id(1))]);assert.equal(pin.records[0],ref);pin.release();reader.abort();store.collect();assert.equal(f.states.get(old).destroys,1);
});

test('GPU fork is staged COW; old content/Undo and sealed new content survive escaped staging mutation',async()=>{
  const {f,store}=runtime(),{ref}=await original(store,f),before=binding(store,ref);let escaped;
  const tx=store.begin('GPU edit');await tx.forkGPU(id(1),ref,({resource,encoder})=>{escaped=resource;encoder.write(resource,Uint8Array.of(90,91,92,93));});assert.equal(store.records.get(id(1)),ref);const receipt=tx.commit(),after=binding(store,store.records.get(id(1)));
  f.data(escaped).fill(17);assert.deepEqual([...f.data(after.resource).slice(0,4)],[90,91,92,93]);assert.deepEqual([...f.data(before.resource).slice(0,4)],[1,2,3,4]);
  store.replay(receipt.delta);assert.equal(store.records.get(id(1)),ref);store.replay(receipt.delta,'redo');assert.equal(f.readCalls,0);before.use.release();after.use.release();receipt.delta.release();store.replace();store.collect();assert.equal(f.scopes.length,0);
});

test('same-address pending GPU staging rejects newer CPU/GPU writes instead of completion-order loss',async()=>{
  const {f,store}=runtime(),wait=deferred();f.wait=wait;const tx=store.begin('Pending'),source=f.buffer(16),pending=tx.captureGPU(id(1),{resource:source,type:3,byteLength:16,count:4});
  assert.throws(()=>tx.set(id(1),hash.T.text,'Later write'),fails('STAGING_ADDRESS_BUSY'));assert.throws(()=>tx.delete(id(1)),fails('STAGING_ADDRESS_BUSY'));
  await assert.rejects(tx.captureGPU(id(1),{resource:source,type:3,byteLength:16,count:4}),fails('STAGING_ADDRESS_BUSY'));assert.equal(tx.pending,1);wait.resolve();await pending;tx.commit().delta.release();assert.equal(store.records.get(id(1)).residency,'gpu');
});

test('commit while GPU pending aborts publication; late staged allocation is disposed once',async()=>{
  const {f,store}=runtime(),wait=deferred();f.wait=wait;const tx=store.begin(),pending=tx.captureGPU(id(1),{resource:f.buffer(16),type:3,byteLength:16,count:4});assert.throws(()=>tx.commit(),fails('STAGING_PENDING'));assert.equal(store.records.size,0);wait.resolve();await assert.rejects(pending,fails('CLOSED_TRANSACTION'));
  assert.equal(f.allocated.filter(r=>f.states.get(r).destroyed).length,1);assert.equal(f.scopes.length,0);
});

test('stale source document during async staging disposes only staging, no new scene mutation',async()=>{
  const {f,store}=runtime(),wait=deferred();f.wait=wait;const tx=store.begin(),pending=tx.captureGPU(id(1),{resource:f.buffer(16),type:3,byteLength:16,count:4});store.replace();const fresh=store.begin();fresh.set(id(2),hash.T.text,'New document');fresh.commit().delta.release();wait.resolve();await assert.rejects(pending,fails('DOCUMENT_CHANGED'));tx.abort();assert.equal(store.records.size,1);assert.equal(store.scalar(id(2)),'New document');assert.equal(f.scopes.length,0);
});

test('explicit pinned export stays coherent during live replace/history trim and preserves Float32/byte padding',async()=>{
  const {f,store}=runtime();const floats=Float32Array.of(-0,1.25,-3.5),source=f.buffer(16,new Uint8Array(floats.buffer)),tx=store.begin();await tx.captureGPU(id(1),{resource:source,type:5,byteLength:12,count:3});await tx.captureGPU(id(2),{resource:f.buffer(16,Uint8Array.of(1,2,3,4,5,99,99,99)),type:0,byteLength:5,count:2});tx.commit().delta.release();
  const pin=store.pinAddresses([id(1),id(2)]),wait=deferred();f.readWait=wait;const task=store.exportRecords(pin);pin.release();store.replace();store.collect();wait.resolve();const blob=await task,index=await hash.index(blob),actual=await hash.read(blob,index.get(id(1)));
  assert.ok(Object.is(actual[0],-0));assert.deepEqual(actual,floats);assert.deepEqual(await hash.read(blob,index.get(id(2))),Uint8Array.of(1,2,3,4,5));store.collect();assert.equal(f.readCalls,2);assert.equal(store.stats.readbacks,2);assert.equal(f.scopes.length,0);
});

test('delta ownership trim cannot release GPU versions still held by another active use',async()=>{
  const {f,store}=runtime(),{ref}=await original(store,f),tx=store.begin('Delete');tx.delete(id(1));const delta=tx.commit().delta,pin=delta.acquireUse('history observer');delta.release();const resource=store.gpuBinding(ref,pin);store.collect();assert.equal(f.states.get(resource).destroyed,false);assert.throws(()=>store.replay(delta),fails('INVALID_DELTA'));pin.release();store.collect();assert.equal(f.states.get(resource).destroys,1);
});

test('GPU adapter validation failure leaves the canonical table and prior version unchanged',async()=>{
  const {f,store}=runtime(),{ref}=await original(store,f),tx=store.begin('Failed fork');await assert.rejects(tx.forkGPU(id(1),ref,()=>{f.scopedError('validation','Bad compute');}),fails('GPU_VALIDATION'));tx.abort();store.collect();assert.equal(store.records.get(id(1)),ref);assert.equal(store.revision,1);assert.equal(f.readCalls,0);assert.equal(f.scopes.length,0);
});


test('binding rejects unrelated/foreign use, wrong exact alias ref and stale GPU epoch',async()=>{
  const {f,gpu,store}=runtime(),{ref}=await original(store,f),tx=store.begin();tx.alias(id(2),ref);tx.commit().delta.release();const pin=store.pinAddresses([id(2)]),use=pin.acquireUse('render');pin.release();assert.throws(()=>store.gpuBinding(ref,use),fails('ACTIVE_USE_REQUIRED'));
  const other=createFrameSceneStore(hash,{gpu}),otherTx=other.begin();await otherTx.captureGPU(id(1),{resource:f.buffer(16),type:3,byteLength:16,count:4});otherTx.commit().delta.release();const foreign=other.pinAddresses([id(1)]),foreignUse=foreign.acquireUse('render');foreign.release();assert.throws(()=>store.gpuBinding(store.records.get(id(2)),foreignUse),fails('ACTIVE_USE_REQUIRED'));
  f.active={...f.gpu};assert.throws(()=>store.gpuBinding(store.records.get(id(2)),use),fails('STALE_DEVICE_EPOCH'));use.release();foreignUse.release();store.replace();other.replace();store.collect();other.collect();
});

test('abort during paused GPU fork disposes late sealed allocation once and leaves old record unchanged',async()=>{
  const {f,store}=runtime(),{ref}=await original(store,f),pause=deferred(),started=deferred(),tx=store.begin('Paused fork');const task=tx.forkGPU(id(1),ref,async({resource,encoder})=>{started.resolve();await pause.promise;encoder.write(resource,Uint8Array.of(99));});await started.promise;tx.abort();tx.abort();pause.resolve();await assert.rejects(task,fails('CLOSED_TRANSACTION'));assert.equal(store.records.get(id(1)),ref);assert.equal(f.readCalls,0);
  store.replace();store.collect();for(const resource of f.allocated)assert.ok(f.states.get(resource).destroys<=1);assert.equal(f.scopes.length,0);
});
