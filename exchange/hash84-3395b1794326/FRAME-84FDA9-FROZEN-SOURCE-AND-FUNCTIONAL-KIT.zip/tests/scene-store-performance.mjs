import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {createFrameSceneStore,hash,id} from './load-runtime.mjs';
const percentile=(xs,p)=>xs.toSorted((a,b)=>a-b)[Math.min(xs.length-1,Math.floor(xs.length*p))];
const timed=action=>{const start=performance.now();const result=action();return {ms:performance.now()-start,result};};
const reports=[];
for(const count of [1000,10000,100000]){
  const store=createFrameSceneStore(hash),owners=Array.from({length:count},(_,i)=>id(i+1));
  const seed=timed(()=>{const tx=store.begin('Native name/type seed');tx.set(hash.K.all,hash.T.ids,owners);for(const owner of owners){tx.set(hash.address(owner,'name'),hash.T.text,'Object '+owner);tx.set(hash.address(owner,'type'),hash.T.bytes,Uint8Array.of(0));}const r=tx.commit();r.delta.release();});
  assert.equal(store.records.size,1+count*2);global.gc?.();
  const readbacks=store.stats.readbacks,visited=store.stats.visitedRecords,latencies=[],names=owners.slice(0,Math.min(2000,count)).map(owner=>hash.address(owner,'name'));
  for(let i=0;i<names.length;i++){
    const t=timed(()=>{const tx=store.begin('Rename');tx.set(names[i],hash.T.text,'New name '+i);const r=tx.commit();assert.equal(r.delta.entries.length,1);store.replay(r.delta);store.replay(r.delta,'redo');r.delta.release();});latencies.push(t.ms);
  }
  assert.equal(store.stats.visitedRecords-visited,names.length,'metadata visits exactly its changed address');assert.equal(store.stats.readbacks,readbacks);
  const pinCount=Math.min(count,10000),pinTime=timed(()=>{const pin=store.pinAddresses(names.slice(0,pinCount));const use=pin.acquireUse('paste');pin.release();assert.equal(use.records.length,names.length);use.release();});
  const abortTime=timed(()=>{const tx=store.begin('Staging/cancel');tx.reserveAddresses(Array.from({length:1000},(_,i)=>id(BigInt(count)+1000000n+BigInt(i))));for(let i=0;i<1000;i++)tx.set(id(BigInt(count)+1000000n+BigInt(i)),hash.T.text,'New');tx.abort();});
  const listTime=timed(()=>{const tx=store.begin('Existing native K.all update');tx.set(hash.K.all,hash.T.ids,[...owners,id(count+1)]);const r=tx.commit();assert.equal(r.delta.entries.length,1);store.replay(r.delta);r.delta.release();});
  const p95=percentile(latencies,.95);assert.ok(p95<2,`complete rename+Undo+Redo p95 ${p95} ms exceeds 2 ms budget`);assert.ok(pinTime.ms<100,'2k immutable pin/use/release budget 100 ms');assert.ok(abortTime.ms<200,'1k reservation/staging/abort budget 200 ms');assert.ok(listTime.ms<250,'100k root-list update/Undo budget 250 ms');
  reports.push({owners:count,records:store.records.size,seedMs:+seed.ms.toFixed(3),renameUndoRedo:{samples:latencies.length,p50Ms:+percentile(latencies,.5).toFixed(4),p95Ms:+p95.toFixed(4),maxMs:+Math.max(...latencies).toFixed(4)},pinUseReleaseMs:+pinTime.ms.toFixed(3),reserved1000CancelMs:+abortTime.ms.toFixed(3),nativeRootListEditUndoMs:+listTime.ms.toFixed(3),gpuReadbacks:store.stats.readbacks,heapUsedMiB:+(process.memoryUsage().heapUsed/1048576).toFixed(1)});
  store.replace();store.collect();global.gc?.();
}
console.log(JSON.stringify({kind:'synthetic CPU, no hardware or UI frames',budgets:{renameUndoRedoP95Ms:2,pinUseReleaseMs:100,reserved1000CancelMs:200,nativeRootListEditUndoMs:250},reports},null,2));
