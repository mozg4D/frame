import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {auditHashArchitecture,runHashArchitectureAudit} from './hash-architecture-audit.mjs';
const read=path=>readFile(new URL('../'+path,import.meta.url),'utf8');
const [html,agents,app,plugins,circuit]=await Promise.all(['index.html','AGENTS.md','app.md','plugins.md','plugins/circuit/data.js'].map(read));

test('strict audit does not mistake the vertical slice for the completed migration',async()=>{
  const result=await runHashArchitectureAudit(),ids=new Set(result.map(v=>v.id));
  for(const id of ['mutable-ui-creation','whole-scene-snapshot-history','ui-to-native-synchronization','native-authoring-json','native-global-json','mutable-plugin-bridge','mutable-attribute-writes','decoded-scene-clipboard','json-clone-source-cage'])assert.ok(ids.has(id),id);
  assert.ok(!ids.has('mutable-plugin-records'),'Live plugin values are read-through native fields; legacy scene history remains a separate failure');
  assert.ok(!ids.has('circuit-json-authoring'),'Circuit primitive columns removed its own JSON writer, without waiving other paths');
  for(const id of ['mandatory-contract-doc','canonical-ram-ingest','unknown-ram-retention','name-read-through','name-write-through','timeline-read-through','timeline-write-through','mutable-timeline-authority','timeline-json-synchronization','json-in-record-table','lazy-source-table','linear-field-lookup','authoring-exception-doc','missing-plugin-rejection-doc'])assert.ok(!ids.has(id),id);
});
test('a generic binary scene snapshot or low type is not mistaken for canonical HASH migration',()=>{
  const changed=html.replace('function snapshot(){return JSON.stringify','function snapshot(){return FrameValue.encode').replace('const T=Object.freeze({bytes:0,','const T=Object.freeze({value: 1,bytes:0,');
  const ids=new Set(auditHashArchitecture({html:changed,agents,app,plugins,circuit}).map(v=>v.id));
  assert.ok(ids.has('whole-scene-snapshot-history'));assert.ok(ids.has('generic-object-low-type'));
});
test('contract regressions and new record-table escapes are detected rather than waived',()=>{
  const changed=html.replace('function createFrameHashRecordTable(hash){','function createFrameHashRecordTable(hash){ JSON.stringify({}); file.slice(0); [].find(()=>true);');
  const ids=new Set(auditHashArchitecture({html:changed,agents:'',app:app+' intentional authoring exception',plugins:plugins+' unknown plugin is rejected',circuit}).map(v=>v.id));
  for(const id of ['mandatory-contract-doc','json-in-record-table','lazy-source-table','linear-field-lookup','authoring-exception-doc','missing-plugin-rejection-doc'])assert.ok(ids.has(id),id);
});

test('Circuit JSON writer regression remains a blocking violation after native-column migration',()=>{
  const ids=new Set(auditHashArchitecture({html,agents,app,plugins,circuit:circuit+'\nconst encoded=JSON.stringify(data);'}).map(v=>v.id));
  assert.ok(ids.has('circuit-json-authoring'));
});
test('restoring a mutable UI clock and native JSON timeline is a blocking regression',()=>{
  const changed=html+'\nlet timelineFrame=0;';
  const ids=new Set(auditHashArchitecture({html:changed.replace('const global={version:1,materials:','const global={version:1,frame:0,total:120,materials:'),agents,app,plugins,circuit}).map(v=>v.id));
  assert.ok(ids.has('mutable-timeline-authority'));assert.ok(ids.has('timeline-json-synchronization'));
});

test('Docs cannot regain JSON storage or a UI owner scan',()=>{
  const changed=html.replace('read:()=>nativeDocumentationText()','read:()=>JSON.parse(raw).documentation').replace('write:nativeWriteDocumentation','write:text=>global.documentation=text').replace('hasObject:hash=>!!scene?.nativeOwnerIds?.has(hash)','objects:()=>nodes');
  const ids=new Set(auditHashArchitecture({html:changed,agents,app,plugins,circuit}).map(v=>v.id));
  for(const id of ['documentation-read-through','documentation-write-through','documentation-native-reference-lookup','documentation-json-synchronization','documentation-json-read'])assert.ok(ids.has(id),id);
  const current=new Set(auditHashArchitecture({html,agents,app,plugins,circuit}).map(v=>v.id));
  for(const id of ['documentation-read-through','documentation-write-through','documentation-native-reference-lookup','documentation-json-synchronization','documentation-json-read'])assert.ok(!current.has(id),id);
});
test('native record declarations cannot regain JSON or a shadow owner map',()=>{
  const changed=html.replace('const {recordValues,pluginRecords,...authoring}=preservedAuthoring','const {recordValues,...authoring}=preservedAuthoring').replace('function createFrameHashRecordTable(hash){','function createFrameHashRecordTable(hash){const unknownDeclarations=new WeakMap();');
  const ids=new Set(auditHashArchitecture({html:changed,agents,app,plugins,circuit}).map(v=>v.id));
  assert.ok(ids.has('record-declarations-excluded-from-json'));assert.ok(ids.has('shadow-record-declarations'));
  const current=new Set(auditHashArchitecture({html,agents,app,plugins,circuit}).map(v=>v.id));
  for(const id of ['record-declarations-excluded-from-json','shadow-record-declarations','native-record-declaration-columns','shared-native-namespace-validation'])assert.ok(!current.has(id),id);
});

 test('plugin values cannot regain a UI writer, lose native views or retain a CPU mirror',()=>{
 const changed=html.replace('get(){return nativePluginRecords(this.nativeHash);}','get(){return this.savedPluginRecords;}').replace('window.frameEngine.setPluginRecord(hash,key,type,value)','(n.pluginRecords??={})[key]={type,value};').replace('type:record.type,value,bytes:', 'type:record.type,author,value,bytes:');
 const ids=new Set(auditHashArchitecture({html:changed,agents,app,plugins,circuit}).map(v=>v.id));
 for(const id of ['mutable-plugin-records','plugin-value-read-through','plugin-value-write-through','duplicate-plugin-cpu-mirror'])assert.ok(ids.has(id),id);
 });

 test('Atomic cannot delete a projection to remove authored native records',()=>{
 const ids=new Set(auditHashArchitecture({html,agents,app,plugins,circuit,atomic:'delete row.pluginRecords;'}).map(v=>v.id));assert.ok(ids.has('mutable-plugin-records-atomic'));
 });


test('native flag views and binding cannot regress into mutable per-row booleans',()=>{
 const changed=html.replace('get(){return !!(nativeObjectFlags(this.nativeHash)&1);}','get(){return this.savedVisible;}').replace('set(value){nativeSetObjectFlag(this.nativeHash,2,value);}','set(value){this.savedEnabled=value;}').replaceAll('window.frameEngine?.bindObjectFlags(n);','');
 const ids=new Set(auditHashArchitecture({html:changed,agents,app,plugins,circuit}).map(v=>v.id));for(const id of ['object-visible-read-through','object-enabled-write-through','object-flags-ui-binding'])assert.ok(ids.has(id),id);
});
