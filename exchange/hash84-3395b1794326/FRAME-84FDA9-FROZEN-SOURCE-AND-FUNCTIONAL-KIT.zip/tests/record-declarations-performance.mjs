import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {createHash} from 'node:crypto';
import {hash,source as html,id} from './load-runtime.mjs';
assert.equal(typeof global.gc,'function','Run with --expose-gc');
const from=html.indexOf('function createFrameHashRecordTable(hash){'),to=html.indexOf('function createFrameHashCodec(){',from);
const table=new Function(html.slice(from,to)+';return createFrameHashRecordTable;')()(hash),{K,T}=hash;
const measure=tagsPerOwner=>{
 const owners=Array.from({length:100000},(_,i)=>id(i+1)),{records}=table.begin();table.put(records,K.all,{id:K.all,type:T.ids,value:owners});
 if(tagsPerOwner)for(let i=0;i<owners.length;i++){const address=hash.address(owners[i],'tags');table.put(records,address,{id:address,type:T.ids,value:[id(100001+i)]});}
 const address=hash.address(owners[0],'d396752c6a1e450b9cd8d90f797b8bb1');global.gc();const before=process.memoryUsage().heapUsed,start=performance.now();table.checkAddress(records,address);const coldMs=performance.now()-start;
 const hotStart=performance.now();for(let i=0;i<10000;i++)table.checkAddress(records,address);const hot10000Ms=performance.now()-hotStart;global.gc();const indexMiB=(process.memoryUsage().heapUsed-before)/1048576;
 assert.ok(coldMs<1500,{coldMs});assert.ok(hot10000Ms<1500,{hot10000Ms});assert.ok(indexMiB<8,{indexMiB});
 return {owners:owners.length,tagsPerOwner,coldMs,hot10000Ms,indexMiB,budgets:{coldMs:1500,hot10000Ms:1500,indexMiB:8}};
};
console.log(JSON.stringify({pass:true,indexSHA256:createHash('sha256').update(html).digest('hex'),scope:'Actual namespace index on synthetic CPU ID relationships; after-GC incremental heap, not peak RAM, complete editor memory or hardware/GPU qualification. Fixture/address-cache allocation precedes the baseline.',cases:[measure(0),measure(1)]}));
