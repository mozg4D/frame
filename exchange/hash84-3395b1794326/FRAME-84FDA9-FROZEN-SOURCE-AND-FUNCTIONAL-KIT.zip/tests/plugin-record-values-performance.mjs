// Actual addressed writer, not a hardware or peak Open qualification.
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {createHash} from 'node:crypto';
import {hash,source,id} from './load-runtime.mjs';
if(!global.gc)throw Error('Run with --expose-gc');
const a=source.indexOf('function createFrameHashRecordTable(hash){'),b=source.indexOf('function createFrameHashCodec(){',a);
const table=new Function(source.slice(a,b)+';return createFrameHashRecordTable;')()(hash),{records}=table.begin(),owner=id(1),key=id(100001),small=id(100002);
table.put(records,hash.K.all,{id:hash.K.all,type:hash.T.ids,value:Array.from({length:100000},(_,i)=>id(i+1))});
const from=source.indexOf('    function nativePluginRecords('),to=source.indexOf('    const nativeNameViews=',from),write=new Function('FrameHashRecords','initial',`let scene={records:initial},nativeIOBusy=false,sceneFrameDirty=false,poseRecordCache=null;${source.slice(from,to)};return nativeSetPluginRecord;`)(table,records);
const input=Float64Array.from({length:1000000},(_,i)=>i+0.25);global.gc();const before=process.memoryUsage();
const start=performance.now();write(owner,key,hash.T.float64,input);const writeMs=performance.now()-start;
const canonical=records.get(hash.address(owner,key)).value;assert.notEqual(canonical,input);assert.equal(canonical.length,input.length);
records[Symbol.iterator]=()=>{throw Error('No full-table cloning for a field write');};
const hot=performance.now();for(let i=0;i<500;i++)write(owner,small,hash.T.uint32,Uint32Array.of(i));const replace500Ms=performance.now()-hot;
global.gc();const after=process.memoryUsage(),retainedMiB=(after.heapUsed-before.heapUsed+after.arrayBuffers-before.arrayBuffers)/1048576;
assert.ok(writeMs<1500,{writeMs,budgetMs:1500});assert.ok(replace500Ms<1500,{replace500Ms,budgetMs:1500});assert.ok(retainedMiB<20,{retainedMiB,budgetMiB:20});
assert.equal(records.get(hash.address(owner,key)).value,canonical);assert.equal(input[0],0.25);
console.log(JSON.stringify({pass:true,indexSHA256:createHash('sha256').update(source).digest('hex'),owners:100000,values:1000000,writeMs,replace500Ms,retainedMiB,budgets:{writeMs:1500,replace500Ms:1500,retainedMiB:20},rssMiB:after.rss/1048576,processPeakRssMiB:process.resourceUsage().maxRSS/1024,scope:'Actual native field writer + namespace index on synthetic CPU data, retained heap/ArrayBuffers after GC. Caller input and owner-ID fixture precede baseline. Not live-editor or peak Open/GPU memory.'}));
