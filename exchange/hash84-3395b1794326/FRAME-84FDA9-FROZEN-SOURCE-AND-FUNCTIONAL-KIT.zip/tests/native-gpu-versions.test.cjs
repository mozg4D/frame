'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const {createFrameSceneGPUVersions} = require('./load-gpu-runtime.cjs');

const {fixture, deferred} = require('./native-gpu-fixture.cjs');

const bytes = value => Array.from(value);

test('capture submits a private snapshot and holds native lifetime before the first await', async () => {
  const f = fixture(), source = f.buffer(16, [1, 2, 3, 4]), gate = deferred();
  f.wait = gate;
  const pending = f.capture(source);
  assert.equal(f.leases.get(source).count, 1);
  assert.equal(f.events.filter(x => x === 'submit').length, 1);
  assert.equal(f.scopes.length, 0, 'capture scopes popped synchronously');
  f.device.queue.writeBuffer(source, 0, new Uint8Array([9, 9, 9, 9]));
  f.releaseGPU(source);
  assert.equal(f.states.get(source).destroyed, false, 'retired source survives while copy pending');
  gate.resolve();
  const version = await pending;
  f.wait = null;
  assert.equal(f.states.get(source).destroyed, true);
  assert.deepEqual(Object.keys(version), ['deviceEpoch', 'type', 'byteLength', 'count']);
  assert.ok(Object.isFrozen(version));
  assert.ok(Object.isFrozen(f.adapter.binding(version)));
  assert.notEqual(f.adapter.binding(version), source);
  assert.deepEqual(bytes(await f.adapter.readback(version)).slice(0, 4), [1, 2, 3, 4]);
  assert.equal(f.adapter.validate(version), true);
  assert.equal(f.adapter.dispose(version), true);
  assert.equal(f.adapter.dispose(version), false);
});

test('fork seals writable staging; old bytes and published bytes survive escaped staging mutation', async () => {
  const f = fixture(), original = await f.capture(f.buffer(16, [1, 2, 3, 4]));
  const gate = deferred(), started = deferred();
  let escaped;
  const pending = f.adapter.fork(original, async ({gpu, resource, encoder}) => {
    assert.equal(gpu, f.gpu); escaped = resource;
    encoder.write(resource, new Uint8Array([7, 8])); started.resolve();
    await gate.promise;
  });
  await started.promise;
  assert.equal(f.readCalls, 0, 'capture and fork do not read geometry back');
  assert.deepEqual(bytes(f.data(f.adapter.binding(original))).slice(0, 4), [1, 2, 3, 4]);
  gate.resolve();
  const version = await pending;
  assert.notEqual(f.adapter.binding(version), escaped);
  assert.equal(f.states.get(escaped).destroyed, true);
  assert.throws(() => f.device.queue.writeBuffer(escaped, 0, new Uint8Array([0, 0])));
  // Even a deliberately hostile mock bypass of destruction hits different storage.
  f.data(escaped).fill(99);
  assert.deepEqual(bytes(await f.adapter.readback(version)).slice(0, 4), [7, 8, 3, 4]);
  assert.deepEqual(bytes(await f.adapter.readback(original)).slice(0, 4), [1, 2, 3, 4]);
  assert.equal(f.scopes.length, 0);
});

test('fork and readback each lease synchronously and survive concurrent dispose', async () => {
  const f = fixture(), version = await f.capture(f.buffer(16, [1, 2, 3, 4]));
  const resource = f.adapter.binding(version), gate = deferred();
  f.readWait = gate;
  const read = f.adapter.readback(version);
  const fork = f.adapter.fork(version, async ({resource, encoder}) => {
    encoder.write(resource, new Uint8Array([8]));
  });
  assert.equal(f.leases.get(resource).count, 2);
  f.adapter.dispose(version);
  assert.equal(f.states.get(resource).destroyed, false);
  gate.resolve();
  assert.equal((await read)[0], 1);
  const child = await fork;
  assert.equal(f.states.get(resource).destroys, 1);
  assert.equal((await f.adapter.readback(child))[0], 8);
  assert.throws(() => f.adapter.validate(version), {code: 'DISPOSED_GPU_VERSION'});
});

test('bytes/face masks preserve exact byteLength while native word padding is excluded', async () => {
  const f = fixture();
  const version = await f.capture(f.buffer(16, [1, 2, 3, 4, 5, 99, 99, 99]), {type: 0, byteLength: 5, count: 2});
  const one = await f.adapter.readback(version);
  assert.deepEqual(bytes(one), [1, 2, 3, 4, 5]);
  one.fill(0);
  assert.deepEqual(bytes(await f.adapter.readback(version)), [1, 2, 3, 4, 5]);
  const empty = await f.capture(f.buffer(4), {type: 0, byteLength: 0, count: 0});
  assert.equal((await f.adapter.readback(empty)).byteLength, 0);
});

test('paged textures and float bit patterns reuse the native copy path', async () => {
  const f = fixture(), raw = new Uint8Array(40);
  const words = new Uint32Array(raw.buffer); words.set([0x80000000, 0x7fc12345, 0x3f800000]);
  const source = f.texture(10, raw);
  const version = await f.capture(source, {type: 5, count: 10, byteLength: 40});
  const binding = f.adapter.binding(version);
  assert.equal(binding.kind, 'texture');
  assert.notEqual(binding.texture, source.texture);
  assert.ok(Object.isFrozen(binding));
  assert.throws(() => { binding.texture = source.texture; }, TypeError);
  assert.deepEqual(bytes(await f.adapter.readback(version)), bytes(raw));
  const child = await f.adapter.fork(version, async ({resource, encoder}) => {
    encoder.write(resource, new Uint8Array([9]), 36);
  });
  assert.equal((await f.adapter.readback(child))[36], 9);
  assert.equal((await f.adapter.readback(version))[36], 0);
});

test('malformed metadata/resources are rejected before retaining or allocating', async () => {
  const f = fixture(), resource = f.buffer();
  const inputs = [
    {type: 6}, {type: 'float32'}, {count: -1}, {count: 1.5}, {byteLength: 15},
    {count: Number.MAX_SAFE_INTEGER, byteLength: 4},
    {type: 0, byteLength: 5, count: 1}, {type: 0, byteLength: 5, count: 3},
    {byteLength: 20, count: 5}, {resource: {size: 16, usage: 12}}
  ];
  for (const input of inputs) await assert.rejects(f.capture(resource, input));
  assert.equal(f.leases.get(resource), undefined);
  assert.equal(f.allocated.length, 1);
  const badTexture = f.texture(4); badTexture.format = 'rgba32uint';
  await assert.rejects(f.capture(badTexture), {code: 'INVALID_GPU_RESOURCE'});
  assert.equal(f.scopes.length, 0);
});

test('foreign/forged versions are rejected even when metadata matches', async () => {
  const f = fixture(), version = await f.capture();
  const other = createFrameSceneGPUVersions(f.deps);
  for (const forged of [{...version}, null, 3]) {
    assert.throws(() => f.adapter.binding(forged), {code: 'INVALID_GPU_VERSION'});
    await assert.rejects(f.adapter.readback(forged), {code: 'INVALID_GPU_VERSION'});
  }
  assert.throws(() => other.validate(version), {code: 'INVALID_GPU_VERSION'});
});

test('session/device replacement and device loss invalidate exact owned versions', async () => {
  const f = fixture(), original = await f.capture();
  f.active = {...f.gpu};
  assert.throws(() => f.adapter.binding(original), {code: 'STALE_DEVICE_EPOCH'});
  assert.equal(f.adapter.dispose(original), true, 'stale versions remain disposable');
  const next = await f.capture();
  assert.notEqual(next.deviceEpoch, original.deviceEpoch);
  f.lost.resolve({reason: 'destroyed'}); await Promise.resolve();
  assert.throws(() => f.adapter.validate(next), {code: 'STALE_DEVICE_EPOCH'});
  f.adapter.dispose(next);
});

test('capture refuses publication after an epoch switch while completion is pending', async () => {
  const f = fixture(), gate = deferred(), source = f.buffer(); f.wait = gate;
  const pending = f.capture(source); f.active = {...f.gpu}; gate.resolve();
  await assert.rejects(pending, {code: 'STALE_DEVICE_EPOCH'});
  assert.equal(f.states.get(f.allocated[1]).destroys, 1);
  assert.equal(f.leases.get(source), undefined);
  assert.equal(f.scopes.length, 0);
});

test('fork refuses publication on epoch change across an awaited callback', async () => {
  const f = fixture(), source = await f.capture(), gate = deferred(), started = deferred();
  const pending = f.adapter.fork(source, async () => { started.resolve(); await gate.promise; });
  await started.promise; f.active = {...f.gpu}; gate.resolve();
  await assert.rejects(pending, {code: 'STALE_DEVICE_EPOCH'});
  assert.equal(f.allocated.length, 3, 'no sealed allocation after stale callback');
  assert.equal(f.states.get(f.allocated[2]).destroys, 1);
  assert.equal(f.scopes.length, 0);
});

for (const kind of ['validation', 'out-of-memory']) {
  test('capture balances both scopes and cleans up on ' + kind, async () => {
    const f = fixture(), source = f.buffer();
    const copy = f.deps.copyResource;
    const adapter = createFrameSceneGPUVersions({...f.deps, copyResource(...args) {
      copy(...args); f.scopedError(kind, 'forced ' + kind);
    }});
    await assert.rejects(adapter.capture({resource: source, type: 3, count: 4, byteLength: 16}), {
      code: kind === 'validation' ? 'GPU_VALIDATION' : 'GPU_OUT_OF_MEMORY'
    });
    assert.equal(f.scopes.length, 0);
    assert.equal(f.states.get(f.allocated[1]).destroys, 1);
    assert.equal(f.leases.get(source), undefined);
  });
  test('fork catches callback ' + kind + ' and retires staging/sealed allocations', async () => {
    const f = fixture(), version = await f.capture();
    await assert.rejects(f.adapter.fork(version, async () => {
      await Promise.resolve(); f.scopedError(kind, 'forced ' + kind);
    }), {code: kind === 'validation' ? 'GPU_VALIDATION' : 'GPU_OUT_OF_MEMORY'});
    assert.equal(f.scopes.length, 0);
    assert.equal(f.states.get(f.allocated[2]).destroys, 1);
    assert.equal(f.states.get(f.allocated[3]).destroys, 1);
    assert.equal(f.adapter.validate(version), true);
  });
}

for (const fault of ['allocation', 'submit', 'queue', 'pop']) {
  test('capture cleans up on ' + fault + ' failure', async () => {
    const f = fixture(), source = f.buffer(), error = Error('forced ' + fault);
    f.faults[fault] = error;
    await assert.rejects(f.capture(source), value => value === error);
    assert.equal(f.scopes.length, 0);
    assert.equal(f.leases.get(source), undefined);
    for (const resource of f.allocated.slice(1)) assert.equal(f.states.get(resource).destroys, 1);
  });
}

test('scope-pop rejection still waits for submitted work before releasing retired source', async () => {
  const f = fixture(), gate = deferred(), source = f.buffer();
  f.wait = gate; f.faults.pop = Error('pop failed');
  const pending = f.capture(source); f.releaseGPU(source);
  await Promise.resolve(); await Promise.resolve();
  assert.equal(f.scopes.length, 0);
  assert.equal(f.states.get(source).destroyed, false);
  gate.resolve(); await assert.rejects(pending, /pop failed/);
  assert.equal(f.states.get(source).destroys, 1);
});

test('throwing staging callback retires only unpublished allocation and preserves old version', async () => {
  const f = fixture(), version = await f.capture(f.buffer(16, [3]));
  await assert.rejects(f.adapter.fork(version, async ({resource, encoder}) => {
    encoder.write(resource, new Uint8Array([8])); throw Error('write failed');
  }), /write failed/);
  assert.equal(f.scopes.length, 0);
  assert.equal(f.states.get(f.allocated[2]).destroys, 1);
  assert.equal((await f.adapter.readback(version))[0], 3);
});

test('overlapping forks/readbacks serialize long scopes, while captures pop nested scopes synchronously', async () => {
  const f = fixture(), version = await f.capture(), gate = deferred(), started = deferred();
  const first = f.adapter.fork(version, async () => { started.resolve(); await gate.promise; });
  await started.promise;
  let secondStarted = false;
  const second = f.adapter.fork(version, async () => { secondStarted = true; });
  const capture = f.capture();
  assert.equal(f.scopes.length, 2, 'nested capture returned the stack to the pending fork');
  await Promise.resolve(); assert.equal(secondStarted, false);
  gate.resolve(); await Promise.all([first, second, capture]);
  assert.equal(secondStarted, true); assert.equal(f.scopes.length, 0);
});

test('separate adapters share the same device serialization', async () => {
  const f = fixture(), other = createFrameSceneGPUVersions(f.deps);
  const a = await f.capture(), b = await other.capture({resource: f.buffer(), type: 3, count: 4, byteLength: 16});
  const gate = deferred(), started = deferred(); let secondStarted = false;
  const first = f.adapter.fork(a, async () => { started.resolve(); await gate.promise; });
  await started.promise;
  const second = other.fork(b, async () => { secondStarted = true; });
  await Promise.resolve(); assert.equal(secondStarted, false);
  gate.resolve(); await Promise.all([first, second]); assert.equal(f.scopes.length, 0);
});

test('readback failure and malformed readback release lifetime leases', async () => {
  const f = fixture(), version = await f.capture(), resource = f.adapter.binding(version);
  f.faults.read = Error('read failed');
  await assert.rejects(f.adapter.readback(version), /read failed/);
  assert.equal(f.leases.get(resource), undefined); assert.equal(f.scopes.length, 0);
  const bad = createFrameSceneGPUVersions({...f.deps, readGPU: async () => new Uint8Array(4)});
  const owned = await bad.capture({resource: f.buffer(), type: 3, count: 4, byteLength: 16});
  await assert.rejects(bad.readback(owned), {code: 'INVALID_GPU_READBACK'});
});

test('duplicate aliases are rejected without releasing source ownership', async () => {
  const f = fixture(), source = f.buffer();
  const adapter = createFrameSceneGPUVersions({...f.deps, duplicateResource: (_gpu, value) => value});
  await assert.rejects(adapter.capture({resource: source, type: 3, count: 4, byteLength: 16}), {code: 'ALIASED_GPU_ALLOCATION'});
  assert.equal(f.states.get(source).destroys, 0);
  assert.equal(f.leases.get(source), undefined);
});

test('native retainer release is idempotent and respects existing borrowed leases', () => {
  const f = fixture(), source = f.buffer();
  f.leases.set(source, {count: 1, retired: false});
  const release = f.deps.retainResource(source); f.releaseGPU(source);
  assert.equal(f.leases.get(source).count, 2);
  release(); release(); assert.equal(f.leases.get(source).count, 1);
  assert.equal(f.states.get(source).destroyed, false);
  const nativeBorrow = f.leases.get(source);
  if (!--nativeBorrow.count) { f.leases.delete(source); if (nativeBorrow.retired) f.releaseGPU(source); }
  assert.equal(f.states.get(source).destroys, 1);
});

const nativePath = path.resolve(__dirname, '../index.html');
test('actual Frame copyResource/duplicateResource execute the buffer and texture mock paths', async () => {
  const source = fs.readFileSync(nativePath, 'utf8');
  const begin = source.indexOf('    function copyResource(encoder,source,target){');
  const end = source.indexOf('    function sceneFromMeshes(', begin);
  assert.ok(begin > 0 && end > begin);
  const f = fixture();
  const native = vm.runInNewContext(source.slice(begin, end) + '\n({copyResource, duplicateResource})', {
    GPUBufferUsage: {COPY_SRC: 4, COPY_DST: 8},
    makeGPUBuffer: f.gpu.makeGPUBuffer,
    makePagedTexture: f.gpu.makePagedTexture
  });
  const adapter = createFrameSceneGPUVersions({...f.deps, ...native});
  for (const resource of [f.buffer(16, [1, 2]), f.texture(4, [3, 4])]) {
    const version = await adapter.capture({resource, type: 3, count: 4, byteLength: 16});
    assert.deepEqual(bytes(await adapter.readback(version)), bytes(f.data(resource)));
  }
});


test('actual nativeReadGPU supports scalar buffers, face padding, and paged row/layer readback', async () => {
  const source = fs.readFileSync(nativePath, 'utf8');
  const begin = source.indexOf('    async function nativeReadGPU(gpu,resource,count){');
  const end = source.indexOf('    async function saveSTL(', begin);
  assert.ok(begin > 0 && end > begin);
  const f = fixture();
  const readGPU = vm.runInNewContext(source.slice(begin, end) + '\n(nativeReadGPU)', {
    Uint8Array,
    GPUBufferUsage: {COPY_DST: 8, MAP_READ: 1},
    GPUMapMode: {READ: 1},
    checkSession: f.deps.checkSession,
    makeGPUBuffer: f.gpu.makeGPUBuffer,
    releaseGPU: f.releaseGPU
  });
  const adapter = createFrameSceneGPUVersions({...f.deps, readGPU});
  const inputs = [
    {resource: f.buffer(16, [1, 2, 3, 4, 5, 99, 99, 99]), type: 0, count: 2, byteLength: 5},
    {resource: f.texture(10, Uint8Array.from({length: 40}, (_, i) => i)), type: 5, count: 10, byteLength: 40},
    {resource: f.buffer(4), type: 0, count: 0, byteLength: 0}
  ];
  for (const input of inputs) {
    const version = await adapter.capture(input);
    assert.deepEqual(bytes(await adapter.readback(version)), bytes(f.data(input.resource).slice(0, input.byteLength)));
  }
  assert.equal(f.scopes.length, 0);
});
