// Real GPU resources and real Copy/Paste handlers; controlled async error-scope
// completion holds Paste while native recopy retires its source clipboard.
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {launch,ready} from '../tools/browser.mjs';

export async function clipboardLifetimeBrowserChecks(page){
 const checks=[],timings=[],check=(name,value,detail)=>{checks.push({name,pass:!!value,detail});assert(value,name+': '+JSON.stringify(detail));},call=(n,a={})=>page.evaluate(([n,a])=>frameAI.call(n,a),[n,a]);
 const measure=async(name,fn)=>{const start=performance.now(),result=await fn(),ms=performance.now()-start,budgetMs=6000;timings.push({name,ms,budgetMs});check(name+' completed latency',ms<budgetMs,{ms,budgetMs});return result;};
 const stats=tag=>page.evaluate(tag=>__clipboardGPU.items.filter(r=>r.tag===tag).map(r=>({label:r.label,kind:r.kind,destroyed:r.destroyed})),tag),live=rows=>rows.length>=6&&rows.every(r=>r.destroyed===0),retired=rows=>rows.length>=6&&rows.every(r=>r.destroyed===1);
 const copy=tag=>measure('Native Copy '+tag,()=>page.evaluate(async tag=>{__clipboardGPU.capture=tag;try{return await frameEngine.copySelection();}finally{__clipboardGPU.capture=null;}},tag));
 const pause=async()=>{await page.evaluate(()=>{const s=__clipboardGPU;s.pauseArmed=true;s.paused=false;s.outcome={state:'pending'};s.task=frameEngine.pasteSelection().then(value=>s.outcome={state:'fulfilled',value},error=>s.outcome={state:'rejected',message:error.message});});await page.waitForFunction(()=>__clipboardGPU.paused&&__clipboardGPU.outcome.state==='pending',{}, {timeout:10000});};
 const resume=async()=>{await page.evaluate(()=>__clipboardGPU.resume());await page.waitForFunction(()=>__clipboardGPU.outcome.state!=='pending',{}, {timeout:10000});return page.evaluate(()=>__clipboardGPU.outcome);};
 try{
  await call('render.stop');await call('scene.new');const objects=[];
  for(let i=0;i<3;i++)objects.push(await call('mesh.create',{vertices:[i*40,0,0,i*40+20,0,0,i*40,20,0],indices:[0,1,2]}));
  await call('scene.select',{ids:objects.map(o=>o.hash)});await call('view.set',{index:2,single:true,mode:'object',shading:'solid'});await call('diagnostics.frame',{frames:2});
  await page.evaluate(async()=>{
   const d=frameEngine.renderer.device;await d.queue.onSubmittedWorkDone();const s=window.__clipboardGPU={items:[],capture:null,pauseArmed:false,paused:false,failNextPosition:false,failureInjected:0,gateStacks:[]};
   s.device=d;s.originalBuffer=d.createBuffer;s.originalTexture=d.createTexture;s.originalPop=d.popErrorScope;
   const track=(resource,label,kind)=>{if(s.capture&&String(label||'').startsWith('clipboard ')){const row={tag:s.capture,label,kind,destroyed:0},destroy=resource.destroy.bind(resource);Object.defineProperty(resource,'destroy',{configurable:true,value:()=>{row.destroyed++;destroy();}});s.items.push(row);}return resource;};
   d.createBuffer=function(desc){if(s.failNextPosition&&desc.label==='independent object copy positions'){s.failNextPosition=false;s.failureInjected++;throw Error('Injected GPU Copy allocation failure');}return track(s.originalBuffer.call(this,desc),desc.label,'buffer');};
   d.createTexture=function(desc){return track(s.originalTexture.call(this,desc),desc.label,'texture');};
   d.popErrorScope=async function(){const stack=Error().stack,result=await s.originalPop.call(this);if(s.pauseArmed&&stack.includes('uploadAndCompute')){s.pauseArmed=false;s.paused=true;s.gateStacks.push(stack);await new Promise(resolve=>s.resume=()=>{s.paused=false;resolve();});}return result;};
  });
  await copy('A');check('Copy captures actual live clipboard GPU buffers',live(await stats('A')),await stats('A'));
  await pause();await copy('B');check('Concurrent recopy retains every leased source GPU buffer',live(await stats('A')),await stats('A'));
  let outcome=await resume();check('Multi-object Paste completes after recopy',outcome.state==='fulfilled',outcome);check('Retired source buffers release exactly once after Paste',retired(await stats('A')),await stats('A'));check('Replacement clipboard remains live',live(await stats('B')),await stats('B'));
  for(let i=0;i<2;i++)await measure('Repeated native Paste '+i,()=>page.evaluate(()=>frameEngine.pasteSelection()));
  check('Repeated Paste does not retire the current clipboard',live(await stats('B')),await stats('B'));let state=await call('scene.inspect');check('Repeated Paste publishes every copied native owner',state.objects.length===12,{objects:state.objects.length});
  await copy('C');check('Next Copy retires the prior current clipboard once',retired(await stats('B')),await stats('B'));const before=state.objects.length;
  await pause();await copy('D');check('Failure-case source is still leased during recopy',live(await stats('C')),await stats('C'));await page.evaluate(()=>__clipboardGPU.failNextPosition=true);outcome=await resume();
  check('Injected allocation failure rejects the actual Paste handler',outcome.state==='rejected'&&outcome.message==='Injected GPU Copy allocation failure',outcome);check('Failure releases retired source GPU buffers exactly once',retired(await stats('C')),await stats('C'));check('Failure preserves replacement clipboard resources',live(await stats('D')),await stats('D'));state=await call('scene.inspect');check('Failed Paste publishes no partial native owners',state.objects.length===before,{before,after:state.objects.length});
  await measure('Native Paste recovers after failure',()=>page.evaluate(()=>frameEngine.pasteSelection()));state=await call('scene.inspect');check('Recovery publishes the expected copied owners',state.objects.length===15,{objects:state.objects.length});
  const saved=await measure('HASH Save after recopy/repeat/failure',()=>call('scene.export',{includeData:true}));check('Native HASH export completes with copied geometry',saved.bytes>0&&!!saved.base64,saved.bytes);
  await copy('E');for(const tag of ['A','B','C','D'])check(tag+' source has one final retirement',retired(await stats(tag)),await stats(tag));
  const frames=await call('diagnostics.frame',{frames:4});check('Native copied scene has bounded CPU/GPU frames',frames.timestampQueries&&frames.frames.length===4&&frames.frames.every(f=>f.cpuMs<50&&f.gpuMs<50),frames);
  return {pass:true,checks,timings,frames,instrumentation:await page.evaluate(()=>({failureInjected:__clipboardGPU.failureInjected,gateStacks:__clipboardGPU.gateStacks,sourceResources:__clipboardGPU.items.length})),scope:'Native GPU clipboard lifetime safety only; decoded clipboard/Undo architecture remains noncompliant.'};
 }catch(error){return {pass:false,checks,timings,error:error.stack};}finally{await page.evaluate(()=>{const s=window.__clipboardGPU;if(!s)return;s.pauseArmed=false;if(s.paused)s.resume();s.failNextPosition=false;s.device.createBuffer=s.originalBuffer;s.device.createTexture=s.originalTexture;s.device.popErrorScope=s.originalPop;}).catch(()=>{});}
}

if(process.argv[1]===fileURLToPath(import.meta.url)){
 const before=await readFile(new URL('../index.html',import.meta.url)),indexSHA256=createHash('sha256').update(before).digest('hex');let session,report;const errors=[],consoleErrors=[];
 try{session=await launch({headless:true});session.page.on('pageerror',e=>errors.push(e.message));session.page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});await ready(session.page);const hardware=await session.page.evaluate(()=>{const d=frameEngine.renderer.device;window.__clipboardDevice=d;window.__clipboardErrors=[];window.__clipboardLost=null;d.pushErrorScope('validation');d.addEventListener('uncapturederror',e=>__clipboardErrors.push(e.error.message));d.lost.then(e=>__clipboardLost={reason:e.reason,message:e.message});return Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(k=>[k,d.adapterInfo[k]]));});assert(hardware.vendor&&hardware.isFallbackAdapter===false&&!/swiftshader|llvmpipe|lavapipe|software/i.test(JSON.stringify(hardware)),'Identifiable hardware WebGPU required');report=await clipboardLifetimeBrowserChecks(session.page);report.hardware=hardware;report.gpu=await session.page.evaluate(async()=>{await __clipboardDevice.queue.onSubmittedWorkDone();return {validation:(await __clipboardDevice.popErrorScope())?.message||null,uncaptured:__clipboardErrors,lost:__clipboardLost,replaced:__clipboardDevice!==frameEngine.renderer.device};});report.pass&&=!errors.length&&!consoleErrors.length&&!report.gpu.validation&&!report.gpu.uncaptured.length&&!report.gpu.lost&&!report.gpu.replaced;
 }catch(error){report={pass:false,error:error.stack};}finally{await session?.close();}
 report.indexSHA256=indexSHA256;report.indexSHA256After=createHash('sha256').update(await readFile(new URL('../index.html',import.meta.url))).digest('hex');report.errors=errors;report.consoleErrors=consoleErrors;report.pass&&=report.indexSHA256===report.indexSHA256After;await mkdir(new URL('./results/',import.meta.url),{recursive:true});await writeFile(new URL('./results/clipboard-lifetime-browser.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify({pass:report.pass,checks:report.checks?.length,error:report.error,gpu:report.gpu,hardware:report.hardware,indexSHA256},null,2));if(!report.pass)process.exitCode=1;
}
