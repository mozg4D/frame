// Actual read-through timeline functions, with RAM records and CPU UI fixtures.
// This does not qualify browser event ordering, real GPU work or the full migration.
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import test from 'node:test';
import vm from 'node:vm';
import {hash,source as html,id} from './load-runtime.mjs';

function section(a,b){const start=html.indexOf(a),end=html.indexOf(b,start);assert(start>=0&&end>start,a);return html.slice(start,end);}
const native=section('    function nativeTimelineState(','    function deformationRevision(');
const createView=new Function(section('function createFrameTimelineView(','const frameTimeline=')+';return createFrameTimelineView;')();
const tableFactory=new Function(section('function createFrameHashRecordTable(hash){','function createFrameHashCodec(){')+';return createFrameHashRecordTable;')();
const table=tableFactory(hash),{K,T}=hash;
const record=(key,value,type=T.float64)=>({id:key,type,value:value instanceof Float64Array||ArrayBuffer.isView(value)?value:Float64Array.of(value)});
function environment(records=new Map()){
 return new Function('FrameHash','FrameHashRecords','records',`
  let scene={records},nativeIOBusy=false,sceneFrameDirty=false;
  function nativeRecord(id,type,value){return {id,type,value};}
  ${native}
  return {read:nativeTimelineState,write:nativeSetTimelineState,get records(){return scene.records;},replace:records=>scene={records},busy:value=>nativeIOBusy=value,get dirty(){return sceneFrameDirty;}};
 `)(hash,table,records);
}
function ui(e){
 let edit=null;
 const view=createView({read:e.read,write:e.write,editing:()=>edit});
 const context=vm.createContext({frameTimeline:view});context.window=context;
 vm.runInContext(html.split('\n').find(line=>line.startsWith('Object.defineProperties(window,{timelineFrame:')),context);
 return {view,context,edit:value=>edit=value};
}

test('timeline defaults need no authored records or JSON and expose live native scalar handles',()=>{
 const e=environment(),u=ui(e);assert.deepEqual(e.read(),{frame:0,total:120});assert.equal(e.records.size,0);
 for(const key of ['timelineFrame','timelineTotal']){const d=Object.getOwnPropertyDescriptor(u.context,key);assert.equal(typeof d.get,'function');assert.equal(typeof d.set,'function');assert.equal('value' in d,false);}
 assert.equal(vm.runInContext('timelineFrame',u.context),0);assert.equal(vm.runInContext('timelineTotal',u.context),120);
});
test('UI globals write actual addressed Float64 fields; direct record changes are immediately visible',()=>{
 const e=environment(),u=ui(e);vm.runInContext('timelineTotal=400;timelineFrame=123',u.context);
 assert.equal(e.records.get(K.timelineFrame).type,T.float64);assert.deepEqual(Array.from(e.records.get(K.timelineFrame).value),[123]);
 assert.deepEqual(Array.from(e.records.get(K.timelineTotal).value),[400]);assert.equal(e.records.has(K.parameters),false);
 e.records.set(K.timelineFrame,record(K.timelineFrame,77));assert.equal(vm.runInContext('timelineFrame',u.context),77);
 const before=e.records;assert.equal(e.dirty,true);e.replace(new Map());assert.equal(vm.runInContext('timelineFrame',u.context),0);assert.equal(vm.runInContext('timelineTotal',u.context),120);assert.equal(before.get(K.timelineFrame).value[0],77);
});
test('frame and range writes validate before mutation, clamp range and omit defaults without a mirror',()=>{
 const e=environment(),u=ui(e);e.write(80,200);const stableTotal=e.records.get(K.timelineTotal);e.write(90,200);assert.equal(e.records.get(K.timelineTotal),stableTotal);vm.runInContext('timelineTotal=40',u.context);assert.deepEqual(e.read(),{frame:40,total:40});
 for(const pair of [[NaN,100],[Infinity,100],[-1,100],[1.5,100],[0,0],[101,100],[0,Number.MAX_SAFE_INTEGER+1]]){
  const before=[...e.records];assert.throws(()=>e.write(...pair),/Invalid timeline/);assert.deepEqual([...e.records],before);
 }
 e.busy(true);assert.throws(()=>vm.runInContext('timelineFrame=12',u.context),/busy/);assert.deepEqual(e.read(),{frame:40,total:40});e.busy(false);
 assert.equal(e.write(40,40),false);e.write(0,120);assert.equal(e.records.size,0);
});
test('one optional opaque timeline representation stays exact, ignored and read-only',()=>{
 const raw=Uint8Array.of(64,0,8,9,10),opaque={id:K.timelineTotal,type:64,opaque:{encoding:64,bytes:raw}},e=environment(new Map([[K.timelineTotal,opaque],[K.timelineFrame,record(K.timelineFrame,500)]])),u=ui(e);
 assert.deepEqual(e.read(),{frame:0,total:120,readOnly:true});assert.equal(u.view.frame,0);assert.equal(u.view.total,120);
 assert.equal(e.write(0,120),false);assert.throws(()=>e.write(1,120),/unsupported HASH/);assert.equal(e.records.get(K.timelineTotal),opaque);assert.deepEqual(raw,Uint8Array.of(64,0,8,9,10));
});
test('actual numeric bindings handle unsupported and busy writes without throwing or changing records',()=>{
 const e=environment(),u=ui(e),errors=[],controls=new Map(),options=new Map();
 Object.assign(u.context,{playing:false,stop(){},frameEvaluateAnimation(){},frameRefreshAnimationUI(){},fileOperationError:error=>errors.push(error.message),$:key=>{if(!controls.has(key))controls.set(key,{key,_sync(){}});return controls.get(key);},bindNumber:(control,value)=>options.set(control.key,value)});
 const lines=html.split('\n').filter(line=>line.startsWith('function frameTimelineInput(')||line.startsWith("bindNumber($('tlCur'),")||line.startsWith("bindNumber($('tlTotal'),")||line.startsWith('function setTimelineFrame(value,'));vm.runInContext(lines.join('\n'),u.context);
 const opaque={id:K.timelineTotal,type:64,opaque:{bytes:Uint8Array.of(4,5)}};e.records.set(K.timelineTotal,opaque);
 assert.throws(()=>vm.runInContext('timelineTotal=121',u.context),/unsupported HASH/); // Prior unguarded binding.
 assert.doesNotThrow(()=>options.get('tlTotal').set(121));assert.doesNotThrow(()=>options.get('tlCur').set(1));assert.equal(e.records.get(K.timelineTotal),opaque);assert.equal(errors.length,2);
 e.records.delete(K.timelineTotal);e.busy(true);assert.doesNotThrow(()=>options.get('tlCur').set(5));assert.match(errors[2],/busy/);assert.deepEqual(e.read(),{frame:0,total:120});
});
test('actual range-extending key command rejects an unsupported clock before history or track mutation',async()=>{
 const start=html.indexOf("register('animation.key',"),end=html.indexOf("register('animation.seek',",start),statement=html.slice(start,end).trim(),arrow=statement.slice(statement.indexOf('async a=>')).replace(/\);$/,'');
 const guard="if(!frameCurves.morphPose&&nativeTimelineState().readOnly&&a.frame>timelineTotal)fail('UNSUPPORTED','Timeline uses an unsupported HASH representation');";assert.ok(arrow.includes(guard));
 const e=environment(new Map([[K.timelineTotal,{id:K.timelineTotal,type:64,opaque:{bytes:Uint8Array.of(3)}}]]));let touched=0;
 const dependencies={animationOwner:()=>({id:'owner'}),FramePlugins:{dispatch:()=>false},frameIsPLAPath:()=>false,frameReadAttribute:()=>[0,0,0],frameCurves:{morphPose:null},frameAttributeKind:()=> 'vector',nativeTimelineState:e.read,timelineTotal:120,fail:(code,message)=>{throw Object.assign(Error(message),{code});},snapshot:()=>{touched++;throw Error('History reached');}};
 const command=body=>new Function('dependencies','with(dependencies){return '+body+';}')(dependencies),args={id:'owner',path:'position',frame:500,value:[1,2,3]};
 await assert.rejects(command(arrow)(args),error=>error.code==='UNSUPPORTED');assert.equal(touched,0);
 await assert.rejects(command(arrow.replace(guard,''))(args),/History reached/);assert.equal(touched,1);
});
test('known timeline schema rejects malformed scalar data even alongside an opaque field',()=>{
 for(const bad of [Float64Array.of(NaN),Float64Array.of(Infinity),Float64Array.of(-1),Float64Array.of(1.5),Float64Array.of(0,1),new Uint32Array([1])]){
  const e=environment(new Map([[K.timelineFrame,record(K.timelineFrame,bad)]]));assert.throws(e.read,/Invalid HASH timeline/);
 }
 const e=environment(new Map([[K.timelineFrame,record(K.timelineFrame,200)]]));assert.throws(e.read,/range/);
 const opaque={id:K.timelineTotal,type:64,opaque:{bytes:Uint8Array.of(1)}};e.records.set(K.timelineTotal,opaque);e.records.set(K.timelineFrame,record(K.timelineFrame,NaN));assert.throws(e.read,/Invalid HASH timeline frame/);
});
test('Morph preview changes only editor time; authored restore writes the same RAM table',()=>{
 const e=environment(),u=ui(e);e.write(13,220);const before=[...e.records],edit={previewFrame:50};u.edit(edit);
 vm.runInContext('timelineFrame=72;timelineTotal=100',u.context);assert.equal(u.view.frame,72);assert.equal(u.view.total,100);assert.deepEqual([...e.records],before);
 assert.deepEqual(u.view.authored,{frame:13,total:220});assert.throws(()=>u.view.frame=101,/Morph/);assert.throws(()=>u.view.total=120,/Morph/);
 u.view.restore({frame:23,total:320});assert.equal(edit.previewFrame,72);assert.deepEqual(e.read(),{frame:23,total:320});u.edit(null);assert.equal(u.view.frame,23);assert.equal(u.view.total,320);
});
test('actual Morph close after document replacement does not restore old authored time',()=>{
 const e=environment(),u=ui(e),oldEdit={owner:'missing',previewFrame:70,saved:{channels:new Map(),selection:[],frame:23,total:220,totalDisabled:false}};
 const state={morphPose:oldEdit};u.edit(oldEdit);Object.assign(u.context,{frameCurves:state,selectionVersion:0,syncTracks(){},node(){},tagOf(){return null;},$(){return {_sync(){}};},frameChannels:new Map(),frameChannelSelection:[],frameEvaluateAnimation(){}});
 // The historical assignments are a negative control: they corrupt the newly
 // installed document when made through real native read-through properties.
 e.write(7,250);u.edit(null);vm.runInContext('timelineFrame=frameCurves.morphPose.saved.frame;timelineTotal=frameCurves.morphPose.saved.total',u.context);assert.deepEqual(e.read(),{frame:23,total:220});
 e.write(7,250);u.edit(oldEdit);
 const line=html.split('\n').find(line=>line.trim().startsWith('function closePose(evaluate=true)'));
 vm.runInContext(line+';closePose(false);',u.context);u.edit(null);assert.deepEqual(e.read(),{frame:7,total:250});assert.equal(state.morphPose,null);
});
test('Morph history state stores editor preview without a second authored frame/range',()=>{
 const history=html.split('\n').find(line=>line.trim().startsWith('function historyState(){const e=frameCurves.morphPose'));
 const state={morphPose:{owner:'owner',pose:'pose',previewFrame:31,selectedKeys:[],saved:{channels:new Map(),selection:[]}}};
 const value=new Function('frameCurves','framePackTrack',history+';return historyState();')(state,v=>v);
 assert.equal(value.previewFrame,31);assert.equal('frame' in value.saved,false);assert.equal('total' in value.saved,false);
 assert.ok(!html.includes('let timelineFrame='));assert.ok(!html.includes('frame:frameCurves.morphPose?.saved.frame'));
});
test('native timeline accesses use addressed lookups and preserve unrelated records',()=>{
 class AddressedMap extends Map{values(){throw Error('linear scan forbidden');}entries(){throw Error('linear scan forbidden');}[Symbol.iterator](){throw Error('linear scan forbidden');}}
 const records=new AddressedMap(),unrelated={id:id(777),type:64,opaque:{bytes:Uint8Array.of(7)}};records.set(unrelated.id,unrelated);
 const e=environment(records);e.write(40,200);assert.deepEqual(e.read(),{frame:40,total:200});assert.equal(records.get(unrelated.id),unrelated);
});
test('actual codec roundtrip stores only native scalar fields and preserves exact values',async()=>{
 const e=environment();e.write(120,Number.MAX_SAFE_INTEGER);const parts=[];
 for(const value of e.records.values())parts.push((await hash.pack(value)).blob);
 const {records}=await table.ingest(new Blob(parts)),fresh=environment(records);assert.deepEqual(fresh.read(),{frame:120,total:Number.MAX_SAFE_INTEGER});assert.equal(records.size,2);assert.equal(records.has(K.parameters),false);
});
test('completed addressed timeline edits and reads remain bounded in a 50000-record table',()=>{
 const e=environment();for(let i=1000;i<51000;i++)e.records.set(id(i),{id:id(i),type:T.text,value:'uninterpreted'});
 const times=[],start=performance.now();for(let i=0;i<3000;i++){const t=performance.now();e.write(i%500,500);assert.equal(e.read().frame,i%500);times.push(performance.now()-t);}
 const elapsedMs=performance.now()-start,p95Ms=times.sort((a,b)=>a-b)[Math.floor(times.length*.95)];assert.ok(elapsedMs<1500,{elapsedMs});assert.ok(p95Ms<2,{p95Ms});
 console.log(JSON.stringify({operation:'3000 completed native timeline edit/read pairs / 50000 unrelated records',elapsedMs,p95Ms,budgets:{totalMs:1500,p95Ms:2},gpuReadbacks:0,scope:'CPU functions and RAM records only'}));
});
