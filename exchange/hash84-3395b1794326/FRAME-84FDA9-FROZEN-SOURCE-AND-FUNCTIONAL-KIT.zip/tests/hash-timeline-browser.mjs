import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';

export async function timelineHashChecks(page){
 const checks=[],timings=[],check=(name,pass,detail)=>{checks.push({name,pass:!!pass,detail});assert.ok(pass,name+': '+JSON.stringify(detail));};
 const call=async(name,args={})=>{const start=performance.now(),value=await page.evaluate(([name,args])=>frameAI.call(name,args),[name,args]),ms=performance.now()-start;timings.push({name,ms,budgetMs:6000});check(name+' completes within 6000ms',ms<6000);return value;};
 const state=()=>page.evaluate(()=>({authored:frameEngine.timelineState(),view:{frame:timelineFrame,total:timelineTotal},frameText:document.querySelector('#tlCur').value,totalText:document.querySelector('#tlTotal').value}));
 const range=async value=>{await page.locator('#tlTotal').fill(String(value));await page.locator('#tlTotal').press('Enter');};
 const packed=base64=>page.evaluate(async value=>{const h=FrameHash,file=new Blob([Uint8Array.from(atob(value),c=>c.charCodeAt(0))]),index=await h.index(file),get=async key=>{const r=index.get(h.K[key]);return r?{type:r.type,value:Array.from(await h.read(file,r))}:null;},metadata=index.get(h.K.parameters),global=metadata?JSON.parse(await h.read(file,metadata)):{};return {frame:await get('timelineFrame'),total:await get('timelineTotal'),jsonClock:Object.hasOwn(global,'frame')||Object.hasOwn(global,'total')};},base64);
 try{
  await call('scene.new');const mesh=await call('mesh.create',{vertices:[0,0,0,25,0,0,0,25,0],indices:[0,1,2]});
  await range(250);await call('animation.seek',{frame:7});const first=await call('scene.export',{includeData:true});
  check('real native inputs and animation seek write the same authored table',(await state()).authored.frame===7&&(await state()).authored.total===250);
  await range(220);await call('animation.seek',{frame:13});await call('scene.update',{id:mesh.hash,name:'Timeline checkpoint'});await call('animation.seek',{frame:23});
  await call('edit.history',{action:'undo'});check('existing chronological Undo restores addressed time',(await state()).authored.frame===13);
  await call('edit.history',{action:'redo'});check('existing chronological Redo restores addressed time',(await state()).authored.frame===23);
  const normal=await call('scene.export',{includeData:true}),raw=await packed(normal.base64);
  check('HASH stores two scalar native fields and no generated JSON clock',raw.frame?.type===6&&raw.frame.value.join()==='23'&&raw.total?.type===6&&raw.total.value.join()==='220'&&!raw.jsonClock,raw);
  await call('scene.open',{name:'timeline-roundtrip.hash',base64:normal.base64});const reopened=await state();
  check('Open changes native reads and real input display without copying UI time',reopened.authored.frame===23&&reopened.authored.total===220&&reopened.frameText==='23'&&reopened.totalText==='220',reopened);
  await call('morph.edit',{id:mesh.hash,action:'create'});await call('morph.edit',{id:mesh.hash,action:'add',name:'Timeline preview'});await call('morph.edit',{id:mesh.hash,action:'mode',mode:'Edit'});await call('animation.seek',{frame:67});const edit=await state();
  check('real Morph editor time is separate from authored HASH time',edit.view.frame===67&&edit.view.total===100&&edit.authored.frame===23&&edit.authored.total===220,edit);
  const during=await call('scene.export',{includeData:true}),duringRaw=await packed(during.base64);
  check('Save during Morph Edit writes authored time without restoring a shadow copy',duringRaw.frame.value[0]===23&&duringRaw.total.value[0]===220&&!duringRaw.jsonClock,duringRaw);
  await call('morph.edit',{id:mesh.hash,action:'mode',mode:'Solve'});const closed=await state();check('leaving Morph reveals the live authored clock',closed.view.frame===23&&closed.view.total===220,closed);
  await call('morph.edit',{id:mesh.hash,action:'mode',mode:'Edit'});await call('scene.open',{name:'replacement-timeline.hash',base64:first.base64});const replacement=await state();
  check('Open while Morph Edit is active preserves the replacement document time',replacement.authored.frame===7&&replacement.authored.total===250&&replacement.view.frame===7&&replacement.view.total===250,replacement);
  const mergeURL=new URL('timeline-merge-fixture.hash',page.url()).href;await page.route(mergeURL,route=>route.fulfill({status:200,contentType:'application/x-frame-hash',body:Buffer.from(normal.base64,'base64')}));
  try{await call('scene.merge',{url:mergeURL});}finally{await page.unroute(mergeURL);}
  const merged=await state();check('Merge retains destination time instead of importing source globals',merged.authored.frame===7&&merged.authored.total===250,merged);
  await page.evaluate(async()=>{const h=FrameHash,{K,T}=h,owner='7'.repeat(32),header=new Uint8Array(26),v=new DataView(header.buffer);v.setUint16(0,64,true);header.set(Uint8Array.from({length:16},(_,i)=>parseInt(K.timelineTotal.slice(i*2,i*2+2),16)),2);v.setBigUint64(18,3n,true);const raw=new Blob([header,Uint8Array.of(1,2,3)]),parts=[raw];for(const r of [{id:K.version,type:T.uint32,value:Uint32Array.of(1)},{id:K.all,type:T.ids,value:[owner]},{id:h.address(owner,'type'),type:T.bytes,value:Uint8Array.of(0)},{id:K.timelineFrame,type:T.float64,value:Float64Array.of(500)}])parts.push((await h.pack(r)).blob);window.__opaqueTimeline=Array.from(new Uint8Array(await raw.arrayBuffer()));await frameEngine.loadFile(new File(parts,'future-timeline.hash'));});
  const rejectedKey=await page.evaluate(async()=>{const before=(await frameAI.call('animation.inspect')).channels,start=performance.now();let code;try{await frameAI.call('animation.key',{id:'7'.repeat(32),path:'position',frame:500,value:[1,2,3]});}catch(error){code=error.code;}return {code,before:before.length,after:(await frameAI.call('animation.inspect')).channels.length,ms:performance.now()-start};});
  check('range-extending key validates clock writability before authoring any track',rejectedKey.code==='UNSUPPORTED'&&rejectedKey.before===rejectedKey.after&&rejectedKey.ms<6000,rejectedKey);
  await page.locator('#tlTotal').fill('121');await page.locator('#tlTotal').press('Enter');
  const rejected=await page.evaluate(()=>{const raw=frameEngine.scene.records.get(FrameHash.K.timelineTotal).opaque.bytes;return {exact:raw.length===__opaqueTimeline.length&&raw.every((v,i)=>v===__opaqueTimeline[i]),frame:frameEngine.scene.records.get(FrameHash.K.timelineFrame).value[0],view:frameEngine.timelineState(),text:document.querySelector('#tlTotal').value,error:document.querySelector('#frame-engine-canvas').dataset.operationError};});
  check('unsupported timeline input is handled, resets its display and preserves native records',rejected.exact&&rejected.frame===500&&rejected.view.readOnly&&rejected.text==='120'&&rejected.error?.includes('unsupported HASH'),rejected);
  const future=await call('scene.export',{includeData:true}),futureExact=await page.evaluate(async base64=>{const h=FrameHash,file=new Blob([Uint8Array.from(atob(base64),c=>c.charCodeAt(0))]),index=await h.index(file),r=index.get(h.K.timelineTotal),raw=new Uint8Array(await file.slice(r.offset-26,r.offset+r.length).arrayBuffer());return raw.length===__opaqueTimeline.length&&raw.every((v,i)=>v===__opaqueTimeline[i]);},future.base64);
  check('explicit Save retains the unsupported timeline block byte-for-byte',futureExact);
  await call('scene.new');const empty=await state(),absent=await page.evaluate(()=>!frameEngine.scene.records.has(FrameHash.K.timelineFrame)&&!frameEngine.scene.records.has(FrameHash.K.timelineTotal));
  check('New uses absent-field defaults instead of the prior UI clock',empty.authored.frame===0&&empty.authored.total===120&&absent,empty);
  await call('view.set',{mode:'object'});return {pass:true,checks,timings};
 }catch(error){return {pass:false,checks,timings,error:error.stack||String(error)};}
}

if(process.argv[1]===fileURLToPath(import.meta.url)){
 const {launch,ready}=await import('../tools/browser.mjs');let session;const errors=[],consoleErrors=[];let report;
 try{
  session=await launch({headless:process.argv.includes('--headless')});const page=session.page;page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});await ready(page);
  const hardware=await page.evaluate(()=>{const d=frameEngine.renderer.device;window.__timelineDevice=d;window.__timelineGPU=[];window.__timelineLost=null;d.pushErrorScope('validation');d.addEventListener('uncapturederror',e=>__timelineGPU.push(e.error.message));d.lost.then(e=>__timelineLost={reason:e.reason,message:e.message});return Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(k=>[k,d.adapterInfo[k]]));});
  assert.equal(hardware.isFallbackAdapter,false);assert.ok(!/swiftshader|llvmpipe/i.test(JSON.stringify(hardware)));
  report=await timelineHashChecks(page);report.hardware=hardware;report.gpu=await page.evaluate(async()=>{await __timelineDevice.queue.onSubmittedWorkDone();return {validation:(await __timelineDevice.popErrorScope())?.message||null,uncaptured:__timelineGPU,lost:__timelineLost,replaced:__timelineDevice!==frameEngine.renderer.device};});
  report.errors=errors;report.consoleErrors=consoleErrors;report.pass&&=!errors.length&&!consoleErrors.length&&!report.gpu.validation&&!report.gpu.uncaptured.length&&!report.gpu.lost&&!report.gpu.replaced;
 }catch(error){report={pass:false,error:error.stack,errors,consoleErrors};}finally{await session?.close();}
 report.indexSHA256=createHash('sha256').update(await readFile(new URL('../index.html',import.meta.url))).digest('hex');await mkdir(new URL('./results/',import.meta.url),{recursive:true});await writeFile(new URL('./results/hash-timeline-browser.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify({pass:report.pass,checks:report.checks?.length,error:report.error,indexSHA256:report.indexSHA256}));process.exitCode=report.pass?0:1;
}
