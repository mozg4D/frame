import test from 'node:test';
import assert from 'node:assert/strict';
import {hash,id,source} from './load-runtime.mjs';
const start=source.indexOf('function createFrameHashCodec(){'),end=source.indexOf('const FrameHash=createFrameHashCodec();',start),code=source.slice(start,end);
const xor=(a,b)=>Array.from({length:16},(_,i)=>(parseInt(a.slice(i*2,i*2+2),16)^parseInt(b.slice(i*2,i*2+2),16)).toString(16).padStart(2,'0')).join('');

test('native XOR addresses retain byte-exact identities for known and arbitrary fields',()=>{
 let state=0x12345678;const random=()=>Array.from({length:16},()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return (state>>>24).toString(16).padStart(2,'0');}).join('');
 for(let i=0;i<1000;i++){const a=random(),b=random();assert.equal(hash.address(a,b),xor(a,b));assert.equal(hash.address(a,'flags'),xor(a,hash.K.flags));}
 for(const [a,b]of [[id(0),id(0)],[id(0),'f'.repeat(32)],['f'.repeat(32),'f'.repeat(32)],[id(1),id(2)]])assert.equal(hash.address(a,b),xor(a,b));
 for(const [name,field]of Object.entries(hash.K))assert.equal(hash.address(id(42),name),hash.address(id(42),field));
});

test('bounded FIFO cache advances one iterator instead of rescanning Map tombstones',()=>{
 const stats={keys:0,next:0},maps=[];
 class ObservedMap extends Map{constructor(...args){super(...args);maps.push(this);}keys(){stats.keys++;const it=super.keys();return {next(){stats.next++;return it.next();}};}}
 const h=new Function('Map',code+';return createFrameHashCodec();')(ObservedMap),limit=131072,count=limit*3+17;
 for(let i=0;i<count;i++)assert.equal(h.address(id(i),'flags'),xor(id(i),h.K.flags));
 const cache=maps[0];assert.equal(cache.size,limit);assert.equal(stats.keys,1);assert.equal(stats.next,count-limit);assert.equal(cache.has(id(0)+':'+h.K.flags),false);assert.equal(cache.has(id(count-1)+':'+h.K.flags),true);
 const before=stats.next;assert.equal(h.address(id(count-1),'flags'),xor(id(count-1),h.K.flags));assert.equal(stats.next,before);
});

test('identifier validation also runs before cache hits and never coerces caller objects',()=>{
 hash.address(id(1),'flags');let touched=false;const object={toString(){touched=true;return id(1);}};
 for(const bad of [object,null,undefined,1,1n,Symbol('id'),'A'.repeat(32),'0'.repeat(31),'g'.repeat(32)])assert.throws(()=>hash.address(bad,'flags'),/Invalid HASH identifier/);
 for(const bad of [object,null,undefined,1,Symbol('field'),'__proto__','constructor','bad'])assert.throws(()=>hash.address(id(1),bad),/Invalid HASH identifier/);
 assert.equal(touched,false);
});
