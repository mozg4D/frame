import test from 'node:test';
import assert from 'node:assert/strict';
import {hash,id,source,opaqueBlock} from './load-runtime.mjs';
import {objectFlagEngine} from './object-flags-runtime.mjs';
const owner=id(1),address=hash.address(owner,'flags');
const record=value=>({id:address,type:hash.T.bytes,value:Uint8Array.of(value)});

test('bound object flags use one canonical byte and shared accessors',()=>{
 const e=objectFlagEngine(new Map(),[owner]),a={nativeHash:owner,visible:false,enabled:false,folded:true},b={nativeHash:owner};e.bind(a);e.bind(b);
 assert.deepEqual([a.visible,a.enabled,a.folded],[true,true,false]);
 for(const key of ['visible','enabled','folded']){const d=Object.getOwnPropertyDescriptor(a,key);assert.equal(d.get,Object.getOwnPropertyDescriptor(b,key).get);assert.equal('value' in d,false);assert.equal(d.enumerable,true);}
 a.visible=false;assert.equal(e.records.get(address).value[0],2);assert.deepEqual([a.visible,b.enabled,b.folded],[false,true,false]);b.folded=true;assert.equal(e.records.get(address).value[0],6);
 b.enabled=false;assert.equal(e.records.get(address).value[0],4);assert.equal(a.enabled,false);assert.equal(e.cache,null);assert.equal(e.dirty,true);
});

test('flags follow addressed replacement, removal and table publication',()=>{
 const records=new Map([[address,record(5)]]),e=objectFlagEngine(records,[owner]),n={nativeHash:owner};e.bind(n);
 assert.deepEqual([n.visible,n.enabled,n.folded],[true,false,true]);records.set(address,record(0));assert.deepEqual([n.visible,n.enabled,n.folded],[false,false,false]);
 records.delete(address);assert.deepEqual([n.visible,n.enabled,n.folded],[true,true,false]);e.swap(new Map([[address,record(7)]]));assert.deepEqual([n.visible,n.enabled,n.folded],[true,true,true]);n.visible=false;assert.equal(e.records.get(address).value[0],6);assert.equal(records.has(address),false);
});

test('unchanged writes preserve exact record, cache and dirty state even while I/O is busy',()=>{
 const old=record(3),e=objectFlagEngine(new Map([[address,old]]),[owner]);const cache=e.cache;e.busy(true);
 assert.equal(e.write(owner,2,true),false);assert.equal(e.records.get(address),old);assert.equal(e.cache,cache);assert.equal(e.dirty,false);
 assert.throws(()=>e.write(owner,2,false),/I\/O is busy/);assert.equal(e.records.get(address),old);assert.equal(e.cache,cache);
});

test('writes validate owner, bit and boolean before changing canonical state',()=>{
 const old=record(5),e=objectFlagEngine(new Map([[address,old]]),[owner]),cache=e.cache;
 for(const [h,bit,value]of [[id(9),1,true],[owner,0,true],[owner,3,true],[owner,8,true],[owner,2,1],[owner,1,'false'],[owner,4,null]])assert.throws(()=>e.write(h,bit,value));
 assert.equal(e.records.get(address),old);assert.equal(e.cache,cache);assert.equal(e.dirty,false);
});

test('known malformed flags reject without weakening native validation',()=>{
 for(const bad of [{type:hash.T.float64,value:Float64Array.of(1)},{type:hash.T.bytes,value:Uint8Array.of(8)},{type:hash.T.bytes,value:new Uint8Array()},{type:hash.T.bytes,value:Uint8Array.of(1,2)},{type:hash.T.bytes,value:[3]}]){
  const old={id:address,...bad},e=objectFlagEngine(new Map([[address,old]]),[owner]);assert.throws(()=>e.read(owner),/Invalid HASH object flags/);assert.throws(()=>e.write(owner,1,false),/Invalid HASH object flags/);assert.equal(e.records.get(address),old);
 }
});

test('unknown flag representations remain uninterpreted and cannot be overwritten',()=>{
 const raw=opaqueBlock(address,0x804d),old={id:address,type:77,opaque:{encoding:0x804d,bytes:raw}},e=objectFlagEngine(new Map([[address,old]]),[owner]),n={nativeHash:owner};e.bind(n);
 assert.deepEqual([n.visible,n.enabled,n.folded],[true,true,false]);for(const key of ['visible','enabled','folded'])assert.throws(()=>{n[key]=!n[key];},/unsupported HASH representation/);assert.equal(e.records.get(address),old);assert.equal(e.cache.records,e.records);assert.equal(e.dirty,false);
});

test('repeated binding is idempotent and uninstalled draft rows are untouched',()=>{
 const e=objectFlagEngine(new Map(),[owner]),n={nativeHash:owner};e.bind(n);const d=Object.getOwnPropertyDescriptor(n,'visible');e.bind(n);assert.equal(Object.getOwnPropertyDescriptor(n,'visible').get,d.get);
 const draft={nativeHash:id(2),visible:false,enabled:false,folded:true};e.bind(draft);assert.equal(Object.getOwnPropertyDescriptor(draft,'visible').value,false);e.bind(null);
});

test('names share an accessor instead of retaining per-row closures or a binding WeakSet',()=>{
 const other=id(2),e=objectFlagEngine(new Map(),[owner,other]),a={nativeHash:owner},b={nativeHash:other};e.bindName(a);e.bindName(b);
 assert.equal(Object.getOwnPropertyDescriptor(a,'name').get,Object.getOwnPropertyDescriptor(b,'name').get);a.name='One';b.name='Two';assert.equal(a.name,'One');assert.equal(b.name,'Two');
 assert.equal(e.records.get(hash.address(owner,'name')).value,'One');assert.equal(e.records.get(hash.address(other,'name')).value,'Two');
});

test('a preflighted multi-target fold rejects opaque data before changing any row',()=>{
 const other=id(2),otherAddress=hash.address(other,'flags'),old=record(3),opaque={id:otherAddress,type:77,opaque:{encoding:77,bytes:opaqueBlock(otherAddress,77)}};
 const e=objectFlagEngine(new Map([[address,old],[otherAddress,opaque]]),[owner,other]),rows=[{id:'a',nativeHash:owner},{id:'b',nativeHash:other}];for(const n of rows)e.bind(n);
 const handler=source.split('\n').find(l=>l.startsWith("$('btnBrowser').onclick="));assert.ok(handler);
 const control=new Function('nodes','window','handler',`const button={};let treeAllFolded=false,foldSnapshot=null;const $=()=>button,children=()=>[1],node=id=>nodes.find(n=>n.id===id),setBrowserIcon=()=>{},renderTree=()=>{};eval(handler);return {click:()=>button.onclick(),state:()=>({treeAllFolded,foldSnapshot})};`)(rows,{frameEngine:{checkObjectFlags:e.check}},handler);
 assert.throws(()=>control.click(),/unsupported HASH representation/);assert.equal(e.records.get(address),old);assert.equal(rows[0].folded,false);assert.deepEqual(control.state(),{treeAllFolded:false,foldSnapshot:null});
});

test('actual camera activation preflights all flags before its Undo command starts',()=>{
 const other=id(2),otherAddress=hash.address(other,'flags'),old=record(1),opaque={id:otherAddress,type:77,opaque:{encoding:77,bytes:opaqueBlock(otherAddress,77)}};
 const e=objectFlagEngine(new Map([[address,old],[otherAddress,opaque]]),[owner,other]),rows=[{nativeHash:owner,type:'render'},{nativeHash:other,type:'render'}];for(const n of rows)e.bind(n);let commits=0;
 const line=source.split('\n').find(l=>l.startsWith('function frameEnableCamera('));assert.ok(line);const activate=new Function('nodes','window','commit',line+';return frameEnableCamera;')(rows,{frameEngine:{checkObjectFlags:e.check}},action=>{commits++;action();});
 assert.throws(()=>activate(rows[0]),/unsupported HASH representation/);assert.equal(commits,0);assert.equal(e.records.get(address),old);
});

test('all eight admitted combinations retain unrelated bits and prior record versions',()=>{
 for(let flags=0;flags<8;flags++)for(const bit of [1,2,4]){const old=record(flags),e=objectFlagEngine(new Map([[address,old]]),[owner]);const value=!(flags&bit);assert.equal(e.write(owner,bit,value),true);assert.equal(e.records.get(address).value[0],flags^bit);assert.equal(old.value[0],flags);assert.notEqual(e.records.get(address).value,old.value);}
});

test('decoded legacy history can capture a read-through projection without becoming its authority',()=>{
 const e=objectFlagEngine(new Map([[address,record(6)]]),[owner]),n={nativeHash:owner};e.bind(n);const before={...n};n.visible=true;const after={...n};assert.deepEqual([before.visible,before.enabled,before.folded],[false,true,true]);
 // Existing decoded history reinstalls a transient DTO. The canonical byte is
 // replaced first; rebinding then drops the transient booleans.
 e.records.set(address,record((before.visible?1:0)|(before.enabled?2:0)|(before.folded?4:0)));const restored={...before};e.bind(restored);assert.equal(n.visible,false);assert.equal(restored.visible,false);e.records.set(address,record((after.visible?1:0)|(after.enabled?2:0)|(after.folded?4:0)));assert.equal(restored.visible,true);
});

test('render-time camera normalization consults native writability before changing flags',()=>{
 assert.ok(source.includes("n!==camera&&window.frameEngine.objectFlagsWritable?.(n.nativeHash,n)!==false"));assert.ok(source.includes("objectFlagsWritable:(owner,view)=>!scene?.nativeOwnerIds?.has(owner)||!scene.records.get(FrameHash.address(owner,'flags'))?.opaque&&(!nativeIOBusy||!!view&&Object.getOwnPropertyDescriptor(view,'enabled')?.get!==nativeFlagViews.enabled.get)"));
 const sync=source.slice(source.indexOf('function frameSyncEngineVisibility(){'),source.indexOf('// SLP1:'));
 assert.ok(sync.includes('window.frameEngine?.bindObjectFlags(n)'));assert.ok(source.includes('window.frameEngine?.bindObjectName(n);window.frameEngine?.bindObjectFlags(n);window.frameEngine?.bindPluginRecords(n);'));
});

test('busy admission normalizes transient camera DTOs before binding, while live flags stay protected',()=>{
 const other=id(2),records=new Map(),e=objectFlagEngine(records,[owner,other]),rows=[{id:'a',nativeHash:owner,type:'render',parent:null,visible:true,enabled:true,folded:false},{id:'b',nativeHash:other,type:'render',parent:null,visible:true,enabled:true,folded:false}];e.busy(true);
 assert.equal(e.writable(owner,rows[0]),true);const start=source.indexOf('function frameSyncEngineVisibility(){'),end=source.indexOf('// SLP1:',start),code=source.slice(start,end);assert.ok(start>=0&&end>start);let specs;
 const frameEngine={scene:{meshes:[]},objectFlagsWritable:e.writable,bindObjectName:e.bindName,bindObjectFlags:e.bind,bindPluginRecords(){},syncObjects:input=>{specs=input;for(const row of input){const id=hash.address(row.hash,'flags');records.set(id,{id,type:hash.T.bytes,value:Uint8Array.of(row.flags)});}}};
 const sync=new Function('nodes','window','FramePlugins','FrameHash','node','frameSoloContains','const frameAuthoring=()=>null;'+code+';return frameSyncEngineVisibility;')(rows,{frameEngine,FrameSpline:{supported:new Set(),generators:new Set(),shape:()=>null}},{owner:()=>null},hash,id=>rows.find(n=>n.id===id),()=>true);
 sync();assert.deepEqual(specs.map(o=>o.flags),[3,1]);assert.deepEqual(rows.map(n=>n.enabled),[true,false]);assert.equal(e.writable(owner,rows[0]),false);assert.throws(()=>{rows[0].enabled=false;},/I\/O is busy/);
});

test('actual selection notifications do not unfold authored parents during native I/O',()=>{
 const start=source.indexOf("FrameViewWindows.onWindow('frame-engine-selection'"),end=source.indexOf('function frameSelectEngineObjects(',start),handler=source.slice(start,end);assert.ok(start>=0&&end>start);
 function fixture(busy,negative=false){
  const child=id(2),old=record(7),e=objectFlagEngine(new Map([[address,old]]),[owner,child]),rows=[{id:'parent',nativeHash:owner,parent:null,tags:[]},{id:'child',nativeHash:child,parent:'parent',tags:[]}];for(const row of rows)e.bind(row);e.busy(busy);
  const code=negative?handler.replace('&&window.frameEngine?.objectFlagsWritable?.(p.nativeHash,p)!==false',''):handler;assert.ok(!negative||code!==handler);
  const dispatch=new Function('nodes','window','handler',`let selected=new Set(),selectedTag=null,selectedTags=new Set(),focusId=null,anchorId=null,frameUITransaction=0,callback,trees=0;const node=id=>nodes.find(n=>n.id===id),FrameMorph={selectionChanged(){}},frameSelectObjectMaterial=()=>{},renderTree=()=>trees++,refreshSelection=()=>{},scrollToFocus=()=>{},FrameViewWindows={onWindow:(_name,fn)=>callback=fn};eval(handler);return {run:hash=>callback({detail:{scope:'objects',hashes:[hash],indices:[]}}),state:()=>({selected:[...selected],trees})};`)(rows,{frameEngine:{objectFlagsWritable:e.writable}},code);
  return {e,rows,old,dispatch,child};
 }
 const busy=fixture(true);busy.dispatch.run(busy.child);assert.equal(busy.rows[0].folded,true);assert.equal(busy.e.records.get(address),busy.old);assert.deepEqual(busy.dispatch.state(),{selected:['child'],trees:0});
 const ready=fixture(false);ready.dispatch.run(ready.child);assert.equal(ready.rows[0].folded,false);assert.equal(ready.e.records.get(address).value[0],3);assert.equal(ready.dispatch.state().trees,1);
 const prior=fixture(true,true);assert.throws(()=>prior.dispatch.run(prior.child),/I\/O is busy/);assert.equal(prior.e.records.get(address),prior.old);
});
