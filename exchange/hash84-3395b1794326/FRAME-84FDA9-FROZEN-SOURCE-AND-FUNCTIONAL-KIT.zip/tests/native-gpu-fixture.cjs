'use strict';
const assert = require('node:assert/strict');
const {createFrameSceneGPUVersions, createFrameNativeResourceRetainer} = require('./load-gpu-runtime.cjs');

function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return {promise, resolve, reject};
}

// copyResource follows the native source; the fixture allocator has dependency
// names/usage constants adapted to the fake GPU. The final test separately
// executes the actual unmodified native helper functions from index.html.
// Device APIs are CPU fakes: this is NOT WebGPU hardware validation.
function copyResource(encoder,source,target){
  if(source.kind==='texture')encoder.copyTextureToTexture({texture:source.texture},{texture:target.texture},[source.width,source.height,source.layers]);
  else encoder.copyBufferToBuffer(source,0,target,0,source.size);
}
function duplicateResource(gpu,source,label){return source.kind==='texture'?gpu.makePagedTexture(gpu,label,source.count,source.format):gpu.makeGPUBuffer(gpu.device,{label,size:source.size,usage:source.usage|4|8});}

function fixture() {
  const states = new WeakMap(), leases = new WeakMap(), allocated = [], events = [];
  const faults = {allocation: null, submit: null, queue: null, read: null, pop: null};
  const scopes = [], lost = deferred();
  let wait = null, readWait = null, active, readCalls = 0;
  function buffer(size = 16, values = null, extra = {}) {
    const state = {data: new Uint8Array(size), destroyed: false, destroys: 0};
    if (values) state.data.set(values);
    const result = {size, usage: 12, ...extra,
      async mapAsync() { assert.equal(state.destroyed, false); },
      getMappedRange() { return state.data.buffer; },
      unmap() {},
      destroy() {
      state.destroyed = true; state.destroys++; events.push('destroy');
    }};
    states.set(result, state); allocated.push(result);
    return result;
  }
  function texture(count, data = null) {
    const width = Math.min(4, Math.max(1, count));
    const height = Math.min(2, Math.max(1, Math.ceil(count / width)));
    const layers = Math.max(1, Math.ceil(count / (width * height)));
    const value = buffer(width * height * layers * 4, data, {
      kind: 'texture', width, height, layers, count, format: 'r32uint', channels: 1, view: {}
    });
    value.texture = {owner: value};
    return value;
  }
  function data(resource) { return states.get(resource).data; }
  function alive(resource) {
    assert.equal(states.get(resource)?.destroyed, false, 'GPU resource must still be alive');
  }
  function scopedError(kind, message) {
    for (let i = scopes.length - 1; i >= 0; i--)
      if (scopes[i].kind === kind) { scopes[i].error ||= {message}; return; }
    throw Error('Uncaptured mock GPU error: ' + kind + ': ' + message);
  }
  const device = {
    lost: lost.promise,
    pushErrorScope(kind) { events.push('push:' + kind); scopes.push({kind, error: null}); },
    popErrorScope() {
      assert.ok(scopes.length, 'scope stack underflow');
      const value = scopes.pop(); events.push('pop:' + value.kind);
      if (faults.pop) { const failure = faults.pop; faults.pop = null; return Promise.reject(failure); }
      return Promise.resolve(value.error);
    },
    createCommandEncoder() {
      let finished = false;
      const ops = [];
      return {
        copyBufferToBuffer(source, sourceOffset, target, targetOffset, size) {
          assert.equal(finished, false); ops.push(() => {
            alive(source); alive(target);
            data(target).set(data(source).subarray(sourceOffset, sourceOffset + size), targetOffset);
          });
        },
        copyTextureToTexture(source, target, extent) {
          assert.deepEqual(Array.from(extent), [source.texture.owner.width, source.texture.owner.height, source.texture.owner.layers]);
          this.copyBufferToBuffer(source.texture.owner, 0, target.texture.owner, 0, source.texture.owner.size);
        },
        copyTextureToBuffer(source, target, extent) {
          const resource = source.texture.owner;
          const [x, y, z] = source.origin;
          const [width, rows] = extent;
          ops.push(() => {
            alive(resource); alive(target.buffer);
            for (let row = 0; row < rows; row++) {
              const from = ((z * resource.height + y + row) * resource.width + x) * 4;
              data(target.buffer).set(data(resource).subarray(from, from + width * 4), row * target.bytesPerRow);
            }
          });
        },
        write(resource, bytes, offset = 0) {
          assert.equal(finished, false); ops.push(() => { alive(resource); data(resource).set(bytes, offset); });
        },
        finish() { assert.equal(finished, false); finished = true; return ops; }
      };
    },
    queue: {
      submit(commands) {
        events.push('submit');
        if (faults.submit) throw faults.submit;
        for (const ops of commands) for (const op of ops) op();
      },
      onSubmittedWorkDone() {
        events.push('done');
        if (faults.queue) return Promise.reject(faults.queue);
        return wait ? wait.promise : Promise.resolve();
      },
      writeBuffer(resource, offset, bytes) { alive(resource); data(resource).set(bytes, offset); }
    }
  };
  const gpu = {
    device, dead: false,
    makeGPUBuffer(_device, descriptor) {
      if (faults.allocation) throw faults.allocation;
      return buffer(descriptor.size, null, {usage: descriptor.usage});
    },
    makePagedTexture(_gpu, _label, count) {
      if (faults.allocation) throw faults.allocation;
      return texture(count);
    }
  };
  active = gpu;
  const releaseGPU = resource => {
    const lease = leases.get(resource);
    if (lease?.count) { lease.retired = true; return; }
    resource.destroy();
  };
  const deps = {
    getSession: () => active,
    checkSession(value) { if (active !== value || value.dead) throw Error('GPU session changed'); },
    retainResource: createFrameNativeResourceRetainer(leases, releaseGPU),
    duplicateResource, copyResource, releaseGPU,
    async readGPU(_gpu, resource, count) {
      readCalls++;
      if (readWait) await readWait.promise;
      if (faults.read) throw faults.read;
      alive(resource);
      return data(resource).slice(0, count * 4);
    }
  };
  const adapter = createFrameSceneGPUVersions(deps);
  const capture = (resource = buffer(), overrides = {}) => adapter.capture({resource, type: 3, byteLength: 16, count: 4, ...overrides});
  return {
    adapter, deps, gpu, device, lost, scopes, faults, leases, allocated, states, events,
    buffer, texture, data, releaseGPU, capture, scopedError,
    get readCalls() { return readCalls; },
    set wait(value) { wait = value; },
    set readWait(value) { readWait = value; },
    set active(value) { active = value; }
  };
}

module.exports = {fixture, deferred, copyResource, duplicateResource};
