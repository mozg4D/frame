import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';

export async function documentationHashChecks(page){
 const checks=[],timings=[],check=(name,pass,detail)=>{checks.push({name,pass:!!pass,detail});assert.ok(pass,name+': '+JSON.stringify(detail));};
 const call=async(name,args={})=>{const start=performance.now(),value=await page.evaluate(([n,a])=>frameAI.call(n,a),[name,args]),ms=performance.now()-start;timings.push({name,ms,budgetMs:6000});check(name+' completes within 6000ms',ms<6000);return value;};
 const inspectFile=base64=>page.evaluate(async value=>{const h=FrameHash,file=new Blob([Uint8Array.from(atob(value),c=>c.charCodeAt(0))]),index=await h.index(file),record=index.get(h.K.documentation),metadata=index.get(h.K.parameters);return {text:record&&!record.unsupported?await h.read(file,record):null,type:record?.type,nested:metadata?Object.hasOwn(JSON.parse(await h.read(file,metadata)),'documentation'):false};},base64);
 try{
  await call('scene.new');const mesh=await call('mesh.create',{vertices:[0,0,0,25,0,0,0,25,0],indices:[0,1,2]}),empty=await call('docs.get');
  const text='Literal JSON {"value":3}\nUnicode \u0414\u043e\u043a\u0443\u043c\u0435\u043d\u0442 \ud83d\ude00\nObject: '+mesh.hash;
  const created=await call('docs.create',{text,version:empty.version}),refs=await call('docs.inspect');
  check('actual Docs API resolves a native owner',refs.references.length===1&&refs.references[0].status==='present',refs);
  const native=await page.evaluate(()=>{const h=FrameHash,r=frameEngine.scene.records.get(h.K.documentation);window.__docNativeRef=r;return {type:r.type,text:r.value};});
  check('Docs author one native literal text field',native.type===7&&native.text===text,native);
  await call('scene.update',{id:mesh.hash,name:'Doc carrier'});
  check('unrelated native rebuild retains the exact Doc record',await page.evaluate(()=>frameEngine.scene.records.get(FrameHash.K.documentation)===__docNativeRef));
  const stale=await page.evaluate(async args=>{try{await frameAI.call('docs.update',args);return null;}catch(e){return e.code;}},{text:'Stale',version:empty.version});
  check('stale API writer rejects without replacing native text',stale==='CONFLICT'&&(await call('docs.get')).text===text,{stale});
  const saved=await call('scene.export',{includeData:true}),packed=await inspectFile(saved.base64);
  check('explicit HASH export contains literal text without nested JSON documentation',packed.type===7&&packed.text===text&&!packed.nested,packed);
  await call('scene.open',{name:'documentation-roundtrip.hash',base64:saved.base64});const reopened=await call('docs.get');
  check('real Open preserves Unicode and invalidates the old Doc version',reopened.text===text&&reopened.version!==created.version,reopened);
  await call('docs.update',{text:'Destination',version:reopened.version});
  const mergeURL=new URL('documentation-merge-fixture.hash',page.url()).href;await page.route(mergeURL,route=>route.fulfill({status:200,contentType:'application/x-frame-hash',body:Buffer.from(saved.base64,'base64')}));
  try{await call('scene.merge',{url:mergeURL});}finally{await page.unroute(mergeURL);}
  const merged=await call('docs.inspect');check('Merge appends literal documentation and remaps its imported native owner',(await call('docs.get')).text.startsWith('Destination\n\n--- Imported scene documentation ---\n')&&merged.references.length===1&&merged.references[0].hash!==mesh.hash&&merged.references[0].status==='present',merged);
  await call('docs.delete',{version:merged.version});check('delete removes the native Doc address',await page.evaluate(()=>!frameEngine.scene.records.has(FrameHash.K.documentation)));
  await page.evaluate(async()=>{const h=FrameHash,{K,T}=h,owner='6'.repeat(32),header=new Uint8Array(26),v=new DataView(header.buffer);v.setUint16(0,0x8040,true);header.set(Uint8Array.from({length:16},(_,i)=>parseInt(K.documentation.slice(i*2,i*2+2),16)),2);v.setBigUint64(18,3n,true);const raw=new Blob([header,Uint8Array.of(7,0,255)]),parts=[raw];for(const r of [{id:K.version,type:T.uint32,value:Uint32Array.of(1)},{id:K.all,type:T.ids,value:[owner]},{id:h.address(owner,'type'),type:T.bytes,value:Uint8Array.of(0)}])parts.push((await h.pack(r)).blob);window.__opaqueDoc=Array.from(new Uint8Array(await raw.arrayBuffer()));await frameEngine.loadFile(new File(parts,'future-documentation.hash'));});
  const ignored=await call('docs.get');check('unknown Doc representation opens without interpretation',ignored.text==='');
  const rejected=await page.evaluate(async version=>{let message;try{await frameAI.call('docs.create',{text:'Must not overwrite unknown',version});}catch(e){message=e.message;}const r=frameEngine.scene.records.get(FrameHash.K.documentation),bytes=r.opaque.bytes;return {message,exact:bytes.length===__opaqueDoc.length&&bytes.every((v,i)=>v===__opaqueDoc[i]),version:frameDocumentation.get().version};},ignored.version);
  check('an unsupported Doc stays read-only without changing its bytes or version',rejected.exact&&rejected.version===ignored.version&&rejected.message?.includes('unsupported HASH'),rejected);
  const opaqueSaved=await call('scene.export',{includeData:true}),exact=await page.evaluate(async value=>{const h=FrameHash,file=new Blob([Uint8Array.from(atob(value),c=>c.charCodeAt(0))]),index=await h.index(file),r=index.get(h.K.documentation),bytes=new Uint8Array(await file.slice(r.offset-26,r.offset+r.length).arrayBuffer());return bytes.length===__opaqueDoc.length&&bytes.every((v,i)=>v===__opaqueDoc[i]);},opaqueSaved.base64);
  check('Save preserves the complete unsupported Doc block exactly',exact);
  await call('scene.new');check('New cannot inherit a prior Doc record',!(await call('docs.inspect')).exists&&await page.evaluate(()=>!frameEngine.scene.records.has(FrameHash.K.documentation)));
  return {pass:true,checks,timings};
 }catch(error){return {pass:false,checks,timings,error:error.stack||String(error)};}
}

if(process.argv[1]===fileURLToPath(import.meta.url)){
 const {launch,ready}=await import('../tools/browser.mjs');let session,report;const errors=[],consoleErrors=[];
 try{
  session=await launch({headless:process.argv.includes('--headless')});const page=session.page;page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});await ready(page);
  const hardware=await page.evaluate(()=>{const d=frameEngine.renderer.device;window.__docDevice=d;window.__docGPU=[];window.__docLost=null;d.pushErrorScope('validation');d.addEventListener('uncapturederror',e=>__docGPU.push(e.error.message));d.lost.then(e=>__docLost={reason:e.reason,message:e.message});return Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(k=>[k,d.adapterInfo[k]]));});
  assert.equal(hardware.isFallbackAdapter,false);assert.ok(!/swiftshader|llvmpipe/i.test(JSON.stringify(hardware)));
  report=await documentationHashChecks(page);report.hardware=hardware;report.gpu=await page.evaluate(async()=>{await __docDevice.queue.onSubmittedWorkDone();return {validation:(await __docDevice.popErrorScope())?.message||null,uncaptured:__docGPU,lost:__docLost,replaced:__docDevice!==frameEngine.renderer.device};});
  report.errors=errors;report.consoleErrors=consoleErrors;report.pass&&=!errors.length&&!consoleErrors.length&&!report.gpu.validation&&!report.gpu.uncaptured.length&&!report.gpu.lost&&!report.gpu.replaced;
 }catch(error){report={pass:false,error:error.stack,errors,consoleErrors};}finally{await session?.close();}
 report.indexSHA256=createHash('sha256').update(await readFile(new URL('../index.html',import.meta.url))).digest('hex');await mkdir(new URL('./results/',import.meta.url),{recursive:true});await writeFile(new URL('./results/hash-documentation-browser.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify({pass:report.pass,checks:report.checks?.length,error:report.error,indexSHA256:report.indexSHA256}));process.exitCode=report.pass?0:1;
}
