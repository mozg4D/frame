import test from 'node:test';
import assert from 'node:assert/strict';
import {hash,id,opaqueBlock,source} from './load-runtime.mjs';
import {lookupRuntime,lookupRecords} from './native-lookup-runtime.mjs';
const owner=id(1),child=id(2),{K,T}=hash;
function records(owners=[owner,child]){const {records}=lookupRecords.begin();lookupRecords.put(records,K.all,{id:K.all,type:T.ids,value:owners});return records;}
test('native affine publication reuses the existing hash index without scanning cached rows',()=>{
 const r=lookupRuntime(records()),view=r.pose();Object.defineProperty(view,'find',{get(){throw Error('Linear scan');}});const first=Float64Array.of(1,0,0,0,1,0,0,0,1,10,0,0);r.put(owner,'matrix',T.float64,first);const index=r.cache.byHash;assert.equal(r.lookup(owner),view[0]);assert.equal(view[0].matrix,first);
 r.put(child,'pivot',T.float64,first);assert.equal(r.cache.byHash,index);assert.equal(view[1].pivot,first);assert.equal(r.parent(child,owner),owner);
 r.putFrame(owner,'matrix',[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);assert.equal(r.records.has(hash.address(owner,'matrix')),false);assert.equal(view[0].matrix,undefined);assert.equal(r.cache.byHash,index);
});
test('a replacement native table never reuses an older hash index',()=>{
 const r=lookupRuntime(records()),before=r.lookup(owner),index=r.cache.byHash,next=records();const name=hash.address(owner,'name');lookupRecords.put(next,name,{id:name,type:T.text,value:'Replacement'});r.swap(next);assert.notEqual(r.lookup(owner),before);assert.notEqual(r.cache.byHash,index);assert.equal(r.lookup(owner).name,'Replacement');assert.equal(r.lookup(id(999)),undefined);
});
test('a protected opaque affine record cannot corrupt the derived frame cache',()=>{
 const data=records(),address=hash.address(owner,'matrix'),opaque={id:address,type:T.float64,opaque:{encoding:0x8006,bytes:opaqueBlock(address,0x8006)}};data.set(address,opaque);const r=lookupRuntime(data),view=r.pose();assert.equal(view[0].matrix,undefined);
 r.put(owner,'matrix',T.float64,Float64Array.of(1,0,0,0,1,0,0,0,1,10,0,0));assert.equal(r.records.get(address),opaque);assert.equal(view[0].matrix,undefined);assert.equal(r.cache.byHash,undefined);
});
test('known cloner-parent behavior survives the shared index',()=>{
 const data=records(),address=hash.address(owner,'spline');lookupRecords.put(data,address,{id:address,type:T.bytes,value:{type:'cloner',params:{}}});const r=lookupRuntime(data);assert.equal(r.parent(child,owner),null);assert.equal(r.lookup(owner).spline.type,'cloner');assert.equal(r.parent(owner,null),null);
});
test('captured multi-root graphs build their child index once',()=>{
 const r=lookupRuntime(records()),list=[];for(let i=0;i<1000;i++){const root=id(1000+i*2);list.push({hash:root,parent:null},{hash:id(1001+i*2),parent:root});}let loops=0;
 const objects=new Proxy(list,{get(target,key,receiver){if(key===Symbol.iterator)return function*(){loops++;yield*target;};return Reflect.get(target,key,receiver);}}),children=r.children(objects);
 for(let i=0;i<1000;i++)assert.deepEqual(r.descendants(id(1000+i*2),objects,children),[id(1000+i*2),id(1001+i*2)]);assert.equal(loops,1);assert.ok(source.includes('children=objectChildren(objects),ids=new Set(roots.flatMap(h=>objectDescendants(h,objects,children)))'));
});
test('UI frame replay uses native owner membership and retains the existing capture policy',()=>{
 const r=lookupRuntime(records()),value=Float64Array.of(1,0,0,0,1,0,0,0,1,25,0,0);r.put(owner,'matrix',T.float64,value);const frames=r.capture();assert.deepEqual(frames[0].matrix,Array.from(value));frames[0].matrix[9]=50;r.restore([...frames,{hash:id(999),matrix:Array.from(value)}],null);assert.equal(r.records.get(hash.address(owner,'matrix')).value[9],50);assert.equal(r.records.has(hash.address(id(999),'matrix')),false);assert.ok(source.includes('for(const o of values)if(scene.nativeOwnerIds?.has(o.hash))'));
});
