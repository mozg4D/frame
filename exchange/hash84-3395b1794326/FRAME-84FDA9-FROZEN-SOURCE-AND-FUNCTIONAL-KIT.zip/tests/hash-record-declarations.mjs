import test from 'node:test';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {hash,source as html,id,opaqueBlock} from './load-runtime.mjs';
const section=(a,b)=>{const i=html.indexOf(a),j=html.indexOf(b,i);assert.ok(i>=0&&j>i,a);return html.slice(i,j);};
const table=new Function(section('function createFrameHashRecordTable(hash){','function createFrameHashCodec(){')+';return createFrameHashRecordTable;')()(hash),{K,T}=hash,owner=id(1),key=id(2);
const column=(records,field,type,value)=>{const address=hash.address(owner,field);records.set(address,{id:address,type,value});};

test('native declaration columns are independently addressed and roundtrip without JSON',async()=>{
 const records=new Map();table.putSchema(records,owner,[{key,type:T.float64},{key:id(3),type:64}]);assert.equal(records.size,2);assert.equal(records.has(hash.address(owner,'parameters')),false);
 const parts=await Promise.all([...records.values()].map(r=>hash.pack(r)));const loaded=await table.ingest(new Blob(parts.map(r=>r.blob)));
 assert.deepEqual(table.schema(loaded.records,owner),{opaque:false,rows:[{key,type:T.float64},{key:id(3),type:64}]});
 assert.equal(loaded.records.get(hash.address(owner,'recordKeys')).type,T.ids);assert.equal(loaded.records.get(hash.address(owner,'recordTypes')).type,T.bytes);
});
test('no declaration columns means no ownership claim',()=>assert.deepEqual(table.schema(new Map(),owner),{opaque:false,rows:[]}));
test('known malformed schemas reject without changing records',()=>{
 for(const [keys,types,keyType,typeType]of [[[key],[6,7],4,0],[[key,key],[6,6],4,0],[['bad'],[6],4,0],[[key],[256],4,0],[[key],[6],7,0],[[key],[6],4,6],[Array(65).fill(key),Array(65).fill(6),4,0]]){
  const records=new Map();column(records,'recordKeys',keyType,keys);column(records,'recordTypes',typeType,types.some(t=>t>255)?Uint32Array.from(types):Uint8Array.from(types));const before=[...records];assert.throws(()=>table.schema(records,owner),/Invalid HASH record declarations/);assert.deepEqual([...records],before);
 }
 for(const field of ['recordKeys','recordTypes']){const records=new Map();column(records,field,field==='recordKeys'?4:0,field==='recordKeys'?[key]:Uint8Array.of(6));assert.throws(()=>table.schema(records,owner),/Invalid HASH record declarations/);}
});
test('invalid outgoing rows publish neither column',()=>{
 for(const rows of [[{key,type:-1}],[{key,type:256}],[{key,type:6.5}],[{key:'bad',type:6}],[{key,type:6},{key,type:6}],Array(65).fill({key,type:6}),{}]){
  const records=new Map();assert.throws(()=>table.putSchema(records,owner,rows),/Invalid HASH record declarations/);assert.equal(records.size,0);
 }
});
test('unknown schema encoding takes precedence over interpretation of its partner',()=>{
 const records=new Map(),address=hash.address(owner,'recordTypes'),raw={id:address,type:64,opaque:{bytes:opaqueBlock(address,0x8040)}};records.set(address,raw);column(records,'recordKeys',7,'uninterpreted partner');
 assert.deepEqual(table.schema(records,owner),{opaque:true,rows:[]});const before=[...records];assert.throws(()=>table.putSchema(records,owner,[{key,type:6}]),/unsupported HASH/);assert.deepEqual([...records],before);
 table.putSchema(records,owner,[]);assert.deepEqual([...records],before);
});
test('unavailable declarations derive from canonical columns rather than a second owner map',()=>{
 const records=new Map();table.putSchema(records,owner,[{key,type:64}]);const address=hash.address(owner,key),raw={id:address,type:64,opaque:{bytes:opaqueBlock(address,64)}};records.set(address,raw);
 assert.deepEqual(table.declarations(records,owner,null),{version:1,tags:[],animation:[],pluginRecords:[{key,type:64}]});
 records.delete(hash.address(owner,'recordKeys'));records.delete(hash.address(owner,'recordTypes'));assert.equal(table.declarations(records,owner,null),null);
 assert.equal(section('function createFrameHashRecordTable(hash){','function createFrameHashCodec(){').includes('unknownDeclarations'),false);
});
test('an opaque payload cannot be replaced through its declaration or plugin write preflight',()=>{
 const records=new Map();table.putSchema(records,owner,[{key,type:64}]);const address=hash.address(owner,key),raw={id:address,type:64,opaque:{bytes:opaqueBlock(address,64)}};records.set(address,raw);
 assert.throws(()=>table.writable(records,owner,key),/unsupported HASH/);assert.doesNotThrow(()=>table.writable(records,owner,id(3)));
 for(const authoring of [{pluginRecords:[{key,type:6}]},{pluginRecords:[{key,type:64}],recordValues:{[key]:{type:64,value:[]}}}])assert.throws(()=>table.declarations(records,owner,authoring),/opaque plugin record|unsupported HASH/);
 assert.equal(records.get(address),raw);assert.deepEqual(table.schema(records,owner).rows,[{key,type:64}]);
});
test('payload availability is derived per owner and never activates an unknown interpreter',()=>{
 const records=new Map();table.putSchema(records,owner,[{key,type:6}]);assert.equal(table.usable(records,owner),false);assert.throws(()=>table.writable(records,owner,key),/unsupported HASH/);column(records,key,6,Float64Array.of(1));assert.equal(table.usable(records,owner),true);
 const address=hash.address(owner,key);records.set(address,{id:address,type:6,opaque:{bytes:opaqueBlock(address,6)}});assert.equal(table.usable(records,owner),false);
 const fresh=new Map();table.putSchema(fresh,owner,[{key,type:77}]);column(fresh,key,77,Uint8Array.of(1));assert.equal(table.usable(fresh,owner),false);assert.equal(table.usable(fresh,id(9)),true);
});
test('plugin writes cannot claim unowned preserved data or an absent native property',()=>{
 const records=new Map();column(records,key,6,Float64Array.of(1));assert.throws(()=>table.writable(records,owner,key),/undeclared HASH address/);
 for(const field of ['name','matrix','parent','recordKeys','recordTypes'])assert.throws(()=>table.writable(new Map(),owner,K[field]),/overlaps a native property/);
 const globalAlias=hash.address(owner,K.documentation);assert.throws(()=>table.writable(new Map(),owner,globalAlias),/overlaps a native property/);
});
test('the actual plugin setter validates native values and ownership before publication',()=>{
 const source=html.split('\n').find(l=>l.includes('records:hash=>{own(hash);'));
 const records=new Map(),node={},engine={setPluginRecord:(h,k,t,v)=>table.writePlugin(records,h,k,t,v),bindPluginRecords:()=>{}};
 const set=new Function('window','own','return ({'+source.trim()+'}).setRecord;')({frameEngine:engine},()=>node);
 assert.throws(()=>set(owner,key,7,'bad\ud800'),/Invalid plugin record value/);assert.equal(records.size,0);assert.equal(node.pluginRecords,undefined);
 column(records,key,6,Float64Array.of(1));assert.throws(()=>set(owner,key,6,[2]),/undeclared HASH address/);assert.equal(node.pluginRecords,undefined);
 records.clear();set(owner,key,7,'Literal JSON {"x":1}');assert.equal(records.get(hash.address(owner,key)).value,'Literal JSON {"x":1}');assert.equal(node.pluginRecords,undefined);
});
test('the actual setter rejects a sixty-fifth native record before publication',()=>{
 const source=html.split('\n').find(l=>l.includes('records:hash=>{own(hash);')),records=new Map(),node={};
 for(let i=0;i<64;i++)table.writePlugin(records,owner,id(100+i),6,[i]);
 const set=new Function('window','own','return ({'+source.trim()+'}).setRecord;')({frameEngine:{setPluginRecord:(h,k,t,v)=>table.writePlugin(records,h,k,t,v),bindPluginRecords:()=>{}}},()=>node),before=[...records];
 assert.throws(()=>set(owner,id(999),6,[1]),/Invalid plugin record count/);assert.deepEqual([...records],before);set(owner,id(100),6,[42]);assert.deepEqual(Array.from(records.get(hash.address(owner,id(100))).value),[42]);assert.equal(node.pluginRecords,undefined);
});
test('native namespace index follows canonical ID-list replacement and deletion',()=>{
 const {records}=table.begin();const set=(id,value)=>table.put(records,id,{id,type:T.ids,value});set(K.all,[owner]);const material=id(80),asset=id(81),tag=id(82),later=id(83);set(K.materials,[material]);set(K.assets,[asset]);set(hash.address(owner,'tags'),[tag]);
 for(const [h,field]of [[owner,'recordKeys'],[material,'maps'],[asset,'image'],[tag,'uv']])assert.throws(()=>table.checkAddress(records,hash.address(h,field)),/overlaps a native property/);
 assert.doesNotThrow(()=>table.checkAddress(records,hash.address(later,'uv')));set(hash.address(owner,'tags'),[later]);assert.throws(()=>table.checkAddress(records,hash.address(later,'uv')),/overlaps a native property/);assert.doesNotThrow(()=>table.checkAddress(records,hash.address(tag,'uv')));
 records.delete(hash.address(owner,'tags'));assert.doesNotThrow(()=>table.checkAddress(records,hash.address(later,'uv')));
});
test('native serialization excludes JSON declarations and clipboard captures the addressed columns',()=>{
 const writer=section('    function installNativeRecords(','    function nativeDocumentationText(');
 assert.ok(writer.includes('const {recordValues,pluginRecords,...authoring}=preservedAuthoring'));
 assert.ok(writer.includes('FrameHashRecords.putSchema(records,o.hash,pluginRecords)'));
 assert.ok(section('    function clipboardRecords(','    async function clipboardBlob(').includes("'parameters','recordKeys','recordTypes','tags'"));
 assert.ok(!html.includes('FrameHashRecords.rememberDeclaration('));
});
test('copy rejects an opaque schema before interpreting field payloads',()=>{
 const line=html.split('\n').find(l=>l.trim().startsWith('function assertNativeCopyRecords('));
 const guard=new Function('globalThis',line+';return assertNativeCopyRecords;')({window:{frameEngine:{pluginRecordSchemaSupported:()=>false}}});
 assert.throws(()=>guard([{hash:owner}]),/reference schema for opaque/);
});
test('known plugin activation is quarantined when its declaration schema is unsupported',()=>{
 const source=html.split('\n').find(l=>l.startsWith('function frameRestoreAuthoring(')),entry={manifest:{id:'known'}},FramePlugins={owner:n=>n.type==='known_type'?entry:null};
 const restore=new Function('globalThis','FramePlugins','defaults','definitions','tagDefinitions','frameRestoreChannels',source+';return frameRestoreAuthoring;')({window:{frameEngine:{pluginRecordSchemaSupported:()=>false}}},FramePlugins,()=>({}),{}, {},()=>{}),n={nativeHash:owner,type:'known_type',params:{},tags:[]},plugin={id:'known',type:'known_type',params:{}};
 restore(n,{version:1,plugin,tags:[],animation:[]});assert.equal(n.type,'group');assert.deepEqual(n.ignoredAuthoring.plugin,plugin);assert.equal(n.ignoredAuthoring.pluginReferencesUnresolved,undefined);
});
test('schema lookups stay addressed beside unrelated opaque records',()=>{
 const records=new Map();for(let i=100;i<10100;i++)records.set(id(i),{id:id(i),type:64,opaque:{bytes:Uint8Array.of(1)}});table.putSchema(records,owner,[{key,type:6}]);records[Symbol.iterator]=()=>{throw Error('No scene scan');};
 const start=performance.now();for(let i=0;i<10000;i++)assert.equal(table.schema(records,owner).rows[0].key,key);const elapsedMs=performance.now()-start;assert.ok(elapsedMs<500,{elapsedMs});console.log(JSON.stringify({operation:'10000 addressed schema lookups beside 10000 opaque records',elapsedMs,budgetMs:500,scope:'CPU, not browser/GPU'}));
});
test('namespace checks index known ID relationships without scanning unrelated record entries',()=>{
 const {records}=table.begin(),owners=Array.from({length:100000},(_,i)=>id(i+1));table.put(records,K.all,{id:K.all,type:T.ids,value:owners});records[Symbol.iterator]=()=>{throw Error('No record-entry scan');};records.values=()=>{throw Error('No record-entry scan');};
 const address=hash.address(owner,key),start=performance.now();for(let i=0;i<10000;i++)table.checkAddress(records,address);const elapsedMs=performance.now()-start;assert.ok(elapsedMs<1500,{elapsedMs});console.log(JSON.stringify({operation:'10000 native namespace checks, including index creation for 100000 owners',elapsedMs,budgetMs:1500,scope:'CPU synthetic relationship index, not live scene/GPU qualification'}));
});
