import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const oldPaste="    function pasteSelection(){const task=objectActionQueue.then(async()=>{await clipboardSerial;const shared=await sharedClipboard();if(shared)return mergeFile(new File([shared],'clipboard.hash'),{clipboard:true});if(!nativeClipboard?.roots.length)return [];if(nativeClipboard.gpu!==renderer||renderer.dead){releaseClipboard();throw Error('Clipboard GPU session expired');}const hashes=new Set(nativeClipboard.objects.map(o=>o.hash));for(const o of nativeClipboard.objects){const ref=o.spline?.params.object;if(ref&&ref!=='Drop object'&&!hashes.has(ref)&&!poseObjects().some(o=>o.hash===ref))throw Error('Clipboard references an object absent from this scene');}await selectionQueue;await editSerial;const g={space:scene,clipboard:nativeClipboard};await duplicateGizmoObjects(g);commitObjectCopy(g);await FrameSpline.flush();return selectedRoots();});objectActionQueue=task.catch(()=>{});return task;}\n";
const between=(text,start,end)=>text.slice(text.indexOf(start),text.indexOf(end,text.indexOf(start)));
const paste=text=>between(text,'    function pasteSelection(){','    async function duplicateRows(');

function deferred(){let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};}
const tick=()=>new Promise(resolve=>setTimeout(resolve,0));
function runtime(text,gate,old=false){
  const lifecycle=between(text,'    function disposeClipboard(clip){','    async function connectMeshes(');
  return new Function('gate',`
    const state={releases:[],commits:0},renderer={};let scene={},objectActionQueue=Promise.resolve(),clipboardSerial=Promise.resolve();
    const selectionQueue=Promise.resolve(),editSerial=Promise.resolve(),FrameSpline={flush:async()=>{}},sharedClipboard=async()=>null,poseObjects=()=>[],selectedRoots=()=>['copy'];
    const makeClip=token=>({token,gpu:renderer,roots:[token],objects:[{hash:token}],resources:new Map([[token,{positions:{name:token+':positions'},indices:{name:token+':indices'}}]])});
    let nativeClipboard=makeClip('old');const original=nativeClipboard;
    const releaseGPU=resource=>{if(!resource)return;resource.releases=(resource.releases||0)+1;state.releases.push(resource);};
    const duplicateGizmoObjects=async g=>{await gate.promise;for(const r of g.clipboard.resources.values())if(r.positions.releases||r.indices.releases)throw Error('Clipboard source GPU resource was destroyed during Paste');};
    const commitObjectCopy=()=>state.commits++;
    ${lifecycle}\n${old?oldPaste:paste(text)}
    return {state,original,pasteSelection,releaseClipboard,replace(){releaseClipboard();nativeClipboard=makeClip('new');},get clipboard(){return nativeClipboard;}};
  `)(gate);
}
export async function clipboardLifetimeChecks(html){
  html??=await readFile(new URL('../index.html',import.meta.url),'utf8');
  const checks=[],errors=[],timings=[];
  async function check(name,fn){const start=performance.now();try{await fn();const elapsed=performance.now()-start;assert.ok(elapsed<1000,`Completed CPU handler check ${elapsed.toFixed(1)}ms exceeds 1000ms`);checks.push(name);timings.push({name,ms:elapsed,budgetMs:1000});}catch(error){errors.push({name,error:error.stack||error.message});}}
await check('negative control reproduces current local Paste / Ctrl+C lifetime race',async()=>{
  const gate=deferred(),r=runtime(html,gate,true),pending=r.pasteSelection();await tick();r.replace();assert.equal(r.state.releases.length,2);gate.resolve();await assert.rejects(()=>pending,/destroyed during Paste/);assert.equal(r.state.commits,0);
});
await check('patched local Paste retains source GPU resources through concurrent recopy',async()=>{
  const gate=deferred(),r=runtime(html,gate),pending=r.pasteSelection();await tick();assert.equal(r.original.readers,1);r.replace();assert.equal(r.original.retired,true);assert.equal(r.state.releases.length,0);gate.resolve();assert.deepEqual(await pending,['copy']);assert.equal(r.state.commits,1);assert.equal(r.state.releases.length,2);assert.equal(r.original.readers,0);assert.equal(r.clipboard.token,'new');
});
await check('failed Paste releases retired source once and does not publish history',async()=>{
  const gate=deferred(),r=runtime(html,gate),pending=r.pasteSelection();await tick();r.replace();gate.reject(Error('GPU preparation rejected'));await assert.rejects(()=>pending,/GPU preparation rejected/);assert.equal(r.state.commits,0);assert.equal(r.state.releases.length,2);for(const resource of r.state.releases)assert.equal(resource.releases,1);assert.equal(r.original.readers,0);
});
await check('successful Paste leaves current clipboard alive for repeated Paste',async()=>{
  const gate=deferred(),r=runtime(html,gate);gate.resolve();await r.pasteSelection();await r.pasteSelection();assert.equal(r.state.releases.length,0);assert.equal(r.original.readers,0);assert.equal(r.state.commits,2);r.releaseClipboard();assert.equal(r.state.releases.length,2);
});

  return {pass:errors.length===0,checks,errors,timings};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){const html=process.env.FRAME_INDEX?await readFile(process.env.FRAME_INDEX,'utf8'):undefined;const result=await clipboardLifetimeChecks(html);console.log(JSON.stringify(result,null,2));if(!result.pass)process.exitCode=1;}
