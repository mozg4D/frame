import test from 'node:test';
import assert from 'node:assert/strict';
import {createFrameSceneStore,hash,id,opaqueBlock,seed,source} from './load-runtime.mjs';
const T=hash.T;
function fixture(){const store=createFrameSceneStore(hash);seed(store,[[id(1),T.text,'Original'],[id(2),T.float64,Float64Array.of(-0,1.2345678901234567)]]);return store;}
const failure=code=>error=>error.code===code;

test('one canonical Map holds immutable addressed record versions, never decoded object trees',()=>{
  const store=fixture(),record=store.records.get(id(2)),values=record.value;values[0]=700;values[1]=0;
  assert.equal(store.records.set,undefined);assert.ok(Object.is(record.at(0),-0));assert.equal(record.at(1),1.2345678901234567);
  assert.equal(record.value[1],1.2345678901234567);assert.equal(Object.isFrozen(record),true);assert.throws(()=>{record.id=id(9);},TypeError);
  const tx=store.begin('Typed input');const input=Uint32Array.of(2,3);tx.set(id(3),T.uint32,input);input[0]=700;tx.commit().delta.release();assert.equal(store.records.get(id(3)).at(0),2);
});

test('multi-record publication is atomic to observers, before/after refs are delta-only, and no-op has no history',()=>{
  const store=fixture(),events=[];store.subscribe(e=>{events.push(e);assert.equal(store.scalar(id(1)),'New');assert.equal(store.records.get(id(2)).at(0),12);});
  const old=store.records.get(id(1)),tx=store.begin('Change two fields');tx.set(id(1),T.text,'New').set(id(2),T.float64,Float64Array.of(12,5));assert.equal(store.scalar(id(1)),'Original');
  const receipt=tx.commit();assert.equal(receipt.committed,true);assert.equal(receipt.delta.entries.length,2);assert.equal(receipt.delta.entries[0].before,old);assert.equal(events.length,1);assert.equal(events[0].delta,undefined);
  receipt.delta.release();const revision=store.revision,noop=store.begin('No-op');noop.set(id(1),T.text,'New');assert.deepEqual(noop.commit(),{committed:false,documentId:store.documentId,epoch:0,revision,delta:null});
});

test('addressed CAS rejects stale read dependencies and preserves repeatable reads',()=>{
  const store=fixture(),pending=store.begin('Computed'),first=pending.get(id(1));pending.set(id(3),T.text,'computed');
  const concurrent=store.begin('Other');concurrent.set(id(1),T.text,'Other');concurrent.commit().delta.release();assert.equal(pending.get(id(1)),first);
  assert.throws(()=>pending.commit(),failure('TRANSACTION_CONFLICT'));assert.equal(store.records.has(id(3)),false);assert.equal(pending.closed,true);
});

test('read revisions reject transaction ABA even when exact old record ref is restored by Undo',()=>{
  const store=fixture(),pending=store.begin('Stale');pending.get(id(1));pending.set(id(3),T.text,'wrong');
  const tx=store.begin('Other');tx.set(id(1),T.text,'Other');const delta=tx.commit().delta;store.replay(delta);assert.equal(store.scalar(id(1)),'Original');
  assert.throws(()=>pending.commit(),failure('TRANSACTION_CONFLICT'));delta.release();
});

test('causal record lineage permits legal overlapping linear Undo/Redo without accepting unrelated ABA',()=>{
  const store=fixture(),tx=store.begin('A');tx.set(id(1),T.text,'A');const a=tx.commit().delta;
  const tx2=store.begin('B');tx2.set(id(1),T.text,'B');const b=tx2.commit().delta;
  assert.throws(()=>store.replay(a),failure('HISTORY_CONFLICT'));store.replay(b);store.replay(a);assert.equal(store.scalar(id(1)),'Original');
  store.replay(a,'redo');store.replay(b,'redo');assert.equal(store.scalar(id(1)),'B');
  const original=b.entries[0].before,other=store.begin('Unrelated return');other.put(original);const c=other.commit().delta;
  assert.throws(()=>store.replay(a),failure('HISTORY_CONFLICT'));c.release();b.release();a.release();
});

test('create/delete lineage handles absent-record ABA, per-key disjoint edits stay independent',()=>{
  const store=fixture(),t=store.begin('Create');t.set(id(9),T.text,'Nine');const create=t.commit().delta;
  const t2=store.begin('Delete');t2.delete(id(9));const remove=t2.commit().delta;
  store.replay(remove);store.replay(create);assert.equal(store.records.has(id(9)),false);store.replay(create,'redo');store.replay(remove,'redo');assert.equal(store.records.has(id(9)),false);
  const disjoint=store.begin('Disjoint');disjoint.set(id(1),T.text,'X');const d=disjoint.commit().delta;store.replay(remove);assert.equal(store.scalar(id(1)),'X');d.release();remove.release();create.release();
});

test('transaction abort, invalid input and batch conflict publish nothing and release reservations',()=>{
  const store=fixture(),epoch=store.epoch,revision=store.revision;
  const tx=store.begin('Abort');tx.reserveAddresses([id(3),id(4)]).set(id(3),T.text,'Three');tx.abort();tx.abort();assert.equal(store.records.size,2);assert.equal(store.revision,revision);
  for(const value of [new Float32Array(2),new Float64Array(new SharedArrayBuffer(8))]){const invalid=store.begin('Invalid');assert.throws(()=>invalid.set(id(3),T.float64,value),failure('INVALID_VALUE'));invalid.abort();}
  const invalid=store.begin();assert.throws(()=>invalid.set(id(3),T.text,'\ud800'),failure('INVALID_VALUE'));assert.throws(()=>invalid.set('wrong',T.text,'bad'),failure('INVALID_ID'));invalid.abort();
  const next=store.begin();next.reserveAddresses([id(3)]).set(id(3),T.text,'Three');next.commit().delta.release();assert.equal(store.epoch,epoch);
});

test('address reservations reject explicit collisions atomically and do not claim semantic UID authority',()=>{
  const store=fixture(),a=store.begin(),b=store.begin();a.reserveAddresses([id(8)]);
  assert.throws(()=>b.reserveAddresses([id(7),id(8)]),failure('ADDRESS_CONFLICT'));const c=store.begin();c.reserveAddresses([id(7)]).set(id(7),T.text,'Seven');c.commit().delta.release();
  b.abort();const conflicting=store.begin();conflicting.set(id(8),T.text,'Unreserved write');assert.throws(()=>conflicting.commit(),failure('ADDRESS_CONFLICT'));a.abort();
  assert.equal(store.capabilities().identityReservations,false);assert.equal(store.capabilities().addressReservations,true);
  const occupied=store.begin();assert.throws(()=>occupied.reserveAddresses([id(1)]),failure('ADDRESS_CONFLICT'));occupied.abort();
});

test('document replacement invalidates old transactions/deltas without invalidating retained CPU version leases',()=>{
  const store=fixture(),pin=store.pinAddresses([id(1),id(2)]),tx=store.begin('Pending'),old=tx.get(id(1));tx.set(id(1),T.text,'One');const committed=tx.commit().delta;
  const pending=store.begin();pending.get(id(2));store.replace();assert.equal(store.records.size,0);assert.equal(pin.records[0],old);assert.equal(pin.records[0].value,'Original');
  assert.throws(()=>pending.commit(),failure('DOCUMENT_CHANGED'));assert.throws(()=>store.replay(committed),failure('INVALID_DELTA'));committed.release();pin.release();
});

test('lease owners and active uses have independent idempotent lifetimes',()=>{
  const store=fixture(),pin=store.pinAddresses([id(1),id(2)]),use=pin.acquireUse('paste');pin.release();pin.release();assert.equal(pin.released,true);assert.equal(use.records[0].value,'Original');assert.equal(store.stats.pinnedRecords,2);
  assert.throws(()=>pin.acquireUse(),failure('RELEASED_LEASE'));use.release();use.release();assert.equal(store.stats.pinnedRecords,0);
});

test('opaque records remain owned, exact raw metadata/payload survives export and arbitrary remap/edit rejects',async()=>{
  const store=createFrameSceneStore(hash),input=opaqueBlock(id(50),0x8040),tx=store.begin('Opaque');tx.preserve(id(50),input);tx.commit().delta.release();input.fill(0);
  const original=store.opaqueBytes(store.records.get(id(50))),r=store.records.get(id(50));assert.equal(r.rawType,0x8040);assert.equal(r.byteLength,null);
  original[26]=123;assert.equal(store.opaqueBytes(r)[26],0);const pin=store.pinAddresses([id(50)]),blob=await store.exportRecords(pin);pin.release();assert.deepEqual(new Uint8Array(await blob.arrayBuffer()),opaqueBlock(id(50),0x8040));
  const edit=store.begin('Bad edit');edit.set(id(50),T.text,'Delete unknown');assert.throws(()=>edit.commit(),failure('OPAQUE_EDIT_SCHEMA'));
  const remap=store.begin('Bad remap');assert.throws(()=>remap.alias(id(51),r),failure('OPAQUE_REMAP_SCHEMA'));remap.abort();assert.equal(store.records.get(id(50)),r);
});

test('opaque malformed lengths/addresses and duplicate writes cannot bypass validation',()=>{
  const store=createFrameSceneStore(hash),tx=store.begin();assert.throws(()=>tx.preserve(id(2),opaqueBlock(id(1),64)),failure('INVALID_OPAQUE'));
  assert.throws(()=>tx.preserve(id(1),new Uint8Array(25)),failure('INVALID_OPAQUE'));const block=opaqueBlock(id(1),64);new DataView(block.buffer).setBigUint64(18,99n,true);assert.throws(()=>tx.preserve(id(1),block),failure('INVALID_OPAQUE'));tx.abort();
});

test('native type-4 relations are first-class immutable HASH values, aliases share record payload, not a graph',()=>{
  const store=createFrameSceneStore(hash),tx=store.begin();tx.set(hash.K.all,T.ids,[id(1),id(2)]).set(hash.address(id(2),'parent'),T.ids,[id(1)]);tx.commit().delta.release();
  const refs=store.records.get(hash.K.all),copy=store.begin();copy.alias(id(100),refs);const receipt=copy.commit();assert.deepEqual(store.records.get(id(100)).value,[id(1),id(2)]);assert.equal(store.stats.copiedBytes,48);receipt.delta.release();
});

test('typed range edit copies only its addressed record, preserves negative zero and replays versions',()=>{
  const store=fixture(),before=store.stats,tx=store.begin('Range');tx.patchRange(id(2),1,Float64Array.of(42));const receipt=tx.commit();assert.equal(receipt.delta.entries.length,1);assert.ok(Object.is(store.records.get(id(2)).at(0),-0));assert.equal(store.records.get(id(2)).at(1),42);assert.equal(store.stats.copiedBytes-before.copiedBytes,16);
  store.replay(receipt.delta);assert.equal(store.records.get(id(2)).at(1),1.2345678901234567);receipt.delta.release();
});

test('post-publication notification failures never turn a committed receipt into a false failed action',async()=>{
  const store=fixture();store.subscribe(()=>{throw Error('Listener');});store.subscribe(async()=>{throw Error('Async listener');});store.subscribe(()=>{store.begin();});
  const tx=store.begin('Commit once');tx.set(id(1),T.text,'Committed');const receipt=tx.commit();assert.equal(receipt.committed,true);assert.equal(store.scalar(id(1)),'Committed');await new Promise(r=>setImmediate(r));assert.equal(store.diagnostics.length,3);receipt.delta.release();
});

test('foreign records/deltas, wrong expected revisions and replay direction errors never mutate',()=>{
  const store=fixture(),other=fixture(),tx=store.begin();assert.throws(()=>tx.put(other.records.get(id(1))),failure('FOREIGN_RECORD'));assert.throws(()=>tx.expect(id(1),999),failure('TRANSACTION_CONFLICT'));tx.abort();
  const action=store.begin();action.set(id(1),T.text,'A');const delta=action.commit().delta;assert.throws(()=>other.replay(delta),failure('INVALID_DELTA'));store.replay(delta);assert.throws(()=>store.replay(delta),failure('INVALID_DELTA'));delta.release();assert.throws(()=>store.replay(delta,'redo'),failure('INVALID_DELTA'));
});

test('source contains one generic store and no JSON/object-scene snapshots or codec clone',()=>{
  const core=source.slice(source.indexOf('function createFrameSceneStore(hash,'),source.indexOf('// Generic HASH ingestion'));
  for(const forbidden of [/JSON\./,/structuredClone\(/,/poseObjects\(/,/restoreStructure\(/,/function createFrameHashCodec/])assert.equal(forbidden.test(core),false,String(forbidden));
  const store=fixture();assert.deepEqual(store.capabilities(),{immutableCpuPins:true,immutableGpuPins:false,addressReservations:true,identityReservations:false,addressedTransactions:true,recordDeltas:true,atomicPublication:true,recordDeltaHistory:false,ownershipClosure:false,schemaRemap:false,recordDrivenProjection:false});
});

test('actual Frame native name validators/read-through view execute against the sole SceneStore table',()=>{
  const line=name=>source.split('\n').find(l=>l.trim().startsWith('function '+name+'('));
  const code=[line('nativeValue'),line('nativeObjectName'),line('nativeSetObjectName'),line('bindObjectName')].join('\n');
  const store=createFrameSceneStore(hash),owner=id(999),seedTx=store.begin('Native seed');seedTx.set(hash.K.all,T.ids,[owner]).set(hash.address(owner,'name'),T.text,'Before');seedTx.commit().delta.release();
  const r=new Function('store','FrameHash','owner',`const scene={records:store.records,nativeOwnerIds:new Set([owner])},receipts=[];${source.split('\n').find(l=>l.trim().startsWith('const nativeNameViews='))}let nativeIOBusy=false;function nativePut(map,id,field,type,value){if(map!==store.records)throw Error('Second table');const tx=store.begin('Native name');tx.set(FrameHash.address(id,field),type,value);receipts.push(tx.commit());}${code};const node={nativeHash:owner};bindObjectName(node);return {node,receipts};`)(store,hash,owner);
  assert.equal(Object.getOwnPropertyDescriptor(r.node,'name').value,undefined);r.node.name='After';assert.equal(store.scalar(hash.address(owner,'name')),'After');assert.equal(r.receipts.length,1);assert.equal(r.receipts[0].delta.entries.length,1);
  store.replay(r.receipts[0].delta);assert.equal(r.node.name,'Before');store.replay(r.receipts[0].delta,'redo');assert.equal(r.node.name,'After');assert.throws(()=>{r.node.name='bad\0name';},/Invalid object name/);r.receipts[0].delta.release();
});


test('old-document transactions cannot reserve addresses or observe a replacement document',()=>{
  const store=fixture(),old=store.begin('Old');store.replace();assert.throws(()=>old.reserveAddresses([id(99)]),failure('DOCUMENT_CHANGED'));assert.throws(()=>old.reserveAddresses([]),failure('DOCUMENT_CHANGED'));assert.throws(()=>old.get(id(99)),failure('DOCUMENT_CHANGED'));
  const fresh=store.begin('Fresh');fresh.set(id(99),T.text,'Fresh');fresh.commit().delta.release();assert.equal(store.scalar(id(99)),'Fresh');old.abort();
});


test('reservation iterable callbacks cannot steal another transaction claim or reserve after replacement',()=>{
  const store=fixture(),a=store.begin(),b=store.begin();function* ids(){yield id(80);b.reserveAddresses([id(80)]);yield id(81);}assert.throws(()=>a.reserveAddresses(ids()),failure('ADDRESS_CONFLICT'));
  const c=store.begin();c.set(id(80),T.text,'No claim');assert.throws(()=>c.commit(),failure('ADDRESS_CONFLICT'));a.abort();b.abort();
  const stale=store.begin();function* replace(){store.replace();yield id(99);}assert.throws(()=>stale.reserveAddresses(replace()),failure('DOCUMENT_CHANGED'));stale.abort();
});


test('address pins can enforce planned revisions; explicit version pins never re-resolve newer address contents',()=>{
  const store=fixture(),old=store.records.get(id(1)),epoch=store.epoch,expectedRevisions=new Map([[id(1),store.version(id(1))]]),tx=store.begin();tx.set(id(1),T.text,'New');tx.commit().delta.release();
  assert.throws(()=>store.pinAddresses([id(1)],{expectedEpoch:epoch,expectedRevisions}),failure('TRANSACTION_CONFLICT'));const exact=store.pinVersions([old]);assert.equal(exact.records[0].value,'Original');exact.release();store.replace();assert.throws(()=>store.pinAddresses([],{expectedEpoch:epoch}),failure('DOCUMENT_CHANGED'));
});

test('expect preserves tombstones for absent-create-delete ABA',()=>{
  const store=fixture(),pending=store.begin('Absent-derived');pending.expect(id(77),0).set(id(3),T.text,'Stale result');const create=store.begin();create.set(id(77),T.text,'Temporary');create.commit().delta.release();const remove=store.begin();remove.delete(id(77));remove.commit().delta.release();assert.equal(store.records.has(id(77)),false);assert.throws(()=>pending.commit(),failure('TRANSACTION_CONFLICT'));assert.equal(store.records.has(id(3)),false);
});


test('public RecordRef constructor cannot admit caller-owned mutable payloads or forge canonical versions',()=>{
  const store=fixture(),Constructor=store.records.get(id(1)).constructor,input=Float64Array.of(1);assert.throws(()=>new Constructor(id(99),hash.T.float64,{kind:'cpu',value:input},8),failure('FOREIGN_RECORD'));assert.equal(Object.isFrozen(Constructor.prototype),true);assert.throws(()=>{Constructor.prototype.value='Forged';},TypeError);assert.equal(store.records.has(id(99)),false);
});


test('caller-owned slice methods/getters cannot create mutable canonical ID lists or opaque bytes',()=>{
  const store=createFrameSceneStore(hash);let current=id(1);const ids=[id(1)],trap=[];Object.defineProperty(trap,'0',{get:()=>current,enumerable:true});trap.length=1;ids.slice=()=>trap;
  const raw=opaqueBlock(id(10),64);raw.slice=()=>raw;const tx=store.begin();tx.set(id(5),hash.T.ids,ids).preserve(id(10),raw);tx.commit().delta.release();current=id(2);raw[26]=123;
  assert.equal(store.records.get(id(5)).at(0),id(1));assert.equal(store.opaqueBytes(store.records.get(id(10)))[26],0);
});

test('planned-revision input is normalized before CAS checks, not invoked during comparison',()=>{
  const store=fixture(),expected=new Map([[id(1),store.version(id(1))]]),old=store.records.get(id(1));let calls=0;expected.get=()=>{calls++;const tx=store.begin();tx.set(id(1),hash.T.text,'Changed from callback');tx.commit().delta.release();return 1;};
  const pin=store.pinAddresses([id(1)],{expectedRevisions:expected});assert.equal(calls,0);assert.equal(pin.records[0],old);pin.release();
  const reentrant=new Map([[id(1),store.version(id(1))]]);reentrant[Symbol.iterator]=function*(){const oldRevision=store.version(id(1));const tx=store.begin();tx.set(id(1),hash.T.text,'Changed during normalization');tx.commit().delta.release();yield [id(1),oldRevision];};
  assert.throws(()=>store.pinAddresses([id(1)],{expectedRevisions:reentrant}),failure('TRANSACTION_CONFLICT'));
});


test('own buffer/length accessors cannot hide shared input storage or bypass byte budgets',()=>{
  const store=createFrameSceneStore(hash),shared=new Float64Array(new SharedArrayBuffer(8));Object.defineProperty(shared,'buffer',{value:new ArrayBuffer(8)});const tx=store.begin();assert.throws(()=>tx.set(id(1),hash.T.float64,shared),failure('INVALID_VALUE'));
  const raw=new Uint8Array(new SharedArrayBuffer(26));Object.defineProperty(raw,'buffer',{value:new ArrayBuffer(26)});assert.throws(()=>tx.preserve(id(2),raw),failure('INVALID_OPAQUE'));tx.abort();
  const limited=createFrameSceneStore({...hash,MAX_RECORD:8}),large=Uint8Array.of(1,2,3,4,5,6,7,8,9);Object.defineProperty(large,'byteLength',{value:1});const edit=limited.begin();assert.throws(()=>edit.set(id(1),hash.T.bytes,large),failure('RECORD_LIMIT'));edit.abort();
});
