import {createFrameSceneStore,hash,id} from './load-runtime.mjs';
import {performance} from 'node:perf_hooks';
const mode=process.argv[2],count=100000,owners=Array.from({length:count},(_,i)=>id(i+1));
if(!global.gc||!['plain-native-map','scene-store'].includes(mode))throw Error('Use --expose-gc and mode plain-native-map or scene-store');
global.gc();const before=process.memoryUsage().heapUsed,start=performance.now();let table;
if(mode==='plain-native-map'){
  const records=new Map(),put=(key,type,value)=>records.set(key,{id:key,type,value});
  put(hash.K.all,hash.T.ids,owners);for(const owner of owners){put(hash.address(owner,'name'),hash.T.text,'Object '+owner);put(hash.address(owner,'type'),hash.T.bytes,Uint8Array.of(0));}table=records;
}else{
  table=createFrameSceneStore(hash);const tx=table.begin('Seed');tx.set(hash.K.all,hash.T.ids,owners);for(const owner of owners){tx.set(hash.address(owner,'name'),hash.T.text,'Object '+owner);tx.set(hash.address(owner,'type'),hash.T.bytes,Uint8Array.of(0));}tx.commit().delta.release();
}
const elapsed=performance.now()-start;global.gc();console.log(JSON.stringify({mode,owners:count,records:mode==='scene-store'?table.records.size:table.size,seedMs:+elapsed.toFixed(3),retainedHeapDeltaMiB:+((process.memoryUsage().heapUsed-before)/1048576).toFixed(2),note:'Synthetic after-GC JS heap estimate, not peak RAM or a complete editor baseline'}));
