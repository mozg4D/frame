import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {webcrypto} from 'node:crypto';
import {hash,source as html,id,opaqueBlock} from './load-runtime.mjs';
const section=(a,b)=>{const i=html.indexOf(a),j=html.indexOf(b,i);assert.ok(i>=0&&j>i,a);return html.slice(i,j);};
const table=new Function(section('function createFrameHashRecordTable(hash){','function createFrameHashCodec(){')+';return createFrameHashRecordTable;')()(hash);
const {T,K}=hash,owner=id(1),key=id(900),address=hash.address(owner,key);
function engine(records=new Map()){
 return new Function('FrameHash','FrameHashRecords','FramePlugins','initial',`let scene={records:initial},nativeIOBusy=false,sceneFrameDirty=false,poseRecordCache=null;const appearanceTags=()=>[],frameValidateAuthoring=()=>null,FrameSpline={};${section('    function nativeObjects(','    function installNativeRecords(')};${html.split('\n').find(l=>l.trim().startsWith('function poseObjects('))};${section('    function nativePluginRecords(','    const nativeNameViews=')};return {pose:()=>poseObjects()[0]?.authoring,read:nativePluginRecords,write:nativeSetPluginRecord,clear:nativeClearPluginRecords,bind:bindPluginRecords,swap:r=>scene={records:r},busy:v=>nativeIOBusy=v,get records(){return scene.records},get dirty(){return sceneFrameDirty}};`)(hash,table,{owner:n=>n.type==='known'},records);
}
function leases(nodes=[]){
 const start=html.indexOf('const FramePluginRecords=(()=>{'),end=html.indexOf('\n})();',start)+6,undoStack=[],redoStack=[];
 const value=new Function('FrameHashRecords','nodes','crypto','window','undoStack','redoStack',html.slice(start,end)+';return FramePluginRecords;')(table,nodes,webcrypto,{frameEngine:{pluginHistoryRecords:()=>[]}},undoStack,redoStack);
 return {value,undoStack,redoStack};
}
test('native plugin writes publish one canonical payload and two native columns',()=>{
 const e=engine(),n={nativeHash:owner,type:'known'};e.bind(n);const input=Float64Array.of(-0,1.25,2.5);e.write(owner,key,T.float64,input);
 const r=e.records.get(address);assert.equal(e.records.size,3);assert.ok(r.value instanceof Float64Array);assert.notEqual(r.value,input);assert.deepEqual(r.value,input);input[1]=99;
 assert.equal(n.pluginRecords[key].value,r.value);assert.equal(n.pluginRecords[key].value[1],1.25);assert.equal(e.dirty,true);assert.equal(Object.hasOwn(Object.getOwnPropertyDescriptor(n,'pluginRecords'),'value'),false);
 assert.deepEqual(table.schema(e.records,owner).rows,[{key,type:6}]);
});
test('views share one accessor and follow replaced addressed records and table publication',()=>{
 const e=engine(),a={nativeHash:owner,type:'known'},b={nativeHash:owner,type:'known'};e.bind(a);e.bind(b);
 assert.equal(Object.getOwnPropertyDescriptor(a,'pluginRecords').get,Object.getOwnPropertyDescriptor(b,'pluginRecords').get);
 e.write(owner,key,6,[1]);const before=a.pluginRecords[key].value;e.write(owner,key,6,[2]);assert.notEqual(a.pluginRecords[key].value,before);assert.deepEqual(Array.from(before),[1]);
 const next=new Map();table.writePlugin(next,owner,key,6,[3]);e.swap(next);assert.equal(a.pluginRecords[key].value,next.get(address).value);
});
test('binding retires a transient decoded history projection after canonical publication',()=>{
 const e=engine(),n={nativeHash:owner,type:'known',pluginRecords:{[key]:{type:6,value:[99]}}};e.write(owner,key,6,[1]);e.bind(n);assert.deepEqual(Array.from(n.pluginRecords[key].value),[1]);
 Object.defineProperty(n,'pluginRecords',{value:{},writable:true,configurable:true});e.bind(n);assert.deepEqual(Array.from(n.pluginRecords[key].value),[1]);
});
test('every supported primitive retains exact native pack/read semantics',async()=>{
 for(const [type,input]of [[0,[0,255]],[3,[0,4294967295]],[4,[id(2),id(2)]],[5,[-0,0.1]],[6,[-0,Number.MIN_VALUE,1.25]],[7,'Literal {"x":1}\0💡']]){
  const records=new Map();table.writePlugin(records,owner,key,type,input);const r=records.get(address),packed=await hash.pack(r),index=await hash.index(packed.blob),value=await hash.read(packed.blob,index.get(address));
  assert.deepEqual(value,r.value);if(type===5)assert.equal(value[1],Math.fround(0.1));if(type===4)assert.ok(Object.isFrozen(r.value));
 }
});
test('invalid values, aliases and quota failures leave all addressed records unchanged',()=>{
 const e=engine();e.write(owner,key,6,[1]);
 for(const [k,t,v]of [[key,0,[-1]],[key,3,[1.5]],[key,5,[1e300]],[key,6,[NaN]],[key,4,['bad']],[key,7,'\ud800'],[K.name,6,[2]],[key,77,[2]]]){
  const before=[...e.records];assert.throws(()=>e.write(owner,k,t,v));assert.deepEqual([...e.records],before);
 }
 for(let i=0;i<63;i++)e.write(owner,id(1000+i),6,[i]);const before=[...e.records];assert.throws(()=>e.write(owner,id(9999),6,[1]),/count/);assert.deepEqual([...e.records],before);
});
test('busy or replaced documents reject before publishing normalized plugin values',()=>{
 const e=engine();e.busy(true);assert.throws(()=>e.write(owner,key,6,[1]),/busy/);assert.equal(e.records.size,0);e.busy(false);
 const original=e.records,input={*[Symbol.iterator](){e.swap(new Map());yield 1;}};assert.throws(()=>e.write(owner,key,6,input),/document changed/);assert.equal(original.size,0);assert.equal(e.records.size,0);
});
test('opaque values and unknown schema partners remain byte-exact and read-only',()=>{
 for(const field of [key,'recordTypes']){
  const records=new Map();table.writePlugin(records,owner,key,6,[1]);const addr=hash.address(owner,field),raw={id:addr,type:77,opaque:{bytes:opaqueBlock(addr,0x804d)}};records.set(addr,raw);const before=[...records];
  assert.throws(()=>table.writePlugin(records,owner,key,6,[2]),/unsupported/);assert.throws(()=>table.clearPlugin(records,owner),/unsupported/);assert.deepEqual([...records],before);assert.equal(records.get(addr),raw);
 }
});
test('clearing known declarations preserves unrelated raw records without scanning the table',()=>{
 const records=new Map();table.writePlugin(records,owner,key,6,[1]);const unknown=id(9999),raw={id:unknown,type:77,opaque:{bytes:opaqueBlock(unknown,77)}};records.set(unknown,raw);
 records[Symbol.iterator]=()=>{throw Error('No full-scene table traversal');};table.clearPlugin(records,owner);assert.equal(records.size,1);assert.equal(records.get(unknown),raw);
});
test('history leases share canonical native arrays without an author or typed CPU mirror',()=>{
 const e=engine(),n={nativeHash:owner,type:'known'};e.bind(n);e.write(owner,key,6,Float64Array.of(1,2,3));const canonical=e.records.get(address).value,{value:l,undoStack}=leases([n]);
 const snapshot=JSON.stringify(n,l.replacer),restored=JSON.parse(snapshot,l.reviver);assert.equal(restored.pluginRecords[key].value,canonical);assert.equal(l.native(restored.pluginRecords)[key].value,canonical);
 undoStack.push(snapshot);e.write(owner,key,6,[4,5,6]);assert.equal(l.bytes(),canonical.byteLength);l.collect();assert.equal(JSON.parse(snapshot,l.reviver).pluginRecords[key].value,canonical);
 undoStack.length=0;l.collect();assert.throws(()=>JSON.parse(snapshot,l.reviver),/Retired authoring record/);
});
test('known primitive arrays remain zero-copy internally after validation and replacement preserves older versions',()=>{
 const records=new Map();table.writePlugin(records,owner,key,6,[1,2]);const before=records.get(address).value;assert.equal(table.pluginValue(6,before),before);table.writePlugin(records,owner,id(901),6,before);assert.equal(records.get(hash.address(owner,id(901))).value,before);
 table.writePlugin(records,owner,key,6,[3,4]);assert.deepEqual(Array.from(before),[1,2]);assert.deepEqual(Array.from(records.get(hash.address(owner,id(901))).value),[1,2]);
});
test('plugin column/ref replacement does not rebuild the native owner namespace index',()=>{
 const {records}=table.begin();table.put(records,K.all,{id:K.all,type:T.ids,value:Array.from({length:100000},(_,i)=>id(i+1))});
 const get=records.get;let rootReads=0;records.get=function(address){if(address===K.all)rootReads++;return get.call(this,address);};
 records[Symbol.iterator]=()=>{throw Error('No whole-table staging clone');};
 for(let i=0;i<100;i++)table.writePlugin(records,owner,key,T.ids,[id(800000+i)]);
 assert.equal(rootReads,1,'Only relationship changes may invalidate the derived namespace');
 table.put(records,K.all,{id:K.all,type:T.ids,value:[owner]});const afterRelationshipWrite=rootReads;table.writePlugin(records,owner,key,T.ids,[id(2)]);assert.equal(rootReads,afterRelationshipWrite+1);
});

const atomic=await readFile(new URL('../plugins/atomic/plugin.js',import.meta.url),'utf8');
test('actual Atomic typed columns produce atom objects and flattened survivor reference positions',()=>{
 const line=prefix=>atomic.split('\n').find(l=>l.trim().startsWith(prefix));
 const data=new Map(),P='P',Z='Z',IDS='IDS',MEMBERS='MEMBERS',REST='REST',n={id:'n',type:'atomic'},row={id:'r'};
 data.set(n,{P:Float64Array.of(0.25,1,2,3,4,5,6,7,8),Z:Uint32Array.of(1,6,8),IDS:Uint32Array.of(10,20,30)});data.set(row,{MEMBERS:Uint32Array.of(10,20,30),REST:Float64Array.of(10,11,12,20,21,22,30,31,32)});
 let saved;const writes=new Map(),val=(n,k)=>data.get(n)[k],fn=new Function('val','P','Z','IDS','MEMBERS','REST','elements','allRows','ancestor','record','saveList','selection',line('const list=')+'\n'+line('function removeAtoms(')+';return {list,removeAtoms};')(val,P,Z,IDS,MEMBERS,REST,new Set([1,6,8]),()=>[row],()=>n,(_r,k,v)=>writes.set(k,v),(_n,v)=>saved=v,new Set([20]));
 assert.equal(fn.list(n)[1].id,20);assert.ok(Array.isArray(fn.list(n)[0].p));fn.removeAtoms(n,[20]);assert.deepEqual(saved.map(a=>a.id),[10,30]);assert.deepEqual(writes.get(MEMBERS),[10,30]);assert.deepEqual(writes.get(REST),[10,11,12,30,31,32]);
});
test('actual Atomic preview snapshot flattens held typed positions and anchored membership',async()=>{
 const source=atomic.split('\n').find(l=>l.trim().startsWith('async function snapshot(w,')),n={},r={},data=new Map([[n,{P:Float64Array.of(0,1,2,3,4,5)}],[r,{MEMBERS:Uint32Array.of(10)}]]);let fixed;
 const fn=new Function('snapshotAll','own','val','P','MEMBERS','record','find','updateFixedReference',source+';return snapshot;')(async()=>{},()=>n,(n,k)=>data.get(n)[k],'P','MEMBERS',(_n,k,v)=>{assert.ok(v.every(x=>typeof x==='number'));data.get(n)[k]=Float64Array.from(v);},()=>r,(_w,ids)=>fixed=ids);
 const w={hash:owner,gpu:{n:2,preview:true,dirtyPhysics:true,atoms:[{id:10,p:[9,9,9]},{id:20,p:[8,8,8]}]},dirtyIds:new Set([20]),fixedResources:new Map([[id(2),{basis:true}]])};
 await fn(w,true);assert.deepEqual(Array.from(data.get(n).P),[0,1,2,8,8,8]);assert.deepEqual([...fixed],[10]);assert.equal(w.token,data.get(n).P);assert.equal(w.gpu.dirtyPhysics,false);
});
test('actual Atomic fixed-reference edit copies typed storage before splice and preserves borrowed input',()=>{
 const source=atomic.split('\n').find(l=>l.trim().startsWith('function updateFixedReference(')),n={nativeHash:owner},r={nativeHash:id(2),type:'atomic_fixed'},rest=Float64Array.of(1,2,3,4,5,6);
 const data=new Map([[n,{P:Float64Array.of(10,11,12,20,21,22),IDS:Uint32Array.of(10,20)}],[r,{OWNER:[owner],MEMBERS:Uint32Array.of(10,20),REST:rest,FRAME:Float64Array.of(1)}]]),val=(n,k)=>data.get(n)[k];let written;
 const M={mul:()=>[],inv:()=>[],point:(_m,p)=>Array.from(p)},D={world:()=>[]};
 const fn=new Function('val','P','IDS','OWNER','MEMBERS','REST','FRAME','allRows','ancestor','M','D','record',source+';return updateFixedReference;')(val,'P','IDS','OWNER','MEMBERS','REST','FRAME',()=>[r],()=>n,M,D,(_r,_k,v)=>written=v);
 fn({node:n},new Set([20]));assert.deepEqual(written,[1,2,3,20,21,22]);assert.deepEqual(Array.from(rest),[1,2,3,4,5,6]);
});
test('actual Atomic selection capture maps typed IDs to pairs and flat reference coordinates',()=>{
 const source=atomic.split('\n').find(l=>l.trim().startsWith('function createSelection(')),n={nativeHash:owner},r={nativeHash:id(2)},data={IDS:Uint32Array.of(10,20),P:Float64Array.of(1,2,3,4,5,6)},writes=new Map();
 const identity=()=>Float64Array.from({length:16},(_,i)=>i%5===0?1:0),M={I:identity,mul:identity,inv:identity,point:(_m,p)=>p,pack:x=>x},D={create:()=>r,world:identity};
 const fn=new Function('idsArg','find','ancestor','D','record','MEMBERS','OWNER','REST','FRAME','bounds','M','indexCache','val','IDS','P',source+';return createSelection;')(()=>[10,20],()=>n,()=>n,D,(_r,k,v)=>writes.set(k,v),'MEMBERS','OWNER','REST','FRAME',()=>({min:[0,0,0],max:[0,0,0]}),M,new WeakMap(),(_n,k)=>data[k],'IDS','P');
 assert.equal(fn(n,{}),r);assert.deepEqual(writes.get('REST'),[1,2,3,4,5,6]);assert.deepEqual(writes.get('MEMBERS'),[10,20]);assert.equal(r.creationFrame.length,16);
});

 test('ingested native values are validated in place while public writes isolate caller storage',()=>{
 const input=Float64Array.of(-0,1.25);assert.equal(table.pluginValue(T.float64,input,true),input);assert.equal(table.pluginValue(T.float64,input),input);
 const other=Float64Array.of(2);assert.notEqual(table.pluginValue(T.float64,other),other);assert.throws(()=>table.pluginValue(T.float64,Float64Array.of(Infinity),true),/Invalid plugin record value/);
 });

 test('native clear is busy-fenced and does not remove the read-through handle',()=>{
 const e=engine(),n={nativeHash:owner,type:'known'};e.bind(n);e.write(owner,key,6,[1]);const before=[...e.records];e.busy(true);assert.throws(()=>e.clear(owner),/busy/);assert.deepEqual([...e.records],before);e.busy(false);e.clear(owner);assert.equal(n.pluginRecords,null);assert.equal(e.records.size,0);assert.equal(typeof Object.getOwnPropertyDescriptor(n,'pluginRecords').get,'function');
 });
 test('actual plugin clear validates ownership before touching canonical values',()=>{
 const line=html.split('\n').find(l=>l.includes('records:hash=>{own(hash);')),e=engine();e.write(owner,key,6,[1]);const clear=new Function('window','own','return ({'+line.trim()+'}).clearRecords;')({frameEngine:{clearPluginRecords:e.clear}},h=>{if(h!==owner)throw Error('Foreign plugin owner');});
 const before=[...e.records];assert.throws(()=>clear(id(2)),/Foreign plugin owner/);assert.deepEqual([...e.records],before);clear(owner);assert.equal(e.records.size,0);
 });
test('actual Atomic empty selection conversion clears native fields before changing the UI type',async()=>{
 const source=atomic.split('\n').find(l=>l.trim().startsWith('async function beforeReparent('));
 for(const fail of [false,true]){
  const row={nativeHash:id(2),type:'atomic_selection',params:{x:1}},n={nativeHash:owner},parent={nativeHash:id(3)};let cleared=false;
  const D={world:()=>[],clearRecords:h=>{assert.equal(h,row.nativeHash);assert.equal(row.type,'atomic_selection');if(fail)throw Error('opaque declaration');cleared=true;}};
  const fn=new Function('isRow','ancestor','world','pause','serial','ensure','snapshot','membership','list','M','D',source+';return beforeReparent;')(()=>true,r=>r===row?n:null,()=>({busy:Promise.resolve()}),()=>{},(_w,f)=>f(),async()=>{},async()=>{},()=>new Set(),()=>[],{inv:()=>[]},D);
  if(fail){await assert.rejects(()=>fn(row,parent),/opaque declaration/);assert.equal(row.type,'atomic_selection');assert.deepEqual(row.params,{x:1});assert.equal(cleared,false);}
  else{assert.equal(await fn(row,parent),true);assert.equal(row.type,'group');assert.deepEqual(row.params,{});assert.equal(cleared,true);}
 }
});
test('actual authoring projection reads the native payload view once rather than rebuilding it repeatedly',()=>{
 const source=html.split('\n').find(l=>l.startsWith('function frameAuthoring(n){'));let reads=0;const payload={[key]:{type:6,value:Float64Array.of(1)}},n={id:'row',type:'group',tags:[],get pluginRecords(){reads++;return payload;}};
 const fn=new Function('FrameMorph','frameCurves','FramePlugins','FramePluginRecords',source+';return frameAuthoring;')({sceneChannels:()=>new Map(),serializedTags:()=>[]},{},{owner:()=>null},{native:x=>x});
 assert.equal(fn(n).recordValues,payload);assert.equal(reads,1);
});
test('text leases remain stable across fresh views and equal native replacements, preventing false Undo steps',()=>{
 const e=engine(),n={nativeHash:owner,type:'known'};e.bind(n);e.write(owner,key,7,'Circuit label');const {value:l,undoStack}=leases([n]);
 const before=JSON.stringify(n,l.replacer);assert.equal(JSON.stringify(n,l.replacer),before);
 e.records.set(address,{id:address,type:7,value:['Circuit',' label'].join('')});assert.equal(JSON.stringify(n,l.replacer),before);assert.equal(l.bytes(),0);
 undoStack.push(before);e.clear(owner);assert.equal(l.bytes(),'Circuit label'.length*2);l.collect();assert.equal(JSON.parse(before,l.reviver).pluginRecords[key].value,'Circuit label');
 undoStack.length=0;l.collect();assert.throws(()=>JSON.parse(before,l.reviver),/Retired authoring record/);
 e.write(owner,key,7,'Circuit label');assert.notEqual(JSON.stringify(n,l.replacer),before);assert.throws(()=>JSON.parse(before,l.reviver),/Retired authoring record/);
});

test('cached native metadata follows direct plugin replacement and clear without a UI resync',()=>{
 const {records}=table.begin();table.put(records,K.all,{id:K.all,type:T.ids,value:[owner]});const e=engine(records);e.write(owner,key,6,[1]);const before=e.pose(),original=before.recordValues[key].value;
 e.write(owner,key,6,[2]);assert.deepEqual(Array.from(e.pose().recordValues[key].value),[2]);assert.notEqual(e.pose(),before);assert.deepEqual(Array.from(original),[1]);e.clear(owner);assert.equal(e.pose(),null);
});
test('failed native writes retain both canonical content and a valid cached metadata view',()=>{
 const {records}=table.begin();table.put(records,K.all,{id:K.all,type:T.ids,value:[owner]});const e=engine(records);e.write(owner,key,6,[1]);const before=e.pose();assert.throws(()=>e.write(owner,key,6,[Infinity]),/Invalid plugin record value/);assert.equal(e.pose(),before);assert.deepEqual(Array.from(e.pose().recordValues[key].value),[1]);e.busy(true);assert.throws(()=>e.clear(owner),/busy/);assert.equal(e.pose(),before);
});
