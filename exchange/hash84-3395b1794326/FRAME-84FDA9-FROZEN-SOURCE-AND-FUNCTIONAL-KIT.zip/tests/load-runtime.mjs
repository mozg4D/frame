import {readFile} from 'node:fs/promises';
const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
const extract=(a,b)=>{const start=html.indexOf(a),end=html.indexOf(b,start);if(start<0||end<=start)throw Error('Runtime extraction failed: '+a);return html.slice(start,end);};
export const createFrameHashCodec=new Function(extract('function createFrameHashCodec(){','const FrameHash=createFrameHashCodec();')+';return createFrameHashCodec;')();
export const createFrameSceneGPUVersions=new Function(extract('const createFrameSceneGPUVersions = (() => {','// One canonical addressed table')+';return createFrameSceneGPUVersions;')();
export const createFrameSceneStore=new Function(extract('function createFrameSceneStore(hash,','// Generic HASH ingestion')+';return createFrameSceneStore;')();
export const source=html;
export const id=n=>BigInt(n).toString(16).padStart(32,'0');
export const hash=createFrameHashCodec();
export function opaqueBlock(recordId,encoding,payload=Uint8Array.of(0,255,3)){
  const out=new Uint8Array(26+payload.length),v=new DataView(out.buffer);v.setUint16(0,encoding,true);v.setBigUint64(18,BigInt(payload.length),true);
  out.set(Uint8Array.from({length:16},(_,i)=>parseInt(recordId.slice(i*2,i*2+2),16)),2);out.set(payload,26);return out;
}
export function seed(store,rows){const tx=store.begin('Seed');for(const [key,type,value]of rows)tx.set(key,type,value);const receipt=tx.commit();receipt.delta?.release();return receipt;}
