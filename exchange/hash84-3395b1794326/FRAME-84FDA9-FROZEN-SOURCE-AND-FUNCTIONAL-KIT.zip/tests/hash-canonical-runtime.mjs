import {authoringRecords,authoringBlob} from './record-declaration-fixtures.mjs';
// Executes the actual patched runtime functions, with inert GPU/UI adapters.
// This is CPU integration coverage, not a browser/hardware test.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';
import test from 'node:test';
const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
const section=(a,b)=>{const start=html.indexOf(a),end=html.indexOf(b,start);assert.ok(start>=0&&end>start,a);return html.slice(start,end);};
const line=name=>html.split('\n').find(l=>l.trim().startsWith('function '+name+'('));
const codec=section('function createFrameHashCodec(){','const FrameHash=createFrameHashCodec();');
const table=section('function createFrameHashRecordTable(hash){','function createFrameHashCodec(){');
const documentationFactory=new Function(section('const FrameDocumentation=','const FramePlugins=')+';return FrameDocumentation;')();
const functions=[
  line('nativeRecord'),line('nativePut'),line('nativeValue'),line('poseObjects'),line('poseObject'),
  section('    function nativeObjects(','    function installNativeRecords('),
  section('    function installNativeRecords(','    function deformationRevision('),
  section('    async function nativeDecodePlan(','    async function nativeDecodeMesh('),
  section('    async function nativeDecodeMesh(','    function captureMergeAppearance('),
  section('    async function decodeAppearancePlan(','    function validatePolygonSets('),
  line('validatePolygonSets'),line('uploadPolygonSets'),line('uploadImportedUV'),line('setPolygonRecord'),
  ...['appearanceId','appearanceRecord','appearanceValue','polygonSet','rememberAppearance','putAppearance','appearanceTags'].map(line),
  section('    async function loadHash(','    async function newFile('),
  section('    async function saveHash(','    async function nativeDecodePlan('),
  html.split('\n').find(l=>l.startsWith('function frameValidateAuthoring('))
].join('\n');
function runtime({pluginAvailable=false}={}){
  return new Function('pluginAvailable','FrameDocumentation',`
    ${codec}\n${table}
    const FrameHash=createFrameHashCodec(),FrameHashRecords=createFrameHashRecordTable(FrameHash);
    let scene=null,poseRecordCache=null,renderer,nodes=[],sourceUnavailable=false,nativeIOBusy=false;
    let sceneFrameDirty=false,displayUnitIndex=2,rescaleUnitIndex=2,selectionScope,objectSelection=[],componentPivot,metaUndo=[],metaRedo=[],selectionSignature='',lastImportReport;
    const stats={uploads:0,readbacks:0,disposed:0},polygonResources=new Map(),uvResources=new Map(),morphStates=new Map();
    const bytes=value=>new Uint8Array(value.buffer,value.byteOffset,value.byteLength),makeBuffer=data=>({data:new Uint8Array(bytes(data)),size:data.byteLength});
    renderer={device:{queue:{writeBuffer:(b,o,v)=>b.data.set(bytes(v),o),onSubmittedWorkDone:async()=>{}}}};
    const FramePlugins={ready:Promise.resolve(),flush:async()=>{},owner:n=>pluginAvailable&&n?.type==='absent_type'?{manifest:{id:'absent'}}:null};
    const FrameAuthorData={reserveObjects:()=>()=>{},envelope:v=>v,preflightDocument:()=>{},invalidateDocument:()=>{}};
    const FrameMorph={flush:async()=>{},sceneChannels:()=>new Map()},frameCurves={},FrameSpline={flush:async()=>{},encodeShape:()=>{throw Error('unexpected shape');},decodeShape:()=>{throw Error('unexpected shape');}},window={FrameSpline};
    const definitions={absent_type:['Absent',null,{}]},tagDefinitions={},FramePluginTags={},frameValidateMorphKeys=()=>{},timelineFrame=0,timelineTotal=120,framePackTrack=v=>v,materialKeys=Array(17).fill(0);
    const FM={I:()=>[],unpack:v=>v,equal:(a,b)=>a.length===b.length&&a.every((v,i)=>v===b[i]),determinant:()=>1};
    const document={getElementById:()=>({textContent:''})},canvas={dataset:{}},button={disabled:false},status={hidden:false},units=['','','mm'];
    const selectionQueue=Promise.resolve(),editSerial=Promise.resolve(),appearanceQueue=Promise.resolve(),animationSerial=Promise.resolve();let lazyTask=null;
    const syncPoseWorld=()=>{},framePackTrackStub=()=>{},frameSyncMaterials=()=>{if(scene)scene.appearanceActive=new Set(scene.appearanceIds||[]);},nativeIOStart=()=>{nativeIOBusy=true;return ()=>{};},nativeIOEnd=()=>{nativeIOBusy=false;},clearEdits=async()=>{},getRenderer=async()=>renderer,checkSession=()=>{},clearFeatureDraws=()=>{},clearPickGroups=()=>{},meshRenderGroups=()=>{},resetView=()=>{},applyNativeCamera=()=>{},setVisibility=()=>{},nativeSceneStats=()=>{},draw=async()=>{},fileOperationError=()=>{},ensureImportedUV=()=>{};
    const nativeCamera=()=>Float64Array.of(0,0,1,0,0,0,0,0,0,0,0,1),validNativeCamera=v=>v?.length===12;
    const disposeScene=()=>{stats.disposed++;},disposeMesh=()=>{},makeGPUBuffer=(_d,o)=>({data:new Uint8Array(o.size),size:o.size}),GPUBufferUsage={STORAGE:1,COPY_SRC:2,COPY_DST:4};
    const sceneFromMeshes=(_gpu,meshes)=>({meshes,records:new Map(),triangleCount:meshes.reduce((n,m)=>n+m.triangleCount,0)});
    const uploadAndCompute=async(_gpu,input)=>{stats.uploads++;sourceUnavailable=true;return {positions:makeBuffer(input.vertices),indices:makeBuffer(input.indices),vertexCount:input.vertexCount,triangleCount:input.triangleCount,count:input.indices.length,connected:{range:{data:new Uint8Array(16),size:16}}};};
    const nativeReadGPU=async(_gpu,resource,count)=>{stats.readbacks++;return resource.data.slice(0,count*4);};
    const nativeSceneEvent=()=>{const indices=new Map(scene.meshes.map((m,i)=>[m.hashId,i]));nodes=nativeObjects().map(o=>{o.index=indices.get(o.hash);return {...o,nativeHash:o.hash,type:o.type===0?'group':'mesh',spec:o};});for(const n of nodes){bindObjectName(n);bindObjectFlags(n);}};
    const frameSyncEngineVisibility=()=>{if(!scene)return;installNativeRecords(nodes.map(n=>({...n.spec,name:n.name,flags:(n.visible?1:0)|(n.enabled?2:0)|(n.folded?4:0),authoring:n.authoring??n.spec.authoring})),scene.records.get(FrameHash.K.camera)?.value);for(const n of nodes){bindObjectName(n);bindObjectFlags(n);}};
    ${functions}
    const docs=FrameDocumentation.create({read:()=>nativeDocumentationText(),write:nativeWriteDocumentation,hasObject:hash=>!!scene?.nativeOwnerIds?.has(hash)});
    return {docs,nativeDocumentationText,timelineState:nativeTimelineState,setTimelineState:nativeSetTimelineState,FrameHash,FrameHashRecords,loadHash,saveHash,nativeDecodePlan,nativeDecodeMesh,installNativeRecords,bindObjectName,nativeObjectName,nativeSetObjectName,nativeObjects,stats,get saveDiagnostics(){return canvas.dataset.hashSave&&JSON.parse(canvas.dataset.hashSave);},get nodes(){return nodes;},get scene(){return scene;},get sourceUnavailable(){return sourceUnavailable;},sync:frameSyncEngineVisibility};
  `)(pluginAvailable,documentationFactory);
}
const id=n=>n.toString(16).padStart(32,'0'),owner=id(1),mesh=id(2),unknown=id(900),flagged=id(901),field='d396752c6a1e450b9cd8d90f797b8bb1',futureField='cf525ee8f31c436f80acbdc29757799f',refsField='584d72d250f94d0d98bed022da5d5cef';
function rawBlock(hash,recordId,type,value){const h=new Uint8Array(26),v=new DataView(h.buffer);v.setUint16(0,type,true);h.set(Uint8Array.from({length:16},(_,i)=>parseInt(recordId.slice(i*2,i*2+2),16)),2);v.setBigUint64(18,BigInt(value.length),true);return new Blob([h,value]);}
async function fixture(r,{appearance=false,declared=false,timeline=null}={}){
  const h=r.FrameHash,{K,T}=h,rows=[
    [K.version,T.uint32,Uint32Array.of(1)],[K.all,T.ids,[owner,mesh]],
    [h.address(owner,'type'),T.bytes,Uint8Array.of(0)],[h.address(owner,'name'),T.text,'Owner'],
    [h.address(mesh,'type'),T.bytes,Uint8Array.of(1)],[h.address(mesh,'name'),T.text,'Triangle'],[h.address(mesh,'parent'),T.ids,[owner]],
    [h.address(mesh,'positions'),T.float32,Float32Array.of(0,0,0,1.25,0,0,0,2.5,0)],[h.address(mesh,'indices'),T.uint32,Uint32Array.of(0,1,2)],
    [h.address(owner,field),T.float64,Float64Array.of(-0,1.2345678901234567)],
    [h.address(owner,refsField),T.ids,[owner,mesh,unknown,id(999)]]
  ];
  if(timeline)rows.push([K.timelineFrame,T.float64,Float64Array.of(timeline.frame)],[K.timelineTotal,T.float64,Float64Array.of(timeline.total)]);
  if(declared)rows.push(...authoringRecords(h,owner,{version:1,tags:[],animation:[],plugin:{id:'absent',type:'absent_type',params:{}},pluginRecords:[{key:futureField,type:64}]}).map(({id,type,value})=>[id,type,value]));
  if(appearance){const material=id(500),tag=id(501),uvTag=id(502);rows.push(
    [K.materials,T.ids,[material]],[h.address(material,'name'),T.text,'Material'],[h.address(material,'parameters'),T.float64,Float64Array.of(0,0,80,0,0,50,0,1.5,0,0,0,0,0,50,100)],
    [h.address(mesh,'tags'),T.ids,[tag,uvTag]],[h.address(tag,'material'),T.ids,[material]],[h.address(tag,'faces'),T.bytes,Uint8Array.of(1)],
    [h.address(uvTag,'uv'),T.float32,Float32Array.of(0,0,1,0,0,1)]
  );}
  const parts=[];for(const [recordId,type,value]of rows)parts.push((await h.pack({id:recordId,type,value})).blob);
  parts.push(rawBlock(h,unknown,64,Uint8Array.of(7,0,255)),rawBlock(h,flagged,0x8000,Uint8Array.of(1,2,3)),rawBlock(h,h.address(owner,futureField),64,Uint8Array.of(3,2,1)));
  const blob=new Blob(parts);let reads=0;
  class Source extends Blob{async arrayBuffer(){assert.equal(r.sourceUnavailable,false,'source read after upload began');reads++;return super.arrayBuffer();}slice(){throw Error('Source file slice cannot back canonical data');}}
  const file=new Source([blob]);Object.defineProperty(file,'name',{value:'canonical.hash'});
  return {file,blob,get reads(){return reads;}};
}
async function declarationRows(h,file,index,owner){const keys=await h.read(file,index.get(h.address(owner,'recordKeys'))),types=await h.read(file,index.get(h.address(owner,'recordTypes')));return keys.map((key,i)=>({key,type:types[i]}));}
async function raw(file,indexed,recordId){const e=indexed.get(recordId);return new Uint8Array(await file.slice(e.offset-26,e.offset+e.length).arrayBuffer());}

test('actual native Docs Open, edit, rebuild, Save and reopen use a literal text field',async()=>{
 const r=runtime(),f=await fixture(r),h=r.FrameHash,text='Doc 😀\nObject: '+owner+'\nObject: '+id(777);
 const doc=(await h.pack({id:h.K.documentation,type:h.T.text,value:text})).blob;await r.loadHash(new File([f.blob,doc],'docs.hash'));
 assert.equal(r.docs.get().text,text);r.nodes.push({nativeHash:id(777),type:'draft-only',name:'Not a native owner'});assert.deepEqual(r.docs.inspect().references.map(r=>r.status),['present','missing']);r.nodes.pop();
 r.docs.update({text:text+'\nChanged',version:r.docs.get().version});const record=r.scene.records.get(h.K.documentation);r.sync();assert.equal(r.scene.records.get(h.K.documentation),record);assert.equal(r.stats.readbacks,0);
 const saved=await r.saveHash(),fresh=runtime();await fresh.loadHash(new File([saved],'docs-reopened.hash'));assert.equal(fresh.docs.get().text,text+'\nChanged');assert.equal(Object.hasOwn(JSON.parse(fresh.scene.records.get(h.K.parameters)?.value||'{}'),'documentation'),false);
});

test('native ownership declarations work without any JSON authoring envelope',async()=>{
 const r=runtime(),f=await fixture(r),h=r.FrameHash,rows=[{id:h.address(owner,'recordKeys'),type:h.T.ids,value:[field]},{id:h.address(owner,'recordTypes'),type:h.T.bytes,value:Uint8Array.of(6)}],parts=await Promise.all(rows.map(row=>h.pack(row)));
 await r.loadHash(new Blob([f.blob,...parts.map(r=>r.blob)]));assert.ok(r.scene.records.get(h.address(owner,field)).opaque);r.sync();const saved=await r.saveHash(),index=await h.index(saved);
 assert.equal(index.has(h.address(owner,'parameters')),false);assert.deepEqual(await declarationRows(h,saved,index,owner),[{key:field,type:6}]);
 const fresh=runtime();await fresh.loadHash(saved);assert.deepEqual(fresh.nativeObjects().find(o=>o.hash===owner).authoring.pluginRecords,[{key:field,type:6}]);
});

test('malformed known declaration columns reject before GPU allocation and current document replacement',async()=>{
 const r=runtime(),f=await fixture(r);await r.loadHash(f.file);const prior=r.scene,before=r.stats.uploads,h=r.FrameHash;
 for(const [type,types]of [[h.T.bytes,Uint8Array.of(6,6)],[h.T.uint32,Uint32Array.of(256)]]){const parts=await Promise.all([{id:h.address(owner,'recordKeys'),type:h.T.ids,value:[field]},{id:h.address(owner,'recordTypes'),type,value:types}].map(row=>h.pack(row)));await assert.rejects(r.loadHash(new Blob([f.blob,...parts.map(r=>r.blob)])),/Invalid HASH record declarations/);assert.equal(r.scene,prior);assert.equal(r.stats.uploads,before);}
});

test('opaque declaration encoding and its uninterpreted partner survive actual Open rebuild Save and reopen',async()=>{
 const r=runtime(),f=await fixture(r),h=r.FrameHash,unknownTypes=rawBlock(h,h.address(owner,'recordTypes'),0x8040,Uint8Array.of(3,1,4)),partner=(await h.pack({id:h.address(owner,'recordKeys'),type:h.T.text,value:'Uninterpreted future schema partner'})).blob;
 await r.loadHash(new Blob([f.blob,unknownTypes,partner]));const before=r.scene,keys=r.scene.records.get(h.address(owner,'recordKeys'));
 assert.ok(keys.opaque);assert.deepEqual(r.nativeObjects().find(o=>o.hash===owner).authoring,null);
 const attempted=r.nativeObjects();attempted[0].authoring={version:1,tags:[],animation:[],recordValues:{[field]:{type:6,value:[1]}}};assert.throws(()=>r.installNativeRecords(attempted),/unsupported HASH/);assert.equal(r.scene,before);assert.equal(r.scene.records.get(h.address(owner,'recordKeys')),keys);
 r.nodes[0].name='Changed unrelated native name';r.sync();const saved=await r.saveHash(),index=await h.index(saved);for(const [field,block]of [['recordTypes',unknownTypes],['recordKeys',partner]])assert.deepEqual(await raw(saved,index,h.address(owner,field)),new Uint8Array(await block.arrayBuffer()));
 const fresh=runtime();await fresh.loadHash(saved);assert.equal(fresh.nativeObjects()[0].name,'Changed unrelated native name');assert.ok(fresh.scene.records.get(h.address(owner,'recordTypes')).opaque);
});

test('plugin declarations cannot claim either native declaration column',async()=>{
 for(const fieldName of ['recordKeys','recordTypes']){const r=runtime(),f=await fixture(r),h=r.FrameHash,authoring=await authoringBlob(h,owner,{version:1,tags:[],animation:[],pluginRecords:[{key:h.K[fieldName],type:fieldName==='recordKeys'?4:0}]});await assert.rejects(r.loadHash(new Blob([f.blob,authoring])),/overlaps a native property/);assert.equal(r.stats.uploads,0);}
});

test('uninterpreted ownership survives owner Delete and history-style restore without a shadow declaration copy',async()=>{
 const r=runtime(),f=await fixture(r,{declared:true}),h=r.FrameHash,plan=await r.nativeDecodePlan(f.blob);for(const field of ['recordKeys','recordTypes']){const address=h.address(owner,field);assert.ok(plan.importReport.retainedNativeDeclarations.includes(address));assert.ok(!plan.importReport.retainedExtensionRecords.includes(address));}await r.loadHash(f.file);r.sync();
 const before=r.nativeObjects(),original=before.find(o=>o.hash===owner);original.authoring={...original.authoring,pluginRecords:[],recordValues:{}};
 r.installNativeRecords(before.filter(o=>o.hash!==owner).map(o=>({...o,parent:null})));
 assert.ok(r.scene.records.has(h.address(owner,'recordKeys')));assert.ok(r.scene.records.has(h.address(owner,'recordTypes')));assert.ok(r.scene.records.get(h.address(owner,futureField)).opaque);
 r.installNativeRecords(before);const saved=await r.saveHash(),index=await h.index(saved);assert.deepEqual(await declarationRows(h,saved,index,owner),[{key:futureField,type:64}]);assert.deepEqual(await raw(saved,index,h.address(owner,futureField)),await raw(f.blob,await h.index(f.blob),h.address(owner,futureField)));
});
test('known invalid Doc text rejects native admission before GPU upload',async()=>{
 for(const [type,value]of [[3,Uint32Array.of(1)],[7,'x'.repeat(1048577)]]){
  const r=runtime(),f=await fixture(r),h=r.FrameHash,doc=(await h.pack({id:h.K.documentation,type,value})).blob;await assert.rejects(r.loadHash(new File([f.blob,doc],'invalid-doc.hash')),/Wrong HASH property type|Invalid documentation text/);assert.equal(r.stats.uploads,0);
 }
 const r=runtime(),f=await fixture(r),h=r.FrameHash,invalid=rawBlock(h,h.K.documentation,h.T.text,Uint8Array.of(0xc3));
 await assert.rejects(r.loadHash(new File([f.blob,invalid],'invalid-utf8-doc.hash')),/encoded data|encoding/i);assert.equal(r.stats.uploads,0);
});
test('an optional opaque Doc survives unrelated native edits and exact Save',async()=>{
 const r=runtime(),f=await fixture(r),h=r.FrameHash,doc=rawBlock(h,h.K.documentation,0x8040,Uint8Array.of(0,17,255));await r.loadHash(new File([f.blob,doc],'future-doc.hash'));
 assert.equal(r.docs.get().text,'');assert.throws(()=>r.docs.create({text:'Cannot replace opaque text',version:r.docs.get().version}),/unsupported HASH/);r.nodes[0].name='Edited';r.sync();const saved=await r.saveHash(),index=await h.index(saved);assert.deepEqual(await raw(saved,index,h.K.documentation),new Uint8Array(await doc.arrayBuffer()));
});
test('native Doc global address cannot be claimed by a declared plugin field',async()=>{
 const r=runtime({pluginAvailable:true}),f=await fixture(r),h=r.FrameHash,field=h.address(owner,h.K.documentation),metadata={version:1,tags:[],animation:[],plugin:{id:'absent',type:'absent_type',params:{}},pluginRecords:[{key:field,type:7}]};
 const a=await authoringBlob(h,owner,metadata),doc=(await h.pack({id:h.K.documentation,type:7,value:'Aliased'})).blob;
 await assert.rejects(r.loadHash(new File([f.blob,a,doc],'aliased-doc.hash')),/overlaps a native property/);assert.equal(r.stats.uploads,0);
});

test('actual Open, sync, Save and reopen preserve timeline from addressed fields with no routine readback',async()=>{
  const r=runtime(),f=await fixture(r,{timeline:{frame:13,total:220}});await r.loadHash(f.file);assert.deepEqual(r.timelineState(),{frame:13,total:220});
  r.setTimelineState(37,330);const frame=r.scene.records.get(r.FrameHash.K.timelineFrame),total=r.scene.records.get(r.FrameHash.K.timelineTotal);r.sync();
  assert.equal(r.scene.records.get(r.FrameHash.K.timelineFrame),frame);assert.equal(r.scene.records.get(r.FrameHash.K.timelineTotal),total);assert.equal(r.stats.readbacks,0);
  const output=await r.saveHash(),fresh=runtime();await fresh.loadHash(new File([output],'timeline.hash'));assert.deepEqual(fresh.timelineState(),{frame:37,total:330});
  const metadata=JSON.parse(fresh.scene.records.get(fresh.FrameHash.K.parameters)?.value||'{}');assert.equal(Object.hasOwn(metadata,'frame'),false);assert.equal(Object.hasOwn(metadata,'total'),false);
});
test('known invalid timeline scalars reject actual Open before GPU admission',async()=>{
  for(const timeline of [{frame:NaN,total:120},{frame:1,total:Infinity},{frame:-1,total:120},{frame:121,total:120}]){
    const r=runtime(),f=await fixture(r,{timeline});await assert.rejects(r.loadHash(f.file),/Invalid HASH timeline/);assert.equal(r.stats.uploads,0);
  }
});
test('unsupported optional timeline records survive real rebuild and Save while unrelated names stay editable',async()=>{
  const r=runtime(),f=await fixture(r),h=r.FrameHash,opaque=rawBlock(h,h.K.timelineTotal,0x8040,Uint8Array.of(3,4,5,255));
  const frame=(await h.pack({id:h.K.timelineFrame,type:h.T.float64,value:Float64Array.of(500)})).blob;
  await r.loadHash(new File([f.blob,frame,opaque],'future-timeline.hash'));assert.deepEqual(r.timelineState(),{frame:0,total:120,readOnly:true});
  assert.equal(r.setTimelineState(0,120),false);assert.throws(()=>r.setTimelineState(1,120),/unsupported HASH/);r.nodes[0].name='Edited';r.sync();
  const out=await r.saveHash(),index=await h.index(out);assert.deepEqual(await raw(out,index,h.K.timelineTotal),new Uint8Array(await opaque.arrayBuffer()));
  const fresh=runtime();await fresh.loadHash(new File([out],'future-reopened.hash'));assert.deepEqual(fresh.timelineState(),{frame:0,total:120,readOnly:true});assert.equal(fresh.nativeObjects()[0].name,'Edited');
});
test('declared plugin fields cannot alias the two native timeline global addresses',async()=>{
  for(const key of ['timelineFrame','timelineTotal']){
    const r=runtime({pluginAvailable:true}),f=await fixture(r),h=r.FrameHash,field=h.address(owner,h.K[key]);
    const a={version:1,tags:[],animation:[],plugin:{id:'absent',type:'absent_type',params:{}},pluginRecords:[{key:field,type:h.T.float64}]};
    const metadata=await authoringBlob(h,owner,a),value=(await h.pack({id:h.K[key],type:h.T.float64,value:Float64Array.of(1)})).blob;
    await assert.rejects(r.loadHash(new File([f.blob,metadata,value],'alias.hash')),/overlaps a native property/);assert.equal(r.stats.uploads,0);
  }
});

function objectProjectionEvent(negative=false){
  let handler=html.split('\n').find(l=>l.startsWith("FrameViewWindows.onWindow('frame-engine-objects'"));assert(handler);
  if(negative)handler=handler.replace('window.frameEngine?.bindObjectName(n);','n.name=o.name;');
  return new Function('rejection',`
    let callback,writes=0,serial=0,nodes=[],selected,focusId,anchorId;
    const names=new Map([['old','Canonical old'],['root','Canonical root'],['child','Canonical child']]);
    const bind=n=>Object.defineProperty(n,'name',{configurable:true,enumerable:true,get:()=>names.get(n.nativeHash),set:()=>{writes++;throw Error(rejection);}});
    const old={id:'old-row',nativeHash:'old'};bind(old);nodes.push(old);
    const FrameViewWindows={onWindow:(_name,fn)=>callback=fn},window={FrameSpline:{restore(){},request(){}},frameEngine:{bindObjectName:bind,bindObjectFlags(){},bindPluginRecords(){}}},frameUITags=x=>x,frameRestoreAuthoring=()=>{},renderTree=()=>{},renderAttributes=()=>{},syncHUD=()=>{};
    const create=(_type,_parent,name)=>{const n={id:'new-'+(++serial),name};nodes.unshift(n);return n;};
    ${handler}
    callback({detail:{objects:[{hash:'root',type:0,name:'Cached root',parent:null,tags:[]},{hash:'child',type:0,name:'Cached child',parent:'root',tags:[]},{hash:'old',type:0,name:'Cached old',parent:null,tags:[]}],selection:['child']}});
    return {nodes,writes,selected};
  `);
}
test('native object projection restores hierarchy without writing read-through names during I/O',()=>{
  for(const rejection of ['HASH I/O is busy','Object name uses an unsupported HASH representation']){const state=objectProjectionEvent()(rejection),root=state.nodes.find(n=>n.nativeHash==='root'),child=state.nodes.find(n=>n.nativeHash==='child');assert.equal(state.writes,0);assert.equal(child.parent,root.id);assert.equal(child.name,'Canonical child');assert.equal(state.nodes.find(n=>n.nativeHash==='old').name,'Canonical old');assert(state.selected.has(child.id));}
});
test('the prior projection write-through negative control aborts before hierarchy publication',()=>{
  assert.throws(()=>objectProjectionEvent(true)('HASH I/O is busy'),/HASH I\/O is busy/);
});

test('actual loadHash ingests the complete RAM table and publishes known geometry as GPU descriptors',async()=>{
  const r=runtime(),f=await fixture(r);await r.loadHash(f.file);
  assert.equal(f.reads,1);assert.equal(r.stats.uploads,1);assert.equal(r.stats.readbacks,0);
  assert.ok(r.scene.records instanceof Map);
  const h=r.FrameHash;
  assert.deepEqual(r.scene.records.get(h.K.all).value,[owner,mesh]);
  assert.deepEqual(r.scene.records.get(h.address(mesh,'parent')).value,[owner]);
  for(const key of ['positions','indices']){const v=r.scene.records.get(h.address(mesh,key)).value;assert.equal(v.gpu,true);assert.ok(!ArrayBuffer.isView(v));assert.ok(v.resource);}
  assert.deepEqual(r.scene.records.get(h.address(owner,refsField)).value,[owner,mesh,unknown,id(999)]);
  assert.ok(r.scene.records.get(unknown).opaque.bytes instanceof Uint8Array);
});

test('real native name property reads/writes canonical records immediately, without a mutable name slot',async()=>{
  const r=runtime(),f=await fixture(r);await r.loadHash(f.file);const n=r.nodes.find(n=>n.nativeHash===mesh),h=r.FrameHash,address=h.address(mesh,'name');
  const d=Object.getOwnPropertyDescriptor(n,'name');assert.equal(d.value,undefined);assert.equal(typeof d.get,'function');assert.equal(typeof d.set,'function');
  n.name='Changed through native UI view';assert.equal(r.scene.records.get(address).value,n.name);
  r.scene.records.set(address,{id:address,type:h.T.text,value:'Record changed first'});assert.equal(n.name,'Record changed first');
  assert.throws(()=>{n.name='bad\0name';},/Invalid object name/);assert.equal(n.name,'Record changed first');
  const before=r.stats.readbacks,t=performance.now();for(let i=0;i<10000;i++){n.name='Name '+i;assert.equal(n.name,'Name '+i);}assert.ok(performance.now()-t<500,'10k native addressed name writes/reads stay below 500 ms');assert.equal(r.stats.readbacks,before);
});

test('unknown records survive actual installNativeRecords and saveHash after native name edits',async()=>{
  const r=runtime(),f=await fixture(r);await r.loadHash(f.file);const h=r.FrameHash,n=r.nodes.find(n=>n.nativeHash===mesh);
  n.name='New name';r.sync();r.sync();
  const saved=await r.saveHash(),before=await h.index(f.blob),after=await h.index(saved);
  for(const recordId of [unknown,flagged,h.address(owner,futureField)])assert.deepEqual(await raw(saved,after,recordId),await raw(f.blob,before,recordId));
  assert.deepEqual(await h.read(saved,after.get(h.address(owner,field))),Float64Array.of(-0,1.2345678901234567));
  assert.deepEqual(await h.read(saved,after.get(h.address(owner,refsField))),[owner,mesh,unknown,id(999)]);
  assert.equal(await h.read(saved,after.get(h.address(mesh,'name'))),'New name');
  assert.deepEqual(await h.read(saved,after.get(h.address(mesh,'positions'))),Float32Array.of(0,0,0,1.25,0,0,0,2.5,0));
  assert.equal(f.reads,1);assert.equal(r.stats.readbacks,2,'only explicit Save reads known mesh positions/indices');
  assert.equal(r.saveDiagnostics.rawBytesComplete,false);assert.equal(r.saveDiagnostics.opaqueRecords,3);assert.ok(r.saveDiagnostics.opaqueStoredBytes>0);
});

test('actual appearance loader retains managed material/tag/mask/UV records despite the pre-populated RAM Map',async()=>{
  const r=runtime(),f=await fixture(r,{appearance:true});await r.loadHash(f.file);const h=r.FrameHash;
  for(const recordId of [h.K.materials,h.address(id(500),'name'),h.address(id(500),'parameters'),h.address(mesh,'tags'),h.address(id(501),'material'),h.address(id(501),'faces'),h.address(id(502),'uv')])assert.ok(r.scene.appearanceIds.has(recordId),recordId);
  assert.equal(r.scene.records.get(h.address(id(501),'faces')).value.gpu,true);
  assert.equal(r.scene.records.get(h.address(id(502),'uv')).value.gpu,true);
  const saved=await r.saveHash(),index=await h.index(saved);
  assert.deepEqual(await h.read(saved,index.get(h.address(id(501),'faces'))),Uint8Array.of(1));
  assert.deepEqual(await h.read(saved,index.get(h.address(id(502),'uv'))),Float32Array.of(0,0,1,0,0,1));
  assert.ok(index.has(unknown));
});

test('unsupported declared plugin record opens inactive and survives native UI synchronization and Save',async()=>{
  const r=runtime(),f=await fixture(r,{declared:true});await r.loadHash(f.file);const h=r.FrameHash;
  const n=r.nodes.find(n=>n.nativeHash===owner);n.authoring={...n.spec.authoring,pluginRecords:[],recordValues:{}};
  n.name='Unavailable plugin owner';r.sync();
  const saved=await r.saveHash(),index=await h.index(saved),a=JSON.parse(await h.read(saved,index.get(h.address(owner,'parameters'))));
  assert.equal(Object.hasOwn(a,'pluginRecords'),false);assert.deepEqual(await declarationRows(h,saved,index,owner),[{key:futureField,type:64}]);
  assert.deepEqual(await raw(saved,index,h.address(owner,futureField)),await raw(f.blob,await h.index(f.blob),h.address(owner,futureField)));
  assert.equal(a.plugin.id,'absent');
});

async function declaredFloatFixture(r,{unresolved=false,semantic='plugin',finite=false}={}){
  const f=await fixture(r),h=r.FrameHash,index=await h.index(f.blob),parts=[],key=h.address(owner,field),metadata=h.address(owner,'parameters');
  const buffer=new ArrayBuffer(512),bits=new DataView(buffer);
  for(const [i,word]of [0x7ff0000000000001n,0x7ff8000000001234n,0xfff8000000005678n,0x7ff0000000000000n,0xfff0000000000000n,0x8000000000000000n].entries())bits.setBigUint64(i*8,word,true);
  const value=finite?Float64Array.of(-0,1.25,2.5):new Float64Array(buffer);
  const authoring={version:1,tags:[],animation:[],plugin:{id:'absent',type:'absent_type',params:{}},pluginRecords:[{key:field,type:h.T.float64}],...unresolved?{pluginReferencesUnresolved:true}:{}};
  for(const [id,e]of index)if(id!==key&&id!==metadata&&(semantic==='plugin'||id!==h.address(owner,semantic)))parts.push(f.blob.slice(e.offset-26,e.offset+e.length));
  parts.push(await authoringBlob(h,owner,authoring));
  const packed=await h.pack({id:key,type:h.T.float64,value});parts.push(packed.blob);
  if(semantic!=='plugin')parts.push((await h.pack({id:h.address(owner,semantic),type:h.T.float64,value:semantic==='light'?Float64Array.of(Infinity,6500,30):Float64Array.of(NaN,0,0,0,1,0,0,0,1,0,0,0)})).blob);
  const blob=new Blob(parts);return {blob,key,packed,value};
}

test('absent plugin Float64 sentinel/NaN payloads keep their original compressed block through Open, sync, Save and reopen',async()=>{
  const r=runtime(),f=await declaredFloatFixture(r),h=r.FrameHash;
  assert.ok(f.packed.type&256,'fixture must exercise original compression flags');
  let reads=0;class Source extends Blob{async arrayBuffer(){assert.equal(r.sourceUnavailable,false);assert.equal(++reads,1);return super.arrayBuffer();}slice(){throw Error('Opaque retention cannot use source-file slices');}}
  const start=performance.now();await r.loadHash(new Source([f.blob]));assert.equal(reads,1);
  assert.ok(r.scene.records.get(f.key).opaque);assert.deepEqual(r.nativeObjects().find(o=>o.hash===owner).authoring.recordValues,{});
  assert.deepEqual(r.scene.records.get(f.key).opaque.bytes,new Uint8Array(await f.packed.blob.arrayBuffer()));
  const n=r.nodes.find(n=>n.nativeHash===owner);n.authoring={...n.spec.authoring,pluginRecords:[],recordValues:{}};n.name='Retained raw plugin data';r.sync();r.sync();
  const saved=await r.saveHash(),index=await h.index(saved),a=JSON.parse(await h.read(saved,index.get(h.address(owner,'parameters'))));
  assert.equal(Object.hasOwn(a,'pluginRecords'),false);assert.deepEqual(await declarationRows(h,saved,index,owner),[{key:field,type:h.T.float64}]);
  assert.deepEqual(await raw(saved,index,f.key),new Uint8Array(await f.packed.blob.arrayBuffer()));
  const again=runtime();await again.loadHash(saved);again.sync();const savedAgain=await again.saveHash();
  assert.deepEqual(await raw(savedAgain,await h.index(savedAgain),f.key),new Uint8Array(await f.packed.blob.arrayBuffer()));
  assert.ok(performance.now()-start<3000,'complete small Open/sync/Save/reopen roundtrip budget 3 seconds');
});

test('unresolved installed plugin records remain opaque while available known finite records retain their existing path',async()=>{
  const r=runtime({pluginAvailable:true}),unknown=await declaredFloatFixture(r,{unresolved:true});await r.loadHash(unknown.blob);
  assert.ok(r.scene.records.get(unknown.key).opaque);assert.deepEqual(r.nativeObjects().find(o=>o.hash===owner).authoring.recordValues,{});
  const finite=await declaredFloatFixture(r,{finite:true});await r.loadHash(finite.blob);
  assert.equal(r.scene.records.get(finite.key).opaque,undefined);assert.deepEqual(r.nativeObjects().find(o=>o.hash===owner).authoring.recordValues[field].value,finite.value);
});

test('known empty text primitive survives native object projection, sync, Save and reopen without becoming an array',async()=>{
  const r=runtime({pluginAvailable:true}),f=await fixture(r),h=r.FrameHash,parts=[],key=h.address(owner,field),metadata=h.address(owner,'parameters');
  for(const [id,e]of await h.index(f.blob))if(id!==key&&id!==metadata)parts.push(f.blob.slice(e.offset-26,e.offset+e.length));
  parts.push((await h.pack({id:key,type:h.T.text,value:''})).blob,await authoringBlob(h,owner,{version:1,tags:[],animation:[],plugin:{id:'absent',type:'absent_type',params:{}},pluginRecords:[{key:field,type:h.T.text}]}));
  await r.loadHash(new Blob(parts));assert.equal(r.nativeObjects().find(o=>o.hash===owner).authoring.recordValues[field].value,'');r.sync();r.sync();
  const saved=await r.saveHash(),index=await h.index(saved);assert.equal(await h.read(saved,index.get(key)),'');
  const again=runtime({pluginAvailable:true});await again.loadHash(saved);assert.equal(again.nativeObjects().find(o=>o.hash===owner).authoring.recordValues[field].value,'');
});

test('available plugin nonfinite values and known affine/geometry fields still reject before replacing the active scene',async()=>{
  const r=runtime({pluginAvailable:true}),base=await fixture(r);await r.loadHash(base.file);const prior=r.scene,disposed=r.stats.disposed;
  await assert.rejects(()=>declaredFloatFixture(r).then(f=>r.loadHash(f.blob)),/Invalid plugin record value/);
  assert.equal(r.scene,prior);assert.equal(r.stats.disposed,disposed);
  const missing=runtime();await missing.loadHash((await fixture(missing)).file);const current=missing.scene;
  for(const semantic of ['matrix','projection','light'])await assert.rejects(()=>declaredFloatFixture(missing,{semantic}).then(f=>missing.loadHash(f.blob)),/Invalid HASH (affine frame|projection or light)/);
  const f=await fixture(missing),h=missing.FrameHash,parts=[],position=h.address(mesh,'positions');
  for(const [id,e]of await h.index(f.blob))if(id!==position)parts.push(f.blob.slice(e.offset-26,e.offset+e.length));
  parts.push((await h.pack({id:position,type:h.T.float32,value:Float32Array.of(NaN,0,0,1,0,0,0,1,0)})).blob);
  await assert.rejects(()=>missing.loadHash(new Blob(parts)),/Invalid HASH geometry/);
  assert.equal(missing.scene,current);
});

test('opaque unavailable plugin declarations still cannot overlap native fields',async()=>{
  const r=runtime(),h=r.FrameHash,f=await declaredFloatFixture(r),index=await h.index(f.blob),meta=h.address(owner,'parameters'),parts=[];
  for(const [id,e]of index)if(![meta,h.address(owner,'recordKeys'),h.address(owner,'recordTypes')].includes(id))parts.push(f.blob.slice(e.offset-26,e.offset+e.length));
  parts.push(await authoringBlob(h,owner,{version:1,tags:[],animation:[],plugin:{id:'absent',type:'absent_type',params:{}},pluginRecords:[{key:h.K.matrix,type:h.T.float64}]}));
  await assert.rejects(()=>r.loadHash(new Blob(parts)),/Plugin record overlaps a native property/);assert.equal(r.stats.uploads,0);
});

test('copy preflight rejects opaque declarations before native resource allocation but retains known-record copies',()=>{
  const source=line('assertNativeCopyRecords'),guard=new Function(source+';return assertNativeCopyRecords;')();
  for(const authoring of [{pluginRecords:[{key:field,type:6}]},{pluginRecords:[{key:field,type:64}],recordValues:{}}])assert.throws(()=>guard([{authoring}]),/reference schema for opaque plugin records/);
  assert.doesNotThrow(()=>guard([{authoring:{pluginRecords:[{key:field,type:6}],recordValues:{[field]:{type:6,value:Float64Array.of(1)}}}}]));
  assert.doesNotThrow(()=>guard([{authoring:{plugin:{id:'absent'}}}]));
  const duplicate=section('    async function duplicateGizmoObjects(','    function clipboardRecords('),copy=section('    function copySelection(){','    function pasteSelection(){');
  assert.ok(duplicate.indexOf('assertNativeCopyRecords(')<duplicate.indexOf('duplicateResource('));
  assert.ok(copy.indexOf('assertNativeCopyRecords(')<copy.indexOf("gpu.device.pushErrorScope('out-of-memory')"));
});

test('known managed deletion is pruned while unrelated unknown records remain',async()=>{
  const r=runtime(),f=await fixture(r);await r.loadHash(f.file);const h=r.FrameHash;
  const group=r.nativeObjects().find(o=>o.hash===owner);r.installNativeRecords([group]);
  assert.deepEqual(r.scene.records.get(h.K.all).value,[owner]);
  assert.equal(r.scene.records.has(h.address(mesh,'name')),false);
  assert.ok(r.scene.records.has(unknown));assert.ok(r.scene.records.has(h.address(owner,refsField)));
});

test('legacy direct Map writers cannot overwrite or garbage-collect unsupported opaque records',async()=>{
  const r=runtime(),f=await fixture(r);await r.loadHash(f.file);const original=r.scene.records.get(unknown);
  r.scene.records.set(unknown,{id:unknown,type:r.FrameHash.T.bytes,value:Uint8Array.of(0)});
  assert.equal(r.scene.records.get(unknown),original);assert.equal(r.scene.records.delete(unknown),false);
  assert.equal(r.scene.records.get(unknown),original);
});

test('truncated and duplicate physical records reject before the current scene is disposed',async()=>{
  const r=runtime(),f=await fixture(r);await r.loadHash(f.file);const current=r.scene,before=r.stats.disposed,h=r.FrameHash;
  const valid=rawBlock(h,unknown,64,Uint8Array.of(1,2,3));
  for(const bad of [new Blob([valid,valid]),valid.slice(0,valid.size-1),new Blob([valid,new Uint8Array(25)])])await assert.rejects(()=>r.loadHash(bad));
  assert.equal(r.scene,current);assert.equal(r.stats.disposed,before);
});

test('unknown optional name representation is ignored for display and retained without destructive overwrite',async()=>{
  const r=runtime(),f=await fixture(r),h=r.FrameHash,index=await h.index(f.blob),nameId=h.address(mesh,'name'),parts=[];
  for(const [recordId,e]of index)if(recordId!==nameId)parts.push(f.blob.slice(e.offset-26,e.offset+e.length));
  const opaque=rawBlock(h,nameId,64,Uint8Array.of(9,8,7));parts.push(opaque);
  await r.loadHash(new Blob(parts));const n=r.nodes.find(n=>n.nativeHash===mesh);
  assert.equal(n.name,'Mesh');assert.throws(()=>{n.name='Cannot reinterpret';},/unsupported HASH representation/);
  const saved=await r.saveHash(),after=await h.index(saved);
  assert.deepEqual(await raw(saved,after,nameId),new Uint8Array(await opaque.arrayBuffer()));
});

test('invalid known geometry preflights from RAM before the old scene is retired',async()=>{
  const r=runtime(),f=await fixture(r);await r.loadHash(f.file);const current=r.scene,disposed=r.stats.disposed,h=r.FrameHash,index=await h.index(f.blob),indexId=h.address(mesh,'indices'),parts=[];
  for(const [recordId,e]of index)if(recordId!==indexId)parts.push(f.blob.slice(e.offset-26,e.offset+e.length));
  parts.push((await h.pack({id:indexId,type:h.T.uint32,value:Uint32Array.of(0,1,99)})).blob);
  await assert.rejects(()=>r.loadHash(new Blob(parts)),/Invalid HASH geometry/);
  assert.equal(r.scene,current);assert.equal(r.stats.disposed,disposed);
});

test('both real UI synchronization and engine API expose the native name binding',()=>{
  assert.ok(section('function frameSyncEngineVisibility(){','// SLP1:').includes('window.frameEngine?.bindObjectName(n)'));
  assert.ok(html.includes('const api={bindObjectName,nativeObjectName,nativeSetObjectName,'));
  assert.equal(section('    async function nativeDecodePlan(','    async function nativeDecodeMesh(').includes('await FrameHash.read(file,'),false);
  assert.equal(section('    async function nativeDecodeMesh(','    function captureMergeAppearance(').includes('FrameHash.read('),false);
  assert.ok(section('    async function mergeFile(','    async function loadHash(').includes('Merge cannot safely remap unknown HASH records'));
});

 test('native instance clouds retain their known core record without activating a plugin',async()=>{
  const r=runtime(),f=await fixture(r),h=r.FrameHash,parts=[],address=h.address(owner,field);
  for(const [id,e]of await h.index(f.blob))if(id!==address)parts.push(f.blob.slice(e.offset-26,e.offset+e.length));
  parts.push((await h.pack({id:address,type:h.T.float64,value:Float64Array.of(-0,1.25,2.5,0.75)})).blob,await authoringBlob(h,owner,{version:1,tags:[],animation:[],instanceCloud:[{field,source:mesh}],pluginRecords:[{key:field,type:h.T.float64}]}));
  await r.loadHash(new Blob(parts));const v=r.scene.records.get(address).value;assert.equal(r.scene.records.get(address).opaque,undefined);assert.deepEqual(Array.from(v),[-0,1.25,2.5,0.75]);assert.equal(r.nativeObjects().find(o=>o.hash===owner).authoring.recordValues[field].value,v);r.sync();
  const again=runtime();await again.loadHash(await r.saveHash());assert.deepEqual(Array.from(again.scene.records.get(address).value),Array.from(v));
 });
 test('known core cloud layouts validate without interpreting future encodings',async()=>{
  for(const value of [Float64Array.of(1,2,3),Float64Array.of(1,2,3,-1)]){
   const r=runtime(),f=await fixture(r),h=r.FrameHash,parts=[],address=h.address(owner,field);
   for(const [id,e]of await h.index(f.blob))if(id!==address)parts.push(f.blob.slice(e.offset-26,e.offset+e.length));
   parts.push((await h.pack({id:address,type:h.T.float64,value})).blob,await authoringBlob(h,owner,{version:1,tags:[],animation:[],instanceCloud:[{field,source:mesh}],pluginRecords:[{key:field,type:h.T.float64}]}));
   await assert.rejects(()=>r.loadHash(new Blob(parts)),/Invalid native instance cloud values/);assert.equal(r.stats.uploads,0);
  }
 });

 test('future native cloud payload remains raw through Open and Save',async()=>{
 const r=runtime(),f=await fixture(r),h=r.FrameHash,parts=[],address=h.address(owner,field),block=rawBlock(h,address,0x804d,Uint8Array.of(255,0,7));
 for(const [id,e]of await h.index(f.blob))if(id!==address)parts.push(f.blob.slice(e.offset-26,e.offset+e.length));
 parts.push(block,await authoringBlob(h,owner,{version:1,tags:[],animation:[],instanceCloud:[{field,source:mesh}],pluginRecords:[{key:field,type:77}]}));
 await r.loadHash(new Blob(parts));assert.ok(r.scene.records.get(address).opaque);assert.deepEqual(r.nativeObjects().find(o=>o.hash===owner).authoring.recordValues,{});
 const saved=await r.saveHash();assert.deepEqual(await raw(saved,await h.index(saved),address),new Uint8Array(await block.arrayBuffer()));
 });


test('object flags stay canonical across Open, addressed edits, legacy rebuild and Save',async()=>{
 const r=runtime(),f=await fixture(r);await r.loadHash(f.blob);const n=r.nodes.find(n=>n.nativeHash===owner),h=r.FrameHash,address=h.address(owner,'flags');
 assert.deepEqual([n.visible,n.enabled,n.folded],[true,true,false]);n.visible=false;n.folded=true;const prior=r.scene.records.get(address);assert.equal(prior.value[0],6);r.sync();assert.equal(n.visible,false);assert.equal(n.folded,true);assert.equal(r.nativeObjects().find(o=>o.hash===owner).flags,6);
 const again=runtime();await again.loadHash(await r.saveHash());const restored=again.nodes.find(n=>n.nativeHash===owner);assert.deepEqual([restored.visible,restored.enabled,restored.folded],[false,true,true]);restored.visible=true;restored.folded=false;again.sync();assert.equal(again.scene.records.has(address),false);assert.equal(prior.value[0],6);
});

test('unsupported flags survive Open, default views, rebuild and Save as exact raw bytes',async()=>{
 const r=runtime(),f=await fixture(r),h=r.FrameHash,parts=[],address=h.address(owner,'flags'),block=rawBlock(h,address,0x804d,Uint8Array.of(255,0,7));
 for(const [id,e]of await h.index(f.blob))if(id!==address)parts.push(f.blob.slice(e.offset-26,e.offset+e.length));parts.push(block);await r.loadHash(new Blob(parts));
 const n=r.nodes.find(n=>n.nativeHash===owner),opaque=r.scene.records.get(address);assert.deepEqual([n.visible,n.enabled,n.folded],[true,true,false]);assert.throws(()=>{n.enabled=false;},/unsupported HASH representation/);r.sync();assert.equal(r.scene.records.get(address),opaque);
 const saved=await r.saveHash();assert.deepEqual(await raw(saved,await h.index(saved),address),new Uint8Array(await block.arrayBuffer()));
});
