import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {hash,id} from './load-runtime.mjs';
import {lookupRuntime,lookupRecords} from './native-lookup-runtime.mjs';
assert.equal(typeof global.gc,'function','Use --expose-gc');
const owners=Array.from({length:100000},(_,i)=>id(i+1)),{records}=lookupRecords.begin(),address=(h,f)=>(BigInt('0x'+h)^BigInt('0x'+hash.K[f])).toString(16).padStart(32,'0'),text=JSON.stringify({version:1,tags:[],animation:[]});
lookupRecords.put(records,hash.K.all,{id:hash.K.all,type:hash.T.ids,value:owners});for(const owner of owners)for(const [field,type,value]of [['type',hash.T.bytes,Uint8Array.of(0)],['parameters',hash.T.text,text]]){const id=address(owner,field);lookupRecords.put(records,id,{id,type,value});}
const r=lookupRuntime(records),used=()=>{global.gc();const m=process.memoryUsage();return m.heapUsed+m.arrayBuffers;};let t=performance.now();const view=r.pose(),existingMetadataWarmupMs=performance.now()-t,baseline=used();
t=performance.now();for(let i=0;i<1000;i++)r.put(owners.at(-1),'matrix',hash.T.float64,Float64Array.of(1,0,0,0,1,0,0,0,1,i,0,0));const publish1000Ms=performance.now()-t;assert.equal(view.at(-1).matrix[9],999);assert.equal(r.cache.byHash.size,owners.length);
t=performance.now();const frames=r.capture(),capture100kMs=performance.now()-t;t=performance.now();r.restore(frames,null);const restore100kMs=performance.now()-t;assert.equal(r.records.get(address(owners.at(-1),'matrix')).value[9],999);
const graph=[];for(let i=0;i<20000;i++){const owner=id(300000+i*2);graph.push({hash:owner,parent:null},{hash:id(300001+i*2),parent:owner});}
t=performance.now();const children=r.children(graph);let visited=0;for(let i=0;i<20000;i++)visited+=r.descendants(id(300000+i*2),graph,children).length;const twentyKRootsMs=performance.now()-t;assert.equal(visited,40000);
const addedMiB=(used()-baseline)/1048576;assert.equal(view.length,owners.length);assert.equal(frames.length,owners.length);assert.equal(r.records,records);assert.equal(children.size,20001);assert.equal(graph.length,40000);assert.ok(addedMiB>=0);
const budgets={publish1000Ms:250,capture100kMs:1500,restore100kMs:2000,twentyKRootsMs:1000,addedMiB:64},values={publish1000Ms,capture100kMs,restore100kMs,twentyKRootsMs,addedMiB},pass=Object.entries(budgets).every(([key,max])=>values[key]<=max);
console.log(JSON.stringify({pass,indexSHA256:createHash('sha256').update(await readFile(new URL('../index.html',import.meta.url))).digest('hex'),owners:owners.length,existingMetadataWarmupMs,...values,budgets,scope:'Actual native publishers, shared index, frame capture/replay and graph traversal; CPU-only adapters. Existing decoded metadata cache is warmed before measurement and remains explicit migration debt. Includes first hash-index construction and retained100k affine captures/40k graph nodes. Does not qualify complete UI/render callbacks, full structural history, peak Open or hardware.'},null,2));assert.ok(pass,'Native lookup budget exceeded');
