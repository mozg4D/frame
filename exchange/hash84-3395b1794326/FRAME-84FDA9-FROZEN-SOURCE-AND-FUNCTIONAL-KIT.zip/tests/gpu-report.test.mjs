import test from 'node:test';import assert from 'node:assert/strict';
import {collectFailureGPU} from './gpu-report.mjs';
const harness=({validation=null,uncaptured=[],lost=null,changed=false,queueError=null,scopeError=null,missing=false}={})=>{
 let waits=0,pops=0;
 const device={queue:{async onSubmittedWorkDone(){waits++;if(queueError)throw Error(queueError);}},async popErrorScope(){pops++;if(scopeError)throw Error(scopeError);return validation?{message:validation}:null;}};
 const window={__frameGPUDevice:missing?undefined:device,__frameGPU:uncaptured,__frameGPULost:lost,frameEngine:{renderer:{device:changed?{}:device}}};
 return {session:{page:{evaluate:fn=>new Function('window','return ('+fn.toString()+')();')(window)}},counts:()=>({waits,pops})};
};
test('an aborted common stage still waits and captures the actual main validation scope once',async()=>{
 const h=harness(),report={pass:false,errors:['Original stage failure']};await collectFailureGPU(h.session,report);assert.deepEqual(report.gpu,{validation:null,uncaptured:[],lost:null,changed:false});assert.deepEqual(h.counts(),{waits:1,pops:1});assert.deepEqual(report.errors,['Original stage failure']);await collectFailureGPU(h.session,report);assert.deepEqual(h.counts(),{waits:1,pops:1});assert.equal(report.pass,false);
});
test('already collected successful-path diagnostics are never popped twice',async()=>{
 const h=harness(),gpu={validation:null,uncaptured:[],lost:null,changed:false},report={pass:true,errors:[],gpu};await collectFailureGPU(h.session,report);assert.equal(report.gpu,gpu);assert.deepEqual(h.counts(),{waits:0,pops:0});
});
test('validation, uncaptured, lost and replacement cannot turn into a clean failure report',async()=>{
 for(const options of [{validation:'invalid command'},{uncaptured:['uncaptured']},{lost:{reason:'unknown'}},{changed:true}]){const h=harness(options),report={pass:true,errors:[]};await collectFailureGPU(h.session,report);assert.equal(report.pass,false);assert.deepEqual(h.counts(),{waits:1,pops:1});}
});
test('queue and scope inspection errors preserve the original failure and remain explicit',async()=>{
 for(const options of [{queueError:'device lost'},{scopeError:'scope missing'}]){const h=harness(options),report={pass:false,errors:['original']};await collectFailureGPU(h.session,report);assert.ok(report.gpu.inspectionError);assert.equal(report.errors[0],'original');assert.equal(report.errors.length,2);assert.equal(report.pass,false);}
});
test('an absent adapter/scope is an inspection error rather than a skipped pass',async()=>{
 for(const session of [null,harness({missing:true}).session]){const report={pass:true,errors:[]};await collectFailureGPU(session,report);assert.equal(report.pass,false);assert.ok(report.gpu.inspectionError);}
});
