// Native UI/API/GPU regression, intended for the repository's isolated session.
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
export async function canonicalHashChecks(page){
  const checks=[],timings=[],check=(name,pass,detail)=>{checks.push({name,pass:!!pass,detail});assert.ok(pass,name+': '+JSON.stringify(detail));};
  const call=async(name,args={})=>{const start=performance.now(),value=await page.evaluate(([n,a])=>frameAI.call(n,a),[name,args]),ms=performance.now()-start;timings.push({name,ms,budgetMs:6000});check(name+' completes within 6000 ms',ms<6000);return value;};
  try{
    const opened=await page.evaluate(async()=>{
      const h=FrameHash,{K,T}=h,id=n=>n.toString(16).padStart(32,'0'),owner=id(1),mesh=id(2),unknown=id(900),flagged=id(901),key='cf525ee8f31c436f80acbdc29757799f',refs='584d72d250f94d0d98bed022da5d5cef',number='d396752c6a1e450b9cd8d90f797b8bb1',sentinel='e6d95201f9ee437da9f140b2e17ab3ac';
      const rows=[[K.version,T.uint32,Uint32Array.of(1)],[K.all,T.ids,[owner,mesh]],[h.address(owner,'type'),T.bytes,Uint8Array.of(0)],[h.address(owner,'name'),T.text,'Owner'],[h.address(mesh,'name'),T.text,'Triangle'],[h.address(mesh,'parent'),T.ids,[owner]],[h.address(mesh,'positions'),T.float32,Float32Array.of(0,0,0,25,0,0,0,25,0)],[h.address(mesh,'indices'),T.uint32,Uint32Array.of(0,1,2)],
        [h.address(owner,number),T.float64,Float64Array.of(-0,1.2345678901234567)],[h.address(owner,refs),T.ids,[owner,mesh,unknown,id(999)]],[h.address(owner,'parameters'),T.text,JSON.stringify({version:1,tags:[],animation:[],plugin:{id:'absent',type:'absent_type',params:{}}})],[h.address(owner,'recordKeys'),T.ids,[key,sentinel]],[h.address(owner,'recordTypes'),T.bytes,Uint8Array.of(64,T.float64)]];
      const block=(recordId,encoding,value)=>{const a=new Uint8Array(26),v=new DataView(a.buffer);v.setUint16(0,encoding,true);a.set(Uint8Array.from({length:16},(_,i)=>parseInt(recordId.slice(i*2,i*2+2),16)),2);v.setBigUint64(18,BigInt(value.length),true);return new Blob([a,value]);};
      const parts=[];for(const [recordId,type,value]of rows)parts.push((await h.pack({id:recordId,type,value})).blob);
      parts.push(block(unknown,64,Uint8Array.of(7,0,255)),block(flagged,0x8000,Uint8Array.of(1,2,3)),block(h.address(owner,key),64,Uint8Array.of(3,2,1)));
      const sentinelBytes=new ArrayBuffer(512),sentinelView=new DataView(sentinelBytes);for(const [i,v]of [0x7ff0000000000001n,0x7ff8000000001234n,0xfff8000000005678n,0x7ff0000000000000n,0xfff0000000000000n,0x8000000000000000n].entries())sentinelView.setBigUint64(i*8,v,true);const packedSentinel=await h.pack({id:h.address(owner,sentinel),type:T.float64,value:new Float64Array(sentinelBytes)});parts.push(packedSentinel.blob);
      const original=new Blob(parts);let sourceReads=0;const file=new File([original],'canonical-hash.hash');file.slice=()=>{throw Error('Canonical scene must not retain source-file slices');};const read=file.arrayBuffer.bind(file);file.arrayBuffer=()=>{sourceReads++;return read();};
      const start=performance.now();await frameEngine.loadFile(file);const openMs=performance.now()-start;file.arrayBuffer=()=>{throw Error('Source file is unavailable after Open');};
      window.__canonicalHashTest={owner,mesh,unknown,flagged,key,refs,number,sentinel,original,sourceReads};
      const n=nodes.find(n=>n.nativeHash===mesh),d=Object.getOwnPropertyDescriptor(n,'name');
      return {owner,mesh,rowId:n.id,openMs,sourceReads,hashTable:frameEngine.scene.records instanceof Map,nameView:typeof d.get==='function'&&typeof d.set==='function'&&!Object.hasOwn(d,'value'),rawSentinel:!!frameEngine.scene.records.get(h.address(owner,sentinel))?.opaque&&!!(packedSentinel.type&256)&&!Object.hasOwn(frameEngine.scene.records.get(h.address(owner,sentinel)),'value'),gpu:['positions','indices'].every(k=>frameEngine.scene.records.get(h.address(mesh,k))?.value?.gpu===true),unknown:frameEngine.scene.records.get(unknown)?.opaque?.bytes instanceof Uint8Array};
    });
    check('Open builds a complete RAM hash table',opened.hashTable&&opened.sourceReads===1,opened);
    check('Open publishes native GPU descriptors and keeps unknown RAM bytes',opened.gpu&&opened.unknown,opened);
    check('Unavailable plugin nonfinite Float64 uses an opaque RAM block rather than UI/plugin values',opened.rawSentinel,opened);
    check('Loaded UI name is a read-through native property',opened.nameView,opened);
    timings.push({name:'native Open',ms:opened.openMs,budgetMs:6000});check('Native Open completes within 6000 ms',opened.openMs<6000);
    await call('scene.update',{id:opened.mesh,name:'API native name'});
    check('API rename updates the canonical addressed text',await page.evaluate(h=>frameEngine.nativeObjectName(h)==='API native name',opened.mesh));
    await call('edit.history',{action:'undo'});check('Native Undo restores the read-through name',await page.evaluate(h=>frameEngine.nativeObjectName(h)==='Triangle',opened.mesh));
    await call('edit.history',{action:'redo'});check('Native Redo restores the same field',await page.evaluate(h=>frameEngine.nativeObjectName(h)==='API native name',opened.mesh));
    const rowId=await page.evaluate(h=>nodes.find(n=>n.nativeHash===h).id,opened.mesh);
    await page.locator('#row-'+rowId+' .ob-name').dblclick();const input=page.locator('.ob-rename');await input.fill('Cancelled');await input.press('Escape');
    check('Native rename Escape preserves canonical data',await page.evaluate(h=>frameEngine.nativeObjectName(h)==='API native name',opened.mesh));
    await page.locator('#row-'+rowId+' .ob-name').dblclick();await input.fill('Native UI name');await input.press('Enter');await call('scene.inspect');
    check('Actual rename input writes the canonical field',await page.evaluate(h=>frameEngine.nativeObjectName(h)==='Native UI name',opened.mesh));
    const saved=await call('scene.export',{includeData:true}),content=await page.evaluate(async base64=>{
      const t=__canonicalHashTest,h=FrameHash,file=new Blob([Uint8Array.from(atob(base64),c=>c.charCodeAt(0))]),before=await h.index(t.original),after=await h.index(file);
      const bytes=async(f,e)=>new Uint8Array(await f.slice(e.offset-26,e.offset+e.length).arrayBuffer());
      let unchanged=true;for(const recordId of [t.unknown,t.flagged,h.address(t.owner,t.key),h.address(t.owner,t.sentinel)]){const a=await bytes(t.original,before.get(recordId)),b=await bytes(file,after.get(recordId));unchanged&&=a.length===b.length&&a.every((v,i)=>v===b[i]);}
      const number=await h.read(file,after.get(h.address(t.owner,t.number))),references=await h.read(file,after.get(h.address(t.owner,t.refs))),authoring=JSON.parse(await h.read(file,after.get(h.address(t.owner,'parameters'))));
      return {unchanged,number:Object.is(number[0],-0)&&number[1]===1.2345678901234567,references:references.join()=== [t.owner,t.mesh,t.unknown,'000000000000000000000000000003e7'].join(),declaration:!Object.hasOwn(authoring,'pluginRecords')&&(await h.read(file,after.get(h.address(t.owner,'recordKeys')))).join()===[t.key,t.sentinel].join()&&(await h.read(file,after.get(h.address(t.owner,'recordTypes')))).join()===[64,h.T.float64].join(),name:await h.read(file,after.get(h.address(t.mesh,'name')))};
    },saved.base64);
    check('Save preserves unknown record contents/encoding, numeric bits, references and unavailable declarations',content.unchanged&&content.number&&content.references&&content.declaration,content);
    check('Save retains the actual UI name',content.name==='Native UI name',content);
    await call('scene.open',{name:'canonical-roundtrip.hash',base64:saved.base64});
    const reopened=await page.evaluate(()=>{const t=__canonicalHashTest;return {unknown:frameEngine.scene.records.has(t.unknown),name:frameEngine.nativeObjectName(t.mesh),gpu:frameEngine.scene.records.get(FrameHash.address(t.mesh,'positions'))?.value?.gpu===true};});
    check('Real Open→edit→Save→Open preserves opaque data and native GPU ownership',reopened.unknown&&reopened.gpu&&reopened.name==='Native UI name',reopened);
    await call('plugins.describe',{plugin:'circuit'});
    const future=await page.evaluate(async()=>{
      const h=FrameHash,{K,T}=h,owner='5'.repeat(32),field='e8426bfae17d4d8b8d9b8fdd299f2c77',address=h.address(owner,field),head=new Uint8Array(26),view=new DataView(head.buffer);view.setUint16(0,0x804d,true);head.set(Uint8Array.from({length:16},(_,i)=>parseInt(address.slice(i*2,i*2+2),16)),2);view.setBigUint64(18,4n,true);const raw=new Blob([head,Uint8Array.of(9,8,7,6)]),rows=[[K.version,T.uint32,Uint32Array.of(1)],[K.all,T.ids,[owner]],[h.address(owner,'type'),T.bytes,Uint8Array.of(0)],[h.address(owner,'name'),T.text,'Future Circuit data'],[h.address(owner,'parameters'),T.text,JSON.stringify({version:1,tags:[],animation:[],plugin:{id:'circuit',type:'circuit',params:{}}})],[h.address(owner,'recordKeys'),T.ids,[field]],[h.address(owner,'recordTypes'),T.bytes,Uint8Array.of(77)]],parts=[raw];for(const [id,type,value]of rows)parts.push((await h.pack({id,type,value})).blob);
      window.__futureOwnedRecord={owner,field,raw:Array.from(new Uint8Array(await raw.arrayBuffer()))};await frameEngine.loadFile(new File(parts,'future-circuit-record.hash'));const n=nodes.find(n=>n.nativeHash===owner);let rejected=false;try{frameEngine.checkPluginRecordWrite(owner,field);}catch(e){rejected=/unsupported HASH/.test(e.message);}return {owner,type:n.type,ignored:n.ignoredAuthoring?.plugin?.id,supported:frameEngine.pluginRecordSchemaSupported(owner),rejected};
    });
    check('a loaded known plugin stays inactive for unsupported owned data while the file opens',future.type==='group'&&future.ignored==='circuit'&&!future.supported&&future.rejected,future);
    await call('scene.update',{id:future.owner,name:'Retained future plugin data'});const futureSaved=await call('scene.export',{includeData:true});
    const inspectFuture=base64=>page.evaluate(async value=>{const h=FrameHash,t=__futureOwnedRecord,file=new Blob([Uint8Array.from(atob(value),c=>c.charCodeAt(0))]),index=await h.index(file),record=index.get(h.address(t.owner,t.field)),raw=new Uint8Array(await file.slice(record.offset-26,record.offset+record.length).arrayBuffer()),metadata=JSON.parse(await h.read(file,index.get(h.address(t.owner,'parameters')))),keys=await h.read(file,index.get(h.address(t.owner,'recordKeys'))),types=await h.read(file,index.get(h.address(t.owner,'recordTypes')));return {exact:raw.length===t.raw.length&&raw.every((v,i)=>v===t.raw[i]),type:types[0],key:keys[0],plugin:metadata.plugin.id,unresolved:metadata.pluginReferencesUnresolved,nested:Object.hasOwn(metadata,'pluginRecords')};},base64);const futureExact=await inspectFuture(futureSaved.base64);
    check('native Save retains unsupported owned bytes and its native declaration without JSON or a permanent quarantine flag',futureExact.exact&&futureExact.type===77&&futureExact.key==='e8426bfae17d4d8b8d9b8fdd299f2c77'&&futureExact.plugin==='circuit'&&!futureExact.unresolved&&!futureExact.nested,futureExact);
    await call('scene.delete',{ids:[future.owner]});await call('edit.history',{action:'undo'});await call('edit.history',{action:'redo'});await call('edit.history',{action:'undo'});const historySaved=await call('scene.export',{includeData:true}),historyExact=await inspectFuture(historySaved.base64);
    check('actual Delete Undo Redo Undo preserves unknown ownership and original payload without a shadow snapshot',historyExact.exact&&historyExact.type===77&&historyExact.key===futureExact.key&&historyExact.plugin==='circuit'&&!historyExact.nested,historyExact);
    return {pass:true,checks,timings};
  }catch(error){return {pass:false,checks,timings,error:error.stack||String(error)};}
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
  const {launch,ready}=await import('../tools/browser.mjs');let session;const errors=[],consoleErrors=[];
  try{
    session=await launch({headless:process.argv.includes('--headless')});session.page.on('pageerror',e=>errors.push(e.message));session.page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});await ready(session.page);
    const hardware=await session.page.evaluate(()=>{const d=frameEngine.renderer.device;window.__canonicalDevice=d;window.__canonicalGPU=[];window.__canonicalLost=null;d.pushErrorScope('validation');d.addEventListener('uncapturederror',e=>__canonicalGPU.push(e.error.message));d.lost.then(e=>__canonicalLost={reason:e.reason,message:e.message});return Object.fromEntries(['vendor','architecture','device','description','isFallbackAdapter'].map(k=>[k,d.adapterInfo[k]]));});
    assert.ok(!hardware.isFallbackAdapter&&!/swiftshader|llvmpipe/i.test(JSON.stringify(hardware)),'Hardware WebGPU is required; software fallback is not a pass');
    const result=await canonicalHashChecks(session.page);result.hardware=hardware;result.errors=errors;result.consoleErrors=consoleErrors;
    result.gpu=await session.page.evaluate(async()=>{await __canonicalDevice.queue.onSubmittedWorkDone();return {validation:(await __canonicalDevice.popErrorScope())?.message||null,uncaptured:__canonicalGPU,lost:__canonicalLost,replaced:__canonicalDevice!==frameEngine.renderer.device};});
    if(errors.length||consoleErrors.length||result.gpu.validation||result.gpu.uncaptured.length||result.gpu.lost||result.gpu.replaced)result.pass=false;
    console.log(JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;
  }finally{await session?.close();}
}
