// Native authoring data only. No electrical solver or calculated values.
// Circuit-owned native COLUMN fields. Local IDs deliberately use uint32, not
// native remappable ID primitives. See README for the complete versioned layout.
export const LEGACY_RECORD='c17c0170000000000000000000000001';
export const RECORDS=Object.freeze(Object.fromEntries(['header','ids','offsets','labels','groundPresent','ground','positions','netPresent','assignments'].map((name,i)=>[name,'c17c01700000000000000000000000'+(i+2).toString(16).padStart(2,'0')])));
export const RECORD=RECORDS.header;
export const LIMITS=Object.freeze({components:512,pins:64,nets:1024});
export const fail=(code,message)=>Object.assign(new Error(message),{code});
export const uid=()=>crypto.randomUUID().replaceAll('-','');
export const models=Object.freeze({
 resistor:{name:'Resistor',label:'R',pins:['A','B'],fields:{Resistance:1000},units:{Resistance:'ohm'}},
 capacitor:{name:'Capacitor',label:'C',pins:['A','B'],fields:{Capacitance:1e-6},units:{Capacitance:'F'}},
 inductor:{name:'Inductor',label:'L',pins:['A','B'],fields:{Inductance:1e-3},units:{Inductance:'H'}},
 diode:{name:'Diode',label:'D',pins:['A','K'],fields:{'Saturation current':1e-14,'Emission coefficient':1},units:{'Saturation current':'A'}},
 led:{name:'LED',label:'LED',pins:['A','K'],fields:{'Saturation current':1e-20,'Emission coefficient':2},units:{'Saturation current':'A'}},
 bjt:{name:'BJT',label:'Q',pins:['B','C','E'],fields:{Polarity:['NPN','PNP'],'Forward beta':100},units:{}},
 mosfet:{name:'MOSFET',label:'M',pins:['G','D','S','B'],fields:{Polarity:['N-channel','P-channel'],'Threshold voltage':2},units:{'Threshold voltage':'V'}},
 voltage:{name:'Voltage source',label:'V',pins:['+','-'],fields:{Voltage:5},units:{Voltage:'V'}},
 current:{name:'Current source',label:'I',pins:['+','-'],fields:{Current:.001},units:{Current:'A'}},
 controller:{name:'Controller',label:'U',pins:['VDD','GND','IN','OUT'],fields:{'High voltage':3.3,'Output resistance':50},units:{'High voltage':'V','Output resistance':'ohm'}},
 custom:{name:'Component',label:'X',pins:['1','2'],fields:{},units:{}}
});
export function normalizeName(value){
 if(typeof value!=='string')throw fail('INVALID_ARGUMENT','Net name must be text.');
 const name=value.normalize('NFC').trim();
 if(!name.isWellFormed()||name.length>128||/[\u0000-\u001f\u007f]/u.test(name))throw fail('INVALID_ARGUMENT','Net name must contain at most 128 UTF-16 code units, well-formed Unicode and no control characters.');
 return name;
}
export const modelOf=n=>n?.type?.startsWith('circuit_')?n.type.slice(8):null;
export function pinsFor(kind,definitions=null){
 const labels=models[kind]?.pins;if(!labels)throw fail('INVALID_ARGUMENT','Unknown component kind.');
 const pins=definitions||labels.map((label,i)=>({label,position:labels.length===2?[i?10:-10,0,0]:[-10+20*(i%2),0,8-16*Math.floor(i/2)]}));
 if(!Array.isArray(pins)||!pins.length||pins.length>LIMITS.pins)throw fail('INVALID_ARGUMENT','A component needs 1 to 64 pins.');
 const names=new Set();
 return Array.from(pins,p=>{if(!p||typeof p.label!=='string'||!p.label.trim()||!p.label.isWellFormed()||p.label.length>64||names.has(p.label)||!Array.isArray(p.position)||p.position.length!==3||!Array.from(p.position).every(v=>Number.isFinite(v)&&Math.abs(v)<=1e6))throw fail('INVALID_ARGUMENT','Pins need unique well-formed Unicode labels and finite local positions.');names.add(p.label);return {id:uid(),label:p.label,position:[...p.position],net:null};});
}
export const initial=n=>n.type==='circuit'?{version:1,nets:[],ground:null}:{version:1,pins:pinsFor(modelOf(n))};
function validateData(n,data){
 const id=v=>typeof v==='string'&&/^[0-9a-f]{32}$/.test(v);
 if(data?.version!==1)throw fail('CIRCUIT_DATA_INVALID','Unsupported Circuit authoring data version.');
 if(n.type==='circuit'){
  if(!Array.isArray(data.nets)||data.nets.length>LIMITS.nets||data.ground!==null&&!id(data.ground))throw fail('CIRCUIT_DATA_INVALID','Invalid Circuit nets.');
  const ids=new Set(),names=new Set();for(const net of data.nets){if(!net||!id(net.id)||ids.has(net.id)||typeof net.name!=='string'||!net.name||!net.name.isWellFormed()||net.name.length>128||/[\u0000-\u001f\u007f]/u.test(net.name)||net.name.normalize('NFC').trim()!==net.name||names.has(net.name))throw fail('CIRCUIT_DATA_INVALID','Invalid Circuit network.');ids.add(net.id);names.add(net.name);}if(data.ground!==null&&!ids.has(data.ground))throw fail('CIRCUIT_DATA_INVALID','Missing ground network.');
 }else{
  if(!Array.isArray(data.pins)||!data.pins.length||data.pins.length>LIMITS.pins)throw fail('CIRCUIT_DATA_INVALID','Invalid Circuit pins.');
  const ids=new Set(),labels=new Set();for(const p of data.pins){if(!p||!id(p.id)||ids.has(p.id)||typeof p.label!=='string'||!p.label.trim()||!p.label.isWellFormed()||p.label.length>64||labels.has(p.label)||!Array.isArray(p.position)||p.position.length!==3||!Array.from(p.position).every(v=>Number.isFinite(v)&&Math.abs(v)<=1e6)||p.net!==null&&!id(p.net))throw fail('CIRCUIT_DATA_INVALID','Invalid Circuit pin.');ids.add(p.id);labels.add(p.label);}
 }
}
const invalid=message=>{throw fail('CIRCUIT_DATA_INVALID',message);};
const words=id=>Array.from({length:4},(_,i)=>parseInt(id.slice(i*8,i*8+8),16));
const localID=(values,at=0)=>Array.from({length:4},(_,i)=>values[at+i].toString(16).padStart(8,'0')).join('');
// Build and validate every replacement before the first native effect. The
// caller owns the existing native transaction; no scene or Undo is introduced.
export function encodeData(n,data){
 validateData(n,data);
 const owner=n.type==='circuit',rows=owner?data.nets:data.pins,offsets=[0],labels=[];
 for(const row of rows){labels.push(owner?row.name:row.label);offsets.push(offsets.at(-1)+labels.at(-1).length);}
 const records={};const put=(name,type,value)=>records[RECORDS[name]]={type,value};
 put('header',3,Uint32Array.of(1,owner?0:1,rows.length));
 put('ids',3,Uint32Array.from(rows.flatMap(row=>words(row.id))));
 put('offsets',3,Uint32Array.from(offsets));put('labels',7,labels.join(''));
 if(owner){put('groundPresent',0,Uint8Array.of(data.ground===null?0:1));put('ground',3,Uint32Array.from(words(data.ground??'0'.repeat(32))));}
 else{put('positions',6,Float64Array.from(rows.flatMap(row=>row.position)));put('netPresent',0,Uint8Array.from(rows.map(row=>row.net===null?0:1)));put('assignments',3,Uint32Array.from(rows.flatMap(row=>words(row.net??'0'.repeat(32)))));}
 return records;
}
export function readData(D,n){
 const records=D.records(n.nativeHash);if(!records)invalid('Circuit authoring columns are missing.');if(Object.hasOwn(records,LEGACY_RECORD))invalid('Legacy JSON Circuit records are unsupported; recreate this authoring data.');
 const column=(name,type,length)=>{
  const r=records[RECORDS[name]],v=r?.value;
  if(!r||r.type!==type||!(Array.isArray(v)||ArrayBuffer.isView(v)&&!(v instanceof DataView))||v.length!==length)invalid('Missing or malformed Circuit '+name+' column.');
  for(const x of v)if(typeof x!=='number'||!Number.isFinite(x)||type!==6&&(!Number.isInteger(x)||x<0||x>(type===0?255:0xffffffff)))invalid('Invalid Circuit '+name+' column value.');
  return v;
 };
 const owner=n.type==='circuit',header=column('header',3,3),count=header[2],max=owner?LIMITS.nets:LIMITS.pins;
 if(header[0]!==1||header[1]!==Number(!owner)||count>max||!owner&&!count)invalid('Unsupported Circuit column header or count.');
 for(const name of owner?['positions','netPresent','assignments']:['groundPresent','ground'])if(Object.hasOwn(records,RECORDS[name]))invalid('Circuit columns do not match the owner kind.');
 const ids=column('ids',3,count*4),offsets=column('offsets',3,count+1),pool=records[RECORDS.labels];
 if(pool?.type!==7||typeof pool.value!=='string'||pool.value.length>count*(owner?128:64)||!pool.value.isWellFormed()||offsets[0]!==0||offsets[count]!==pool.value.length)invalid('Invalid Circuit label pool.');
 const labels=[];for(let i=0;i<count;i++){if(offsets[i+1]<=offsets[i]||offsets[i+1]>pool.value.length||offsets[i+1]-offsets[i]>(owner?128:64))invalid('Invalid Circuit label offsets.');labels.push(pool.value.slice(offsets[i],offsets[i+1]));}
 let data;
 if(owner){const present=column('groundPresent',0,1),ground=column('ground',3,4);if(present[0]>1||!present[0]&&ground.some(x=>x!==0))invalid('Invalid Circuit Ground presence.');data={version:1,nets:labels.map((name,i)=>({id:localID(ids,i*4),name})),ground:present[0]?localID(ground):null};}
 else{const positions=column('positions',6,count*3),present=column('netPresent',0,count),assignments=column('assignments',3,count*4);
  data={version:1,pins:labels.map((label,i)=>{const id=localID(assignments,i*4);if(present[i]>1||!present[i]&&id!=='0'.repeat(32))invalid('Invalid Circuit pin assignment presence.');return {id:localID(ids,i*4),label,position:Array.from(positions.slice(i*3,i*3+3)),net:present[i]?id:null};})};
 }
 validateData(n,data);return data;
}
export function saveData(D,n,data){
 const records=encodeData(n,data);
 if(Object.hasOwn(D.records(n.nativeHash)||{},LEGACY_RECORD))invalid('Legacy JSON Circuit records are unsupported; recreate this authoring data.');
 for(const [key,r]of Object.entries(records))D.setRecord(n.nativeHash,key,r.type,r.value);
}
// Ephemeral authoring connectivity, not a netlist, model validator or solver result.
export function topology(D,owner){
 const data=readData(D,owner),nets=new Map(data.nets.map(net=>[net.id,net]));
 const members=D.nodes.filter(n=>models[modelOf(n)]&&n.params.Circuit===owner.nativeHash);
 if(members.length>LIMITS.components)throw fail('LIMIT_EXCEEDED','Circuit supports at most 512 preview components.');
 const nodeForNet=id=>id===data.ground?'0':'n_'+id;
 const components=members.map(n=>({hash:n.nativeHash,kind:modelOf(n),enabled:n.enabled!==false,pins:readData(D,n).pins.map(p=>{
  if(p.net!==null&&!nets.has(p.net))throw fail('CIRCUIT_DATA_INVALID','Pin refers to a missing network in its Circuit.');
  return {id:p.id,label:p.label,position:[...p.position],net:p.net,node:p.net===null?'p_'+n.nativeHash+'_'+p.id:nodeForNet(p.net)};
 })})).sort((a,b)=>a.hash.localeCompare(b.hash));
 return {circuit:owner.nativeHash,stage:'authoring-preview',authoringOnly:true,numericalAvailable:false,enabled:owner.enabled!==false,ground:data.ground,
  nets:data.nets.map(net=>({...net,node:nodeForNet(net.id)})).sort((a,b)=>a.id.localeCompare(b.id)),components};
}
export function tree(points){
 if(points.length<2)return [];
 // A deterministic star is a connected tree, never an all-pairs graph.
 return points.slice(1).flatMap(p=>[...points[0],...p]);
}
