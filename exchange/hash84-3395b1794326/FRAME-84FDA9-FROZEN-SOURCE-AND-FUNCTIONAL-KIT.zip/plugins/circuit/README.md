# Circuit (under construction)

This is an authoring preview, not an electrical simulator. It deliberately returns no calculated voltage/current and has no running firmware or Scope. The completion criterion from the Circuit concept has not been reached.

## Available now

- An ordinary, empty Circuit owner. It has no square, surface, box or calculation volume.
- Separate ordinary Resistor, Capacitor, Inductor, Diode, LED, BJT, MOSFET, Voltage source, Current source, Controller and custom Component objects. Circuit Attributes has compact creation actions; components use native selection, transforms, visibility, parameters, Undo and HASH.
- Flat local-X/Z line symbols on a transparent background, drawn through the existing shared-device render callback. The symbols never face the camera automatically. There are no SVG-texture cards or extra rows for strokes/pins.
- Stable local pin identifiers and positions. Each component's native Circuit reference is explicit and independent of grouping. Creating a component from the owner makes it a child of that owner. Standalone components are unassigned.
- Owner-local stable networks, one-pin assignment/disconnection, rename/merge, explicit Ground, and a connected-tree visualization controlled by Nets. Crossing lines does not connect networks. Visibility affects only the authoring display.
- Common field discovery and native authoring writes for declared scalar parameters, with units/ranges supplied by the manifest. No competing binding registry.

These parameters are authored intentions, not complete validated electrical models. A Controller is an inert component. An LED has no calculated light output; its arrows are a static symbol. Polarity is retained as metadata; variant-specific symbol embellishment is unfinished.

## API

Discover with frameAI plugins.describe for plugin circuit, then call the existing plugins.command on an owner's native hash.

- status / inspect: inspect owner networks or component pins. Unavailable pin voltage is null with availability solver-unavailable, never a false zero.
- topology: read a bounded, detached connectivity snapshot for one Circuit. Includes stable component/pin/net identities, local pin positions and explicit owner/component enabled flags. Visibility and parenting do not alter electrical membership. It validates record integrity and rejects dangling net references; it does not validate electrical models or physical solvability.
- create-component: kind from resistor, capacitor, inductor, diode, led, bjt, mosfet, voltage, current, controller or custom; optional name. Custom accepts 1–64 explicitly labelled local-position pins. Compact create-resistor and equivalent actions are also registered.
- create-net: name; returns an existing or new owner-local stable ID.
- assign-net: component owner, stable pin ID, name. A nonempty new name creates a network, an existing name connects to it, and empty text disconnects that pin only.
- rename-net: Circuit owner, stable net ID, new name. An existing name merges all member pins and Ground into its canonical ID in one native Undo transaction.
- set-ground: Circuit owner, net ID or null. It observes an explicit reference network, not an implicit connection.
- move-component: component owner, target circuit hash. Explicit transfer clears network assignments while retaining pin IDs. Ordinary reparenting never transfers electrical membership.

Network names are Unicode NFC, trimmed, case-sensitive, 1–128 UTF-16 code units without control characters. Empty text is accepted only for pin disconnection. Unassigned pins are distinct, not one implicit node. Networks in separate Circuits are independent even if names match.

Topology node identifiers are `n_<net ID>` for assigned networks and `p_<component hash>_<pin ID>` for disconnected pins. Only the explicitly selected Ground maps to `0`; a network named `0` has no special meaning. Clients must address nodes as `(circuit, node)` because copied Circuits retain owner-local network IDs. Node names never contain user-entered net names. Components and nets are sorted by stable identity; pin order is the authored order. Disabled components remain in this authoring snapshot with `enabled:false`; this is not a compiled active solver graph. No connectivity snapshot is persisted in HASH or cached as a second scene model.

Creation and explicit or generic ownership transfer validate target authoring data before mutation. Generic owner edits also enforce the same component bound. Failed target preflight does not add an Undo step.

Bounds are 512 created components per Circuit, 64 pins per component and 1024 networks per Circuit. Authoring settings use seconds of electrical time per Frame second (default 0.001 s/s) and decimal MB (1 MB = 1,000,000 bytes). History is only a future allocation ceiling; the preview allocates no measurement history.

## Explicitly unfinished

- ngspice/WASM selection, reproducible build, licensing/dependency review and real JS/solver closed-loop prototype.
- DC, transient and AC analyses; model import, model validation/replacement, real-part/footprint metadata, netlist export and numerical tolerances.
- Controller execution and accepted-time event scheduling with Scene Control. Shared Scene Control currently exists but its full simulation/export lifecycle contract is not implemented by Circuit.
- Interactive Net/Ground/pin rows, pin/net hit-testing and highlights, compact labels and viewport context menus. Use the native Object Browser for selection and the API for network authoring. Custom component positions are preserved; custom pin lead artwork is unfinished.
- One shared Scope window, read-only Curves, differential measurements, history storage/decimation, reset/replay and memory qualification. No separate window or transport was copied from Docs.
- LED preset integration and current-dependent temporary emission.

solve, transient, ac, reset, scope, controller, results and export-netlist reject with CIRCUIT_AUTHORING_ONLY before mutation. Unsupported work is not reported as Passed. No ngspice, model-library or other third-party executable artifact ships in this preview; original project code/artwork follows the repository LICENSE.

## Data and lifecycle

Circuit-owned authoring persists as independently addressed native COLUMN records. It contains no JSON object document, encoded JSON bytes or opaque whole-scene blob. `readData`/`saveData` retain the ephemeral `{version:1,nets,ground}` / `{version:1,pins}` object API; only pins/networks/Ground are persisted in these fields. All field keys have prefix `c17c01700000000000000000000000` followed by the two hexadecimal digits below:

| Suffix | Column | Native type | Layout |
| --- | --- | --- | --- |
| 02 | header | 3, uint32 | `[1, kind, count]`, kind 0 Circuit / 1 component |
| 03 | ids | 3, uint32 | `count * 4` words: each 32-hex owner-local ID split left-to-right into four eight-hex words |
| 04 | offsets | 3, uint32 | `count + 1` UTF-16 code-unit offsets into labels, starting at 0 and ending at pool length |
| 05 | labels | 7, text | Concatenated net names or pin labels, no delimiters or object syntax |
| 06 | groundPresent | 0, uint8 | Circuit only: one 0/1 flag |
| 07 | ground | 3, uint32 | Circuit only: four Ground ID words, all zero when absent |
| 08 | positions | 6, Float64 | Component only: `count * 3` xyz values in authored pin order |
| 09 | netPresent | 0, uint8 | Component only: `count` 0/1 assignment flags |
| 0a | assignments | 3, uint32 | Component only: `count * 4` net ID words, all zero for absent assignment |

Counts are 0-1024 for Circuit networks and 1-64 for component pins. Presence flags distinguish null from a valid all-zero 128-bit ID. IDs are numeric words deliberately using type 3; native type 4 would incorrectly remap these owner-local identities during copy. Positions preserve exact finite JS Float64 values within +/-1e6, without quantization. Labels and each offset slice must be well-formed Unicode; offsets are strictly increasing, length bounded and cannot split a surrogate pair. Duplicate IDs, net names or pin labels, malformed columns, missing/wrong-type/length columns, unexpected kind-specific columns, noncanonical names, invalid flags, unflagged nonzero IDs and missing Ground references reject. Readers accept native ordinary numeric arrays and decoded typed arrays, validate every column and return detached objects without effects. Saves validate and construct all replacement columns before calling `D.setRecord` inside the existing caller-owned native transaction. Existing record values are never mutated in place.

The former JSON field `c17c0170000000000000000000000001` explicitly rejects, even alongside new columns. There is no fallback or migration. Recreate legacy authoring data. Circuit object references remain normal scalar native reference parameters; core copy/HASH remapping owns them. No new scene, Undo, binding registry or reference path is introduced.

Shared-core boundary: the current core still serializes generic authoring metadata (including plugin descriptors, record field layout and scalar parameters) as JSON in `index.html`. This increment removes the Circuit-owned scene blob only. It does not establish whole-scene no-JSON HASH compliance; replacing that shared metadata bridge remains coordinator work. More column descriptors also add metadata overhead; primitive payload measurements below exclude that overhead.

No samples, caches, derived polylines, GPU buffers, solver heap or live program state are saved. The network cache compares immutable record-value identities and small numeric transform/visibility dependencies, without serializing column contents on every frame. New wrappers around the same immutable values reuse the cache; owner/pin records, owner inverse frame, component frames and inherited visibility invalidate it.

The renderer reuses canonical Frame transforms, the shared device, native pass, camera and frame uniforms. Identical component symbols reuse one small vertex buffer. Network buffers are bounded, invalidated by authoring, Circuit-owner inverse frame, component world frames and effective inherited visibility, and retired on owner deletion/device loss. There is no competing scene graph, animation loop, Undo, panel, runtime, GPUDevice or electrical state.

## Checks

CPU: `node plugins/circuit/tests/cpu.mjs` runs the combined authoring, native-column and resource-double cache contracts, syntax checks and source-hashed evidence writing. Focused gates are `tests/records.mjs` and `tests/net-cache.mjs` under this plugin. The column gate extracts the actual core native record adapter, HASH primitive pack/index/read codec and copy remapper; small, near-limit and exact 1024-net/64-pin fixtures verify typed binary roundtrips and raw/packed payload sizes against a legacy JSON record through the same codec. These measurements cover plugin primitives plus 26-byte record headers only, excluding generic scene metadata; they are not whole-scene HASH sizes. Synthetic sequential IDs, repeated positions and repeated label padding are compressible; packed sizes are fixture-specific, not predictions for random IDs or user scenes. The small fixture grows because of separate record headers. Native browser gate: `node plugins/circuit/tests/index.mjs` (visible hardware Chromium by default; `--headless` explicit). Catalogue discovery uses that same pluginChecks entry point, including focused column CPU checks. CPU evidence is written to `tests/results/circuit-native-columns-cpu.json`; hardware evidence remains `tests/results/circuit-authoring-preview.json`. CPU primitive codec tests do not certify native scene lifecycle/UI/GPU behavior. Current test results and unrun release gates belong in QUALIFICATION.md.
