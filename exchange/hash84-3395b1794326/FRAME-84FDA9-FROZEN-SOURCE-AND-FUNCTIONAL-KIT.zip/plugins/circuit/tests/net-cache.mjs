import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {installSymbols} from '../viewport.js';
import {readData,saveData} from '../data.js';
import {nativeRecords} from './records.mjs';
import {symbol,bounds} from '../symbols.js';

// Execute the shipped render/cache code with explicit CPU GPU-resource doubles.
// This proves cache invalidation and bounded buffer retirement, not hardware rendering.
export async function netCacheChecks(){
 const started=performance.now(),checks=[],timings=[],uploads=[],draws=[],buffers=[];
 const check=(name,fn)=>{fn();checks.push({name,pass:true});};
 const saved=Object.fromEntries(['GPUShaderStage','GPUBufferUsage'].map(key=>[key,Object.getOwnPropertyDescriptor(globalThis,key)]));
 globalThis.GPUShaderStage={VERTEX:1,FRAGMENT:2};globalThis.GPUBufferUsage={VERTEX:1,COPY_DST:2};
 const translation=x=>new Float64Array([1,0,0,0,0,1,0,0,0,0,1,0,x,0,0,1]);
 const M={inv:m=>translation(-m[12]),mul:(a,b)=>translation(a[12]+b[12]),point:(m,p)=>[m[12]+p[0],p[1],p[2]]};
 const owner={id:1,nativeHash:'1'.repeat(32),type:'circuit',visible:true,params:{Nets:true}},group={id:2,type:'group',visible:true,parent:null};
 const a={id:3,nativeHash:'3'.repeat(32),type:'circuit_resistor',visible:true,parent:2},b={id:4,nativeHash:'4'.repeat(32),type:'circuit_resistor',visible:true,parent:null};
 const worlds=new Map([[owner.nativeHash,translation(0)],[a.nativeHash,translation(20)],[b.nativeHash,translation(40)]]),net='5'.repeat(32);
 const records=new Map([[owner.nativeHash,nativeRecords({version:1,nets:[{id:net,name:'NET'}],ground:null})],...[a,b].map(c=>[c.nativeHash,nativeRecords({version:1,pins:[{id:'6'.repeat(32),label:'A',net,position:[0,0,0]}]})])]);
 let viewport;
 const D={nodes:[owner,group,a,b],world:hash=>worlds.get(hash),records:hash=>records.get(hash),setRecord:(hash,key,type,value)=>records.get(hash)[key]={type,value:type===7?value:Array.from(value)}};
 const device={
  createBindGroupLayout:()=>({}),createPipelineLayout:()=>({}),createBindGroup:()=>({}),
  createShaderModule:()=>({getCompilationInfo:async()=>({messages:[]})}),createRenderPipelineAsync:async()=>({}),
  createBuffer:descriptor=>{const buffer={...descriptor,destroyed:false,destroy(){this.destroyed=true;}};buffers.push(buffer);return buffer;},
  queue:{writeBuffer:(buffer,_offset,value)=>{if(buffer.label==='Circuit network authoring lines')uploads.push({buffer,values:Array.from(value)});}},
  lost:new Promise(()=>{})
 };
 const pass={setPipeline(){},setBindGroup(){},setVertexBuffer(_slot,buffer){this.buffer=buffer;},draw(count){draws.push({count,buffer:this.buffer});}},camera={},frame={};
 const render=()=>{const before=draws.length;viewport.render({pass,camera,frame,orthographic:true,hash:owner.nativeHash,device,format:'bgra8unorm'});return draws.length-before;};
 try{
  await installSymbols({document:D,math:M,requestDraw(){},viewport:{register:async descriptor=>viewport=descriptor}},{find:()=>owner,members:()=>[a,b],read:n=>readData(D,n),symbol,bounds});
  render();await new Promise(resolve=>setImmediate(resolve));render();
  check('network cache initially uploads expected owner-local pin endpoints',()=>assert.deepEqual(uploads.at(-1).values,[20,0,0,40,0,0]));
  const initial=uploads.at(-1).buffer,initialCount=uploads.length;render();
  check('unchanged owner, visibility and pins reuse the network buffer',()=>assert.equal(uploads.length,initialCount));
  worlds.set(owner.nativeHash,translation(10));render();
  check('independent Circuit-owner translation invalidates the cache',()=>{assert.equal(uploads.length,initialCount+1);assert.deepEqual(uploads.at(-1).values,[10,0,0,30,0,0]);assert(initial.destroyed);});
  check('borrowed owner frame keeps the rebuilt line on world-space pin endpoints',()=>{const v=uploads.at(-1).values,m=worlds.get(owner.nativeHash);assert.deepEqual([...M.point(m,v.slice(0,3)),...M.point(m,v.slice(3,6))],[20,0,0,40,0,0]);});
  const translated=uploads.at(-1).buffer;group.visible=false;const uploadCount=uploads.length;
  check('hiding a component ancestor removes the cached pin and retires the old line',()=>{assert.equal(render(),0);assert.equal(uploads.length,uploadCount);assert(translated.destroyed);assert.equal(a.visible,true);});
  group.visible=true;render();
  check('restoring inherited visibility rebuilds the valid network tree',()=>{assert.equal(uploads.length,uploadCount+1);assert.deepEqual(uploads.at(-1).values,[10,0,0,30,0,0]);});
  check('immutable pin-position column replacement invalidates cache without replacing record wrapper',()=>{const data=readData(D,a);data.pins[0].position[0]=5;saveData(D,a,data);render();assert.deepEqual(uploads.at(-1).values,[15,0,0,30,0,0]);});
  check('immutable pin-assignment column replacement removes old connectivity',()=>{const data=readData(D,a);data.pins[0].net=null;saveData(D,a,data);const prior=uploads.at(-1).buffer;assert.equal(render(),0);assert(prior.destroyed);});
  check('owner network column replacement invalidates topology identity',()=>{const data=readData(D,a);data.pins[0].net=net;saveData(D,a,data);render();const prior=uploads.at(-1).buffer;saveData(D,owner,{version:1,nets:[],ground:null});assert.equal(render(),0);assert(prior.destroyed);saveData(D,owner,{version:1,nets:[{id:net,name:'NET'}],ground:null});render();assert.deepEqual(uploads.at(-1).values,[15,0,0,30,0,0]);});
  check('new record wrapper with same immutable values reuses cache',()=>{const count=uploads.length;records.set(a.nativeHash,{...records.get(a.nativeHash)});render();assert.equal(uploads.length,count);});
  check('independent component world-frame changes invalidate cache',()=>{worlds.set(b.nativeHash,translation(50));render();assert.deepEqual(uploads.at(-1).values,[15,0,0,40,0,0]);});
  check('unchanged cache checks never enumerate native numeric column contents',()=>{let locked=false;const columns=[];for(const rows of records.values())for(const row of Object.values(rows))if(row.type!==7){const original=row.value;row.value=new Proxy(original,{get(target,key,receiver){if(locked&&(key===Symbol.iterator||key==='toJSON'||typeof key==='string'&&/^\d+$/.test(key)))throw Error('Enumerated unchanged numeric column');return Reflect.get(target,key,receiver);}});columns.push([row,original]);}try{assert.equal(render(),1);locked=true;const count=uploads.length;assert.equal(render(),1);assert.equal(uploads.length,count);}finally{locked=false;for(const [row,value]of columns)row.value=value;render();}});
  const reuseStart=performance.now();for(let i=0;i<1000;i++)render();const reuseMS=performance.now()-reuseStart;assert(reuseMS<1000);timings.push({name:'1000 unchanged native-column network-cache lookups',ms:reuseMS,limit:1000});
  D.nodes=[];viewport.retire(owner.nativeHash);
  check('owner retirement releases every owned line/symbol buffer',()=>assert(buffers.every(buffer=>buffer.destroyed)));
  const ms=performance.now()-started;assert(ms<1000,'CPU net-cache regression exceeded its 1000 ms budget');
  return {pass:true,checks,timings:[...timings,{name:'Circuit net-cache CPU regression',ms,limit:1000}],scope:'Actual shipped cache code with CPU resource doubles only; no GPU was requested.'};
 }finally{for(const [key,descriptor]of Object.entries(saved)){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}}
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))console.log(JSON.stringify(await netCacheChecks(),null,2));
