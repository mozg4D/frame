import {spawnSync} from 'node:child_process';
import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,relative} from 'node:path';
import {fileURLToPath} from 'node:url';

// Deliberately CPU-only. Do not invoke a browser, GPU gate or dependency install.
const root=fileURLToPath(new URL('../../../',import.meta.url)),nodeArgs=['--preserve-symlinks','--preserve-symlinks-main'];
const run=path=>spawnSync(process.execPath,[...nodeArgs,path],{cwd:root,encoding:'utf8',maxBuffer:16*1024*1024});
const started=performance.now(),gate=run('plugins/circuit/tests/authoring.mjs');let result;
try{result=JSON.parse(gate.stdout);if(gate.status!==0)throw Error(gate.stderr||'CPU gate failed');}catch(error){result={pass:false,checks:[],timings:[],error:gate.stderr||error.stack,stdout:gate.stdout};}
const pluginRoot=resolve(root,'plugins/circuit'),pluginFiles=(await readdir(pluginRoot,{recursive:true,withFileTypes:true})).filter(f=>f.isFile()).map(f=>relative(root,resolve(f.parentPath,f.name)).replaceAll('\\','/')).sort();
result.syntax=[];for(const path of pluginFiles.filter(p=>/\.(mjs|js)$/.test(p))){const checked=spawnSync(process.execPath,[...nodeArgs,'--check',path],{cwd:root,encoding:'utf8'});result.syntax.push({path,pass:checked.status===0,...checked.status===0?{}:{error:checked.stderr}});if(checked.status!==0)result.pass=false;}
const diff=spawnSync('git',['diff','--check','--','plugins/circuit'],{cwd:root,encoding:'utf8'});result.whitespace={pass:diff.status===0,...diff.status===0?{}:{error:diff.stdout+diff.stderr}};if(diff.status!==0)result.pass=false;
result.sources={};for(const path of ['index.html','app.md','plugins.md','AGENTS.md','plugins/AGENTS.md','plugins/index.json',...pluginFiles])result.sources[path]=createHash('sha256').update(await readFile(resolve(root,path))).digest('hex');
result.runtime={node:process.version,executable:process.execPath,flags:nodeArgs};result.totalCompletedMS=performance.now()-started;result.nativeSceneVerified=false;result.hardwareVerified=false;
result.unrun=['Native browser/HASH lifecycle and typed-record reopen/Duplicate/clipboard/Merge assertions','Hardware WebGPU/render and fresh frame timing','npm test','npm run test:stress','npm run test:all / 100M','Electrical solver, ngspice parser/execution, controller synchronization and Scope'];
result.boundary='Circuit-owned primitive payloads only: shared core still persists generic plugin metadata/layout/parameters as JSON. No whole-scene no-JSON compliance or whole-scene size improvement is claimed.';
const output=resolve(root,'tests/results/circuit-native-columns-cpu.json');await mkdir(resolve(root,'tests/results'),{recursive:true});await writeFile(output,JSON.stringify(result,null,2));
console.log(JSON.stringify({pass:result.pass,checks:result.checks.length,syntaxFiles:result.syntax.length,timings:result.timings,measurements:result.measurements,evidence:output,error:result.error},null,2));process.exitCode=result.pass?0:1;
