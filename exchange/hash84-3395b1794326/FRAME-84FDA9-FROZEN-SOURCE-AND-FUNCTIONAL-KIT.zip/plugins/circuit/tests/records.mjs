import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {RECORDS,LEGACY_RECORD,encodeData,saveData,readData,topology,normalizeName,pinsFor} from '../data.js';

const id=n=>n.toString(16).padStart(32,'0'),owner={nativeHash:'a'.repeat(32),type:'circuit'},component={nativeHash:'b'.repeat(32),type:'circuit_custom',params:{Circuit:owner.nativeHash}};
// Mutable array fixtures exercise invalid column encodings below; actual native
// typed borrows and the shipped table/lease factories are also exercised.
export function nativeRecords(data){
 const n={type:Object.hasOwn(data,'nets')?'circuit':'circuit_custom',nativeHash:id(1)},records={};
 saveData({records:()=>records,setRecord:(_h,key,type,value)=>records[key]={type,value:type===7?value:Array.from(value)}},n,data);
 return records;
}
const fixture=(nets=3,pins=3)=>({
 network:{version:1,nets:Array.from({length:nets},(_,i)=>({id:id(i),name:('N'+i+' \u{1f9ea} e\u0301').normalize('NFC')})),ground:nets?id(0):null},
 part:{version:1,pins:Array.from({length:pins},(_,i)=>({id:id(i),label:'P'+i+' \u{1f50c}',position:[i?1/3:-0,i?1e6:Number.MIN_VALUE,-1e6],net:i%2?id(0):null}))}
});
const get=(records,n)=>readData({records:()=>records},n);
export async function recordChecks(){
 const checks=[],timings=[],measurements=[];
 const check=async(name,fn)=>{await fn();checks.push({name:'Circuit native columns: '+name,pass:true});};
 const bad=fn=>assert.throws(fn,e=>e.code==='CIRCUIT_DATA_INVALID');
 await check('new unique field identities and native column primitive types',()=>{
  assert.equal(new Set(Object.values(RECORDS)).size,9);for(const key of Object.values(RECORDS)){assert.match(key,/^[0-9a-f]{32}$/);assert.notEqual(key,LEGACY_RECORD);}
  const {network,part}=fixture(),a=encodeData(owner,network),b=encodeData(component,part);
  assert(a[RECORDS.ids].value instanceof Uint32Array);assert(b[RECORDS.positions].value instanceof Float64Array);assert(b[RECORDS.netPresent].value instanceof Uint8Array);
  for(const r of [...Object.values(a),...Object.values(b)])assert([0,3,6,7].includes(r.type));assert.equal(typeof a[RECORDS.labels].value,'string');
 });
 await check('roundtrip arrays/typed arrays preserves Unicode, exact float64, zero IDs and null presence',()=>{
  const {network,part}=fixture();part.pins[2].net=id(0);
  for(const encode of [nativeRecords,(d)=>encodeData(Object.hasOwn(d,'nets')?owner:component,d)]){
   const a=encode(network),b=encode(part);assert.deepEqual(get(a,owner),network);assert.deepEqual(get(b,component),part);assert.equal(get(b,component).pins[0].net,null);assert.equal(get(b,component).pins[1].net,id(0));
   const result=get(b,component);result.pins[0].position[0]=42;result.pins[0].label='changed';assert.deepEqual(get(b,component),part);
  }
  assert.deepEqual(get(nativeRecords({version:1,nets:[],ground:null}),owner),{version:1,nets:[],ground:null});
 });
 const {network,part}=fixture();
 const corruptions=[
  ['missing header',r=>delete r[RECORDS.header]],['legacy JSON only',r=>{for(const k of Object.keys(r))delete r[k];r[LEGACY_RECORD]={type:7,value:'{}'};}],
  ['legacy JSON alongside columns',r=>r[LEGACY_RECORD]={type:7,value:'{}'}],['header primitive type',r=>r[RECORDS.header].type=7],
  ['unsupported version',r=>r[RECORDS.header].value[0]=2],['wrong owner kind',r=>r[RECORDS.header].value[1]=0],['empty component',r=>r[RECORDS.header].value[2]=0],
  ['over-limit count',r=>r[RECORDS.header].value[2]=65],['fractional count',r=>r[RECORDS.header].value[2]=1.5],['short header',r=>r[RECORDS.header].value.pop()],
  ['missing IDs',r=>delete r[RECORDS.ids]],['native remappable ID type forbidden',r=>r[RECORDS.ids].type=4],['short IDs',r=>r[RECORDS.ids].value.pop()],
  ['out of range ID word',r=>r[RECORDS.ids].value[0]=2**32],['negative ID word',r=>r[RECORDS.ids].value[0]=-1],['text ID word',r=>r[RECORDS.ids].value[0]='0'],
  ['duplicate pin ID',r=>r[RECORDS.ids].value.splice(4,4,...r[RECORDS.ids].value.slice(0,4))],['DataView column',r=>r[RECORDS.ids].value=new DataView(new ArrayBuffer(48))],
  ['missing offset',r=>r[RECORDS.offsets].value.pop()],['nonzero first offset',r=>r[RECORDS.offsets].value[0]=1],['nonincreasing offset',r=>r[RECORDS.offsets].value[1]=0],['label per-row bound',r=>{r[RECORDS.labels].value='x'.repeat(65)+'BC';r[RECORDS.offsets].value=[0,65,66,67];}],
  ['offset exceeds pool',r=>r[RECORDS.offsets].value[1]=100000],['trailing pool text',r=>r[RECORDS.labels].value+='x'],['nontext pool',r=>r[RECORDS.labels].value=[]],
  ['wrong pool primitive',r=>r[RECORDS.labels].type=0],['missing pool',r=>delete r[RECORDS.labels]],['lone surrogate pool',r=>r[RECORDS.labels].value='\ud800'+r[RECORDS.labels].value.slice(1)],
  ['surrogate boundary split',r=>{r[RECORDS.labels].value='\u{1f50c}';r[RECORDS.header].value[2]=2;r[RECORDS.ids].value=r[RECORDS.ids].value.slice(0,8);r[RECORDS.offsets].value=[0,1,2];r[RECORDS.positions].value=r[RECORDS.positions].value.slice(0,6);r[RECORDS.netPresent].value=[0,0];r[RECORDS.assignments].value=Array(8).fill(0);}],
  ['duplicate labels',r=>{r[RECORDS.labels].value='AAA';r[RECORDS.offsets].value=[0,1,2,3];}],['blank label',r=>{r[RECORDS.labels].value='   ';r[RECORDS.offsets].value=[0,1,2,3];}],
  ['position count',r=>r[RECORDS.positions].value.pop()],['position primitive',r=>r[RECORDS.positions].type=5],['position NaN',r=>r[RECORDS.positions].value[0]=NaN],
  ['position infinity',r=>r[RECORDS.positions].value[0]=Infinity],['position bound',r=>r[RECORDS.positions].value[0]=1e6+1],['position null',r=>r[RECORDS.positions].value[0]=null],
  ['missing presence',r=>delete r[RECORDS.netPresent]],['invalid presence flag',r=>r[RECORDS.netPresent].value[0]=2],['presence byte bound',r=>r[RECORDS.netPresent].value[0]=256],
  ['short assignment',r=>r[RECORDS.assignments].value.pop()],['hidden assignment without presence',r=>r[RECORDS.assignments].value[0]=1],['inapplicable Ground column',r=>r[RECORDS.ground]={type:3,value:[0,0,0,0]}]
 ];
 for(const [name,edit]of corruptions)await check(name+' rejects read without mutation',()=>{const r=nativeRecords(part);edit(r);const before=structuredClone(r);bad(()=>get(r,component));assert.deepEqual(r,before);});
 for(const [name,edit]of [
  ['duplicate net ID',d=>d.nets[1].id=d.nets[0].id],['duplicate net name',d=>d.nets[1].name=d.nets[0].name],['missing Ground net',d=>d.ground=id(999)],
  ['noncanonical net name',d=>d.nets[0].name=' e\u0301 '],['net control character',d=>d.nets[0].name='a\nb'],['malformed Unicode net',d=>d.nets[0].name='\udc00'],
  ['uppercase ID',d=>d.nets[0].id='A'.repeat(32)],['short ID',d=>d.nets[0].id='0'],['null missing distinction',d=>delete d.ground],['net bound',d=>d.nets=Array(1025).fill(d.nets[0])]
 ])await check(name+' rejects save before native effects',()=>{
  const d=structuredClone(network);edit(d);const r=nativeRecords(network),before=structuredClone(r);let effects=0;
  bad(()=>saveData({records:()=>r,setRecord(){effects++;}},owner,d));assert.equal(effects,0);assert.deepEqual(r,before);
 });
 await check('pin save validates every row before effects and never changes existing immutable values',()=>{
  const r=nativeRecords(part),before=structuredClone(r),d=structuredClone(part);d.pins.at(-1).position[2]=Infinity;let effects=0;
  bad(()=>saveData({records:()=>r,setRecord(){effects++;}},component,d));assert.equal(effects,0);assert.deepEqual(r,before);
  for(const value of ['\ud800','\udc00','x'.repeat(65),d.pins[0].label]){d.pins.at(-1).position[2]=0;d.pins.at(-1).label=value;bad(()=>encodeData(component,d));}
  const old=r[RECORDS.ids].value;saveData({records:()=>r,setRecord:(_h,key,type,value)=>r[key]={type,value:type===7?value:Array.from(value)}},component,part);assert.notEqual(r[RECORDS.ids].value,old);assert.deepEqual(before,nativeRecords(part));
  bad(()=>saveData({records:()=>({[LEGACY_RECORD]:{type:7,value:'{}'}}),setRecord(){effects++;}},component,part));assert.equal(effects,0);
  assert.throws(()=>normalizeName('\ud800'),e=>e.code==='INVALID_ARGUMENT');assert.throws(()=>pinsFor('custom',[{label:'\udc00',position:[0,0,0]}]),e=>e.code==='INVALID_ARGUMENT');
 });
 await check('sparse authoring arrays reject before any replacement or creation',()=>{
  const d=structuredClone(part);d.pins[0].position=Array(3);let effects=0;bad(()=>saveData({records:()=>({}),setRecord(){effects++;}},component,d));assert.equal(effects,0);
  assert.throws(()=>pinsFor('custom',Array(1)),e=>e.code==='INVALID_ARGUMENT');assert.throws(()=>pinsFor('custom',[{label:'A',position:Array(3)}]),e=>e.code==='INVALID_ARGUMENT');
 });
 for(const [name,key,value]of [['Ground presence',RECORDS.groundPresent,[2]],['unflagged Ground',RECORDS.groundPresent,[0]],['missing Ground ID',RECORDS.ground,[0,0,0,999]]])await check(name+' corruption rejects',()=>{
  const r=nativeRecords(network);if(name==='unflagged Ground')r[RECORDS.ground].value=[0,0,0,1];r[key].value=value;bad(()=>get(r,owner));
 });
 for(const [name,edit]of [['duplicate net ID',r=>r[RECORDS.ids].value.splice(4,4,...r[RECORDS.ids].value.slice(0,4))],['duplicate net name',r=>{r[RECORDS.labels].value='AAA';r[RECORDS.offsets].value=[0,1,2,3];}],['network count',r=>r[RECORDS.header].value[2]=1025],['unexpected component column',r=>r[RECORDS.positions]={type:6,value:[]}]])await check(name+' rejects owner read without mutation',()=>{const r=nativeRecords(network);edit(r);const before=structuredClone(r);bad(()=>get(r,owner));assert.deepEqual(r,before);});
 const html=await readFile(new URL('../../../index.html',import.meta.url),'utf8');
 const section=(start,end)=>{const a=html.indexOf(start),b=html.indexOf(end,a);assert(a>=0&&b>a,start);return html.slice(a,b);};
 const codec=new Function(section('function createFrameHashCodec(){','const FrameHash=createFrameHashCodec();')+';return createFrameHashCodec();')();
 const table=new Function('hash',section('function createFrameHashRecordTable(hash){','function createFrameHashCodec(){')+';return createFrameHashRecordTable(hash);')(codec);
 const native=new Function('FrameHashRecords','nodes','undoStack','redoStack','window',section('const FramePluginRecords=(()=>{','// Strict known plugin-tag')+';return FramePluginRecords;')(table,[],[],[],{});
 const line=start=>section(start,'\n');
 const manifest=JSON.parse(await readFile(new URL('../plugin.json',import.meta.url),'utf8'));
 const remap=new Function('types','tagDefinitions',[line('  function owner(n)'),line('  function referenceField('),line('  function remapAuthoring(')].join('\n')+';return remapAuthoring;')(new Map(manifest.objects.map(o=>[o.type,{manifest}])),{});
 await check('actual core copy remaps scalar Circuit reference and preserves numeric local IDs',()=>{
  const r=nativeRecords(part),input={plugin:{id:'circuit',type:component.type,params:{Circuit:owner.nativeHash}},pluginRecords:Object.entries(r).map(([key,v])=>({key,type:v.type})),recordValues:r};
  const mapping=new Map([[owner.nativeHash,id(500)],[id(0),id(999)],[id(1),id(998)]]),copied=remap(input,mapping);
  assert.equal(copied.plugin.params.Circuit,id(500));assert.deepEqual(copied.recordValues,r);assert.deepEqual(copied.pluginRecords,input.pluginRecords);assert.deepEqual(get(copied.recordValues,component),part);assert.notEqual(copied.recordValues[RECORDS.ids].value,r[RECORDS.ids].value);
 });
 for(const [name,nets,pins,maxLabels]of [['small',2,2,false],['near-limit',1023,63,false],['exact-maximum',1024,64,true]])await check(name+' actual native HASH primitive roundtrip and payload measurement',async()=>{
  const f=fixture(nets,pins);if(maxLabels){for(const net of f.network.nets)net.name=net.name.padEnd(128,'x');for(const pin of f.part.pins)pin.label=pin.label.padEnd(64,'x');}
  if(name==='small'){f.network.nets[0].name='GND';f.network.nets[1].name='OUT';f.part.pins.forEach((pin,i)=>{pin.label=i?'B':'A';pin.position=[i?10:-10,0,0];});}
  const start=performance.now(),rows=[];let rawBytes=0,packedBytes=0,legacyRawBytes=0,legacyPackedBytes=0;
  for(const [n,data]of [[owner,f.network],[component,f.part]]){
   const r=native.native(nativeRecords(data)),packed=await Promise.all(Object.entries(r).map(async([key,row])=>{const p=await codec.pack({id:codec.address(n.nativeHash,key),...row});rawBytes+=p.rawBytes;packedBytes+=p.blob.size;return p.blob;}));rows.push(...packed);
   const legacy=await codec.pack({id:codec.address(n.nativeHash,LEGACY_RECORD),type:7,value:JSON.stringify(data)});legacyRawBytes+=legacy.rawBytes;legacyPackedBytes+=legacy.blob.size;
  }
  const blob=new Blob(rows),index=await codec.index(blob);assert.equal(index.size,13);
  for(const [n,data]of [[owner,f.network],[component,f.part]]){const records={};for(const key of Object.keys(nativeRecords(data))){const r=index.get(codec.address(n.nativeHash,key));records[key]={type:r.type,value:await codec.read(blob,r)};}assert.deepEqual(get(records,n),data);}
  const ms=performance.now()-start;assert(ms<2000);timings.push({name:name+' actual CPU HASH column encode/decode',ms,limit:2000});measurements.push({fixture:name,nets,pins,maxLabelCodeUnits:maxLabels?{net:128,pin:64}:null,rawColumnBytes:rawBytes,packedColumnBytesIncludingRecordHeaders:packedBytes,legacyJSONUTF8Bytes:legacyRawBytes,legacyPackedBytesIncludingRecordHeaders:legacyPackedBytes,scope:'Isolated plugin primitives only; excludes whole-scene metadata and native scene lifecycle.',fixtureCaveat:'Synthetic sequential local IDs, repeated positions and repeated padding are compressible. Packed sizes are fixture-specific, not forecasts for random-ID/user scenes.'});
 });
 await check('completed max-payload codec and topology operations have bounded latency',()=>{
  const f=fixture(1024,64),records=new Map([[owner.nativeHash,nativeRecords(f.network)],[component.nativeHash,nativeRecords(f.part)]]),D={nodes:[owner,component],records:hash=>records.get(hash),setRecord:(hash,key,type,value)=>records.get(hash)[key]={type,value:type===7?value:Array.from(value)}};
  for(const [name,run]of [['100 maximum-network replacements',()=>saveData(D,owner,f.network)],['100 maximum-pin replacements',()=>saveData(D,component,f.part)],['100 maximum-network reads',()=>readData(D,owner)],['100 maximum-pin reads',()=>readData(D,component)],['100 max-payload authoring topologies',()=>topology(D,owner)]]){const start=performance.now();for(let i=0;i<100;i++)run();const ms=performance.now()-start;assert(ms<1000,name);timings.push({name,ms,limit:1000});}
  const snapshot=topology(D,owner);assert.equal(snapshot.nets.length,1024);assert.equal(snapshot.components[0].pins.length,64);assert.equal(new Set(snapshot.components[0].pins.filter(p=>p.net===null).map(p=>p.node)).size,32);
 });
 return {pass:true,checks,timings,measurements,scope:'CPU actual native primitive codec/remapper plus authoring adapters; no native scene/HASH lifecycle, browser or GPU qualification.'};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))console.log(JSON.stringify(await recordChecks(),null,2));
