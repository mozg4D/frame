Frame HASH best-effort: isolated browser gate, NOT a release.

Base: qualified frame-reference-fan-r4-run (index a8e82c4e8986a57b5b4b0d72539c5bbe60dbbfb8c6671e588492bedb4a77eba0).
Candidate: a78e9964b4d096104f446f50f98866d9bdf5347d96a8c9973753b22bb56a1c02.
No Docs/CFD/thermal runtime changes, no live site or user scene is opened.

1. Verify ZIP and external manifest SHA supplied with delivery before extraction.
2. Node 22+, Playwright/playwright-core 1.64.1 and installed hardware Chromium are required. No installation or credentials are performed.
3. From extracted packet:
   node prepare.mjs "C:\Users\user\frame-gpu-check\frame-reference-fan-r4-run" "C:\Users\user\frame-gpu-check\frame-hash-best-effort-run" --dry-run
   node prepare.mjs "C:\Users\user\frame-gpu-check\frame-reference-fan-r4-run" "C:\Users\user\frame-gpu-check\frame-hash-best-effort-run"
   Choose a fresh destination if that name exists. Never overwrite an old candidate.
4. From the NEW target, use its existing tools/browser.mjs channel chromium and pinned installed executable via FRAME_BROWSER when needed:
   node tests/syntax.mjs
   node tests/hash-best-effort.mjs
   node tests/plugin-references.mjs
   node tests/hash-best-effort-browser.mjs --headless
   node tests/plugin-references-browser.mjs --headless
5. Preserve each original JSON report under a unique name, hash it, report exact source hashes, assertions/cases, adapter, GPU/page/console errors, timings and source stability. On FAIL preserve report and stop for diagnosis. Never weaken assertions or edit runtime in the tested target.

Only whitelisted verified files are copied from r4. Private test scenes, prior reports, unlisted files and directory links are not copied. All preparation preflight completes before creating the destination. Node dependencies are copied from the already installed base, not installed. Full application aggregate tests are NOT qualified by this focused packet; private scene inputs are omitted.

Cloud evidence: host best-effort 56/56, existing reference 52/52, shipped executable/lazy script syntax PASS, independent review no remaining blocker. npm test and stress attempted but blocked at missing bundled Chromium; official system Chromium was also unable to start due sandbox socket restriction even with one normal elevated retry. No browser/GPU pass claimed.

Behavior: supported native shells/hierarchy/geometry/PSR open despite unknown plugin/type/tag; missing semantics stay inactive. Declared opaque metadata/typed records survive Save. Merge/copy remap only known references. Unknown plugin/tag payloads receive persisted unresolved markers after identity changes, so later availability cannot silently bind stale strings. Undeclared extension records are omitted with diagnostics. Corrupt core/native ownership still rejects before scene replacement. Known manifests whose module activation fails remain outside this change.
