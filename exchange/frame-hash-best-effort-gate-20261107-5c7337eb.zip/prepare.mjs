import {readFile,readdir,lstat,realpath,copyFile,cp,mkdir,writeFile} from 'node:fs/promises';
import {constants} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve,relative,join,dirname,isAbsolute,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
export const packet=dirname(fileURLToPath(import.meta.url));
export const baseline='a8e82c4e8986a57b5b4b0d72539c5bbe60dbbfb8c6671e588492bedb4a77eba0';
export const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
export const exists=async path=>{try{await lstat(path);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}};
export function localPath(path){if(typeof path!=='string'||!path||isAbsolute(path)||path.includes('\\')||path.includes(':')||path.split('/').some(p=>!p||p==='.'||p==='..'))throw Error('Invalid manifest path: '+path);return path;}
export async function loadManifest(name){const value=JSON.parse(await readFile(join(packet,name),'utf8'));if(!value||Array.isArray(value)||typeof value!=='object')throw Error('Invalid manifest '+name);for(const [path,hash]of Object.entries(value)){localPath(path);if(!/^[a-f0-9]{64}$/.test(hash))throw Error('Invalid SHA256 '+path);}return value;}
export async function verifyFiles(root,manifest){for(const [path,hash]of Object.entries(manifest)){let bytes;try{bytes=await readFile(join(root,localPath(path)));}catch(error){throw Error('Required file unavailable: '+path+' ('+error.code+')');}if(sha(bytes)!==hash)throw Error('SHA256 mismatch: '+path);}return Object.keys(manifest).length;}
async function inventory(root,prefix=''){let files=[];for(const entry of await readdir(join(root,prefix),{withFileTypes:true})){const path=prefix?prefix+'/'+entry.name:entry.name;if(entry.isSymbolicLink())throw Error('Package symlinks are not allowed: '+path);if(entry.isDirectory())files.push(...await inventory(root,path));else if(entry.isFile())files.push(path);else throw Error('Unsupported package entry: '+path);}return files;}
export async function verifyPackage(){const manifest=await loadManifest('PACKAGE-SHA256.json');await verifyFiles(packet,manifest);const actual=(await inventory(packet)).filter(p=>p!=='PACKAGE-SHA256.json').sort();if(JSON.stringify(actual)!==JSON.stringify(Object.keys(manifest).sort()))throw Error('Unexpected or missing package file');return manifest;}
const inside=(a,b)=>{const rel=relative(a,b);return rel===''||(!rel.startsWith('..'+sep)&&rel!=='..'&&!isAbsolute(rel));};
async function safeDestination(base,destination){base=await realpath(resolve(base));destination=resolve(destination);if(await exists(destination))throw Error('Destination already exists; choose a fresh directory. Nothing was changed.');const parent=await realpath(dirname(destination));destination=join(parent,relative(dirname(destination),destination));if(inside(base,destination)||inside(destination,base)||inside(packet,destination)||inside(destination,packet))throw Error('Destination must be outside both the base and this package.');return {base,destination};}
async function dependencyVersions(root){for(const name of ['playwright','playwright-core']){const p=JSON.parse(await readFile(join(root,'node_modules',name,'package.json'),'utf8'));if(p.version!=='1.64.1'||p.name!==name)throw Error('Require installed '+name+' 1.64.1; no installation was attempted.');}}
export async function inspectBase(root,manifest){const missing=[];for(const [path,hash]of Object.entries(manifest)){try{if(sha(await readFile(join(root,path)))!==hash)missing.push({path,reason:'SHA256 mismatch'});}catch(error){missing.push({path,reason:error.code||error.message});}}return missing;}
export async function prepare(base,destination,{dryRun=false}={}){
 if(Number(process.versions.node.split('.')[0])<22)throw Error('Node 22 or later is required.');
 await verifyPackage();({base,destination}=await safeDestination(base,destination));
 if(sha(await readFile(join(base,'index.html')))!==baseline)throw Error('Base core is not exact a8e82c; nothing was changed.');
 await dependencyVersions(base);const baseFiles=await loadManifest('BASE-OPTIONAL.json'),overlay=await loadManifest('OVERLAY-SHA256.json');const focused=await loadManifest('BASE-REQUIRED.json');await verifyFiles(base,focused);const missingAggregate=await inspectBase(base,baseFiles),missingPaths=new Set(missingAggregate.map(x=>x.path)),copiedBase=Object.fromEntries(Object.entries({...focused,...baseFiles}).filter(([path])=>!missingPaths.has(path)&&!Object.hasOwn(overlay,path))); await verifyFiles(join(packet,'overlay'),overlay);
 const result={kind:'isolated-frame-hash-best-effort-gate',prepared:!dryRun,dryRun,base,destination,baselineSHA256:baseline,coreSHA256:overlay['index.html'],baseFiles:Object.keys(copiedBase).length,copiedBase,missingAggregate,fullSuiteInputsReady:false,omittedPrivateFixtures:true,overlayFiles:Object.keys(overlay).length,dependencies:['playwright@1.64.1','playwright-core@1.64.1'],browserStarted:false,hardwareVerified:false};
 if(dryRun)return result;
 await mkdir(destination,{recursive:false});
 for(const [root,manifest]of [[base,copiedBase],[join(packet,'overlay'),overlay]])for(const path of Object.keys(manifest)){const to=join(destination,path);await mkdir(dirname(to),{recursive:true});await copyFile(join(root,path),to,constants.COPYFILE_EXCL);}
 await mkdir(join(destination,'node_modules'));for(const name of ['playwright','playwright-core'])await cp(join(base,'node_modules',name),join(destination,'node_modules',name),{recursive:true,dereference:true,force:false,errorOnExist:true});
 await verifyFiles(destination,{...copiedBase,...overlay});await dependencyVersions(destination);
 // Detect source changes during copying; never report a partial copy as ready.
 if(sha(await readFile(join(base,'index.html')))!==baseline)throw Error('Base core changed during preparation. Target is incomplete; do not run it.');await verifyFiles(base,copiedBase);await verifyFiles(join(packet,'overlay'),overlay);
 await writeFile(join(destination,'HASH-BEST-EFFORT-PREPARED.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});return result;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const args=process.argv.slice(2),dryRun=args.includes('--dry-run'),pos=args.filter(a=>a!=='--dry-run');
 try{if(pos.length!==2||args.some(a=>a.startsWith('--')&&a!=='--dry-run'))throw Error('Usage: node prepare.mjs <exact qualified reference/Fan r4 base> <fresh destination> [--dry-run]');console.log(JSON.stringify(await prepare(pos[0],pos[1],{dryRun}),null,2));}catch(error){console.error(error.message);process.exitCode=1;}
}
