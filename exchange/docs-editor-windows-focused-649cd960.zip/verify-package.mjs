import {readFile} from 'node:fs/promises';import {createHash} from 'node:crypto';
const manifest=JSON.parse(await readFile(new URL('./PACKAGE-SHA256.json',import.meta.url),'utf8'));
for(const [path,sha] of Object.entries(manifest)){const b=await readFile(new URL(path,import.meta.url));if(createHash('sha256').update(b).digest('hex')!==sha)throw Error('SHA mismatch: '+path);}
console.log('PASS '+Object.keys(manifest).length+' package files verified');
