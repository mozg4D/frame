TECHNICAL TEST ONLY. Isolated Docs editor candidate, not main/live or the qualified HASH+Docs-core integration. No release approval. No user scenes/models or node_modules. Empty scene and small Unicode documentation only, no stress loop. The archive contains required runtime modules and focused test tools; Playwright and Chromium are external prerequisites.

In a NEW extracted folder, PowerShell:
  Get-FileHash .\index.html -Algorithm SHA256
Expected index: 2806261924a5e0229fe0f2b62a9c23e277505810ec45aa8c0b87cc05cd2e5531
  node .\verify-package.mjs
If dependencies are not installed (requires network and disk space):
  npm.cmd ci
  npx.cmd playwright install chromium
Do not install while a time-sensitive print/recording is running. These are not automatic package actions.
  node .\tests\documentation-sync.mjs
  node .\tests\documentation-selection.mjs
  node .\tests\scene-documentation.mjs
  node .\tests\documentation-browser.mjs

The last command launches one visible Chromium session and a documentation popup, serving only a loopback address. It starts Frame WebGPU but performs no Structural/Thermal/CFD solve or large mesh workloads. Close unrelated Frame sessions if desired. Do not use an existing user scene. Runtime result: DOCS-BROWSER-RESULT.json, including failing stage/stack; return full file, console and browser version/adapter environment. A failure must not be skipped or converted to PASS.

Coverage: actual separate window, native typing and Undo including clear/ack/Undo; realtime API edits, caret after prefix insertion; native HASH export/new/open of Unicode text; concurrent disjoint local synthetic composition and queued API edit; same-scene deletion stays editable, new empty scene disables editor; focus reuse.
Synthetic composition events check code ordering ONLY, not OS IME. Manual follow-up remains mandatory: real Windows Japanese/Chinese IME while another window edits; selection and Undo/Redo across remote edits; overlapping edit recovery; popup-blocked and installed PWA behaviors; native Save/Open/Share and HASH Merge workflows. No claim of browser/GPU PASS until actual run and review.
