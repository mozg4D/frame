// Requires a real browser/WebGPU Frame startup. Not a CPU pass substitute.
import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
const report={pass:false,checks:[],limitations:['Synthetic composition events are not real OS IME qualification','No installed PWA/popup blocker qualification','No production or merged HASH core qualification']};
import {launch,ready} from '../tools/browser.mjs';
const browser=await launch({headless:process.argv.includes('--headless')});
try{
 const page=browser.page;page.on('pageerror',e=>(report.pageErrors??=[]).push(e.message));await ready(page);const call=(name,args={})=>page.evaluate(([n,a])=>frameAI.call(n,a),[name,args]);
 assert.equal(await page.locator('#btnDocs').isHidden(),true);
 let s=await call('docs.get');await call('docs.create',{text:'alpha\nomega',version:s.version});await page.locator('#btnDocs').waitFor({state:'visible'});
 const opened=page.waitForEvent('popup');await page.locator('#btnDocs').click();const editor=await opened;await editor.waitForSelector('textarea:enabled');assert.equal(await editor.locator('textarea').inputValue(),'alpha\nomega');
 await editor.locator('textarea').focus();await editor.keyboard.press('Control+End');await editor.keyboard.type('!');await page.waitForFunction(()=>frameDocumentation.get().text.endsWith('!'));
 await editor.keyboard.press('Control+z');await page.waitForFunction(()=>frameDocumentation.get().text==='alpha\nomega');
 s=await call('docs.get');await call('docs.update',{text:'ALPHA\nomega',version:s.version});await editor.waitForFunction(()=>document.querySelector('textarea').value==='ALPHA\nomega');
 await editor.locator('textarea').focus();await editor.keyboard.press('Control+End');await editor.keyboard.type('?');await page.waitForFunction(()=>frameDocumentation.get().text==='ALPHA\nomega?');
 await editor.keyboard.press('Control+z');await page.waitForFunction(()=>frameDocumentation.get().text==='ALPHA\nomega');
 await editor.locator('textarea').evaluate(e=>e.setSelectionRange(3,3,'none'));s=await call('docs.get');await call('docs.update',{text:'XX'+s.text,version:s.version});await editor.waitForFunction(()=>document.querySelector('textarea').value.startsWith('XX'));assert.equal(await editor.locator('textarea').evaluate(e=>e.selectionStart),5);assert.equal(await editor.locator('output').isHidden(),true);
 const beforeClear=await editor.locator('textarea').inputValue();await editor.locator('textarea').focus();await editor.keyboard.press('Control+a');await editor.keyboard.press('Backspace');await page.waitForFunction(()=>frameDocumentation.get().text==='');assert.equal(await editor.locator('textarea').isEnabled(),true);await editor.keyboard.press('Control+z');await page.waitForFunction(text=>frameDocumentation.get().text===text,beforeClear);
 report.checks.push('popup, typing Undo, remote updates, selection, clear-ack Undo');
 // Exercise the real native codec with Unicode text, no mesh or stress workload.
 const unicode='Требования 😀\n日本語 é\nObject: '+ 'a'.repeat(32);s=await call('docs.get');await call('docs.update',{text:unicode,version:s.version});await editor.waitForFunction(text=>document.querySelector('textarea').value===text,unicode);
 const exported=await call('scene.export',{includeData:true,format:'hash'});assert.ok(exported.bytes>0&&exported.bytes<1024*1024);await call('scene.new');await editor.waitForSelector('textarea:disabled');await call('scene.open',{base64:exported.base64,name:'documentation-roundtrip.hash'});assert.equal((await call('docs.get')).text,unicode);await editor.waitForFunction(text=>document.querySelector('textarea').value===text,unicode);assert.equal(await editor.locator('textarea').isEnabled(),true);report.checks.push('native HASH export/new/open Unicode roundtrip');
 // Synthetic IME ordering: hold local composition while an actual queued API edit arrives.
 s=await call('docs.get');await call('docs.update',{text:'alpha\nomega',version:s.version});await editor.waitForFunction(()=>document.querySelector('textarea').value==='alpha\nomega');
 await editor.locator('textarea').evaluate(e=>{e.dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true}));e.value='日本alpha\nomega';e.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true,inputType:'insertCompositionText',data:'日本'}));});
 s=await call('docs.get');await call('docs.update',{text:'alpha\nomega!',version:s.version});assert.equal(await editor.locator('textarea').inputValue(),'日本alpha\nomega');await editor.locator('textarea').evaluate(e=>e.dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:'日本'})));await page.waitForFunction(()=>frameDocumentation.get().text==='日本alpha\nomega!');await editor.waitForFunction(()=>document.querySelector('textarea').value==='日本alpha\nomega!');report.checks.push('synthetic composition deferral plus concurrent disjoint API edit, CAS rebase');
 const pages=page.context().pages().length;await page.locator('#btnDocs').click();assert.equal(page.context().pages().length,pages);
 s=await call('docs.get');await call('docs.delete',{version:s.version});await editor.waitForFunction(()=>document.querySelector('textarea').value==='');assert.equal(await editor.locator('textarea').isEnabled(),true);assert.equal(await editor.locator('textarea').inputValue(),'');assert.equal(await page.locator('#btnDocs').isHidden(),true);await editor.close();
 report.checks.push('reuse, same-scene remote delete retains enabled editor');assert.equal(report.pageErrors?.length||0,0);report.pass=true;
}catch(error){report.error=error.stack||String(error);process.exitCode=1;}finally{await writeFile(new URL('../DOCS-BROWSER-RESULT.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await browser.close();}
