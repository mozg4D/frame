// One contiguous edit envelope. Conservative: overlapping envelopes conflict.
const splitPair=(s,i)=>i>0&&i<s.length&&/[\uD800-\uDBFF]/.test(s[i-1])&&/[\uDC00-\uDFFF]/.test(s[i]);
export function edit(base,text){let start=0,end=base.length,tail=text.length;while(start<end&&start<tail&&base[start]===text[start])start++;while(end>start&&tail>start&&base[end-1]===text[tail-1]){end--;tail--;}if(splitPair(base,start)||splitPair(text,start))start--;if(splitPair(base,end))end++;if(splitPair(text,tail))tail++;return {start,end,text:text.slice(start,tail)};}
// Insertions at a boundary have right affinity. Positions inside a replacement
// move to its end; the left edge of a nonempty replacement stays at its start.
export function selectionAfter(base,text,start,end,direction='none'){
 const e=edit(base,text),delta=e.text.length-(e.end-e.start),map=p=>p<e.start?p:p>=e.end?p+delta:p===e.start?e.start:e.start+e.text.length;
 let a=Math.max(0,Math.min(text.length,map(start))),b=Math.max(0,Math.min(text.length,map(end)));
 if(start===end){if(splitPair(text,a))a++;b=a;}else{if(splitPair(text,a))a--;if(splitPair(text,b))b++;}
 return {start:a,end:b,direction};
}
export function presentation(s){return {disabled:!s.editable&&!s.text&&!s.pending&&!s.dirty&&!s.fault,readOnly:!!s.fault,message:s.fault||''};}

export function rebase(base,local,remote){
 if(local===base)return remote;if(remote===base||local===remote)return local;
 const a=edit(base,local),b=edit(base,remote);
 // Same-position insertions and touching edit boundaries are intentionally ambiguous.
 if(a.end<b.start)return remote.slice(0,a.start)+a.text+remote.slice(a.end);
 if(b.end<a.start){const shift=b.text.length-(b.end-b.start),start=a.start+shift,end=a.end+shift;return remote.slice(0,start)+a.text+remote.slice(end);}
 throw Error('Concurrent changes overlap. Your draft is retained; copy it before reopening.');
}
const epoch=s=>s.version.slice(0,s.version.lastIndexOf(':'));
const newer=(a,b)=>epoch(a)!==epoch(b)||Number(a.version.split(':').at(-1))>Number(b.version.split(':').at(-1));
export function session({send,changed}){
 let base=null,draft='',pending=null,latest=null,fault='',next=0,editable=false;
 const emit=()=>changed({text:draft,editable,version:base?.version,pending:!!pending,dirty:!!base&&draft!==base.text,fault});
 function integrate(s){if(!base){base=s;draft=s.text;editable=!!s.text;return;}if(epoch(s)!==epoch(base)){if(pending||draft!==base.text)throw Error('Scene changed. Your previous-scene draft is retained; copy it before reopening.');base=s;draft=s.text;editable=!!s.text;return;}if(!newer(s,base))return;draft=rebase(base.text,draft,s.text);base=s;editable||=!!s.text;}
 function pump(){if(fault||pending||!base||draft===base.text)return;pending={id:++next,text:draft,base};send({kind:'write',id:pending.id,text:draft,version:base.version});}
 return {input(text){if(!editable||fault)return;draft=text;pump();emit();},snapshot(s){if(fault)return;if(pending){if(!latest||newer(s,latest))latest=s;emit();return;}try{integrate(s);pump();}catch(e){fault=e.message;}emit();},reply(m){if(!pending||m.id!==pending.id)return;const p=pending;pending=null;try{if(m.ok){const s=m.state;if(epoch(s)!==epoch(p.base))throw Error('Scene changed while saving; draft retained.');draft=draft===p.text?s.text:rebase(p.text,draft,s.text);base=s;}else if(m.code!=='CONFLICT')throw Error(m.error||'Save failed; draft retained.');if(latest){const s=latest;latest=null;integrate(s);}if(!m.ok&&!fault&&base.version===p.base.version)throw Error(m.error||'Save conflict; draft retained.');pump();}catch(e){fault=e.message;}emit();},disconnect(){fault='Main scene connection closed. Draft retained here; copy it before closing.';emit();},get state(){return {base,draft,pending,fault};}};
}
