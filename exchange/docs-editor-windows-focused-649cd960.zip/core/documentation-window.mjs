export function installDocumentationWindow({button,api,read,events=window,host=window}){
 let child=null,port=null,token=null;
 const refresh=()=>{const state=read();button.hidden=!state.text;port?.postMessage({kind:'snapshot',state});};
 const ready=event=>{if(!child||event.source!==child||event.origin!==location.origin||event.data?.kind!=='frame-docs-ready'||event.data.token!==token)return;port?.close();const channel=new MessageChannel();port=channel.port1;const active=port;let busy=false;
 active.onmessage=async event=>{const m=event.data;if(m?.kind!=='write'||!Number.isSafeInteger(m.id)||typeof m.text!=='string'||typeof m.version!=='string')return;if(busy){active.postMessage({kind:'reply',id:m.id,ok:false,error:'A documentation write is already pending'});return;}busy=true;try{const state=await api.call('docs.update',{text:m.text,version:m.version});active.postMessage({kind:'reply',id:m.id,ok:true,state});}catch(e){active.postMessage({kind:'snapshot',state:read()});active.postMessage({kind:'reply',id:m.id,ok:false,code:e.code,error:e.message});}finally{busy=false;}};
 child.postMessage({kind:'frame-docs-connect',token},location.origin,[channel.port2]);refresh();};
 button.onclick=()=>{if(child&&!child.closed){child.focus();return;}token=crypto.randomUUID();child=host.open(new URL('../documentation.html#'+token,import.meta.url),'frame-docs-'+token,'popup,width=760,height=700');if(!child)host.alert('Allow this documentation window to open, then click Docs again.');};
 events.addEventListener('frame-documentation-change',refresh);host.addEventListener('message',ready);host.addEventListener('pagehide',()=>{port?.postMessage({kind:'closed'});port?.close();});refresh();
}
