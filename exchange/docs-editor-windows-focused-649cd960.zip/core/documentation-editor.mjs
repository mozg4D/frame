import {session,edit,selectionAfter,presentation} from './documentation-sync.mjs';
const area=document.querySelector('textarea'),status=document.querySelector('output'),token=location.hash.slice(1);let port=null,composing=false,deferred=[],lastState=null;
function paint(s){lastState=s;if(composing)return;if(area.value!==s.text){const change=edit(area.value,s.text),selection=selectionAfter(area.value,s.text,area.selectionStart,area.selectionEnd,area.selectionDirection);area.setRangeText(change.text,change.start,change.end,'preserve');area.setSelectionRange(selection.start,selection.end,selection.direction);}const ui=presentation(s);area.disabled=ui.disabled;area.readOnly=ui.readOnly;status.dataset.error=String(!!s.fault);status.textContent=ui.message;status.hidden=!ui.message;}

const sync=session({send:m=>port.postMessage(m),changed:paint});
window.addEventListener('message',event=>{if(port||event.source!==opener||event.origin!==location.origin||event.data?.kind!=='frame-docs-connect'||event.data.token!==token||event.ports.length!==1)return;port=event.ports[0];port.onmessage=event=>{if(composing)deferred.push(event.data);else receive(event.data);};port.onmessageerror=()=>sync.disconnect();});
function receive(m){if(m?.kind==='snapshot')sync.snapshot(m.state);else if(m?.kind==='reply')sync.reply(m);else if(m?.kind==='closed')sync.disconnect();}
area.addEventListener('input',()=>{if(!composing)sync.input(area.value);});
area.addEventListener('compositionstart',()=>composing=true);
area.addEventListener('compositionend',()=>{composing=false;sync.input(area.value);const messages=deferred;deferred=[];for(const m of messages)receive(m);});
window.addEventListener('beforeunload',e=>{if(lastState?.pending||lastState?.dirty||lastState?.fault||composing){e.preventDefault();e.returnValue='';}});
window.addEventListener('pagehide',()=>port?.close());
if(opener&&token)opener.postMessage({kind:'frame-docs-ready',token},location.origin);else{status.hidden=false;status.textContent='Open documentation from the scene’s Docs button.';}
setInterval(()=>{if(port&&(!opener||opener.closed))sync.disconnect();},1000);
