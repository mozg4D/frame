import {chromium} from 'playwright';
import {readFile,writeFile} from 'node:fs/promises';
import {serve} from '../tools/browser.mjs';
const server=await serve(),browser=await chromium.launch({headless:true,executablePath:process.env.FRAME_BROWSER,ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
try{
 const context=await browser.newContext(),page=await context.newPage(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const start=html.indexOf('const FrameDocumentation='),end=html.indexOf('const FramePlugins=',start);
 await page.route('**/fixture.html',route=>route.fulfill({contentType:'text/html',body:`<button id="doc">Doc</button><textarea id="control"></textarea><script type="module">import {installDocumentationWindow} from '/core/documentation-window.mjs';${html.slice(start,end)}let text='';const docs=FrameDocumentation.create({read:()=>text,write:v=>text=v,notify:state=>dispatchEvent(new CustomEvent('frame-documentation-change',{detail:state}))});window.docs=docs;installDocumentationWindow({button:document.getElementById('doc'),read:()=>docs.get(),write:async(a,g)=>{g();return docs.update(a)}});window.ready=true;</script>`}));
 await page.goto(server.url+'/fixture.html');await page.waitForFunction(()=>window.ready);
 const opened=page.waitForEvent('popup');await page.click('#doc');const popup=await opened;await popup.waitForFunction(()=>{const e=document.querySelector('textarea');return e&&!e.disabled&&!e.readOnly;});
 await popup.evaluate(()=>{window.log=[];const a=document.querySelector('textarea');for(const t of ['beforeinput','input'])a.addEventListener(t,e=>log.push({event:t,type:e.inputType,text:a.value,data:e.data}));const f=a.setRangeText;a.setRangeText=function(...args){log.push({event:'setRangeText',args});return f.apply(this,args);};});
 const results=[];
 for(const [label,p,selector] of [['doc',popup,'textarea'],['control',page,'#control']])for(const word of ['word','слово']){
  const area=p.locator(selector);await area.fill('');await area.pressSequentially(word,{delay:100});await p.keyboard.press('Enter');await p.waitForTimeout(250);const steps=[{action:'typed',text:await area.inputValue()}];for(let i=0;i<4;i++){await p.keyboard.press('Control+z');await p.waitForTimeout(50);steps.push({action:'undo '+i,text:await area.inputValue()});}results.push({label,word,steps});
 }
 for(const remote of [false,true]){
  await popup.close();await page.evaluate(()=>{docs.update({text:'',version:docs.get().version});});const next=page.waitForEvent('popup');await page.click('#doc');const p=await next;await p.waitForFunction(()=>{const e=document.querySelector('textarea');return e&&!e.disabled&&!e.readOnly;});
  const a=p.locator('textarea');await a.pressSequentially('hello world',{delay:40});await page.waitForFunction(()=>docs.get().text==='hello world');
  if(remote){await page.evaluate(()=>docs.update({text:'PREFIX hello world',version:docs.get().version}));await p.waitForFunction(()=>document.querySelector('textarea').value==='PREFIX hello world');}
  await p.keyboard.press('ArrowLeft');await p.keyboard.press('ArrowLeft');await p.keyboard.press('Enter');await p.waitForTimeout(200);const steps=[{action:'typed middle newline',text:await a.inputValue()}];
  for(let i=0;i<5;i++){await p.keyboard.press('Control+z');await p.waitForTimeout(70);steps.push({action:'undo '+i,text:await a.inputValue()});}results.push({label:'middle newline',remote,steps});
  if(remote)await p.close();else await p.close();
 }
 const report={results};await writeFile(new URL('./results/doc-undo-baseline.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}finally{await browser.close();await server.close();}
