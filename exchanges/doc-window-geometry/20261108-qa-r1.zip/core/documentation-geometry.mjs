// Window preferences only. No document text, scene state or display permission.
const key='frame-docs-window-v1';
const finite=(n,min,max)=>typeof n==='number'&&Number.isFinite(n)&&n>=min&&n<=max;
const clamp=(n,min,max)=>Math.max(min,Math.min(n,max));
function workArea(screen){
 if(!screen||!finite(screen.availWidth,100,32768)||!finite(screen.availHeight,100,32768))return null;
 return {left:finite(screen.availLeft,-1000000,1000000)?Math.round(screen.availLeft):0,top:finite(screen.availTop,-1000000,1000000)?Math.round(screen.availTop):0,width:Math.round(screen.availWidth),height:Math.round(screen.availHeight)};
}
function valid(g){return g&&finite(g.left,-1000000,1000000)&&finite(g.top,-1000000,1000000)&&finite(g.width,100,32768)&&finite(g.height,100,32768)&&finite(g.outerWidth,g.width,32768)&&finite(g.outerHeight,g.height,32768);}
export function documentationWindowFeatures(host=window){
 let saved;try{saved=JSON.parse(host.localStorage.getItem(key));}catch{}
 const current=workArea(host.screen);
 if(!valid(saved)){
  const width=Math.min(760,current?.width||760),height=Math.min(700,Math.max(100,(current?.height||780)-80));
  return `popup,width=${width},height=${height}`;
 }
 // The current work area wins when its origin matches, or only one screen is
 // available. Otherwise keep the saved monitor; window.open itself rejects or
 // clamps unavailable placement. Never request screen enumeration permission.
 const previous=workArea(saved.screen&&{availLeft:saved.screen.left,availTop:saved.screen.top,availWidth:saved.screen.width,availHeight:saved.screen.height});
 const area=current&&(!previous||host.screen?.isExtended!==true||current.left===previous.left&&current.top===previous.top)?current:previous;
 const chromeWidth=saved.outerWidth-saved.width,chromeHeight=saved.outerHeight-saved.height;
 const width=Math.round(Math.min(saved.width,Math.max(100,(area?.width||32768)-chromeWidth))),height=Math.round(Math.min(saved.height,Math.max(100,(area?.height||32768)-chromeHeight)));
 const left=Math.round(area?clamp(saved.left,area.left,area.left+Math.max(0,area.width-width-chromeWidth)):saved.left),top=Math.round(area?clamp(saved.top,area.top,area.top+Math.max(0,area.height-height-chromeHeight)):saved.top);
 return `popup,width=${width},height=${height},left=${left},top=${top}`;
}
export function installDocumentationGeometry(host=window){
 let last='';
 const save=()=>{
  try{
   const g={left:host.screenX,top:host.screenY,width:host.innerWidth,height:host.innerHeight,outerWidth:host.outerWidth,outerHeight:host.outerHeight,screen:workArea(host.screen)};
   if(!valid(g))return;
   for(const k of ['left','top','width','height','outerWidth','outerHeight'])g[k]=Math.round(g[k]);
   const value=JSON.stringify(g);if(value===last)return;
   host.localStorage.setItem(key,value);last=value;
  }catch{} // Blocked/quota-limited preferences must not affect draft safety.
 };
 // Browsers expose resize, but no cross-browser window-move event.
 const timer=host.setInterval(save,1000);
 for(const name of ['resize','blur','beforeunload'])host.addEventListener(name,save);
 host.addEventListener('pagehide',()=>{save();host.clearInterval(timer);});
 save();
}
