import {chromium} from 'playwright';
import {readFile} from 'node:fs/promises';
import {serve} from '../tools/browser.mjs';
const server=await serve(), browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium'});
try {
const context=await browser.newContext(),page=await context.newPage();
const html=await readFile(new URL('../index.html',import.meta.url),'utf8'),start=html.indexOf('const FrameDocumentation='),end=html.indexOf('const FramePlugins=',start);
await page.route('**/fixture.html',route=>route.fulfill({contentType:'text/html',body:`<button id="doc">Doc</button><script type="module">import {installDocumentationWindow} from '/core/documentation-window.mjs';${html.slice(start,end)}let text='';const docs=FrameDocumentation.create({read:()=>text,write:v=>text=v,notify:state=>dispatchEvent(new CustomEvent('frame-documentation-change',{detail:state}))});window.docs=docs;installDocumentationWindow({button:document.getElementById('doc'),read:()=>docs.get(),write:async(a,g)=>{g();return docs.update(a)}});window.ready=true;</script>`}));
await page.goto(server.url+'/fixture.html');await page.waitForFunction(()=>window.ready);
const popup=page.waitForEvent('popup');await page.click('#doc');const doc=await popup;await doc.locator('textarea:not([disabled])').waitFor();
await doc.evaluate(()=>{window.log=[];for(const t of ['beforeinput','input'])document.querySelector('textarea').addEventListener(t,e=>log.push({event:t,type:e.inputType,text:e.target.value,data:e.data}));const area=document.querySelector('textarea'),range=area.setRangeText;area.setRangeText=function(...args){log.push({event:'setRangeText',args});return range.apply(this,args)};});
const output=[];
for(const word of ['word','слово']) {
await doc.locator('textarea').fill('');await doc.locator('textarea').pressSequentially(word,{delay:100});await doc.keyboard.press('Enter');await doc.waitForTimeout(250);output.push({phase:'typed',text:await doc.locator('textarea').inputValue()});for(let i=0;i<4;i++){await doc.keyboard.press('Control+z');await doc.waitForTimeout(50);output.push({phase:'undo'+i,text:await doc.locator('textarea').inputValue()});}}
console.log(JSON.stringify({output,log:await doc.evaluate(()=>log)},null,2));
} finally {await browser.close();await server.close();}
